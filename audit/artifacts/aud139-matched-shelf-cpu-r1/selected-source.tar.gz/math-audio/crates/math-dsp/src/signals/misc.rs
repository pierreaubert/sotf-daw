/// Clip a sample to prevent overflow in PCM conversion
#[inline]
pub fn clip(x: f32) -> f32 {
    x.clamp(-0.999_999, 0.999_999)
}

/// Calculate number of frames for given duration and sample rate
#[inline]
pub fn frames_for(duration: f32, sample_rate: u32) -> usize {
    (duration * sample_rate as f32).round() as usize
}

pub(super) fn mls_taps(order: u8) -> Option<&'static [u8]> {
    match order {
        2 => Some(&[2, 1]),
        3 => Some(&[3, 1]),
        4 => Some(&[4, 1]),
        5 => Some(&[5, 2]),
        6 => Some(&[6, 1]),
        7 => Some(&[7, 1]),
        8 => Some(&[8, 6, 5, 4]),
        9 => Some(&[9, 4]),
        10 => Some(&[10, 3]),
        11 => Some(&[11, 2]),
        12 => Some(&[12, 6, 4, 1]),
        13 => Some(&[13, 4, 3, 1]),
        14 => Some(&[14, 5, 3, 1]),
        15 => Some(&[15, 1]),
        16 => Some(&[16, 14, 13, 11]),
        17 => Some(&[17, 3]),
        18 => Some(&[18, 7]),
        19 => Some(&[19, 5, 2, 1]),
        20 => Some(&[20, 3]),
        21 => Some(&[21, 2]),
        22 => Some(&[22, 1]),
        23 => Some(&[23, 5]),
        24 => Some(&[24, 4, 3, 1]),
        _ => None,
    }
}

/// Interleave per-channel signals into a multi-channel interleaved buffer
///
/// Takes a vector of per-channel signals and interleaves them frame-by-frame.
///
/// # Arguments
/// * `per_channel` - Vector of per-channel signals (each `Vec<f32>` is one channel)
///
/// # Returns
/// Interleaved signal where samples are ordered: [ch0_frame0, ch1_frame0, ..., ch0_frame1, ch1_frame1, ...]
///
/// # Panics
/// Panics if the channels do not all have equal length — interleaving
/// requires the same number of frames per channel.
pub fn interleave_per_channel(per_channel: &[Vec<f32>]) -> Vec<f32> {
    let n_channels = per_channel.len();
    if n_channels == 0 {
        return Vec::new();
    }
    let n_frames = per_channel[0].len();
    assert!(
        per_channel.iter().all(|ch| ch.len() == n_frames),
        "interleave_per_channel: all channels must have equal length \
         (channel 0 has {n_frames} frames)"
    );
    let mut interleaved = Vec::with_capacity(n_frames * n_channels);

    for frame in 0..n_frames {
        for channel_data in per_channel.iter().take(n_channels) {
            interleaved.push(channel_data[frame]);
        }
    }

    interleaved
}

/// Replicate a mono signal to multiple channels
///
/// Takes a mono signal and replicates it to all channels.
///
/// # Arguments
/// * `mono` - Mono signal
/// * `channels` - Number of output channels
///
/// # Returns
/// Interleaved multi-channel signal with the same content on all channels
pub fn replicate_mono(mono: &[f32], channels: u16) -> Vec<f32> {
    let n_frames = mono.len();
    let mut interleaved = Vec::with_capacity(n_frames * channels as usize);

    for &sample in mono {
        for _ in 0..channels {
            interleaved.push(sample);
        }
    }

    interleaved
}

/// Add silence padding to the beginning and end of a signal
///
/// # Arguments
/// * `signal` - Original signal
/// * `pre_samples` - Number of silence samples to add before
/// * `post_samples` - Number of silence samples to add after
///
/// # Returns
/// New signal with padding
pub fn add_silence_padding(signal: &[f32], pre_samples: usize, post_samples: usize) -> Vec<f32> {
    let total_len = pre_samples + signal.len() + post_samples;
    let mut padded = vec![0.0; total_len];

    // Copy original signal in the middle
    padded[pre_samples..pre_samples + signal.len()].copy_from_slice(signal);

    padded
}

/// Convert mono signal to stereo by copying to both channels
pub fn mono_to_stereo(mono_signal: Vec<f32>) -> Vec<f32> {
    let mut stereo_signal = Vec::with_capacity(mono_signal.len() * 2);
    for sample in mono_signal {
        stereo_signal.push(sample); // Left channel
        stereo_signal.push(sample); // Right channel
    }
    stereo_signal
}

/// Direct single-bin DFT evaluated with the `sin` convention:
///   `s[k] ≈ A · sin(ωk + φ)` → `phase = atan2(imag, real)`.
///
/// Returns the raw `(real, imag)` accumulators so callers can either
/// compute magnitude themselves or average across windows without
/// extra trigonometry.
///
/// The `k_offset` argument lets sub-slices of a larger signal share a
/// common time reference. When analysing `signal[mid..]`, pass
/// `k_offset = mid` so the projection basis stays anchored at the
/// original `t = 0`; otherwise the two halves' phase measurements
/// acquire a synthetic offset proportional to `mid · ω`.
#[inline]
pub(super) fn single_bin_dft(
    signal: &[f32],
    freq_hz: f32,
    sample_rate: u32,
    k_offset: usize,
) -> (f64, f64) {
    let omega = 2.0 * std::f64::consts::PI * freq_hz as f64 / sample_rate as f64;
    let mut re = 0.0_f64;
    let mut im = 0.0_f64;
    // Reference convention: the emitted burst is `sin(ω·t)`. A pure
    // sin-phase signal should produce `phase = 0`. Projecting onto
    // `sin(ω·t)` (real part) and `+cos(ω·t)` (imag part) makes
    // `atan2(imag, real)` return the phase of a sin-referenced tone:
    //   sin(ωt) → phase = 0°
    //   cos(ωt) → phase = +90°
    //   −sin(ωt) → phase = ±180°
    //
    // The basis is advanced by complex rotation (`z *= e^{iω}`) in f64
    // instead of calling sin/cos per sample; drift over practical buffer
    // lengths is ~N·2⁻⁵³, far below the phase tests' tolerances (pinned
    // by `single_bin_dft_recurrence_matches_direct_trig`).
    let theta0 = omega * k_offset as f64;
    let mut sin = theta0.sin();
    let mut cos = theta0.cos();
    let step_sin = omega.sin();
    let step_cos = omega.cos();
    for &s in signal {
        let x = s as f64;
        re += x * sin;
        im += x * cos;
        let next_sin = sin * step_cos + cos * step_sin;
        cos = cos * step_cos - sin * step_sin;
        sin = next_sin;
    }
    (re, im)
}
