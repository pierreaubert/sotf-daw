/// Time constant (ms) to one-pole coefficient.
#[inline]
pub(super) fn time_to_coeff(time_ms: f32, sample_rate: u32) -> f32 {
    if time_ms <= 0.0 {
        0.0
    } else {
        (-1.0 / (time_ms * 0.001 * sample_rate as f32)).exp()
    }
}

#[inline]
pub(super) fn hold_ms_to_samples(hold_ms: f32, sample_rate: u32) -> usize {
    (hold_ms * 0.001 * sample_rate as f32) as usize
}
