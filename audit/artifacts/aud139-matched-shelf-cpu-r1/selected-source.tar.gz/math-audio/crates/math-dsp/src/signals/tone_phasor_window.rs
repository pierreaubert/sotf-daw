use super::misc::single_bin_dft;
use super::types::TonePhasorWindow;

/// Collect per-window single-bin lock-in phasors at `freq_hz`. Drops
/// the first and last `len/8` samples (settling around the fades),
/// splits the remaining steady portion into ≥ 1 sub-windows snapped to
/// integer cycles, and runs `single_bin_dft` on each.
///
/// Minimum-resolvable frequency on a buffer of length `n` is
/// `8 · num_windows · freq_hz ≤ sample_rate`; below that, the helper
/// merges sub-windows so each still spans ≥ 1 full cycle (down to a
/// single sub-window) — this keeps the per-bin DFT leakage-free
/// instead of returning falsely-confident sub-cycle estimates.
///
/// Returns an empty vector for degenerate inputs (signal too short,
/// `num_windows == 0`, `freq_hz <= 0`, fewer than one cycle even after
/// merging).
pub fn tone_phase_phasors(
    signal: &[f32],
    freq_hz: f32,
    sample_rate: u32,
    num_windows: usize,
) -> Vec<TonePhasorWindow> {
    if signal.len() < 8 || freq_hz <= 0.0 || sample_rate == 0 || num_windows == 0 {
        return Vec::new();
    }
    let settle = signal.len() / 8;
    let steady_start = settle;
    let steady_end = signal.len() - settle;
    if steady_end <= steady_start + 1 {
        return Vec::new();
    }
    let steady_len = steady_end - steady_start;
    let samples_per_cycle = sample_rate as f64 / freq_hz as f64;
    let min_cycle_samples = samples_per_cycle.ceil() as usize;
    if min_cycle_samples < 2 || steady_len < min_cycle_samples {
        // Less than one full cycle of the target frequency fits in the
        // analysis region — single-bin DFT below one cycle has severe
        // spectral leakage with falsely-low circular-std (correlated
        // bias across sub-windows). Refuse to produce results rather
        // than mislead the caller.
        return Vec::new();
    }
    // Aim for `num_windows` sub-windows but never split below one
    // full cycle. Effective count is the largest k in [1, num_windows]
    // such that floor(steady_len / k) >= samples_per_cycle.
    let mut effective_windows = num_windows;
    while effective_windows > 1 && steady_len / effective_windows < min_cycle_samples {
        effective_windows -= 1;
    }
    let raw_win_len = steady_len / effective_windows;
    let complete_cycles = (raw_win_len as f64 / samples_per_cycle).floor() as usize;
    if complete_cycles == 0 {
        return Vec::new();
    }
    // Round the total duration of all complete cycles once. Rounding a single
    // cycle and multiplying it accumulates the fractional-sample error and can
    // leave long windows noticeably short or long of an integer cycle count.
    let win_len = (complete_cycles as f64 * samples_per_cycle).round() as usize;

    let mut out = Vec::with_capacity(effective_windows);
    for w in 0..effective_windows {
        let start = steady_start + w * win_len;
        let end = start + win_len;
        if end > signal.len() {
            break;
        }
        let (re, im) = single_bin_dft(&signal[start..end], freq_hz, sample_rate, start);
        out.push(TonePhasorWindow {
            re,
            im,
            start,
            len: win_len,
        });
    }
    out
}

/// Magnitude-squared coherence between two per-window phasor streams
/// at the same frequency, in `[0, 1]`. Both streams must have the same
/// length and matching `start` indices (use [`tone_phase_phasors`] on
/// the same signal layout).
///
/// Returns:
///   `γ² = |⟨X · conj(Y)⟩|² / (⟨|X|²⟩ · ⟨|Y|²⟩)`
///
/// `1.0` means the two streams' per-window phasors are perfectly
/// linearly related (clean linkage between mic and loopback);
/// values toward `0.0` indicate uncorrelated noise on either side.
/// Returns `None` when the inputs disagree on length / start indices
/// or when either stream has zero energy.
pub fn phasor_coherence(a: &[TonePhasorWindow], b: &[TonePhasorWindow]) -> Option<f64> {
    if a.is_empty() || a.len() != b.len() {
        return None;
    }
    if !a
        .iter()
        .zip(b)
        .all(|(p, q)| p.start == q.start && p.len == q.len)
    {
        return None;
    }
    let mut cross_re = 0.0_f64;
    let mut cross_im = 0.0_f64;
    let mut auto_a = 0.0_f64;
    let mut auto_b = 0.0_f64;
    for (p, q) in a.iter().zip(b) {
        // X · conj(Y) = (X.re + iX.im)(Y.re - iY.im)
        cross_re += p.re * q.re + p.im * q.im;
        cross_im += p.im * q.re - p.re * q.im;
        auto_a += p.re * p.re + p.im * p.im;
        auto_b += q.re * q.re + q.im * q.im;
    }
    let denom = auto_a * auto_b;
    if denom <= 0.0 {
        return None;
    }
    let num = cross_re * cross_re + cross_im * cross_im;
    Some((num / denom).clamp(0.0, 1.0))
}
