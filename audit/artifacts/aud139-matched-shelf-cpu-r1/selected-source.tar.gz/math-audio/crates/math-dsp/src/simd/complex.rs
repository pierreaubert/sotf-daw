#[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
use super::misc::SHUFFLE_SWAP_RE_IM;
#[cfg(all(target_arch = "aarch64", target_feature = "fcma"))]
use super::misc::fcmla_mul_acc;
use rustfft::num_complex::Complex;

#[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
/// # Safety
/// Caller must ensure `dst`, `src` and `hrtf` have at least `start + 4` elements.
#[inline]
pub unsafe fn complex_mul_add_simd_chunk(
    dst: &mut [Complex<f32>],
    src: &[Complex<f32>],
    hrtf: &[Complex<f32>],
    start: usize,
) {
    use std::arch::x86_64::*;

    // Process 4 complex numbers (8 floats) at once using AVX2
    // Input layout: [re0, im0, re1, im1, re2, im2, re3, im3]
    unsafe {
        let src_ptr = src.as_ptr().add(start) as *const f32;
        let hrtf_ptr = hrtf.as_ptr().add(start) as *const f32;
        let dst_ptr = dst.as_mut_ptr().add(start) as *mut f32;

        // Load 4 complex numbers
        let a = _mm256_loadu_ps(src_ptr);
        let b = _mm256_loadu_ps(hrtf_ptr);
        let dst_val = _mm256_loadu_ps(dst_ptr);

        // Complex multiplication: (a + bi) * (c + di) = (ac - bd) + (ad + bc)i

        // Duplicate real and imaginary parts correctly:
        // moveldup: duplicates even elements [0, 0, 2, 2, 4, 4, 6, 6] -> [re0, re0, re1, re1, ...]
        // movehdup: duplicates odd elements  [1, 1, 3, 3, 5, 5, 7, 7] -> [im0, im0, im1, im1, ...]
        let a_re = _mm256_moveldup_ps(a);
        let a_im = _mm256_movehdup_ps(a);

        // Compute: a.re * b = [re*re, re*im, ...] = [ac, ad, ...]
        let ac_ad = _mm256_mul_ps(a_re, b);

        // Swap b's re/im: [im, re, im, re, ...] = [d, c, ...]
        let b_swapped = _mm256_shuffle_ps(b, b, SHUFFLE_SWAP_RE_IM);

        // Compute: a.im * b_swapped = [im*im, im*re, ...] = [bd, bc, ...]
        let bd_bc = _mm256_mul_ps(a_im, b_swapped);

        // Combine using addsub: performs [a[0]-b[0], a[1]+b[1], a[2]-b[2], a[3]+b[3], ...]
        // This gives us: [(ac - bd), (ad + bc), ...] = [result.re, result.im, ...]
        let result = _mm256_addsub_ps(ac_ad, bd_bc);

        // Add to destination (accumulate)
        let final_result = _mm256_add_ps(dst_val, result);

        _mm256_storeu_ps(dst_ptr, final_result);
    }
}

#[cfg(all(target_arch = "aarch64", target_feature = "fcma"))]
/// # Safety
/// Caller must ensure `dst`, `src` and `hrtf` have at least `start + 2` elements.
#[inline]
pub unsafe fn complex_mul_add_simd_chunk(
    dst: &mut [Complex<f32>],
    src: &[Complex<f32>],
    hrtf: &[Complex<f32>],
    start: usize,
) {
    use std::arch::aarch64::*;

    unsafe {
        let src_ptr = src.as_ptr().add(start) as *const f32;
        let hrtf_ptr = hrtf.as_ptr().add(start) as *const f32;
        let dst_ptr = dst.as_mut_ptr().add(start) as *mut f32;

        let a = vld1q_f32(src_ptr);
        let b = vld1q_f32(hrtf_ptr);
        let r = vld1q_f32(dst_ptr);
        let result = fcmla_mul_acc(r, a, b);
        vst1q_f32(dst_ptr, result);
    }
}

#[cfg(all(
    target_arch = "aarch64",
    target_feature = "neon",
    not(target_feature = "fcma")
))]
/// # Safety
/// Caller must ensure `dst`, `src` and `hrtf` have at least `start + 2` elements.
#[inline]
pub unsafe fn complex_mul_add_simd_chunk(
    dst: &mut [Complex<f32>],
    src: &[Complex<f32>],
    hrtf: &[Complex<f32>],
    start: usize,
) {
    use std::arch::aarch64::*;

    unsafe {
        let src_ptr = src.as_ptr().add(start) as *const f32;
        let hrtf_ptr = hrtf.as_ptr().add(start) as *const f32;
        let dst_ptr = dst.as_mut_ptr().add(start) as *mut f32;

        let a = vld1q_f32(src_ptr);
        let b = vld1q_f32(hrtf_ptr);
        let dst_val = vld1q_f32(dst_ptr);

        let a_re = vtrn1q_f32(a, a);
        let a_im = vtrn2q_f32(a, a);
        let ac_ad = vmulq_f32(a_re, b);
        let b_swapped = vrev64q_f32(b);
        let bd_bc = vmulq_f32(a_im, b_swapped);

        let sign_bit: u32 = 0x80000000;
        let neg_mask = vreinterpretq_f32_u32(vsetq_lane_u32::<2>(
            sign_bit,
            vsetq_lane_u32::<0>(sign_bit, vdupq_n_u32(0)),
        ));

        let bd_bc_negated = vreinterpretq_f32_u32(veorq_u32(
            vreinterpretq_u32_f32(bd_bc),
            vreinterpretq_u32_f32(neg_mask),
        ));
        let result = vaddq_f32(ac_ad, bd_bc_negated);
        let final_result = vaddq_f32(dst_val, result);

        vst1q_f32(dst_ptr, final_result);
    }
}

#[cfg(not(any(
    all(target_arch = "x86_64", target_feature = "avx2"),
    all(target_arch = "aarch64", target_feature = "neon")
)))]
#[inline]
pub fn complex_mul_add_simd_chunk(
    dst: &mut [Complex<f32>],
    src: &[Complex<f32>],
    hrtf: &[Complex<f32>],
    start: usize,
) {
    // Scalar fallback (will be optimized by LLVM auto-vectorization)
    dst[start] += src[start] * hrtf[start];
}

/// SIMD-optimized complex multiply-accumulate
///
/// Computes: `dst[i] += src[i] * hrtf[i]` for all `i`
///
/// Uses platform-specific SIMD instructions for maximum performance:
/// - AVX2 on x86-64 (4 complex at once)
/// - NEON on aarch64 (2 complex at once)
/// - Scalar fallback with auto-vectorization hints
///
/// # Panics
/// Panics if `src` or `hrtf` are shorter than `dst` (the SIMD kernels index
/// all three slices through raw pointers, so mismatched lengths would read
/// out of bounds).
#[inline]
pub fn complex_mul_add_simd(dst: &mut [Complex<f32>], src: &[Complex<f32>], hrtf: &[Complex<f32>]) {
    let len = dst.len();
    assert_eq!(src.len(), len, "src length must match dst length");
    assert_eq!(hrtf.len(), len, "hrtf length must match dst length");

    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    {
        // Process 4 complex at a time with AVX2
        let simd_len = (len / 4) * 4;

        for i in (0..simd_len).step_by(4) {
            unsafe {
                complex_mul_add_simd_chunk(dst, src, hrtf, i);
            }
        }

        // Scalar remainder
        for i in simd_len..len {
            dst[i] += src[i] * hrtf[i];
        }
    }

    #[cfg(all(target_arch = "aarch64", target_feature = "neon"))]
    {
        // Process 2 complex at a time with NEON
        let simd_len = (len / 2) * 2;

        for i in (0..simd_len).step_by(2) {
            unsafe {
                complex_mul_add_simd_chunk(dst, src, hrtf, i);
            }
        }

        // Scalar remainder
        for i in simd_len..len {
            dst[i] += src[i] * hrtf[i];
        }
    }

    #[cfg(not(any(
        all(target_arch = "x86_64", target_feature = "avx2"),
        all(target_arch = "aarch64", target_feature = "neon")
    )))]
    {
        // Scalar fallback
        for i in 0..len {
            dst[i] += src[i] * hrtf[i];
        }
    }
}

/// SIMD-optimized complex multiplication (without accumulation)
///
/// Computes: `dst[i] = src[i] * hrtf[i]` for all `i`
///
/// # Panics
/// Panics if `src` or `hrtf` are shorter than `dst` (the SIMD kernels index
/// all three slices through raw pointers, so mismatched lengths would read
/// out of bounds).
#[inline]
pub fn complex_mul_simd(dst: &mut [Complex<f32>], src: &[Complex<f32>], hrtf: &[Complex<f32>]) {
    let len = dst.len();
    assert_eq!(src.len(), len, "src length must match dst length");
    assert_eq!(hrtf.len(), len, "hrtf length must match dst length");

    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    {
        use std::arch::x86_64::*;

        let simd_len = (len / 4) * 4;

        for i in (0..simd_len).step_by(4) {
            unsafe {
                let src_ptr = src.as_ptr().add(i) as *const f32;
                let hrtf_ptr = hrtf.as_ptr().add(i) as *const f32;
                let dst_ptr = dst.as_mut_ptr().add(i) as *mut f32;

                let a = _mm256_loadu_ps(src_ptr);
                let b = _mm256_loadu_ps(hrtf_ptr);

                let a_re = _mm256_moveldup_ps(a);
                let a_im = _mm256_movehdup_ps(a);
                let ac_ad = _mm256_mul_ps(a_re, b);
                let b_swapped = _mm256_shuffle_ps(b, b, SHUFFLE_SWAP_RE_IM);
                let bd_bc = _mm256_mul_ps(a_im, b_swapped);
                let result = _mm256_addsub_ps(ac_ad, bd_bc);

                _mm256_storeu_ps(dst_ptr, result);
            }
        }

        for i in simd_len..len {
            dst[i] = src[i] * hrtf[i];
        }
    }

    #[cfg(all(target_arch = "aarch64", target_feature = "fcma"))]
    {
        use std::arch::aarch64::*;

        let simd_len = (len / 2) * 2;

        for i in (0..simd_len).step_by(2) {
            unsafe {
                let src_ptr = src.as_ptr().add(i) as *const f32;
                let hrtf_ptr = hrtf.as_ptr().add(i) as *const f32;
                let dst_ptr = dst.as_mut_ptr().add(i) as *mut f32;

                let a = vld1q_f32(src_ptr);
                let b = vld1q_f32(hrtf_ptr);
                let r = vdupq_n_f32(0.0);
                let result = fcmla_mul_acc(r, a, b);
                vst1q_f32(dst_ptr, result);
            }
        }

        for i in simd_len..len {
            dst[i] = src[i] * hrtf[i];
        }
    }

    #[cfg(all(
        target_arch = "aarch64",
        target_feature = "neon",
        not(target_feature = "fcma")
    ))]
    {
        use std::arch::aarch64::*;

        let simd_len = (len / 2) * 2;

        for i in (0..simd_len).step_by(2) {
            unsafe {
                let src_ptr = src.as_ptr().add(i) as *const f32;
                let hrtf_ptr = hrtf.as_ptr().add(i) as *const f32;
                let dst_ptr = dst.as_mut_ptr().add(i) as *mut f32;

                let a = vld1q_f32(src_ptr);
                let b = vld1q_f32(hrtf_ptr);

                let a_re = vtrn1q_f32(a, a);
                let a_im = vtrn2q_f32(a, a);
                let ac_ad = vmulq_f32(a_re, b);
                let b_swapped = vrev64q_f32(b);
                let bd_bc = vmulq_f32(a_im, b_swapped);

                let sign_bit: u32 = 0x80000000;
                let neg_mask = vreinterpretq_f32_u32(vsetq_lane_u32::<2>(
                    sign_bit,
                    vsetq_lane_u32::<0>(sign_bit, vdupq_n_u32(0)),
                ));

                let bd_bc_negated = vreinterpretq_f32_u32(veorq_u32(
                    vreinterpretq_u32_f32(bd_bc),
                    vreinterpretq_u32_f32(neg_mask),
                ));

                let result = vaddq_f32(ac_ad, bd_bc_negated);
                vst1q_f32(dst_ptr, result);
            }
        }

        for i in simd_len..len {
            dst[i] = src[i] * hrtf[i];
        }
    }

    #[cfg(not(any(
        all(target_arch = "x86_64", target_feature = "avx2"),
        all(target_arch = "aarch64", target_feature = "neon")
    )))]
    {
        for i in 0..len {
            dst[i] = src[i] * hrtf[i];
        }
    }
}

/// SIMD-optimized in-place complex multiplication
///
/// Computes: `dst[i] *= hrtf[i]` for all `i`
///
/// # Panics
/// Panics if `hrtf` is shorter than `dst` (the SIMD kernels index both slices
/// through raw pointers, so a mismatched length would read out of bounds).
#[inline]
#[allow(dead_code)]
pub fn complex_mul_inplace_simd(dst: &mut [Complex<f32>], hrtf: &[Complex<f32>]) {
    let len = dst.len();
    assert_eq!(hrtf.len(), len, "hrtf length must match dst length");

    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    {
        use std::arch::x86_64::*;

        let simd_len = (len / 4) * 4;

        for i in (0..simd_len).step_by(4) {
            unsafe {
                let dst_ptr = dst.as_mut_ptr().add(i) as *mut f32;
                let hrtf_ptr = hrtf.as_ptr().add(i) as *const f32;

                let a = _mm256_loadu_ps(dst_ptr);
                let b = _mm256_loadu_ps(hrtf_ptr);

                let a_re = _mm256_moveldup_ps(a);
                let a_im = _mm256_movehdup_ps(a);
                let ac_ad = _mm256_mul_ps(a_re, b);
                let b_swapped = _mm256_shuffle_ps(b, b, SHUFFLE_SWAP_RE_IM);
                let bd_bc = _mm256_mul_ps(a_im, b_swapped);
                let result = _mm256_addsub_ps(ac_ad, bd_bc);

                _mm256_storeu_ps(dst_ptr, result);
            }
        }

        for i in simd_len..len {
            dst[i] *= hrtf[i];
        }
    }

    #[cfg(all(target_arch = "aarch64", target_feature = "fcma"))]
    {
        use std::arch::aarch64::*;

        let simd_len = (len / 2) * 2;

        for i in (0..simd_len).step_by(2) {
            unsafe {
                let dst_ptr = dst.as_mut_ptr().add(i) as *mut f32;
                let hrtf_ptr = hrtf.as_ptr().add(i) as *const f32;

                let a = vld1q_f32(dst_ptr);
                let b = vld1q_f32(hrtf_ptr);
                let r = vdupq_n_f32(0.0);
                let result = fcmla_mul_acc(r, a, b);
                vst1q_f32(dst_ptr, result);
            }
        }

        for i in simd_len..len {
            dst[i] *= hrtf[i];
        }
    }

    #[cfg(all(
        target_arch = "aarch64",
        target_feature = "neon",
        not(target_feature = "fcma")
    ))]
    {
        use std::arch::aarch64::*;

        let simd_len = (len / 2) * 2;

        for i in (0..simd_len).step_by(2) {
            unsafe {
                let dst_ptr = dst.as_mut_ptr().add(i) as *mut f32;
                let hrtf_ptr = hrtf.as_ptr().add(i) as *const f32;

                let a = vld1q_f32(dst_ptr);
                let b = vld1q_f32(hrtf_ptr);

                let a_re = vtrn1q_f32(a, a);
                let a_im = vtrn2q_f32(a, a);
                let ac_ad = vmulq_f32(a_re, b);
                let b_swapped = vrev64q_f32(b);
                let bd_bc = vmulq_f32(a_im, b_swapped);

                let sign_bit: u32 = 0x80000000;
                let neg_mask = vreinterpretq_f32_u32(vsetq_lane_u32::<2>(
                    sign_bit,
                    vsetq_lane_u32::<0>(sign_bit, vdupq_n_u32(0)),
                ));

                let bd_bc_negated = vreinterpretq_f32_u32(veorq_u32(
                    vreinterpretq_u32_f32(bd_bc),
                    vreinterpretq_u32_f32(neg_mask),
                ));

                let result = vaddq_f32(ac_ad, bd_bc_negated);
                vst1q_f32(dst_ptr, result);
            }
        }

        for i in simd_len..len {
            dst[i] *= hrtf[i];
        }
    }

    #[cfg(not(any(
        all(target_arch = "x86_64", target_feature = "avx2"),
        all(target_arch = "aarch64", target_feature = "neon")
    )))]
    {
        for i in 0..len {
            dst[i] *= hrtf[i];
        }
    }
}
