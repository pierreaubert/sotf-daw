use super::DynamicsCore;
use super::consts::RMS_WINDOW_MS;
use super::types::DynamicsMode;
use super::types::GateState;

const SR: u32 = 48000;

#[test]
fn test_compress_gain_reduction() {
    let core = DynamicsCore::new(DynamicsMode::Compress, 2, SR);

    // Below threshold — no compression
    let gr = core.calculate_gain_reduction(-30.0, -20.0, 4.0, 0.0);
    assert_eq!(gr, 0.0);

    // At threshold — no compression
    let gr = core.calculate_gain_reduction(-20.0, -20.0, 4.0, 0.0);
    assert_eq!(gr, 0.0);

    // 12 dB above threshold with 4:1 ratio, no knee
    // GR = 12 * (1 - 1/4) = 9 dB
    let gr = core.calculate_gain_reduction(-8.0, -20.0, 4.0, 0.0);
    assert!((gr - 9.0).abs() < 0.01, "expected ~9.0, got {gr}");

    // Soft knee: at exact threshold, should be in the knee zone
    let gr = core.calculate_gain_reduction(-20.0, -20.0, 4.0, 6.0);
    // In the knee zone: overshoot = -20 - (-20) + 3 = 3, kf = 3/6 = 0.5
    // GR = 0.25 * 3.0 * 0.75 = 0.5625
    assert!(gr > 0.0 && gr < 3.0, "knee GR should be moderate, got {gr}");
}

#[test]
fn test_expand_attenuation() {
    let mut core = DynamicsCore::new(DynamicsMode::Expand, 1, SR);
    core.set_expand_params(3.0, 50.0, 40.0);

    // Above threshold — no expansion
    let atten = core.calculate_gain_reduction(-10.0, -20.0, 4.0, 0.0);
    assert_eq!(atten, 0.0);

    // At threshold — no expansion
    let atten = core.calculate_gain_reduction(-20.0, -20.0, 4.0, 0.0);
    assert_eq!(atten, 0.0);

    // 12 dB below threshold with 4:1 ratio, no knee
    // atten = 12 * (1 - 1/4) = 9 dB
    let atten = core.calculate_gain_reduction(-32.0, -20.0, 4.0, 0.0);
    assert!((atten - 9.0).abs() < 0.01, "expected ~9.0, got {atten}");

    // Test range cap: 60 dB below threshold with 4:1
    // uncapped = 60 * 0.75 = 45, but range_db = 40
    let atten = core.calculate_gain_reduction(-80.0, -20.0, 4.0, 0.0);
    assert!(
        (atten - 40.0).abs() < 0.01,
        "expected range cap at 40.0, got {atten}"
    );
}

#[test]
fn test_envelope_attack_release() {
    let mut core = DynamicsCore::new(DynamicsMode::Compress, 1, SR);
    core.set_attack_release(1.0, 50.0); // 1ms attack, 50ms release

    // Attack: feed target of 10 dB GR
    let mut env = 0.0f32;
    for _ in 0..480 {
        // 10ms worth of samples
        env = core.apply_envelope(0, 10.0);
    }
    // After 10ms with 1ms attack, should be close to target
    assert!(
        env > 9.0,
        "after 10ms attack (1ms time constant), envelope should be near 10.0, got {env}"
    );

    // Release: feed target of 0 dB GR
    for _ in 0..24000 {
        // 500ms — 10 time constants
        env = core.apply_envelope(0, 0.0);
    }
    // After 500ms with 50ms release, should be very near zero
    assert!(
        env < 0.1,
        "after 500ms release (50ms time constant), envelope should be near 0, got {env}"
    );
}

#[test]
fn test_gate_state_machine() {
    let mut core = DynamicsCore::new(DynamicsMode::Expand, 1, SR);
    core.set_expand_params(3.0, 0.0, 40.0); // 3dB hysteresis, 0ms hold, 40dB range
    core.set_attack_release(0.1, 50.0);

    let threshold = -20.0;
    let ratio = 4.0;
    let knee = 0.0;

    // Start in Open state
    assert_eq!(core.gate_state(0), GateState::Open);

    // Above threshold — stays open, no attenuation
    let atten = core.process_gate_state(0, -10.0, threshold, ratio, knee);
    assert_eq!(atten, 0.0);
    assert_eq!(core.gate_state(0), GateState::Open);

    // Below threshold — transitions to Hold (hold_ms=0 so immediate transition check)
    let atten = core.process_gate_state(0, -25.0, threshold, ratio, knee);
    assert_eq!(atten, 0.0); // Hold still produces 0 attenuation initially
    assert_eq!(core.gate_state(0), GateState::Hold);

    // Still below close threshold (-20 - 3 = -23), hold counter exhausted
    // since hold_ms=0, counter is 0 — should transition to Closing
    let atten = core.process_gate_state(0, -25.0, threshold, ratio, knee);
    assert!(atten > 0.0, "should be expanding now, got {atten}");
    assert_eq!(core.gate_state(0), GateState::Closing);

    // Back above threshold — should re-open
    let atten = core.process_gate_state(0, -10.0, threshold, ratio, knee);
    assert_eq!(atten, 0.0);
    assert_eq!(core.gate_state(0), GateState::Open);
}

#[test]
fn test_gate_hold_samples_cached_updates() {
    let mut core = DynamicsCore::new(DynamicsMode::Expand, 1, 48_000);
    assert_eq!(core.hold_samples_cached, 2_400);

    core.set_expand_params(3.0, 10.0, 40.0);
    assert_eq!(core.hold_samples_cached, 480);

    core.initialize(96_000);
    assert_eq!(core.hold_samples_cached, 960);

    let _ = core.process_gate_state(0, -30.0, -20.0, 4.0, 0.0);
    assert_eq!(core.hold_counter[0], 960);
}

#[test]
fn test_sidechain_hpf() {
    let mut core = DynamicsCore::new(DynamicsMode::Compress, 1, SR);
    core.set_sidechain_hpf(200.0, 0); // 200Hz 2nd order HPF

    // Low frequency (50Hz) should be attenuated
    let mut low_energy = 0.0f32;
    let freq = 50.0;
    for i in 0..SR {
        let sample = (2.0 * std::f32::consts::PI * freq * i as f32 / SR as f32).sin();
        let filtered = core.apply_sidechain_filter(0, sample);
        low_energy += filtered * filtered;
    }

    // Reset HPF state
    core.set_sidechain_hpf(200.0, 0);

    // High frequency (1kHz) should pass through
    let mut high_energy = 0.0f32;
    let freq = 1000.0;
    for i in 0..SR {
        let sample = (2.0 * std::f32::consts::PI * freq * i as f32 / SR as f32).sin();
        let filtered = core.apply_sidechain_filter(0, sample);
        high_energy += filtered * filtered;
    }

    assert!(
        high_energy > low_energy * 10.0,
        "HPF should strongly attenuate 50Hz vs 1kHz: low={low_energy}, high={high_energy}"
    );
}

#[test]
fn test_detection_peak_vs_rms() {
    let mut core = DynamicsCore::new(DynamicsMode::Compress, 1, SR);

    // Peak detection
    core.set_detection_mode(0);
    let peak_level = core.detect_level(0, 0.5);
    assert!((peak_level - 0.5).abs() < 0.001, "peak should be 0.5");

    // Negative sample should also return abs
    let peak_neg = core.detect_level(0, -0.5);
    assert!(
        (peak_neg - 0.5).abs() < 0.001,
        "peak of negative should be 0.5"
    );

    // Switch to RMS
    core.set_detection_mode(1);

    // Feed constant signal for a full window to prime the RMS detector
    let window_len = (RMS_WINDOW_MS * 0.001 * SR as f32).round() as usize;
    let mut rms_level = 0.0f32;
    for _ in 0..window_len + 1 {
        rms_level = core.detect_level(0, 0.5);
    }
    // RMS of constant 0.5 = 0.5
    assert!(
        (rms_level - 0.5).abs() < 0.05,
        "RMS of constant 0.5 should be ~0.5, got {rms_level}"
    );

    // Now feed a half-wave signal: the RMS will differ from peak
    core.set_detection_mode(0);
    let peak_half = core.detect_level(0, 1.0);

    core.set_detection_mode(1);
    // Feed mixed signal for a full window
    for i in 0..window_len + 1 {
        let sample = if i % 2 == 0 { 1.0 } else { 0.0 };
        rms_level = core.detect_level(0, sample);
    }
    // RMS of alternating 1.0/0.0 = sqrt(0.5) ≈ 0.707
    // Peak would be 1.0
    assert!(
        rms_level < peak_half,
        "RMS should be less than peak for alternating signal: rms={rms_level}, peak={peak_half}"
    );
}

#[test]
fn test_no_allocations_in_hot_path() {
    // This test verifies the hot-path methods can be called in a tight loop
    // without triggering allocations. We verify by checking the methods
    // operate on pre-allocated storage only.
    let mut core = DynamicsCore::new(DynamicsMode::Compress, 2, SR);
    core.set_sidechain_hpf(100.0, 0);
    core.set_detection_mode(0);
    core.set_attack_release(5.0, 50.0);

    // Run 10000 iterations of the hot path
    for i in 0..10000 {
        let sample = (i as f32 * 0.01).sin();
        let ch = i % 2;

        let filtered = core.apply_sidechain_filter(ch, sample);
        let level = core.detect_level(ch, filtered);

        let input_db = if level < 1e-10 {
            -120.0
        } else {
            20.0 * level.log10()
        };

        let gr = core.calculate_gain_reduction(input_db, -20.0, 4.0, 6.0);
        let _env = core.apply_envelope(ch, gr);
    }

    // If we got here without panicking, the hot path is allocation-free.
    // The methods only operate on pre-allocated Vecs and stack values.
    assert!(core.envelope_db(0).is_finite());
    assert!(core.envelope_db(1).is_finite());
}

/// Measure the actual frame delay through the lookahead path by sending an
/// impulse at frame 0 and returning the frame index where it reappears.
fn measure_lookahead_delay(core: &mut DynamicsCore, channels: usize, frames: usize) -> usize {
    let mut output = vec![0.0f32; channels];
    for i in 0..frames {
        let mut input = vec![0.0f32; channels];
        if i == 0 {
            input.fill(1.0);
        }
        core.lookahead_process_frame(&input, &mut output);
        if output[0] != 0.0 {
            return i;
        }
    }
    panic!("impulse never reappeared within {frames} frames");
}

#[test]
fn test_lookahead_delay_samples_matches_actual_delay_off() {
    // Lookahead off (0 ms): the reported delay must match the actual delay
    // of the buffer path, which still applies its minimum delay.
    let mut core = DynamicsCore::new(DynamicsMode::Compress, 1, SR);
    let reported = core.lookahead_delay_samples();
    let actual = measure_lookahead_delay(&mut core, 1, 10);
    assert_eq!(
        reported, actual,
        "reported lookahead latency ({reported}) must match actual delay ({actual})"
    );
}

#[test]
fn test_lookahead_delay_samples_matches_actual_delay_on() {
    let mut core = DynamicsCore::new(DynamicsMode::Compress, 2, SR);
    core.set_lookahead_ms(5.0); // 5ms = 240 samples at 48kHz
    let reported = core.lookahead_delay_samples();
    assert_eq!(reported, 240);
    let actual = measure_lookahead_delay(&mut core, 2, 300);
    assert_eq!(
        reported, actual,
        "reported lookahead latency ({reported}) must match actual delay ({actual})"
    );

    // Turning lookahead back off must re-sync report with actual delay.
    core.set_lookahead_ms(0.0);
    let reported = core.lookahead_delay_samples();
    let actual = measure_lookahead_delay(&mut core, 2, 10);
    assert_eq!(
        reported, actual,
        "reported lookahead latency ({reported}) must match actual delay ({actual})"
    );
}

#[test]
fn test_lookahead_process_frame() {
    let mut core = DynamicsCore::new(DynamicsMode::Compress, 2, SR);
    core.set_lookahead_ms(5.0); // 5ms = 240 samples at 48kHz

    let delay = core.lookahead_delay_samples();
    assert_eq!(delay, 240);

    // Push frames through the lookahead
    let mut output = vec![0.0f32; 2];
    for frame in 0..240 {
        let input = [frame as f32, (frame as f32) * 10.0];
        core.lookahead_process_frame(&input, &mut output);
        // First 240 frames should output silence (delay filling)
        assert_eq!(output[0], 0.0);
        assert_eq!(output[1], 0.0);
    }

    // Frame 240 should output frame 0's data
    let input = [240.0, 2400.0];
    core.lookahead_process_frame(&input, &mut output);
    assert!((output[0] - 0.0).abs() < 0.001);
    assert!((output[1] - 0.0).abs() < 0.001);

    // Frame 241 should output frame 1's data
    let input = [241.0, 2410.0];
    core.lookahead_process_frame(&input, &mut output);
    assert!((output[0] - 1.0).abs() < 0.001);
    assert!((output[1] - 10.0).abs() < 0.001);
}

#[test]
fn test_reset_clears_state() {
    let mut core = DynamicsCore::new(DynamicsMode::Expand, 2, SR);
    core.set_expand_params(3.0, 50.0, 40.0);

    // Build up some state
    for _ in 0..1000 {
        core.apply_envelope(0, 10.0);
        core.apply_envelope(1, 5.0);
    }
    assert!(core.envelope_db(0) > 0.0);
    assert!(core.envelope_db(1) > 0.0);

    core.reset();

    assert_eq!(core.envelope_db(0), 0.0);
    assert_eq!(core.envelope_db(1), 0.0);
    assert_eq!(core.gate_state(0), GateState::Open);
    assert_eq!(core.gate_state(1), GateState::Open);
}

#[test]
fn test_measured_makeup() {
    let mut core = DynamicsCore::new(DynamicsMode::Compress, 1, SR);

    // Feed steady gain reduction
    for _ in 0..480000 {
        core.update_measured_makeup(6.0);
    }
    let makeup_db = core.measured_makeup_db();
    assert!(
        (makeup_db - 6.0).abs() < 0.1,
        "measured makeup should converge to ~6dB, got {makeup_db}"
    );

    // After reset, should be zero
    core.reset();
    assert!(core.measured_makeup_db().abs() < 0.01);
}

#[test]
fn test_expand_with_gate_state_machine_and_envelope() {
    // Integration test: gate state machine feeds into envelope
    let mut core = DynamicsCore::new(DynamicsMode::Expand, 1, SR);
    core.set_expand_params(3.0, 0.0, 40.0);
    core.set_attack_release(0.1, 10.0);

    let threshold = -20.0;
    let ratio = 4.0;
    let knee = 0.0;

    // Feed a quiet signal (below threshold) for a while
    for _ in 0..4800 {
        let target = core.process_gate_state(0, -40.0, threshold, ratio, knee);
        core.apply_envelope(0, target);
    }

    // Envelope should show significant attenuation
    let env = core.envelope_db(0);
    assert!(
        env > 5.0,
        "after sustained below-threshold signal, envelope should show attenuation, got {env}"
    );

    // Feed a loud signal (above threshold) — gate should re-open
    for _ in 0..4800 {
        let target = core.process_gate_state(0, -10.0, threshold, ratio, knee);
        core.apply_envelope(0, target);
    }

    let env = core.envelope_db(0);
    assert!(
        env < 0.5,
        "after above-threshold signal, envelope should recover, got {env}"
    );
}

#[test]
fn test_gate_state_hold_with_counter() {
    let mut core = DynamicsCore::new(DynamicsMode::Expand, 1, SR);
    core.set_expand_params(3.0, 10.0, 40.0); // 10ms hold = 480 samples
    core.set_attack_release(0.1, 10.0);

    let threshold = -20.0;
    let ratio = 4.0;
    let knee = 0.0;

    // Signal drops below threshold → enters Hold
    let atten = core.process_gate_state(0, -25.0, threshold, ratio, knee);
    assert_eq!(atten, 0.0);
    assert_eq!(core.gate_state(0), GateState::Hold);
    assert_eq!(core.hold_counter[0], 480);

    // During hold period, still below threshold but counter not exhausted
    let atten = core.process_gate_state(0, -25.0, threshold, ratio, knee);
    assert_eq!(atten, 0.0);
    assert_eq!(core.gate_state(0), GateState::Hold);
    assert!(core.hold_counter[0] < 480);
}

#[test]
fn test_gate_state_boundary_open_threshold() {
    let mut core = DynamicsCore::new(DynamicsMode::Expand, 1, SR);
    core.set_expand_params(3.0, 0.0, 40.0);

    let threshold = -20.0;
    let ratio = 4.0;
    let knee = 0.0;

    // Exactly at open threshold should stay open
    let atten = core.process_gate_state(0, -20.0, threshold, ratio, knee);
    assert_eq!(atten, 0.0);
    assert_eq!(core.gate_state(0), GateState::Open);

    // Just below open threshold → Hold
    let atten = core.process_gate_state(0, -20.01, threshold, ratio, knee);
    assert_eq!(atten, 0.0);
    assert_eq!(core.gate_state(0), GateState::Hold);
}

#[test]
fn test_gate_state_boundary_close_threshold() {
    let mut core = DynamicsCore::new(DynamicsMode::Expand, 1, SR);
    core.set_expand_params(3.0, 0.0, 40.0);

    let threshold = -20.0;
    let _close_th = threshold - 3.0; // -23.0
    let ratio = 4.0;
    let knee = 0.0;

    // Drop below open threshold
    core.process_gate_state(0, -25.0, threshold, ratio, knee);
    // With 0ms hold, immediately check transition to Closing
    let atten = core.process_gate_state(0, -23.0, threshold, ratio, knee);
    // Exactly at close threshold: not < close_th, so stays in Hold with 0 attenuation
    assert_eq!(atten, 0.0);

    // Now below close threshold
    let atten = core.process_gate_state(0, -23.01, threshold, ratio, knee);
    assert!(atten > 0.0);
    assert_eq!(core.gate_state(0), GateState::Closing);
}

#[test]
fn test_gate_state_multichannel_independence() {
    let mut core = DynamicsCore::new(DynamicsMode::Expand, 2, SR);
    core.set_expand_params(3.0, 0.0, 40.0);

    let threshold = -20.0;
    let ratio = 4.0;
    let knee = 0.0;

    // Ch0 quiet, Ch1 loud
    core.process_gate_state(0, -40.0, threshold, ratio, knee);
    core.process_gate_state(1, -10.0, threshold, ratio, knee);

    assert_eq!(core.gate_state(0), GateState::Hold);
    assert_eq!(core.gate_state(1), GateState::Open);

    // Continue: ch0 goes to Closing, ch1 stays Open
    core.process_gate_state(0, -40.0, threshold, ratio, knee);
    assert_eq!(core.gate_state(0), GateState::Closing);
    assert_eq!(core.gate_state(1), GateState::Open);
}

#[test]
fn test_apply_envelope_attack_release_selection() {
    let mut core = DynamicsCore::new(DynamicsMode::Compress, 1, SR);
    core.set_attack_release(1.0, 50.0);

    // Start at 0 envelope
    core.apply_envelope(0, 10.0); // target > envelope → attack
    let env_after_attack = core.envelope_db(0);

    // Now target < envelope → release
    core.apply_envelope(0, 0.0);
    let env_after_release = core.envelope_db(0);

    assert!(env_after_attack > 0.0);
    assert!(env_after_release < env_after_attack);
}

#[test]
fn test_apply_envelope_exact_equality() {
    let mut core = DynamicsCore::new(DynamicsMode::Compress, 1, SR);
    core.set_attack_release(1.0, 50.0);

    // Set envelope to a known value
    for _ in 0..10000 {
        core.apply_envelope(0, 5.0);
    }
    let env = core.envelope_db(0);

    // target == envelope → release coefficient (since target_gr <= envelope)
    let env2 = core.apply_envelope(0, env);
    assert!(
        (env2 - env).abs() < 0.001,
        "when target equals envelope, envelope should not change much, got {env2} vs {env}"
    );
}

#[test]
fn test_apply_envelope_nan_recovery() {
    let mut core = DynamicsCore::new(DynamicsMode::Compress, 1, SR);
    core.set_attack_release(1.0, 50.0);

    // Build up a real envelope
    for _ in 0..480 {
        core.apply_envelope(0, 10.0);
    }
    let env_before = core.envelope_db(0);
    assert!(env_before > 5.0, "setup: envelope should be built up");

    // A single non-finite target must not permanently corrupt the envelope
    let after_nan = core.apply_envelope(0, f32::NAN);
    assert!(after_nan.is_finite(), "NaN target produced NaN envelope");
    assert!(core.envelope_db(0).is_finite());
    let after_inf = core.apply_envelope(0, f32::INFINITY);
    assert!(
        after_inf.is_finite(),
        "Inf target produced non-finite envelope"
    );

    // Subsequent finite targets must still be tracked normally
    let mut env = 0.0f32;
    for _ in 0..24000 {
        // 500ms, 10 release time constants
        env = core.apply_envelope(0, 0.0);
    }
    assert!(
        env < 0.1,
        "envelope should recover and release to ~0 after NaN, got {env}"
    );
}

#[test]
fn test_apply_envelope_program_dependent_release() {
    let mut core = DynamicsCore::new(DynamicsMode::Compress, 1, SR);
    core.set_attack_release(1.0, 50.0);
    core.set_program_dependent_release(true);

    // Build up envelope
    for _ in 0..1000 {
        core.apply_envelope(0, 10.0);
    }
    let env_before = core.envelope_db(0);

    // Release with program-dependent mode
    core.apply_envelope(0, 0.0);
    let env_after = core.envelope_db(0);

    assert!(env_after < env_before);
}

#[test]
fn test_calculate_gain_reduction_knee_soft() {
    let core = DynamicsCore::new(DynamicsMode::Compress, 1, SR);

    // With 6 dB knee centered at threshold (-20), the knee zone is [-23, -17].
    // Below knee zone: no GR
    let gr_below = core.calculate_gain_reduction(-24.0, -20.0, 4.0, 6.0);
    assert_eq!(gr_below, 0.0, "below knee zone should have no GR");

    // At upper edge of knee zone (-17): should match hard knee
    let gr_edge = core.calculate_gain_reduction(-17.0, -20.0, 4.0, 6.0);
    let gr_hard = core.calculate_gain_reduction(-17.0, -20.0, 4.0, 0.0);
    assert!(
        (gr_edge - gr_hard).abs() < 0.01,
        "at upper knee edge, soft knee should match hard knee: edge={gr_edge}, hard={gr_hard}"
    );

    // Inside knee zone (-20, at threshold): GR should be positive but less than hard-knee at upper edge
    let gr_mid = core.calculate_gain_reduction(-20.0, -20.0, 4.0, 6.0);
    assert!(
        gr_mid > 0.0 && gr_mid < gr_hard,
        "inside knee zone, GR should be moderate: mid={gr_mid}, hard_at_edge={gr_hard}"
    );

    // Above knee zone: should match hard knee
    let gr_above = core.calculate_gain_reduction(-10.0, -20.0, 4.0, 6.0);
    let gr_hard_above = core.calculate_gain_reduction(-10.0, -20.0, 4.0, 0.0);
    assert!(
        (gr_above - gr_hard_above).abs() < 0.01,
        "above knee zone, soft knee should match hard knee: above={gr_above}, hard={gr_hard_above}"
    );
}

#[test]
fn test_calculate_gain_reduction_expand_range_cap() {
    let core = DynamicsCore::new(DynamicsMode::Expand, 1, SR);

    // Far below threshold should be capped at range_db
    let atten = core.calculate_gain_reduction(-120.0, -20.0, 4.0, 0.0);
    // range_db defaults to 40.0
    assert!(
        (atten - 40.0).abs() < 0.01,
        "far below threshold should hit range cap, got {atten}"
    );
}

#[test]
fn test_calculate_gain_reduction_expand_at_threshold() {
    let core = DynamicsCore::new(DynamicsMode::Expand, 1, SR);

    // At threshold → no attenuation
    let atten = core.calculate_gain_reduction(-20.0, -20.0, 4.0, 0.0);
    assert_eq!(atten, 0.0);

    // Above threshold → no attenuation
    let atten = core.calculate_gain_reduction(-10.0, -20.0, 4.0, 0.0);
    assert_eq!(atten, 0.0);
}

#[test]
fn test_calculate_gain_reduction_compress_knee_edge() {
    let core = DynamicsCore::new(DynamicsMode::Compress, 1, SR);

    // Exactly at knee edge: threshold + knee/2
    let gr = core.calculate_gain_reduction(-17.0, -20.0, 4.0, 6.0);
    assert!(gr >= 0.0);
    assert!(gr <= 9.0);
}
