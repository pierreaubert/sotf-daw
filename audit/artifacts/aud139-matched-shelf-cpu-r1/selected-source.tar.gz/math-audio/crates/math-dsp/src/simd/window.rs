/// SIMD-optimized windowed copy (for FFT input preparation)
///
/// Computes: `dst[i] = src[i] * window[i]` for all `i`
#[inline]
pub fn window_mul_simd(dst: &mut [f32], src: &[f32], window: &[f32]) {
    debug_assert_eq!(dst.len(), src.len());
    debug_assert_eq!(dst.len(), window.len());
    let len = dst.len();

    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    {
        use std::arch::x86_64::*;

        let simd_len = (len / 8) * 8;

        for i in (0..simd_len).step_by(8) {
            unsafe {
                let src_ptr = src.as_ptr().add(i);
                let win_ptr = window.as_ptr().add(i);
                let dst_ptr = dst.as_mut_ptr().add(i);

                let s = _mm256_loadu_ps(src_ptr);
                let w = _mm256_loadu_ps(win_ptr);
                let result = _mm256_mul_ps(s, w);

                _mm256_storeu_ps(dst_ptr, result);
            }
        }

        for i in simd_len..len {
            dst[i] = src[i] * window[i];
        }
    }

    #[cfg(all(target_arch = "aarch64", target_feature = "neon"))]
    {
        use std::arch::aarch64::*;

        let simd_len = (len / 4) * 4;

        for i in (0..simd_len).step_by(4) {
            unsafe {
                let src_ptr = src.as_ptr().add(i);
                let win_ptr = window.as_ptr().add(i);
                let dst_ptr = dst.as_mut_ptr().add(i);

                let s = vld1q_f32(src_ptr);
                let w = vld1q_f32(win_ptr);
                let result = vmulq_f32(s, w);

                vst1q_f32(dst_ptr, result);
            }
        }

        for i in simd_len..len {
            dst[i] = src[i] * window[i];
        }
    }

    #[cfg(not(any(
        all(target_arch = "x86_64", target_feature = "avx2"),
        all(target_arch = "aarch64", target_feature = "neon")
    )))]
    {
        for i in 0..len {
            dst[i] = src[i] * window[i];
        }
    }
}

/// SIMD-optimized in-place window multiplication.
#[inline]
pub fn window_mul_simd_inplace(data: &mut [f32], window: &[f32]) {
    let len = data.len().min(window.len());

    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    {
        use std::arch::x86_64::*;
        let simd_len = (len / 8) * 8;
        for i in (0..simd_len).step_by(8) {
            unsafe {
                let ptr = data.as_mut_ptr().add(i);
                let win_ptr = window.as_ptr().add(i);
                let d = _mm256_loadu_ps(ptr);
                let w = _mm256_loadu_ps(win_ptr);
                _mm256_storeu_ps(ptr, _mm256_mul_ps(d, w));
            }
        }
        for i in simd_len..len {
            data[i] *= window[i];
        }
    }

    #[cfg(all(target_arch = "aarch64", target_feature = "neon"))]
    {
        use std::arch::aarch64::*;
        let simd_len = (len / 4) * 4;
        for i in (0..simd_len).step_by(4) {
            unsafe {
                let ptr = data.as_mut_ptr().add(i);
                let win_ptr = window.as_ptr().add(i);
                let d = vld1q_f32(ptr);
                let w = vld1q_f32(win_ptr);
                vst1q_f32(ptr, vmulq_f32(d, w));
            }
        }
        for i in simd_len..len {
            data[i] *= window[i];
        }
    }

    #[cfg(not(any(
        all(target_arch = "x86_64", target_feature = "avx2"),
        all(target_arch = "aarch64", target_feature = "neon")
    )))]
    {
        for i in 0..len {
            data[i] *= window[i];
        }
    }
}
