/// Next power of two for wav analysis (capped at 1M)
pub(super) fn wav_next_power_of_two(n: usize) -> usize {
    let mut p = 1;
    while p < n {
        p *= 2;
    }
    p.min(1048576)
}

/// Generate logarithmically spaced frequencies.
///
/// A single point degenerates to the geometric midpoint of the range
/// (`sqrt(min_freq * max_freq)`), the natural "center" of a log axis;
/// zero points yield an empty vector.
pub(super) fn generate_log_frequencies(
    num_points: usize,
    min_freq: f32,
    max_freq: f32,
) -> Vec<f32> {
    if num_points == 1 {
        return vec![(min_freq * max_freq).sqrt()];
    }

    let log_min = min_freq.ln();
    let log_max = max_freq.ln();
    let step = (log_max - log_min) / (num_points - 1) as f32;

    (0..num_points)
        .map(|i| (log_min + i as f32 * step).exp())
        .collect()
}

/// Find the next power of two greater than or equal to n
pub(super) fn next_power_of_two(n: usize) -> usize {
    if n == 0 {
        return 1;
    }
    n.next_power_of_two()
}

/// Unwrap phase in degrees to produce a continuous phase curve.
/// Wraps each inter-sample difference to [-180, 180] and accumulates,
/// handling arbitrarily large jumps (not just single ±360° wraps).
pub(super) fn unwrap_phase_deg(phase_deg: &[f32]) -> Vec<f32> {
    if phase_deg.is_empty() {
        return Vec::new();
    }

    let mut unwrapped = Vec::with_capacity(phase_deg.len());
    unwrapped.push(phase_deg[0]);

    for i in 1..phase_deg.len() {
        let diff = phase_deg[i] - phase_deg[i - 1];
        let wrapped_diff = diff - 360.0 * (diff / 360.0).round();
        unwrapped.push(unwrapped[i - 1] + wrapped_diff);
    }

    unwrapped
}

/// Trim late steady-state noise before Schroeder integration.
///
/// This is a lightweight Lundeby-style guard: estimate the tail noise from the
/// last 10% of 10 ms windows, keep the last window that is at least 10 dB above
/// that floor, and leave a short headroom after it.
pub(super) fn trim_impulse_to_noise_floor(impulse: &[f32], sample_rate: f32) -> &[f32] {
    const WINDOW_MS: f32 = 10.0;
    const TAIL_FRACTION: f32 = 0.10;
    const SNR_THRESHOLD: f32 = 10.0;
    const HEADROOM_WINDOWS: usize = 3;
    const MIN_LENGTH_MS: f32 = 100.0;

    if sample_rate <= 0.0 || impulse.is_empty() {
        return impulse;
    }

    let window_samples = (sample_rate * WINDOW_MS / 1000.0) as usize;
    let min_samples = (sample_rate * MIN_LENGTH_MS / 1000.0) as usize;
    if window_samples == 0 || impulse.len() < min_samples {
        return impulse;
    }

    let num_windows = impulse.len() / window_samples;
    if num_windows < 20 {
        return impulse;
    }

    let energies: Vec<f32> = (0..num_windows)
        .map(|window| {
            let start = window * window_samples;
            let end = start + window_samples;
            impulse[start..end]
                .iter()
                .map(|sample| sample * sample)
                .sum::<f32>()
                / window_samples as f32
        })
        .collect();

    let tail_count = ((num_windows as f32 * TAIL_FRACTION).ceil() as usize).max(1);
    let tail_start = num_windows - tail_count;
    let noise_floor = energies[tail_start..].iter().sum::<f32>() / tail_count as f32;
    if noise_floor <= 0.0 || !noise_floor.is_finite() {
        return impulse;
    }

    let signal_threshold = noise_floor * SNR_THRESHOLD;
    let Some(last_signal_window) = energies
        .iter()
        .enumerate()
        .rev()
        .find(|(_, energy)| **energy > signal_threshold)
        .map(|(idx, _)| idx)
    else {
        return impulse;
    };

    let keep_windows = (last_signal_window + 1 + HEADROOM_WINDOWS).min(num_windows);
    let keep_samples = (keep_windows * window_samples).min(impulse.len());
    if keep_samples >= impulse.len() {
        impulse
    } else {
        &impulse[..keep_samples]
    }
}

/// Find a frequency point where the magnitude reaches a specific dB level
///
/// # Arguments
/// * `frequencies` - Frequency points in Hz
/// * `magnitude_db` - Magnitude in dB
/// * `target_db` - The target level to find (e.g., -3.0)
/// * `from_start` - If true, search from the beginning of the curve. If false, search from the end.
///
/// # Returns
/// The interpolated frequency where the target dB is reached, or None if not found.
pub fn find_db_point(
    frequencies: &[f32],
    magnitude_db: &[f32],
    target_db: f32,
    from_start: bool,
) -> Option<f32> {
    if frequencies.len() < 2 || frequencies.len() != magnitude_db.len() {
        return None;
    }

    if from_start {
        for i in 0..magnitude_db.len() - 1 {
            let m0 = magnitude_db[i];
            let m1 = magnitude_db[i + 1];

            // Check if target_db is between m0 and m1
            if (m0 <= target_db && target_db <= m1) || (m1 <= target_db && target_db <= m0) {
                // Linear interpolation: m0 + t * (m1 - m0) = target_db
                let denominator = m1 - m0;
                if denominator.abs() < 1e-9 {
                    return Some(frequencies[i]);
                }
                let t = (target_db - m0) / denominator;
                return Some(frequencies[i] + t * (frequencies[i + 1] - frequencies[i]));
            }
        }
    } else {
        for i in (1..magnitude_db.len()).rev() {
            let m0 = magnitude_db[i];
            let m1 = magnitude_db[i - 1];

            // Check if target_db is between m0 and m1
            if (m0 <= target_db && target_db <= m1) || (m1 <= target_db && target_db <= m0) {
                let denominator = m1 - m0;
                if denominator.abs() < 1e-9 {
                    return Some(frequencies[i]);
                }
                let t = (target_db - m0) / denominator;
                return Some(frequencies[i] + t * (frequencies[i - 1] - frequencies[i]));
            }
        }
    }

    None
}
