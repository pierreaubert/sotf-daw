use rustfft::num_complex::Complex;

/// Flush denormal numbers to zero to prevent CPU performance spikes and audio glitches.
///
/// Denormal floats (IEEE 754 subnormals with magnitude < `f32::MIN_POSITIVE` ≈ 1.175e-38)
/// cause significant CPU overhead when processed by FMA instructions. Normal values
/// smaller than `f32::MIN_POSITIVE` do not exist — `f32::MIN_POSITIVE` IS the boundary.
/// Values at or above `f32::MIN_POSITIVE` are normal and will never be zeroed.
///
/// This is intentionally nonlinear and permanently replaces subnormal samples.
/// Apply it to DSP state or outputs where denormal suppression is desired, not to
/// archival/raw audio buffers whose subnormal tail values must be preserved.
#[inline]
pub fn flush_denormals_inplace(samples: &mut [f32]) {
    // f32::MIN_POSITIVE (~1.175e-38) is the smallest positive *normal* f32.
    // Values with abs() < MIN_POSITIVE are subnormals (denormals).
    const DENORM_THRESHOLD: f32 = f32::MIN_POSITIVE;

    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    {
        use std::arch::x86_64::*;

        let threshold = unsafe { _mm256_set1_ps(DENORM_THRESHOLD) };
        let zero = unsafe { _mm256_set1_ps(0.0) };
        let len = samples.len();
        let simd_len = (len / 8) * 8;

        for i in (0..simd_len).step_by(8) {
            unsafe {
                let ptr = samples.as_mut_ptr().add(i);
                let val = _mm256_loadu_ps(ptr);
                let abs_val = _mm256_andnot_ps(_mm256_set1_ps(-0.0), val);
                let mask = _mm256_cmp_ps(abs_val, threshold, _CMP_LT_OQ);
                let result = _mm256_blendv_ps(val, zero, mask);
                _mm256_storeu_ps(ptr, result);
            }
        }

        for sample in samples.iter_mut().take(len).skip(simd_len) {
            if sample.abs() < DENORM_THRESHOLD {
                *sample = 0.0;
            }
        }
    }

    #[cfg(all(target_arch = "aarch64", target_feature = "neon"))]
    {
        use std::arch::aarch64::*;

        let threshold = unsafe { vdupq_n_f32(DENORM_THRESHOLD) };
        let zero = unsafe { vdupq_n_f32(0.0) };
        let len = samples.len();
        let simd_len = (len / 4) * 4;

        for i in (0..simd_len).step_by(4) {
            unsafe {
                let ptr = samples.as_mut_ptr().add(i);
                let val = vld1q_f32(ptr);
                let abs_val = vabsq_f32(val);
                let mask = vcltq_f32(abs_val, threshold);
                let result = vbslq_f32(mask, zero, val);
                vst1q_f32(ptr, result);
            }
        }

        for sample in &mut samples[simd_len..len] {
            if sample.abs() < DENORM_THRESHOLD {
                *sample = 0.0;
            }
        }
    }

    #[cfg(not(any(
        all(target_arch = "x86_64", target_feature = "avx2"),
        all(target_arch = "aarch64", target_feature = "neon")
    )))]
    {
        for sample in samples {
            if sample.abs() < DENORM_THRESHOLD {
                *sample = 0.0;
            }
        }
    }
}

/// Flush denormals in complex buffer (applies to both real and imaginary parts)
#[inline]
pub fn flush_denormals_complex_inplace(samples: &mut [Complex<f32>]) {
    // A Complex<f32> is just two f32s (re and im)
    // We can treat the whole buffer as a slice of f32 and use flush_denormals_inplace
    let len = samples.len() * 2;
    let ptr = samples.as_mut_ptr() as *mut f32;
    let f32_samples = unsafe { std::slice::from_raw_parts_mut(ptr, len) };
    flush_denormals_inplace(f32_samples);
}

#[cfg(test)]
mod denorm_tests {
    use super::*;

    #[test]
    fn test_flush_denormals_basic() {
        // 1e-39 is subnormal (below f32::MIN_POSITIVE) and must be zeroed.
        // 1e-20, 1e-10, 1.0 are normal and must be preserved.
        let mut samples = [1e-39_f32, 1e-20, 1e-10, 0.0, -1e-39_f32, 1.0];
        flush_denormals_inplace(&mut samples);
        assert_eq!(samples[0], 0.0, "subnormal 1e-39 must be zeroed");
        assert_eq!(samples[1], 1e-20);
        assert_eq!(samples[2], 1e-10);
        assert_eq!(samples[3], 0.0);
        assert_eq!(samples[4], 0.0, "negative subnormal -1e-39 must be zeroed");
        assert_eq!(samples[5], 1.0);
    }

    /// A normal f32 value just above the subnormal boundary must NOT be zeroed.
    #[test]
    fn test_flush_denormals_normal_small_not_zeroed() {
        // 1e-35 is a normal f32 (above f32::MIN_POSITIVE ~1.175e-38).
        let mut samples = [1e-35_f32];
        flush_denormals_inplace(&mut samples);
        assert!(
            samples[0] != 0.0,
            "normal value 1e-35 (above f32::MIN_POSITIVE) must not be zeroed"
        );
    }

    /// A subnormal f32 value must be zeroed.
    #[test]
    fn test_flush_denormals_subnormal_zeroed() {
        // 1e-39 is a subnormal f32 (below f32::MIN_POSITIVE ~1.175e-38).
        let mut samples = [1e-39_f32];
        flush_denormals_inplace(&mut samples);
        assert_eq!(
            samples[0], 0.0,
            "subnormal value 1e-39 (below f32::MIN_POSITIVE) must be zeroed"
        );
    }

    #[test]
    fn test_flush_denormals_complex() {
        use rustfft::num_complex::Complex;
        // re=1e-39 (subnormal) zeroed; im=1e-30 (normal) preserved.
        let mut samples = [
            Complex::new(1e-39_f32, 1e-30_f32),
            Complex::new(1.0, 1e-39_f32),
            Complex::new(0.0, 0.0),
        ];
        flush_denormals_complex_inplace(&mut samples);
        assert_eq!(samples[0].re, 0.0, "subnormal re must be zeroed");
        assert!(samples[0].im != 0.0, "normal im 1e-30 must be preserved");
        assert_eq!(samples[1].re, 1.0);
        assert_eq!(samples[1].im, 0.0, "subnormal im must be zeroed");
        assert_eq!(samples[2].re, 0.0);
        assert_eq!(samples[2].im, 0.0);
    }

    #[test]
    fn test_flush_denormals_empty() {
        let mut samples: [f32; 0] = [];
        flush_denormals_inplace(&mut samples);
    }

    #[test]
    fn test_flush_denormals_unaligned() {
        let mut samples = [1e-39_f32; 7];
        flush_denormals_inplace(&mut samples);
        for s in samples.iter() {
            assert_eq!(*s, 0.0);
        }
    }

    #[test]
    fn test_flush_denormals_large_buffer() {
        let mut samples = vec![1e-39_f32; 1000];
        flush_denormals_inplace(&mut samples);
        for s in samples.iter() {
            assert_eq!(*s, 0.0);
        }
    }

    #[test]
    fn test_flush_denormals_all_normal() {
        let mut samples = [1.0f32, -1.0, 0.5, -0.5, 1e-30, -1e-30];
        flush_denormals_inplace(&mut samples);
        assert_eq!(samples[0], 1.0);
        assert_eq!(samples[1], -1.0);
        assert_eq!(samples[2], 0.5);
        assert_eq!(samples[3], -0.5);
        assert_eq!(samples[4], 1e-30);
        assert_eq!(samples[5], -1e-30);
    }

    #[test]
    fn test_flush_denormals_mixed() {
        let mut samples = [1.0f32, 1e-39, -1e-39, 0.5, 1e-39, -0.5, 1e-39];
        flush_denormals_inplace(&mut samples);
        assert_eq!(samples[0], 1.0);
        assert_eq!(samples[1], 0.0);
        assert_eq!(samples[2], 0.0);
        assert_eq!(samples[3], 0.5);
        assert_eq!(samples[4], 0.0);
        assert_eq!(samples[5], -0.5);
        assert_eq!(samples[6], 0.0);
    }

    #[test]
    fn test_flush_denormals_min_positive_boundary() {
        // f32::MIN_POSITIVE is the boundary; values at or above should NOT be zeroed
        let mut samples = [f32::MIN_POSITIVE, f32::MIN_POSITIVE * 0.5];
        flush_denormals_inplace(&mut samples);
        assert!(samples[0] != 0.0, "f32::MIN_POSITIVE should not be zeroed");
        assert_eq!(
            samples[1], 0.0,
            "half of MIN_POSITIVE is subnormal and should be zeroed"
        );
    }

    #[test]
    fn test_flush_denormals_complex_mixed() {
        use rustfft::num_complex::Complex;
        let mut samples = [
            Complex::new(1.0f32, 1e-39_f32),
            Complex::new(1e-39_f32, 1.0),
            Complex::new(1e-39_f32, 1e-39_f32),
        ];
        flush_denormals_complex_inplace(&mut samples);
        assert_eq!(samples[0].re, 1.0);
        assert_eq!(samples[0].im, 0.0);
        assert_eq!(samples[1].re, 0.0);
        assert_eq!(samples[1].im, 1.0);
        assert_eq!(samples[2].re, 0.0);
        assert_eq!(samples[2].im, 0.0);
    }
}
