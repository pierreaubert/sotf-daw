/// Result of a single-bin DFT-based phase extraction at a target
/// frequency, together with a stability metric that flags modally
/// contaminated bursts.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TonePhaseResult {
    /// Phase of the fundamental at `freq_hz` in degrees, wrapped to
    /// `(−180°, 180°]`. Relative to a reference `sin(ω·t)` emitted at
    /// the start of the analysis window.
    pub phase_deg: f64,
    /// Magnitude of the bin at `freq_hz` (linear, same units as the
    /// input signal). Zero when the signal contains no tone.
    pub magnitude: f64,
    /// |phase_half1 − phase_half2| in degrees. A stable,
    /// single-sinusoid burst has `stability_deg ≈ 0`. Modal ringing,
    /// low SNR, or time-varying phase drive this above 20°, which is
    /// the GD-Opt v2 advisory threshold for `"bass_anchor_unreliable"`.
    pub stability_deg: f64,
}

/// Per-window lock-in phasor at `freq_hz` produced by
/// [`tone_phase_phasors`]. Carries the raw `(re, im)` from
/// `single_bin_dft` plus the `start` index in the parent signal so a
/// caller can correlate two streams sub-window for sub-window.
#[derive(Debug, Clone, Copy)]
pub struct TonePhasorWindow {
    pub re: f64,
    pub im: f64,
    pub start: usize,
    pub len: usize,
}

/// Aggregate a slice of per-window phasors into a `TonePhaseResult`.
/// See [`extract_tone_phase_windowed`] for the semantics.
pub fn aggregate_tone_phase(phasors: &[TonePhasorWindow]) -> TonePhaseResult {
    let zero = TonePhaseResult {
        phase_deg: 0.0,
        magnitude: 0.0,
        stability_deg: 0.0,
    };
    if phasors.is_empty() {
        return zero;
    }
    let mut sum_re = 0.0_f64;
    let mut sum_im = 0.0_f64;
    let mut sum_mag = 0.0_f64;
    let mut sum_cos = 0.0_f64;
    let mut sum_sin = 0.0_f64;
    for p in phasors {
        sum_re += p.re;
        sum_im += p.im;
        let mag = (p.re * p.re + p.im * p.im).sqrt();
        sum_mag += 2.0 * mag / p.len as f64;
        let phase = p.im.atan2(p.re);
        sum_cos += phase.cos();
        sum_sin += phase.sin();
    }
    let n = phasors.len() as f64;
    let phase_rad = sum_im.atan2(sum_re);
    let mean_mag = sum_mag / n;
    let mean_cos = sum_cos / n;
    let mean_sin = sum_sin / n;
    let r_bar = (mean_cos * mean_cos + mean_sin * mean_sin).sqrt().min(1.0);
    let circ_std_rad = if r_bar > 1e-9 {
        (-2.0 * r_bar.ln()).sqrt()
    } else {
        std::f64::consts::PI
    };
    TonePhaseResult {
        phase_deg: phase_rad.to_degrees(),
        magnitude: mean_mag,
        stability_deg: circ_std_rad.to_degrees(),
    }
}
