/// A bin entry for the priority queue (max-heap by magnitude).
#[derive(PartialEq)]
pub(super) struct HeapEntry {
    pub(super) magnitude: f64,
    pub(super) bin: usize,
}

impl Eq for HeapEntry {}

impl PartialOrd for HeapEntry {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for HeapEntry {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        self.magnitude
            .partial_cmp(&other.magnitude)
            .unwrap_or(std::cmp::Ordering::Equal)
    }
}
