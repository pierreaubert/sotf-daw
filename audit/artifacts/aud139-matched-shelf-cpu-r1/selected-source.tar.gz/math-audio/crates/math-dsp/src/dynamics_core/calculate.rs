/// Compressor gain reduction: standard soft-knee formula.
///
/// Returns gain reduction in dB (positive value) for signals above threshold.
#[inline]
pub(super) fn calculate_compress_gr(input_db: f32, threshold: f32, ratio: f32, knee: f32) -> f32 {
    let slope = 1.0 - 1.0 / ratio.max(1.0);
    if knee < 0.1 {
        if input_db <= threshold {
            0.0
        } else {
            (input_db - threshold) * slope
        }
    } else if input_db < threshold - knee / 2.0 {
        0.0
    } else if input_db > threshold + knee / 2.0 {
        (input_db - threshold) * slope
    } else {
        let overshoot = input_db - threshold + knee / 2.0;
        let kf = overshoot / knee;
        kf * kf * (knee / 2.0) * slope
    }
}

/// Expander attenuation: below-threshold expansion with range cap.
///
/// Returns attenuation in dB (positive value) for signals below threshold,
/// capped at range_db.
#[inline]
pub(super) fn calculate_expand_atten(
    input_db: f32,
    threshold: f32,
    ratio: f32,
    knee: f32,
    range_db: f32,
) -> f32 {
    let slope = 1.0 - 1.0 / ratio.max(1.0);
    let atten = if knee < 0.1 {
        if input_db >= threshold {
            0.0
        } else {
            (threshold - input_db) * slope
        }
    } else if input_db > threshold + knee / 2.0 {
        0.0
    } else if input_db < threshold - knee / 2.0 {
        (threshold - input_db) * slope
    } else {
        let below = threshold + knee / 2.0 - input_db;
        let kf = below / knee;
        kf * kf * (knee / 2.0) * slope
    };
    atten.min(range_db.max(0.0))
}
