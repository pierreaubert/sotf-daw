/// One-shot result of [`measure_binaural`].
#[derive(Debug, Clone, Copy)]
pub struct BinauralLoudnessResult {
    /// Integrated programme loudness (LUFS), with EBU R128 two-pass gating.
    pub integrated_lufs: f64,
    /// Momentary loudness (400 ms window) at end of measurement.
    pub momentary_lufs: f64,
    /// Short-term loudness (3 s window) at end of measurement.
    pub shortterm_lufs: f64,
    /// Sample peak (linear, 0..1+) for the left ear.
    pub sample_peak_left: f64,
    /// Sample peak (linear, 0..1+) for the right ear.
    pub sample_peak_right: f64,
    /// True peak (linear, 0..1+) for the left ear, BS.1770-4 4× oversampled.
    pub true_peak_left: f64,
    /// True peak (linear, 0..1+) for the right ear, BS.1770-4 4× oversampled.
    pub true_peak_right: f64,
}

/// Standard channel orderings supported by [`BinauralDownmix`] presets.
///
/// All layouts follow the SMPTE / WAV interleaving convention used
/// elsewhere in this crate.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SurroundLayout {
    /// 5.0: `L, R, C, Ls, Rs` (5 channels).
    FiveZero,
    /// 5.1: `L, R, C, LFE, Ls, Rs` (6 channels).
    FiveOne,
    /// 7.1: `L, R, C, LFE, Ls, Rs, Lrs, Rrs` (8 channels).
    SevenOne,
}
