use crate::auto_makeup::MeasuredMakeup;
use crate::detector::{DetectionMode, LevelDetector};
use crate::envelope::DualRelease;
use crate::lookahead::LookaheadBuffer;
use math_audio_iir_fir::{Biquad, BiquadFilterType, peq_butterworth_highpass};

mod calculate;
mod consts;
mod misc;
#[cfg(test)]
mod tests;
mod types;

pub use types::*;

use calculate::calculate_compress_gr;
use calculate::calculate_expand_atten;
use consts::DUAL_RELEASE_SLOW_MULTIPLIER;
use consts::MAX_LOOKAHEAD_MS;
use consts::MEASURED_MAKEUP_SMOOTHING_MS;
use consts::RMS_WINDOW_MS;
use misc::hold_ms_to_samples;
use misc::time_to_coeff;

/// Shared dynamics processor used by both compressor and expander, single-band
/// and multiband. Each band in a multiband plugin gets its own DynamicsCore
/// instance.
pub struct DynamicsCore {
    mode: DynamicsMode,
    channels: usize,
    sample_rate: u32,

    // === Envelope ===
    envelope: Vec<f32>,
    attack_coeff: f32,
    release_coeff: f32,
    attack_ms: f32,
    release_ms: f32,

    // === Detection ===
    level_detectors: Vec<LevelDetector>,
    detection_mode_index: usize, // 0=peak, 1=RMS

    // === Sidechain filter (HPF or Tilt) ===
    sidechain_hpf_biquads: Vec<Vec<Biquad>>,
    sidechain_hpf_hz: f32,
    sidechain_hpf_order_index: usize, // 0=2nd, 1=4th
    sidechain_tilt_biquads: Vec<Biquad>,
    sidechain_tilt_db: f32,
    sidechain_filter_mode: SidechainFilterMode,

    // === Program-dependent release (compress mode only) ===
    dual_release: Vec<DualRelease>,
    program_dependent_release: bool,

    // === Makeup gain ===
    measured_makeup: MeasuredMakeup,

    // === Lookahead ===
    lookahead_buffer: LookaheadBuffer,
    lookahead_ms: f32,
    lookahead_frame_buf: Vec<f32>,

    // === Expand-mode gate state ===
    gate_state: Vec<GateState>,
    hold_counter: Vec<usize>,
    hysteresis_db: f32,
    hold_ms: f32,
    hold_samples_cached: usize,
    range_db: f32,
}

impl DynamicsCore {
    /// Create a new dynamics core processor.
    ///
    /// Pre-allocates all Vecs. Initializes coefficients for the given sample rate.
    /// LookaheadBuffer is sized for max 20ms capacity.
    pub fn new(mode: DynamicsMode, channels: usize, sample_rate: u32) -> Self {
        let detection_mode = DetectionMode::Peak;
        let max_lookahead_samples =
            (MAX_LOOKAHEAD_MS * 0.001 * sample_rate as f32).round() as usize;
        let attack_ms = 10.0;
        let release_ms = 100.0;

        let mut core = Self {
            mode,
            channels,
            sample_rate,

            envelope: vec![0.0; channels],
            attack_coeff: 0.0,
            release_coeff: 0.0,
            attack_ms,
            release_ms,

            level_detectors: (0..channels)
                .map(|_| LevelDetector::new(detection_mode, sample_rate))
                .collect(),
            detection_mode_index: 0,

            sidechain_hpf_biquads: Vec::new(),
            sidechain_hpf_hz: 0.0,
            sidechain_hpf_order_index: 0,
            sidechain_tilt_biquads: Vec::new(),
            sidechain_tilt_db: 0.0,
            sidechain_filter_mode: SidechainFilterMode::Off,

            dual_release: (0..channels)
                .map(|_| {
                    DualRelease::new(
                        release_ms,
                        release_ms * DUAL_RELEASE_SLOW_MULTIPLIER,
                        sample_rate,
                    )
                })
                .collect(),
            program_dependent_release: false,

            measured_makeup: MeasuredMakeup::new(MEASURED_MAKEUP_SMOOTHING_MS, sample_rate),

            lookahead_buffer: LookaheadBuffer::new(max_lookahead_samples.max(1), channels),
            lookahead_ms: 0.0,
            lookahead_frame_buf: vec![0.0; channels],

            gate_state: vec![GateState::Open; channels],
            hold_counter: vec![0; channels],
            hysteresis_db: 3.0,
            hold_ms: 50.0,
            hold_samples_cached: hold_ms_to_samples(50.0, sample_rate),
            range_db: 40.0,
        };

        core.attack_coeff = time_to_coeff(attack_ms, sample_rate);
        core.release_coeff = time_to_coeff(release_ms, sample_rate);
        // Lookahead disabled by default (0ms), set delay to minimum so push works
        core.lookahead_buffer.set_delay(1);

        core
    }

    /// Update sample rate and recompute all derived coefficients.
    ///
    /// Resizes level detectors and lookahead buffer for new sample rate.
    ///
    /// This method rebuilds buffers and filter state, so it is not real-time
    /// safe. Call it from setup or a manager thread, not from the audio callback.
    pub fn initialize(&mut self, sample_rate: u32) {
        self.sample_rate = sample_rate;

        // Recompute envelope coefficients
        self.attack_coeff = time_to_coeff(self.attack_ms, sample_rate);
        self.release_coeff = time_to_coeff(self.release_ms, sample_rate);
        self.hold_samples_cached = hold_ms_to_samples(self.hold_ms, sample_rate);

        // Rebuild sidechain filters
        self.rebuild_sidechain_hpf_internal();
        self.rebuild_sidechain_tilt_internal();

        // Reinitialize level detectors
        let mode = self.detection_mode();
        self.level_detectors = (0..self.channels)
            .map(|_| LevelDetector::new(mode, sample_rate))
            .collect();

        // Reinitialize lookahead buffer
        let max_lookahead_samples =
            (MAX_LOOKAHEAD_MS * 0.001 * sample_rate as f32).round() as usize;
        self.lookahead_buffer
            .resize(max_lookahead_samples.max(1), self.channels);
        if self.lookahead_ms > 0.0 {
            self.lookahead_buffer
                .set_delay_ms(self.lookahead_ms, sample_rate);
        } else {
            self.lookahead_buffer.set_delay(1);
        }

        // Reinitialize dual release
        self.dual_release = (0..self.channels)
            .map(|_| {
                DualRelease::new(
                    self.release_ms,
                    self.release_ms * DUAL_RELEASE_SLOW_MULTIPLIER,
                    sample_rate,
                )
            })
            .collect();

        // Reinitialize measured makeup
        self.measured_makeup = MeasuredMakeup::new(MEASURED_MAKEUP_SMOOTHING_MS, sample_rate);

        // Ensure frame buffer matches channel count
        self.lookahead_frame_buf.resize(self.channels, 0.0);
    }

    /// Zero all state: envelopes, gate states, hold counters, HPF biquad states,
    /// level detectors, lookahead buffer.
    pub fn reset(&mut self) {
        self.envelope.fill(0.0);

        // Reset gate state
        self.gate_state.fill(GateState::Open);
        self.hold_counter.fill(0);

        // Reset sidechain filter states by rebuilding
        self.rebuild_sidechain_hpf_internal();
        self.rebuild_sidechain_tilt_internal();

        // Reset level detectors
        for det in &mut self.level_detectors {
            det.reset();
        }

        // Reset lookahead
        self.lookahead_buffer.reset();

        // Reset dual release
        for dr in &mut self.dual_release {
            dr.reset();
        }

        // Reset measured makeup
        self.measured_makeup.reset();
    }

    /// Update attack and release time constants.
    ///
    /// Also updates dual release times (slow = release * 4.0).
    pub fn set_attack_release(&mut self, attack_ms: f32, release_ms: f32) {
        self.attack_ms = attack_ms;
        self.release_ms = release_ms;
        self.attack_coeff = time_to_coeff(attack_ms, self.sample_rate);
        self.release_coeff = time_to_coeff(release_ms, self.sample_rate);

        // Update dual release times
        for dr in &mut self.dual_release {
            dr.set_times(
                release_ms,
                release_ms * DUAL_RELEASE_SLOW_MULTIPLIER,
                self.sample_rate,
            );
        }
    }

    /// Rebuild sidechain HPF biquad cascade using `peq_butterworth_highpass()`.
    ///
    /// Same Butterworth cascade pattern as the compressor plugin.
    pub fn set_sidechain_hpf(&mut self, freq_hz: f32, order_index: usize) {
        self.sidechain_hpf_hz = freq_hz;
        self.sidechain_hpf_order_index = order_index;
        self.sidechain_filter_mode = if freq_hz > 0.0 {
            SidechainFilterMode::Hpf {
                freq_hz,
                order_index,
            }
        } else {
            SidechainFilterMode::Off
        };
        self.rebuild_sidechain_hpf_internal();
        self.sidechain_tilt_biquads.clear();
        self.sidechain_tilt_db = 0.0;
    }

    /// Set a spectral tilt filter on the sidechain detection path.
    ///
    /// `tilt_db`: positive values weight HF more heavily (e.g., +3 dB makes the
    /// compressor more sensitive to high frequencies). Negative values weight LF.
    /// Implemented as a 1st-order high-shelf at 1 kHz.
    pub fn set_sidechain_tilt(&mut self, tilt_db: f32) {
        self.sidechain_tilt_db = tilt_db;
        if tilt_db.abs() < 0.01 {
            // Tilt is being disabled: switch the sidechain filter off. The
            // filter mode selects which state is applied, so this also
            // deactivates any configured HPF (HPF and tilt are mutually
            // exclusive); the HPF biquads are left allocated for reuse.
            self.sidechain_filter_mode = SidechainFilterMode::Off;
            self.sidechain_tilt_biquads.clear();
            return;
        }
        self.sidechain_filter_mode = SidechainFilterMode::Tilt { tilt_db };
        // Clear HPF — tilt and HPF are mutually exclusive
        self.sidechain_hpf_biquads.clear();
        self.sidechain_hpf_hz = 0.0;
        self.rebuild_sidechain_tilt_internal();
    }

    /// Set sidechain filter using the unified enum.
    pub fn set_sidechain_filter(&mut self, mode: SidechainFilterMode) {
        match mode {
            SidechainFilterMode::Off => {
                self.sidechain_hpf_biquads.clear();
                self.sidechain_hpf_hz = 0.0;
                self.sidechain_tilt_biquads.clear();
                self.sidechain_tilt_db = 0.0;
                self.sidechain_filter_mode = SidechainFilterMode::Off;
            }
            SidechainFilterMode::Hpf {
                freq_hz,
                order_index,
            } => {
                self.set_sidechain_hpf(freq_hz, order_index);
            }
            SidechainFilterMode::Tilt { tilt_db } => {
                self.set_sidechain_tilt(tilt_db);
            }
        }
    }

    /// Set detection mode: 0=peak, 1=RMS. Reinitializes level detectors.
    ///
    /// Out-of-range indices are clamped to the nearest valid mode (with a
    /// debug assertion) instead of silently mapping to Peak.
    pub fn set_detection_mode(&mut self, mode_index: usize) {
        debug_assert!(
            mode_index <= 1,
            "detection mode index {mode_index} out of range (0=peak, 1=RMS); clamping"
        );
        self.detection_mode_index = mode_index.min(1);
        let mode = self.detection_mode();
        for det in &mut self.level_detectors {
            det.set_mode(mode);
        }
    }

    /// Update the lookahead delay.
    pub fn set_lookahead_ms(&mut self, ms: f32) {
        self.lookahead_ms = ms.clamp(0.0, MAX_LOOKAHEAD_MS);
        if self.lookahead_ms > 0.0 {
            self.lookahead_buffer
                .set_delay_ms(self.lookahead_ms, self.sample_rate);
        } else {
            self.lookahead_buffer.set_delay(1);
        }
    }

    /// Enable or disable program-dependent release (compress mode only).
    pub fn set_program_dependent_release(&mut self, enabled: bool) {
        self.program_dependent_release = enabled;
    }

    /// Set expand-mode parameters: hysteresis, hold, and range.
    pub fn set_expand_params(&mut self, hysteresis_db: f32, hold_ms: f32, range_db: f32) {
        self.hysteresis_db = hysteresis_db;
        self.hold_ms = hold_ms;
        self.hold_samples_cached = hold_ms_to_samples(hold_ms, self.sample_rate);
        self.range_db = range_db;
    }

    /// Get the dynamics mode.
    pub fn mode(&self) -> DynamicsMode {
        self.mode
    }

    /// Get the number of channels.
    pub fn channels(&self) -> usize {
        self.channels
    }

    // ========================================================================
    // Hot-path methods — called per-sample, zero allocations
    // ========================================================================

    /// Run the sidechain filter (HPF or Tilt) for this channel.
    ///
    /// Returns the filtered sample. If no sidechain filter is active, returns
    /// the input sample unchanged.
    #[inline]
    pub fn apply_sidechain_filter(&mut self, ch: usize, sample: f32) -> f32 {
        match self.sidechain_filter_mode {
            SidechainFilterMode::Off => sample,
            SidechainFilterMode::Hpf { .. } => {
                if ch >= self.sidechain_hpf_biquads.len() {
                    return sample;
                }
                let biquads: &mut [Biquad] = &mut self.sidechain_hpf_biquads[ch];
                let mut x = sample as f64;
                for bq in biquads.iter_mut() {
                    x = bq.process(x);
                }
                x as f32
            }
            SidechainFilterMode::Tilt { .. } => {
                if ch >= self.sidechain_tilt_biquads.len() {
                    return sample;
                }
                self.sidechain_tilt_biquads[ch].process(sample as f64) as f32
            }
        }
    }

    /// Detect level for one sample on a channel.
    ///
    /// Peak mode returns abs(sample). RMS mode uses the LevelDetector's sliding
    /// window and returns the linear RMS amplitude.
    #[inline]
    pub fn detect_level(&mut self, ch: usize, sample: f32) -> f32 {
        if self.detection_mode_index == 0 {
            // Peak mode: absolute value
            sample.abs()
        } else {
            // RMS mode: use LevelDetector
            self.level_detectors[ch].process_linear(sample)
        }
    }

    /// Calculate gain reduction/expansion attenuation for the given input level.
    ///
    /// For Compress mode: standard soft-knee gain reduction (above threshold).
    /// For Expand mode: expansion attenuation (below threshold), capped by range_db.
    #[inline]
    pub fn calculate_gain_reduction(
        &self,
        input_db: f32,
        threshold: f32,
        ratio: f32,
        knee_db: f32,
    ) -> f32 {
        match self.mode {
            DynamicsMode::Compress => calculate_compress_gr(input_db, threshold, ratio, knee_db),
            DynamicsMode::Expand => {
                calculate_expand_atten(input_db, threshold, ratio, knee_db, self.range_db)
            }
        }
    }

    /// Apply one-pole attack/release envelope smoothing.
    ///
    /// For compress mode with program_dependent_release enabled, uses DualRelease
    /// for the release coefficient. Returns the smoothed gain reduction in dB.
    ///
    /// Non-finite targets are ignored (the update is skipped) so a single
    /// NaN/Inf detector level cannot permanently corrupt the envelope —
    /// same policy as `EnvelopeFollower::process`.
    #[inline]
    pub fn apply_envelope(&mut self, ch: usize, target_gr: f32) -> f32 {
        if !target_gr.is_finite() {
            return self.envelope[ch];
        }
        let coeff = if target_gr > self.envelope[ch] {
            // Attack phase: target is higher gain reduction
            self.attack_coeff
        } else {
            // Release phase
            match self.mode {
                DynamicsMode::Compress if self.program_dependent_release => {
                    self.dual_release[ch].process(target_gr)
                }
                _ => self.release_coeff,
            }
        };

        // One-pole smoothing
        self.envelope[ch] = target_gr + coeff * (self.envelope[ch] - target_gr);
        self.envelope[ch]
    }

    /// Process the 3-state gate machine for expansion mode.
    ///
    /// Implements Open/Hold/Closing transitions with hysteresis.
    /// Returns the target attenuation in dB (0.0 when gate is open, or the
    /// expansion attenuation when gate is closing).
    ///
    /// This method integrates the gate state machine AND the expansion attenuation
    /// calculation, matching the expander plugin's `process_channel` pattern.
    #[inline]
    pub fn process_gate_state(
        &mut self,
        ch: usize,
        input_db: f32,
        threshold: f32,
        ratio: f32,
        knee_db: f32,
    ) -> f32 {
        let open_th = threshold;
        let close_th = threshold - self.hysteresis_db;

        match self.gate_state[ch] {
            GateState::Open => {
                if input_db < open_th {
                    self.gate_state[ch] = GateState::Hold;
                    self.hold_counter[ch] = self.hold_samples_cached;
                }
                0.0
            }
            GateState::Hold => {
                if input_db >= open_th {
                    self.gate_state[ch] = GateState::Open;
                    self.hold_counter[ch] = 0;
                    0.0
                } else if self.hold_counter[ch] > 0 {
                    self.hold_counter[ch] -= 1;
                    0.0
                } else if input_db < close_th {
                    self.gate_state[ch] = GateState::Closing;
                    self.calculate_gain_reduction(input_db, threshold, ratio, knee_db)
                } else {
                    0.0
                }
            }
            GateState::Closing => {
                if input_db >= open_th {
                    self.gate_state[ch] = GateState::Open;
                    0.0
                } else {
                    self.calculate_gain_reduction(input_db, threshold, ratio, knee_db)
                }
            }
        }
    }

    // ========================================================================
    // Getters
    // ========================================================================

    /// Get the current envelope value (gain reduction in dB) for a channel.
    #[inline]
    pub fn envelope_db(&self, ch: usize) -> f32 {
        self.envelope[ch]
    }

    /// Get the measured makeup gain in dB.
    #[inline]
    pub fn measured_makeup_db(&self) -> f32 {
        self.measured_makeup.makeup_db()
    }

    /// Get the measured makeup gain as a linear multiplier.
    #[inline]
    pub fn measured_makeup_linear(&self) -> f32 {
        self.measured_makeup.makeup_linear()
    }

    /// Update the measured makeup tracker with the current gain reduction.
    #[inline]
    pub fn update_measured_makeup(&mut self, gain_reduction: f32) {
        self.measured_makeup.update(gain_reduction);
    }

    /// Push one interleaved frame into the lookahead buffer, get the delayed
    /// frame out. `input` and `output` must have `channels` elements.
    #[inline]
    pub fn lookahead_process_frame(&mut self, input: &[f32], output: &mut [f32]) {
        self.lookahead_buffer.process_frame(input, output);
    }

    /// Returns the current lookahead delay in samples (frames).
    ///
    /// This reports the actual delay applied by the lookahead buffer. When
    /// lookahead is disabled (`set_lookahead_ms(0)`), the buffer still applies
    /// its minimum 1-frame delay, so this returns 1 — the reported latency
    /// always matches what the audio path actually does.
    pub fn lookahead_delay_samples(&self) -> usize {
        self.lookahead_buffer.delay()
    }

    /// Get a mutable reference to the lookahead frame buffer (pre-allocated).
    ///
    /// This buffer has `channels` elements and is used to avoid per-frame
    /// allocation when processing lookahead.
    #[inline]
    pub fn lookahead_frame_buf(&mut self) -> &mut [f32] {
        &mut self.lookahead_frame_buf
    }

    /// Get the current gate state for a channel (expand mode only).
    pub fn gate_state(&self, ch: usize) -> GateState {
        self.gate_state[ch]
    }

    /// Get the range_db value (expand mode only).
    pub fn range_db(&self) -> f32 {
        self.range_db
    }

    // ========================================================================
    // Internal helpers
    // ========================================================================

    fn detection_mode(&self) -> DetectionMode {
        if self.detection_mode_index == 1 {
            DetectionMode::Rms {
                window_ms: RMS_WINDOW_MS,
            }
        } else {
            DetectionMode::Peak
        }
    }

    fn rebuild_sidechain_hpf_internal(&mut self) {
        let fc = self.sidechain_hpf_hz.max(0.0);
        if fc > 0.0 && self.sample_rate > 0 {
            let order = match self.sidechain_hpf_order_index {
                1 => 4,
                _ => 2,
            };
            let peq = peq_butterworth_highpass(order, fc as f64, self.sample_rate as f64);
            let sections: Vec<Biquad> = peq.into_iter().map(|(_, bq)| bq).collect();
            self.sidechain_hpf_biquads = (0..self.channels).map(|_| sections.clone()).collect();
        } else {
            self.sidechain_hpf_biquads.clear();
        }
    }

    fn rebuild_sidechain_tilt_internal(&mut self) {
        let tilt = self.sidechain_tilt_db;
        if tilt.abs() < 0.01 || self.sample_rate == 0 {
            self.sidechain_tilt_biquads.clear();
            return;
        }
        // 1st-order high-shelf at 1 kHz: positive tilt = more HF sensitivity
        let shelf_freq = 1000.0;
        let q = 0.707; // Butterworth Q for 1st-order approximation
        self.sidechain_tilt_biquads = (0..self.channels)
            .map(|_| {
                Biquad::new(
                    BiquadFilterType::Highshelf,
                    shelf_freq,
                    self.sample_rate as f64,
                    q,
                    tilt as f64,
                )
            })
            .collect();
    }
}
