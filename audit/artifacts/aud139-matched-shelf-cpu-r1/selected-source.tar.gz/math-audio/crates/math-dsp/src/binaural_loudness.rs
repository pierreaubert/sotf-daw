//! Binaural loudness measurement per ITU-R BS.1770-4.
//!
//! BS.1770-4 specifies a K-weighting filter, mean-square energy integration,
//! and channel-weighted summation to obtain loudness in LUFS. The standard
//! defines explicit channel weights for mono, stereo, and 5.1 loudspeaker
//! layouts but does not single out binaural (headphone) reproduction.
//!
//! For binaural content (a 2-channel ear-signal pair produced by HRTF
//! rendering or dummy-head capture), industry practice is to apply the
//! BS.1770-4 algorithm with the same coefficients as the stereo case:
//! channel weights `G_L = G_R = 1.0`, no LFE, no surround +1.5 dB
//! correction. Both ear signals are K-weighted independently, their
//! mean-square energies summed, and the result reported in LUFS.
//!
//! This module wraps [`EbuR128`] with a binaural-specific API:
//!
//! * Always 2 channels (left ear, right ear).
//! * Convenience constructors and per-ear accessors.
//! * Cumulative true-peak tracking across the entire programme (the
//!   underlying [`EbuR128::prev_true_peak`] is snapshot-and-reset, so we
//!   accumulate locally).
//! * A one-shot [`measure_binaural`] helper for offline analysis.
//! * A surround → binaural downmix path ([`BinauralDownmix`],
//!   [`BinauralLoudness::add_surround_f32`], [`measure_binaural_from_surround`])
//!   for measuring loudness of multichannel content as it would be heard
//!   over headphones. Uses ITU-R BS.775 stereo-downmix coefficients by
//!   default — a level-only approximation of true HRTF rendering (no
//!   spectral or ITD cues). Callers with HRTF magnitude data should pass
//!   broadband per-channel gains via [`BinauralDownmix::from_matrix`].
//!
//! # Example
//!
//! ```
//! use math_audio_dsp::binaural_loudness::{BinauralLoudness, BinauralChannel};
//!
//! let mut meter = BinauralLoudness::new(48_000).unwrap();
//! let frames = vec![0.0f32; 48_000 * 2]; // 1 s of stereo silence
//! meter.add_interleaved_f32(&frames).unwrap();
//! let lufs = meter.integrated_lufs().unwrap();
//! assert!(lufs == f64::NEG_INFINITY || lufs < -100.0);
//! let _ = meter.sample_peak(BinauralChannel::Left).unwrap();
//! ```

use crate::ebur128::{EbuR128, Mode};

mod binaural_channel;
mod binaural_downmix;
mod measure;
#[cfg(test)]
mod tests;
mod types;

pub use binaural_channel::*;
pub use binaural_downmix::*;
pub use measure::*;
pub use types::*;

/// Streaming binaural-loudness meter applying ITU-R BS.1770-4 K-weighting
/// and gated integration to a 2-channel ear-signal pair.
pub struct BinauralLoudness {
    ebur128: EbuR128,
    sample_rate: u32,
    // Cumulative true-peak tracking (EbuR128's prev_true_peak is
    // snapshot-and-reset; we accumulate the max across snapshots).
    cum_true_peak: [f64; 2],
    // Interleave scratch buffer for add_separate_f32, reused across calls.
    interleave_buf: Vec<f32>,
}

impl BinauralLoudness {
    /// Create a binaural loudness meter at the given sample rate.
    ///
    /// All BS.1770-4 measurements are enabled: momentary, short-term,
    /// integrated, sample peak, and true peak.
    pub fn new(sample_rate: u32) -> Result<Self, String> {
        Self::with_mode(sample_rate, Mode::all())
    }

    /// Create a binaural loudness meter with explicit measurement modes.
    pub fn with_mode(sample_rate: u32, mode: Mode) -> Result<Self, String> {
        let ebur128 = EbuR128::new(2, sample_rate, mode)?;
        Ok(Self {
            ebur128,
            sample_rate,
            cum_true_peak: [0.0; 2],
            interleave_buf: Vec::new(),
        })
    }

    /// Sample rate this meter was configured for (Hz).
    pub fn sample_rate(&self) -> u32 {
        self.sample_rate
    }

    /// Feed interleaved stereo frames `[L0, R0, L1, R1, ...]`.
    pub fn add_interleaved_f32(&mut self, samples: &[f32]) -> Result<(), String> {
        if !samples.len().is_multiple_of(2) {
            return Err("binaural samples length must be even (interleaved L/R)".into());
        }
        self.ebur128.add_frames_f32(samples)?;
        self.refresh_cumulative_true_peak();
        Ok(())
    }

    /// Feed separate left / right buffers of equal length.
    pub fn add_separate_f32(&mut self, left: &[f32], right: &[f32]) -> Result<(), String> {
        if left.len() != right.len() {
            return Err(format!(
                "left and right buffers must have equal length (got {} vs {})",
                left.len(),
                right.len()
            ));
        }
        let needed = left.len() * 2;
        if self.interleave_buf.len() < needed {
            self.interleave_buf.resize(needed, 0.0);
        }
        let buf = &mut self.interleave_buf[..needed];
        for (i, (&l, &r)) in left.iter().zip(right.iter()).enumerate() {
            buf[i * 2] = l;
            buf[i * 2 + 1] = r;
        }
        self.ebur128.add_frames_f32(buf)?;
        self.refresh_cumulative_true_peak();
        Ok(())
    }

    /// Drain BS.1770-4 true-peak deltas into the cumulative tracker.
    /// `prev_true_peak` resets after read, so we max-merge each call.
    fn refresh_cumulative_true_peak(&mut self) {
        for ch in 0..2u32 {
            // prev_true_peak errors when TRUE_PEAK mode is disabled; skip.
            if let Ok(p) = self.ebur128.prev_true_peak(ch) {
                let i = ch as usize;
                if p > self.cum_true_peak[i] {
                    self.cum_true_peak[i] = p;
                }
            }
        }
    }

    /// Momentary loudness (400 ms window) in LUFS.
    pub fn momentary_lufs(&self) -> Result<f64, String> {
        self.ebur128.loudness_momentary()
    }

    /// Short-term loudness (3 s window) in LUFS.
    pub fn shortterm_lufs(&self) -> Result<f64, String> {
        self.ebur128.loudness_shortterm()
    }

    /// Integrated programme loudness in LUFS with EBU R128 two-pass gating.
    pub fn integrated_lufs(&self) -> Result<f64, String> {
        self.ebur128.loudness_global()
    }

    /// Cumulative sample peak (linear) for the given ear.
    pub fn sample_peak(&self, channel: BinauralChannel) -> Result<f64, String> {
        self.ebur128.sample_peak(channel.index())
    }

    /// Cumulative true peak (linear, BS.1770-4 4× oversampled) for the given ear.
    pub fn true_peak(&self, channel: BinauralChannel) -> f64 {
        self.cum_true_peak[channel.index() as usize]
    }

    /// Feed surround (multichannel) frames by downmixing through `downmix`
    /// to a binaural ear-signal pair, then accumulating BS.1770-4 statistics.
    ///
    /// `samples` must be interleaved with exactly `downmix.channels()`
    /// channels per frame. The downmix is a linear gain matrix applied
    /// frame-by-frame in `f64`; see [`BinauralDownmix`] for caveats and
    /// preset constructors.
    pub fn add_surround_f32(
        &mut self,
        samples: &[f32],
        downmix: &BinauralDownmix,
    ) -> Result<(), String> {
        let nc = downmix.channels();
        if nc == 0 {
            return Err("binaural downmix matrix is empty".into());
        }
        if !samples.len().is_multiple_of(nc) {
            return Err(format!(
                "samples length ({}) must be a multiple of source channel count ({})",
                samples.len(),
                nc
            ));
        }
        let num_frames = samples.len() / nc;
        let needed = num_frames * 2;
        if self.interleave_buf.len() < needed {
            self.interleave_buf.resize(needed, 0.0);
        }
        let buf = &mut self.interleave_buf[..needed];
        let coeffs = downmix.coeffs();
        for (i, frame) in samples.chunks_exact(nc).enumerate() {
            let mut l = 0.0f64;
            let mut r = 0.0f64;
            for (ch, &s) in frame.iter().enumerate() {
                let x = s as f64;
                l += x * coeffs[ch][0];
                r += x * coeffs[ch][1];
            }
            buf[i * 2] = l as f32;
            buf[i * 2 + 1] = r as f32;
        }
        self.ebur128.add_frames_f32(buf)?;
        self.refresh_cumulative_true_peak();
        Ok(())
    }

    /// Snapshot the current measurement state as a [`BinauralLoudnessResult`].
    pub fn snapshot(&self) -> Result<BinauralLoudnessResult, String> {
        Ok(BinauralLoudnessResult {
            integrated_lufs: self.integrated_lufs()?,
            momentary_lufs: self.momentary_lufs()?,
            shortterm_lufs: self.shortterm_lufs()?,
            sample_peak_left: self.sample_peak(BinauralChannel::Left)?,
            sample_peak_right: self.sample_peak(BinauralChannel::Right)?,
            true_peak_left: self.true_peak(BinauralChannel::Left),
            true_peak_right: self.true_peak(BinauralChannel::Right),
        })
    }

    /// Reset all internal state (filters, gating blocks, peaks).
    pub fn reset(&mut self) {
        self.ebur128.reset();
        self.cum_true_peak = [0.0; 2];
    }
}
