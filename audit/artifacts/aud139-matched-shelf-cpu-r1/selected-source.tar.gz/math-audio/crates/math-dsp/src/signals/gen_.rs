use super::misc::clip;
use super::misc::frames_for;
use super::misc::mls_taps;
use crate::stft::RealFftProcessor;
use math_audio_iir_fir::{Biquad, BiquadFilterType};
use rustfft::num_complex::Complex;
use std::f32::consts::PI;

/// Generate a pure tone (sine wave)
///
/// # Arguments
/// * `freq` - Frequency in Hz
/// * `amp` - Amplitude (0.0 to 1.0)
/// * `sample_rate` - Sample rate in Hz
/// * `duration` - Duration in seconds
pub fn gen_tone(freq: f32, amp: f32, sample_rate: u32, duration: f32) -> Vec<f32> {
    let n_frames = frames_for(duration, sample_rate);
    let mut signal = Vec::with_capacity(n_frames);
    let dphi = 2.0 * PI * freq / sample_rate as f32;
    let mut phase: f32 = 0.0;

    for _ in 0..n_frames {
        signal.push(clip(amp * phase.sin()));
        phase += dphi;
        if phase > 2.0 * PI {
            phase -= 2.0 * PI;
        }
    }

    signal
}

/// Generate a two-tone signal (sum of two sine waves)
///
/// Used for intermodulation distortion (IMD) testing.
/// If a1 + a2 > 1.0, the signals are automatically normalized to prevent clipping
/// while preserving the amplitude ratio.
///
/// # Arguments
/// * `f1` - First frequency in Hz
/// * `a1` - First amplitude (0.0 to 1.0)
/// * `f2` - Second frequency in Hz
/// * `a2` - Second amplitude (0.0 to 1.0)
/// * `sample_rate` - Sample rate in Hz
/// * `duration` - Duration in seconds
pub fn gen_two_tone(
    f1: f32,
    a1: f32,
    f2: f32,
    a2: f32,
    sample_rate: u32,
    duration: f32,
) -> Vec<f32> {
    let n_frames = frames_for(duration, sample_rate);
    let mut signal = Vec::with_capacity(n_frames);
    let dphi1 = 2.0 * PI * f1 / sample_rate as f32;
    let dphi2 = 2.0 * PI * f2 / sample_rate as f32;
    let mut phase1: f32 = 0.0;
    let mut phase2: f32 = 0.0;

    // Auto-normalize if the sum of amplitudes exceeds 1.0 to prevent clipping
    let sum_amp = a1 + a2;
    let (norm_a1, norm_a2) = if sum_amp > 1.0 {
        (a1 / sum_amp, a2 / sum_amp)
    } else {
        (a1, a2)
    };

    for _ in 0..n_frames {
        let sample = norm_a1 * phase1.sin() + norm_a2 * phase2.sin();
        signal.push(clip(sample));
        phase1 += dphi1;
        phase2 += dphi2;
        if phase1 > 2.0 * PI {
            phase1 -= 2.0 * PI;
        }
        if phase2 > 2.0 * PI {
            phase2 -= 2.0 * PI;
        }
    }

    signal
}

/// Generate a logarithmic frequency sweep
///
/// Sweeps from `f_start` to `f_end` Hz over the specified duration.
/// Useful for frequency response measurements.
///
/// This is the raw sweep generator and intentionally has no fade. Use
/// [`crate::signals::prepare_signal_for_playback`] when a measurement playback
/// needs pre-roll, post-roll, and edge fades.
///
/// # Arguments
/// * `f_start` - Starting frequency in Hz
/// * `f_end` - Ending frequency in Hz
/// * `amp` - Amplitude (0.0 to 1.0)
/// * `sample_rate` - Sample rate in Hz
/// * `duration` - Duration in seconds
pub fn gen_log_sweep(
    f_start: f32,
    f_end: f32,
    amp: f32,
    sample_rate: u32,
    duration: f32,
) -> Vec<f32> {
    try_gen_log_sweep(f_start, f_end, amp, sample_rate, duration).unwrap_or_default()
}

/// Fallible logarithmic sweep generator with explicit parameter validation.
pub fn try_gen_log_sweep(
    f_start: f32,
    f_end: f32,
    amp: f32,
    sample_rate: u32,
    duration: f32,
) -> Result<Vec<f32>, String> {
    if !f_start.is_finite()
        || !f_end.is_finite()
        || f_start <= 0.0
        || f_end <= 0.0
        || (f_end - f_start).abs() <= f32::EPSILON
    {
        return Err(
            "gen_log_sweep: frequencies must be finite, positive, and distinct".to_string(),
        );
    }
    if sample_rate == 0 || !duration.is_finite() || duration <= 0.0 {
        return Err(
            "gen_log_sweep: sample_rate and duration must be greater than zero".to_string(),
        );
    }
    if !amp.is_finite() {
        return Err("gen_log_sweep: amplitude must be finite".to_string());
    }
    let n_frames = frames_for(duration, sample_rate);
    let mut signal = Vec::with_capacity(n_frames);

    // Use f64 for phase computation to avoid precision loss at high frequencies.
    // The phase reaches tens of thousands of radians by the end of the sweep;
    // f32 sin() of such large values loses significant precision.
    let k = (f_end as f64 / f_start as f64).ln() / duration as f64;
    let coefficient = 2.0 * std::f64::consts::PI * f_start as f64 / k;

    for n in 0..n_frames {
        let t = n as f64 / sample_rate as f64;
        let phase = coefficient * ((k * t).exp() - 1.0);
        signal.push(clip(amp * phase.sin() as f32));
    }

    Ok(signal)
}

/// Generate an octave-scaled logarithmic frequency sweep.
///
/// Unlike [`gen_log_sweep`] (fixed duration uniform across octaves), this
/// function gives the sub-100 Hz region more time so modal energy can settle
/// and be measured accurately.
///
/// ## Time allocation
///
/// Three zones:
/// - **Bass** (f_start → 100 Hz): `bass_octave_duration_s` seconds per octave.
/// - **Mid** (100 Hz → 1 kHz): half the bass per-octave rate.
/// - **High** (1 kHz → f_end): quarter the bass per-octave rate.
///
/// If the computed total < `min_total_duration_s`, the sweep is stretched
/// proportionally so all zones receive a fair share.
///
/// ## Phase accuracy
///
/// Phase accumulation uses `f64` (same as [`gen_log_sweep`]).  Phase at t=0
/// is zero, so even 5–10 Hz sweeps start correctly.
///
/// # Arguments
/// * `f_start` - Starting frequency in Hz (clamped to ≥ 1 Hz)
/// * `f_end` - Ending frequency in Hz
/// * `amp` - Amplitude (0.0 to 1.0)
/// * `sample_rate` - Sample rate in Hz
/// * `bass_octave_duration_s` - Seconds per octave below 100 Hz; values
///   below 0.1 are clamped to 0.1 (zero/negative would otherwise yield a
///   zero or negative time scale and a silently degenerate sweep)
/// * `min_total_duration_s` - Lower bound on total sweep duration
///   (values ≤ 0 mean "no floor")
pub fn gen_log_sweep_octave_scaled(
    f_start: f32,
    f_end: f32,
    amp: f32,
    sample_rate: u32,
    bass_octave_duration_s: f32,
    min_total_duration_s: f32,
) -> Vec<f32> {
    let f_start = f_start.max(1.0) as f64;
    let f_end = (f_end as f64).max(f_start * 1.001);
    let sr = sample_rate as f64;

    const BASS_BOUNDARY: f64 = 100.0;
    const MID_BOUNDARY: f64 = 1000.0;

    // Floor on the per-octave rate: a non-positive value would make the
    // zone durations zero/negative and the stretch `scale` meaningless.
    const MIN_BASS_OCTAVE_DURATION_S: f64 = 0.1;
    let bass_s_oct = (bass_octave_duration_s as f64).max(MIN_BASS_OCTAVE_DURATION_S);
    let mid_s_oct = bass_s_oct * 0.5;
    let high_s_oct = bass_s_oct * 0.25;

    let octaves_bass = {
        let lo = f_start;
        let hi = BASS_BOUNDARY.min(f_end);
        if hi > lo { (hi / lo).log2() } else { 0.0 }
    };
    let octaves_mid = {
        let lo = BASS_BOUNDARY.max(f_start);
        let hi = MID_BOUNDARY.min(f_end);
        if hi > lo { (hi / lo).log2() } else { 0.0 }
    };
    let octaves_high = {
        let lo = MID_BOUNDARY.max(f_start);
        let hi = f_end;
        if hi > lo { (hi / lo).log2() } else { 0.0 }
    };

    let raw_duration =
        octaves_bass * bass_s_oct + octaves_mid * mid_s_oct + octaves_high * high_s_oct;

    let total_duration = raw_duration.max(min_total_duration_s as f64);
    let scale = if raw_duration > 1e-9 {
        total_duration / raw_duration
    } else {
        1.0
    };

    let n_frames = (total_duration * sr).round() as usize;

    // Zone end-times (absolute, after scale).
    let t_bass = octaves_bass * bass_s_oct * scale;
    let t_mid = t_bass + octaves_mid * mid_s_oct * scale;

    // Phase offset accumulated through each zone transition.
    //   φ_zone = coeff * (r - 1)   where r = f_hi / f_lo
    let phase_offset_bass: f64 = if octaves_bass > 1e-9 && t_bass > 1e-9 {
        let hi = BASS_BOUNDARY.min(f_end);
        let c = 2.0 * std::f64::consts::PI * f_start * t_bass / (hi / f_start).ln();
        c * (hi / f_start - 1.0)
    } else {
        0.0
    };

    let phase_offset_mid: f64 = phase_offset_bass
        + if octaves_mid > 1e-9 {
            let lo = BASS_BOUNDARY.max(f_start);
            let hi = MID_BOUNDARY.min(f_end);
            let dur = t_mid - t_bass;
            let c = 2.0 * std::f64::consts::PI * lo * dur / (hi / lo).ln();
            c * (hi / lo - 1.0)
        } else {
            0.0
        };

    let mut signal = Vec::with_capacity(n_frames);

    for n in 0..n_frames {
        let t = n as f64 / sr;

        let phase = if t <= t_bass && t_bass > 1e-9 {
            // Bass zone.
            let hi = BASS_BOUNDARY.min(f_end);
            let c = 2.0 * std::f64::consts::PI * f_start * t_bass / (hi / f_start).ln();
            let k = (hi / f_start).ln() / t_bass;
            c * ((k * t).exp() - 1.0)
        } else if t <= t_mid && octaves_mid > 1e-9 {
            // Mid zone.
            let lo = BASS_BOUNDARY.max(f_start);
            let hi = MID_BOUNDARY.min(f_end);
            let dur = t_mid - t_bass;
            let c = 2.0 * std::f64::consts::PI * lo * dur / (hi / lo).ln();
            let k = (hi / lo).ln() / dur;
            let t_local = t - t_bass;
            phase_offset_bass + c * ((k * t_local).exp() - 1.0)
        } else if octaves_high > 1e-9 {
            // High zone.
            let lo = MID_BOUNDARY.max(f_start);
            let dur = total_duration - t_mid;
            if dur > 1e-9 {
                let c = 2.0 * std::f64::consts::PI * lo * dur / (f_end / lo).ln();
                let k = (f_end / lo).ln() / dur;
                let t_local = t - t_mid;
                phase_offset_mid + c * ((k * t_local).exp() - 1.0)
            } else {
                phase_offset_mid
            }
        } else if octaves_mid > 1e-9 {
            // Entire sweep is in a single zone (mid or bass already handled above).
            phase_offset_mid
        } else {
            // Degenerate: f_start >= f_end or single frequency.
            2.0 * std::f64::consts::PI * f_start * t
        };

        signal.push(clip(amp * phase.sin() as f32));
    }

    signal
}

/// Generate white noise
///
/// Produces noise with a flat frequency spectrum.
/// Uses a deterministic LCG for reproducible output.
///
/// # Arguments
/// * `amp` - Amplitude (0.0 to 1.0)
/// * `sample_rate` - Sample rate in Hz
/// * `duration` - Duration in seconds
pub fn gen_white_noise(amp: f32, sample_rate: u32, duration: f32) -> Vec<f32> {
    gen_white_noise_seeded(amp, sample_rate, duration, 1234567890)
}

/// Generate white noise with a caller-controlled deterministic seed.
pub fn gen_white_noise_seeded(
    amp: f32,
    sample_rate: u32,
    duration: f32,
    mut seed: u64,
) -> Vec<f32> {
    let n_frames = frames_for(duration, sample_rate);
    let mut signal = Vec::with_capacity(n_frames);

    // Simple LCG random number generator for deterministic output
    for _ in 0..n_frames {
        // LCG constants from Numerical Recipes
        seed = seed.wrapping_mul(1664525).wrapping_add(1013904223);
        // Fold the 64-bit state into 32 bits from the high end: the low
        // bits of an LCG have short periods (bit k has period 2^(k+1)).
        // Same extraction as gen_probe_spectrum.
        let random_u32 = ((seed >> 33) ^ seed) as u32;
        let random = (random_u32 as f32 / u32::MAX as f32) * 2.0 - 1.0;
        signal.push(clip(amp * random));
    }

    signal
}

/// Generate pink noise
///
/// Produces noise with a 1/f spectrum (-3dB/octave).
/// Uses the Voss-McCartney algorithm (Paul Kellett's implementation).
///
/// # Arguments
/// * `amp` - Amplitude (0.0 to 1.0)
/// * `sample_rate` - Sample rate in Hz
/// * `duration` - Duration in seconds
pub fn gen_pink_noise(amp: f32, sample_rate: u32, duration: f32) -> Vec<f32> {
    gen_pink_noise_seeded(amp, sample_rate, duration, 9876543210)
}

/// Generate pink noise with a caller-controlled deterministic seed.
pub fn gen_pink_noise_seeded(amp: f32, sample_rate: u32, duration: f32, mut seed: u64) -> Vec<f32> {
    let n_frames = frames_for(duration, sample_rate);
    let mut signal = Vec::with_capacity(n_frames);

    // Voss-McCartney algorithm (Paul Kellett's implementation)
    // Uses multiple white noise generators at different rates
    let mut b0 = 0.0f32;
    let mut b1 = 0.0f32;
    let mut b2 = 0.0f32;
    let mut b3 = 0.0f32;
    let mut b4 = 0.0f32;
    let mut b5 = 0.0f32;
    let mut b6 = 0.0f32;

    // Normalization factor derived from the filter coefficients.
    // Each filter is y_i[n] = a_i*y_i[n-1] + b_i*w[n] driven by the same
    // white noise w[n] (uniform [-1,1], variance 1/3). The steady-state
    // output variance is:
    //   Var = Σ_ij b_i*b_j/(3*(1 - a_i*a_j))    (IIR auto/cross-covariances)
    //       + Σ_i 2*d*b_i/3                      (direct-white ↔ IIR cross)
    //       + Σ_i 2*e*a_i*b_i/3                  (delayed-white b6 ↔ IIR cross)
    //       + (d² + e²)/3                         (direct + delayed white terms)
    // where d=0.5362 (direct white gain) and e=0.115926 (delayed white
    // gain, b6[n] = e*w[n-1]; cov(y_i[n], w[n-1]) = a_i*b_i/3). This gives
    // RMS ≈ 1.7624. Dividing by this value makes RMS(output) ≈ amp for
    // moderate amp (peaks still approach ±1 near amp=1.0, where clip()
    // bounds them).
    const PINK_NORM: f32 = 1.0 / 1.7624;

    for _ in 0..n_frames {
        // Generate white noise
        seed = seed.wrapping_mul(1664525).wrapping_add(1013904223);
        // Fold the 64-bit state into 32 bits from the high end: the low
        // bits of an LCG have short periods (bit k has period 2^(k+1)).
        let random_u32 = ((seed >> 33) ^ seed) as u32;
        let white = (random_u32 as f32 / u32::MAX as f32) * 2.0 - 1.0;

        // Update pink noise state at different rates
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.153_852;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;

        let pink = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
        b6 = white * 0.115926;

        signal.push(clip(amp * pink * PINK_NORM));
    }

    signal
}

/// Generate a Maximum Length Sequence (MLS).
///
/// The sequence is generated by a deterministic Fibonacci LFSR seeded with all
/// ones and mapped from bits to bipolar samples: `1 => +amp`, `0 => -amp`.
/// Supported orders are 2 through 24, giving sequence lengths of
/// `2^order - 1` samples.
///
/// # Arguments
/// * `order` - LFSR order in the range 2..=24
/// * `amp` - Peak amplitude
pub fn gen_mls(order: u8, amp: f32) -> Vec<f32> {
    let Some(taps) = mls_taps(order) else {
        return Vec::new();
    };

    let len = (1_usize << order) - 1;
    let state_mask = (1_u32 << order) - 1;
    let mut tap_mask = 0_u32;
    for &tap in taps {
        tap_mask |= 1_u32 << (tap - 1);
    }

    let amp = clip(amp);
    let mut state = state_mask;
    let mut signal = Vec::with_capacity(len);

    for _ in 0..len {
        let out_bit = state & 1;
        signal.push(if out_bit == 1 { amp } else { -amp });

        let feedback = (state & tap_mask).count_ones() & 1;
        state = ((state << 1) & state_mask) | feedback;
    }

    signal
}

/// Generate a Dirac impulse signal.
///
/// Alias for [`gen_impulse`] using the Dirac naming used by measurement and
/// room-eq workflows.
///
/// # Arguments
/// * `amp` - Amplitude of the impulse sample
/// * `sample_rate` - Sample rate in Hz
/// * `duration` - Duration in seconds
pub fn gen_dirac(amp: f32, sample_rate: u32, duration: f32) -> Vec<f32> {
    gen_impulse(amp, sample_rate, duration)
}

/// Generate an impulse signal (first sample is amplitude, rest are zero)
///
/// # Arguments
/// * `amp` - Amplitude (clipped to ±0.999999 by `clip`, so amp ≥ 1.0
///   produces a 0.999999 sample)
/// * `sample_rate` - Sample rate in Hz
/// * `duration` - Duration in seconds
pub fn gen_impulse(amp: f32, sample_rate: u32, duration: f32) -> Vec<f32> {
    let n_frames = frames_for(duration, sample_rate);
    let mut signal = vec![0.0; n_frames];
    if n_frames > 0 {
        signal[0] = clip(amp);
    }
    signal
}

/// Generate a step signal (all samples are amplitude)
///
/// # Arguments
/// * `amp` - Amplitude (clipped to ±0.999999 by `clip`, so amp ≥ 1.0
///   produces 0.999999 samples)
/// * `sample_rate` - Sample rate in Hz
/// * `duration` - Duration in seconds
pub fn gen_step(amp: f32, sample_rate: u32, duration: f32) -> Vec<f32> {
    let n_frames = frames_for(duration, sample_rate);
    vec![clip(amp); n_frames]
}

/// Generate M-weighted noise
///
/// Produces noise weighted according to ITU-R 468 standard.
/// This weighting emphasizes frequencies around 6.3 kHz, which is
/// useful for acoustic measurements.
///
/// # Arguments
/// * `amp` - Amplitude (0.0 to 1.0)
/// * `sample_rate` - Sample rate in Hz
/// * `duration` - Duration in seconds
pub fn gen_m_noise(amp: f32, sample_rate: u32, duration: f32) -> Vec<f32> {
    gen_m_noise_seeded(amp, sample_rate, duration, 1122334455)
}

/// Generate ITU-R 468-weighted noise with a caller-controlled seed.
pub fn gen_m_noise_seeded(amp: f32, sample_rate: u32, duration: f32, mut seed: u64) -> Vec<f32> {
    let n_frames = frames_for(duration, sample_rate);
    let srate = sample_rate as f64;

    // ITU-R 468 weighting approximation using cascaded biquad filters:
    //   - Highpass at 20 Hz removes sub-bass
    //   - Low shelf +5 dB at 100 Hz shapes the low-frequency rise
    //   - Peak +12 dB at 6.3 kHz is the characteristic ITU-R 468 peak
    //   - Peak -4 dB at 12 kHz shapes the descent above the peak
    //   - Lowpass at 22 kHz rolls off ultrasonics
    let mut filters = [
        Biquad::new(BiquadFilterType::Highpass, 20.0, srate, 0.0, 0.0),
        Biquad::new(BiquadFilterType::Lowshelf, 100.0, srate, 0.6, 5.0),
        Biquad::new(BiquadFilterType::Peak, 6300.0, srate, 1.0, 12.0),
        Biquad::new(BiquadFilterType::Peak, 12000.0, srate, 0.8, -4.0),
        Biquad::new(BiquadFilterType::Lowpass, 22000.0, srate, 0.0, 0.0),
    ];

    // Stream the white noise straight through the biquad chain into the
    // output — no intermediate noise buffer.
    let amp_f64 = amp as f64;
    let mut out = Vec::with_capacity(n_frames);
    for _ in 0..n_frames {
        seed = seed.wrapping_mul(1664525).wrapping_add(1013904223);
        // Fold the 64-bit state into 32 bits from the high end: the low
        // bits of an LCG have short periods (bit k has period 2^(k+1)).
        let random_u32 = ((seed >> 33) ^ seed) as u32;
        let white = (random_u32 as f64 / u32::MAX as f64) * 2.0 - 1.0;
        let mut s = white;
        for f in &mut filters {
            s = f.process(s);
        }
        out.push(clip((amp_f64 * s) as f32));
    }
    out
}

/// Generate the frequency-domain spectrum for an allpass probe signal.
///
/// Returns `spectrum_size = fft_size/2 + 1` complex bins with unit magnitude
/// and continuously accumulated random phase. DC and Nyquist bins are forced real.
pub(super) fn gen_probe_spectrum(fft_size: usize, seed: u64) -> Vec<Complex<f32>> {
    let spectrum_size = fft_size / 2 + 1;
    let mut spectrum = vec![Complex::new(0.0, 0.0); spectrum_size];

    // Seeded LCG for reproducible phase increments
    let mut rng_state = seed;
    let max_delta = std::f32::consts::FRAC_PI_4; // π/4 max increment per bin

    // DC bin: phase = 0 (must be real)
    spectrum[0] = Complex::new(1.0, 0.0);

    let mut phase: f32 = 0.0;
    // fft_size 0/1/2 leave no interior bins between DC and Nyquist;
    // skip the loop so the empty interior slice is never formed.
    if spectrum_size > 2 {
        for bin in spectrum[1..spectrum_size - 1].iter_mut() {
            // LCG step
            rng_state = rng_state
                .wrapping_mul(6364136223846793005)
                .wrapping_add(1442695040888963407);
            let random_u32 = ((rng_state >> 33) ^ rng_state) as u32;
            let delta = (random_u32 as f32 / u32::MAX as f32) * max_delta;
            phase += delta;

            let (sin_p, cos_p) = phase.sin_cos();
            *bin = Complex::new(cos_p, sin_p);

            // Avoid phase growing unboundedly (wrap at 2π)
            if phase > 2.0 * PI {
                phase -= 2.0 * PI;
            }
        }
    }

    // Nyquist bin: phase = 0 (must be real for even-length signals)
    if spectrum_size > 1 {
        spectrum[spectrum_size - 1] = Complex::new(1.0, 0.0);
    }

    spectrum
}

/// Generate a wideband allpass probe signal.
///
/// Synthesized in the DFT domain with unit magnitude at all frequency bins
/// and continuously accumulated random phase. The result is a real signal
/// with flat power spectrum but energy spread across time — better than
/// sweeps for nonlinear speakers (per Johnston AES).
///
/// # Arguments
/// * `n_frames` - Number of output samples (determines frequency resolution)
/// * `sample_rate` - Sample rate in Hz; currently unused (the spectrum is
///   allpass at every bin, so no Hz→bin mapping is needed). Kept for API
///   symmetry with [`gen_narrowband_probe`], which does need it.
/// * `amp` - Peak amplitude (signal is normalized to this)
/// * `seed` - RNG seed for reproducible phase (same seed = same probe)
pub fn gen_allpass_probe(n_frames: usize, _sample_rate: u32, amp: f32, seed: u64) -> Vec<f32> {
    if n_frames == 0 {
        return Vec::new();
    }

    let fft_size = n_frames;
    let mut fft = RealFftProcessor::new_bidirectional(fft_size);

    let spectrum = gen_probe_spectrum(fft_size, seed);
    fft.freq_buffer[..spectrum.len()].copy_from_slice(&spectrum);

    // IFFT to time domain
    fft.inverse();

    // Normalize: scale so peak = amp
    let peak = fft.time_buffer[..n_frames]
        .iter()
        .map(|&x| x.abs())
        .fold(0.0_f32, f32::max);

    let scale = if peak > 1e-10 { amp / peak } else { 0.0 };

    fft.time_buffer[..n_frames]
        .iter()
        .map(|&x| clip(x * scale))
        .collect()
}

/// Generate a narrowband allpass probe (bandpass filtered).
///
/// Same phase structure as `gen_allpass_probe` (when given the same seed),
/// but zeroes out frequency bins outside `[lo_hz, hi_hz]` with a smooth
/// Tukey taper at band edges. Used as a matched filter for delay detection
/// with excellent noise rejection.
///
/// # Arguments
/// * `n_frames` - Number of output samples
/// * `sample_rate` - Sample rate in Hz
/// * `amp` - Peak amplitude (signal is normalized to this)
/// * `seed` - RNG seed (same seed as wideband = identical phase within passband)
/// * `lo_hz` - Lower cutoff frequency in Hz (negative values are clamped to 0)
/// * `hi_hz` - Upper cutoff frequency in Hz
///
/// # Returns
/// The probe signal, or an empty vector when `n_frames == 0` or the band
/// is inverted (`lo_hz >= hi_hz`) — an inverted band would otherwise
/// silently produce an all-zeros buffer.
pub fn gen_narrowband_probe(
    n_frames: usize,
    sample_rate: u32,
    amp: f32,
    seed: u64,
    lo_hz: f32,
    hi_hz: f32,
) -> Vec<f32> {
    if n_frames == 0 || lo_hz >= hi_hz {
        return Vec::new();
    }
    let lo_hz = lo_hz.max(0.0);

    let fft_size = n_frames;
    let spectrum_size = fft_size / 2 + 1;
    let mut fft = RealFftProcessor::new_bidirectional(fft_size);

    let spectrum = gen_probe_spectrum(fft_size, seed);
    let freq_resolution = sample_rate as f32 / fft_size as f32;

    // Number of bins for the Tukey taper at each band edge
    let taper_bins = 10_usize;

    #[allow(clippy::needless_range_loop)]
    for k in 0..spectrum_size {
        let freq = k as f32 * freq_resolution;

        if freq < lo_hz || freq > hi_hz {
            // Outside passband: zero
            fft.freq_buffer[k] = Complex::new(0.0, 0.0);
        } else {
            // Inside passband: apply spectrum with tapers at the edges.
            // When the band is narrower than ~2*taper_bins the two edge
            // tapers overlap; they must compose (multiply), not overwrite,
            // so the envelope stays symmetric around the band centre.
            let mut gain = 1.0_f32;

            // Lower edge taper (Hann half-window, rising from near-zero to 1.0)
            let lo_bin = (lo_hz / freq_resolution).ceil() as usize;
            if k < lo_bin + taper_bins && k >= lo_bin {
                // Use (taper_bins + 1) so edge bins get nonzero gain
                let t = (k - lo_bin + 1) as f32 / (taper_bins + 1) as f32;
                gain *= 0.5 * (1.0 - (PI * t).cos());
            }

            // Upper edge taper (Hann half-window, falling from 1.0 to near-zero)
            let hi_bin = (hi_hz / freq_resolution).floor() as usize;
            if hi_bin >= taper_bins && k > hi_bin - taper_bins && k <= hi_bin {
                let t = (hi_bin - k + 1) as f32 / (taper_bins + 1) as f32;
                gain *= 0.5 * (1.0 - (PI * t).cos());
            }

            fft.freq_buffer[k] = spectrum[k] * gain;
        }
    }

    // IFFT to time domain
    fft.inverse();

    // Normalize peak to amp
    let peak = fft.time_buffer[..n_frames]
        .iter()
        .map(|&x| x.abs())
        .fold(0.0_f32, f32::max);

    let scale = if peak > 1e-10 { amp / peak } else { 0.0 };

    fft.time_buffer[..n_frames]
        .iter()
        .map(|&x| clip(x * scale))
        .collect()
}

/// Generate a Hann-windowed sinusoidal tone burst at a single frequency.
///
/// Used by the recording wizard's BassAnchor step to capture a
/// per-channel phase reference at the bottom of the bass band, where
/// sweep SNR is marginal. At 20 Hz × 5 cycles @ 48 kHz the burst is
/// 250 ms / 12 000 samples — long enough to resolve phase, short enough
/// to keep modal ringing bounded.
///
/// # Arguments
/// * `freq_hz`    - Fundamental frequency of the burst in Hz.
/// * `num_cycles` - Number of cycles (tone-length in periods of `freq_hz`).
/// * `sample_rate` - Sample rate in Hz.
/// * `amp`        - Peak amplitude after windowing (≤ 1.0).
///
/// # Returns
/// The burst as a vector of `f32` samples. An empty vector if any input
/// is zero / sub-sample-length.
pub fn gen_bass_tone_burst(freq_hz: f32, num_cycles: u16, sample_rate: u32, amp: f32) -> Vec<f32> {
    if freq_hz <= 0.0 || num_cycles == 0 || sample_rate == 0 || amp <= 0.0 {
        return Vec::new();
    }
    let n = ((num_cycles as f32 / freq_hz) * sample_rate as f32).round() as usize;
    if n < 2 {
        return Vec::new();
    }
    let omega = 2.0 * std::f64::consts::PI * freq_hz as f64 / sample_rate as f64;
    let n_f = n as f32;
    (0..n)
        .map(|k| {
            let t = k as f32;
            // Hann envelope: (1 - cos(2π k / (n-1))) / 2
            let w = 0.5 * (1.0 - (2.0 * PI * t / (n_f - 1.0)).cos());
            // f64 phase with 2π wrapping (same rationale as gen_log_sweep):
            // the raw argument reaches ~7.5e6 rad for a long high-frequency
            // burst, where f32 rounding alone would cost ~0.5 rad of phase.
            let phase = (omega * k as f64) % (2.0 * std::f64::consts::PI);
            clip(amp * w * phase.sin() as f32)
        })
        .collect()
}

/// Generate a steady-state sinusoidal tone with linear-Hann fade in/out.
///
/// Used by the recording wizard's BassAnchor step (GD-Opt v2 Phase
/// GD-1e) for steady-state lock-in phase extraction. Plays a continuous
/// sine for `duration_s` seconds with `fade_ms` half-Hann fades at the
/// start and end so the speaker doesn't see a transient. The total
/// length is exactly `round(duration_s · sample_rate)` samples.
///
/// # Arguments
/// * `freq_hz`     - Tone frequency in Hz.
/// * `duration_s`  - Total tone length in seconds (≥ `2 · fade_ms`).
/// * `fade_ms`     - Fade-in / fade-out length in milliseconds.
/// * `sample_rate` - Sample rate in Hz.
/// * `amp`         - Peak amplitude in the steady portion (≤ 1.0).
///
/// # Returns
/// A vector of `f32` samples; empty when any input is zero or the
/// duration is shorter than two fades.
pub fn gen_steady_tone(
    freq_hz: f32,
    duration_s: f32,
    fade_ms: f32,
    sample_rate: u32,
    amp: f32,
) -> Vec<f32> {
    if freq_hz <= 0.0 || duration_s <= 0.0 || sample_rate == 0 || amp <= 0.0 {
        return Vec::new();
    }
    let n = (duration_s * sample_rate as f32).round() as usize;
    let fade_n = ((fade_ms.max(0.0) / 1000.0) * sample_rate as f32).round() as usize;
    if n < 2 * fade_n.max(1) {
        return Vec::new();
    }
    let omega = 2.0 * std::f64::consts::PI * freq_hz as f64 / sample_rate as f64;
    (0..n)
        .map(|k| {
            let env = if fade_n == 0 {
                1.0
            } else if k < fade_n {
                // Half-Hann fade-in: 0 → 1 across `fade_n` samples.
                0.5 * (1.0 - (PI * k as f32 / fade_n as f32).cos())
            } else if k >= n - fade_n {
                // Half-Hann fade-out: 1 → 0 across the last `fade_n`.
                let kk = (n - 1 - k) as f32;
                0.5 * (1.0 - (PI * kk / fade_n as f32).cos())
            } else {
                1.0
            };
            // f64 phase with 2π wrapping (same rationale as gen_log_sweep):
            // at 20 kHz a 60 s tone reaches ~7.5e6 rad, where f32 argument
            // rounding alone would cost ~0.5 rad of phase error.
            let phase = (omega * k as f64) % (2.0 * std::f64::consts::PI);
            clip(amp * env * phase.sin() as f32)
        })
        .collect()
}
