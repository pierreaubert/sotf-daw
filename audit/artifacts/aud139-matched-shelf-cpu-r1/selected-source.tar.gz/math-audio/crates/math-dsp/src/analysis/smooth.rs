/// Apply octave smoothing to frequency response data (f64 version)
///
/// Frequencies must be sorted in ascending order (as from FFT or log-spaced grids).
/// If the input slices are mismatched, only paired frequency/value samples are
/// smoothed and returned.
/// Values are averaged arithmetically in the domain supplied by the caller.
/// In particular, dB inputs are smoothed in dB; callers that need energy-domain
/// smoothing must convert to linear power before calling and convert back after.
/// Uses a prefix sum with two-pointer sliding window for O(n) complexity.
pub fn smooth_response_f64(frequencies: &[f64], values: &[f64], octaves: f64) -> Vec<f64> {
    if octaves <= 0.0 || frequencies.is_empty() || values.is_empty() {
        return values.to_vec();
    }

    let paired_len = frequencies.len().min(values.len());

    // Prefix sum for O(1) range averages
    let mut prefix = Vec::with_capacity(paired_len + 1);
    prefix.push(0.0);
    for &v in &values[..paired_len] {
        prefix.push(prefix.last().unwrap() + v);
    }

    let ratio = 2.0_f64.powf(octaves / 2.0);
    let mut smoothed = Vec::with_capacity(paired_len);
    let mut lo = 0usize;
    let mut hi = 0usize;

    for (i, &center_freq) in frequencies[..paired_len].iter().enumerate() {
        if center_freq <= 0.0 {
            smoothed.push(values[i]);
            continue;
        }

        let low_freq = center_freq / ratio;
        let high_freq = center_freq * ratio;

        // Advance lo past frequencies below the window
        while lo < paired_len && frequencies[lo] < low_freq {
            lo += 1;
        }
        // Advance hi to include frequencies within the window
        while hi < paired_len && frequencies[hi] <= high_freq {
            hi += 1;
        }

        let count = hi - lo;
        if count > 0 {
            smoothed.push((prefix[hi] - prefix[lo]) / count as f64);
        } else {
            smoothed.push(values[i]);
        }
    }

    smoothed
}

/// Apply octave smoothing to frequency response data (f32 version)
///
/// Frequencies must be sorted in ascending order (as from FFT or log-spaced grids).
/// If the input slices are mismatched, only paired frequency/value samples are
/// smoothed and returned.
/// Values are averaged arithmetically in the domain supplied by the caller.
/// In particular, dB inputs are smoothed in dB; callers that need energy-domain
/// smoothing must convert to linear power before calling and convert back after.
/// Uses a prefix sum with two-pointer sliding window for O(n) complexity.
pub fn smooth_response_f32(frequencies: &[f32], values: &[f32], octaves: f32) -> Vec<f32> {
    if octaves <= 0.0 || frequencies.is_empty() || values.is_empty() {
        return values.to_vec();
    }

    let paired_len = frequencies.len().min(values.len());

    // Prefix sum for O(1) range averages (accumulate in f64 to avoid precision loss)
    let mut prefix = Vec::with_capacity(paired_len + 1);
    prefix.push(0.0_f64);
    for &v in &values[..paired_len] {
        prefix.push(prefix.last().unwrap() + v as f64);
    }

    let ratio = 2.0_f32.powf(octaves / 2.0);
    let mut smoothed = Vec::with_capacity(paired_len);
    let mut lo = 0usize;
    let mut hi = 0usize;

    for (i, &center_freq) in frequencies[..paired_len].iter().enumerate() {
        if center_freq <= 0.0 {
            smoothed.push(values[i]);
            continue;
        }

        let low_freq = center_freq / ratio;
        let high_freq = center_freq * ratio;

        // Advance lo past frequencies below the window
        while lo < paired_len && frequencies[lo] < low_freq {
            lo += 1;
        }
        // Advance hi to include frequencies within the window
        while hi < paired_len && frequencies[hi] <= high_freq {
            hi += 1;
        }

        let count = hi - lo;
        if count > 0 {
            smoothed.push(((prefix[hi] - prefix[lo]) / count as f64) as f32);
        } else {
            smoothed.push(values[i]);
        }
    }

    smoothed
}
