use super::BinauralLoudness;
use super::binaural_downmix::BinauralDownmix;
use super::types::BinauralLoudnessResult;

/// One-shot binaural loudness measurement on a complete interleaved
/// stereo buffer. Convenient for offline analysis.
pub fn measure_binaural(
    samples_interleaved: &[f32],
    sample_rate: u32,
) -> Result<BinauralLoudnessResult, String> {
    let mut meter = BinauralLoudness::new(sample_rate)?;
    meter.add_interleaved_f32(samples_interleaved)?;
    meter.snapshot()
}

/// One-shot binaural loudness measurement for a multichannel programme.
///
/// Downmixes `samples_interleaved` through `downmix` (which must match
/// the source channel count) to a binaural pair, then applies BS.1770-4
/// loudness measurement.
pub fn measure_binaural_from_surround(
    samples_interleaved: &[f32],
    sample_rate: u32,
    downmix: &BinauralDownmix,
) -> Result<BinauralLoudnessResult, String> {
    let mut meter = BinauralLoudness::new(sample_rate)?;
    meter.add_surround_f32(samples_interleaved, downmix)?;
    meter.snapshot()
}
