pub(super) const RMS_WINDOW_MS: f32 = 10.0;

pub(super) const MEASURED_MAKEUP_SMOOTHING_MS: f32 = 1000.0;

pub(super) const MAX_LOOKAHEAD_MS: f32 = 20.0;

pub(super) const DUAL_RELEASE_SLOW_MULTIPLIER: f32 = 4.0;
