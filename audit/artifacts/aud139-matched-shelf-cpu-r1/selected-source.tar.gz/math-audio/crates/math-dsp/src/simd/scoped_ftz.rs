/// RAII guard that enables FTZ/DAZ on construction and restores the previous
/// FPU control register state on drop, scoping the effect to a block.
///
/// # Usage
/// ```ignore
/// {
///     let _guard = ScopedFtz::new();
///     // FTZ/DAZ active here
/// } // previous FPU state restored on drop
/// ```
///
/// On unsupported platforms this is a no-op. The guard is `!Send` because
/// FPU control registers are per-thread state.
pub struct ScopedFtz {
    #[cfg(target_arch = "x86_64")]
    pub(super) saved_mxcsr: Option<u32>,
    #[cfg(target_arch = "aarch64")]
    pub(super) saved_fpcr: Option<u64>,
}

impl ScopedFtz {
    /// Enable FTZ/DAZ and save the current register state for restoration on drop.
    #[allow(clippy::needless_return)]
    pub fn new() -> Self {
        #[cfg(target_arch = "x86_64")]
        {
            let saved = unsafe {
                let mut mxcsr: u32 = 0;
                std::arch::asm!(
                    "stmxcsr [{}]",
                    in(reg) &mut mxcsr,
                    options(nostack, preserves_flags)
                );
                let new_mxcsr = mxcsr | (1 << 15) | (1 << 6); // FTZ | DAZ
                std::arch::asm!(
                    "ldmxcsr [{}]",
                    in(reg) &new_mxcsr,
                    options(nostack, preserves_flags)
                );
                mxcsr
            };
            return Self {
                saved_mxcsr: Some(saved),
            };
        }

        #[cfg(target_arch = "aarch64")]
        {
            let saved = unsafe {
                let mut fpcr: u64;
                std::arch::asm!("mrs {}, fpcr", out(reg) fpcr);
                let new_fpcr = fpcr | (1u64 << 24); // FZ bit
                std::arch::asm!("msr fpcr, {}", in(reg) new_fpcr);
                fpcr
            };
            return Self {
                saved_fpcr: Some(saved),
            };
        }

        #[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
        Self {}
    }
}

impl Default for ScopedFtz {
    fn default() -> Self {
        Self::new()
    }
}

impl Drop for ScopedFtz {
    fn drop(&mut self) {
        #[cfg(target_arch = "x86_64")]
        if let Some(saved) = self.saved_mxcsr {
            unsafe {
                std::arch::asm!(
                    "ldmxcsr [{}]",
                    in(reg) &saved,
                    options(nostack, preserves_flags)
                );
            }
        }

        #[cfg(target_arch = "aarch64")]
        if let Some(saved) = self.saved_fpcr {
            unsafe {
                std::arch::asm!("msr fpcr, {}", in(reg) saved);
            }
        }
    }
}
