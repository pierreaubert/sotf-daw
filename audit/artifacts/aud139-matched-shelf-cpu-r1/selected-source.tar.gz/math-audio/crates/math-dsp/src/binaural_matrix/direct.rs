use super::misc::apply_direct_window;
use super::misc::real_fft_half_spectrum;
use num_complex::Complex64;
use std::f64::consts::PI;

/// Find the largest absolute sample in an impulse response.
pub fn direct_peak_sample(ir: &[f64]) -> usize {
    ir.iter()
        .enumerate()
        .max_by(|a, b| a.1.abs().total_cmp(&b.1.abs()))
        .map(|(idx, _)| idx)
        .unwrap_or(0)
}

/// Suppress log-sweep harmonic distortion residue tails in a circularly
/// deconvolved IR.
///
/// After log-sweep deconvolution and direct-sound alignment, harmonic residues
/// appear at negative times, i.e. near the end of the circular IR. This zeros
/// short windows around the expected harmonic offsets.
pub fn suppress_log_sweep_harmonic_residues(
    ir: &mut [f64],
    sample_rate: f64,
    sweep_duration_s: f64,
    sweep_start_hz: f64,
    sweep_end_hz: f64,
    max_harmonic: usize,
    window_ms: f64,
) {
    if ir.is_empty()
        || sample_rate <= 0.0
        || sweep_duration_s <= 0.0
        || sweep_start_hz <= 0.0
        || sweep_end_hz <= sweep_start_hz
        || max_harmonic < 2
    {
        return;
    }
    let direct = direct_peak_sample(ir) as isize;
    let log_ratio = (sweep_end_hz / sweep_start_hz).ln();
    let half = ((window_ms.max(0.0) / 1000.0) * sample_rate).round() as isize;
    let len = ir.len() as isize;
    for harmonic in 2..=max_harmonic {
        let offset_s = sweep_duration_s * (harmonic as f64).ln() / log_ratio;
        let center = direct - (offset_s * sample_rate).round() as isize;
        for delta in -half..=half {
            let idx = (center + delta).rem_euclid(len) as usize;
            ir[idx] = 0.0;
        }
    }
}

/// Direct-window an IR and FFT it into a half-spectrum.
pub fn direct_windowed_half_spectrum(
    ir: &[f64],
    sample_rate: f64,
    fft_size: usize,
    start_ms: f64,
    length_ms: f64,
    fade_ms: f64,
) -> Result<Vec<Complex64>, String> {
    if fft_size == 0 || ir.is_empty() {
        return Err("ir and fft_size must be non-empty".to_string());
    }
    let mut windowed = vec![0.0; fft_size];
    let copy_len = ir.len().min(fft_size);
    windowed[..copy_len].copy_from_slice(&ir[..copy_len]);
    apply_direct_window(&mut windowed, sample_rate, start_ms, length_ms, fade_ms);
    Ok(real_fft_half_spectrum(&windowed, fft_size))
}

/// Window an IR relative to its direct-sound peak and FFT it into a half-spectrum.
///
/// Samples keep their original time index in the FFT buffer. That preserves the
/// acoustic arrival phase while avoiding absolute sample-zero windows that miss
/// delayed speaker arrivals.
pub fn direct_peak_windowed_half_spectrum(
    ir: &[f64],
    sample_rate: f64,
    fft_size: usize,
    start_ms: f64,
    length_ms: f64,
    fade_ms: f64,
) -> Result<Vec<Complex64>, String> {
    if fft_size == 0 || ir.is_empty() {
        return Err("ir and fft_size must be non-empty".to_string());
    }
    let direct_sample = direct_peak_sample(ir);
    let mut windowed = vec![0.0; fft_size];
    let copy_len = ir.len().min(fft_size);
    let start = direct_sample as isize + ((start_ms / 1000.0) * sample_rate).round() as isize;
    let length = ((length_ms / 1000.0) * sample_rate).round().max(1.0) as isize;
    let fade = ((fade_ms / 1000.0) * sample_rate).round().max(0.0) as isize;
    let end = start + length;

    for idx in 0..copy_len {
        let idx_i = idx as isize;
        if idx_i < start || idx_i >= end {
            continue;
        }
        let mut value = ir[idx];
        if fade > 0 && idx_i >= end - fade {
            let n = end - idx_i;
            let phase = PI * n as f64 / fade as f64;
            value *= 0.5 - 0.5 * phase.cos();
        }
        windowed[idx] = value;
    }

    Ok(real_fft_half_spectrum(&windowed, fft_size))
}
