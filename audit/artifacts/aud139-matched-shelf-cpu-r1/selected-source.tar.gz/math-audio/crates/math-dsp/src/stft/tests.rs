#![allow(clippy::needless_range_loop)]
use super::batched_real_fft_processor::BatchedRealFftProcessor;
use super::dual_window_stft::DualWindowStft;
use super::generate::design_dual_windows;
use super::generate::generate_hann_window;
use super::generate::generate_hann_window_symmetric;
use super::generate::generate_sqrt_hann_window;
use super::real_fft_processor::RealFftProcessor;
use super::ring_accumulator::RingAccumulator;
use rustfft::num_complex::Complex;

#[test]
fn test_hann_window_size_and_symmetry() {
    let window = generate_hann_window(8);
    assert_eq!(window.len(), 8);

    // Hann window should start near zero and peak at center
    assert!((window[0] - 0.0).abs() < 0.01);
    assert!((window[4] - 1.0).abs() < 0.01);

    // Symmetric: w[i] == w[N-i] for periodic Hann
    for i in 1..4 {
        assert!(
            (window[i] - window[8 - i]).abs() < 1e-6,
            "Window not symmetric at i={}: {} vs {}",
            i,
            window[i],
            window[8 - i]
        );
    }
}

#[test]
fn test_sqrt_hann_cola_property() {
    // sqrt(Hann) analysis * sqrt(Hann) synthesis = Hann
    // Hann has perfect COLA at 50% overlap: w[i] + w[i+N/2] = 1.0
    let n = 256;
    let sqrt_window = generate_sqrt_hann_window(n);
    let hop = n / 2;

    for i in 0..hop {
        // Product of analysis and synthesis = Hann
        let hann_i = sqrt_window[i] * sqrt_window[i];
        let hann_shifted = sqrt_window[i + hop] * sqrt_window[i + hop];
        let sum = hann_i + hann_shifted;
        assert!(
            (sum - 1.0).abs() < 1e-5,
            "sqrt(Hann) COLA violated at i={}: sum={}, expected 1.0",
            i,
            sum
        );
    }
}

#[test]
fn test_hann_window_cola_property() {
    // With 50% overlap, w[i] + w[i + N/2] should equal 1.0 (COLA)
    let n = 256;
    let window = generate_hann_window(n);
    let hop = n / 2;

    for i in 0..hop {
        let sum = window[i] + window[i + hop];
        assert!(
            (sum - 1.0).abs() < 1e-5,
            "COLA violated at i={}: sum={}, expected 1.0",
            i,
            sum
        );
    }
}

#[test]
fn test_symmetric_hann_endpoints_are_zero() {
    let window = generate_hann_window_symmetric(256);
    assert!(window[0].abs() < 1e-7, "First sample should be 0");
    assert!(window[255].abs() < 1e-7, "Last sample should be 0");
    // Peak at center
    assert!((window[128] - 1.0).abs() < 0.01);
}

#[test]
fn test_symmetric_hann_no_nan_for_small_sizes() {
    // size=0: empty
    let w0 = generate_hann_window_symmetric(0);
    assert!(w0.is_empty());

    // size=1: should be [1.0], not NaN
    let w1 = generate_hann_window_symmetric(1);
    assert_eq!(w1.len(), 1);
    assert!(w1[0].is_finite(), "size=1 produced non-finite: {}", w1[0]);
    assert!((w1[0] - 1.0).abs() < 1e-6);

    // size=2: endpoints [0, 0] by symmetric formula
    let w2 = generate_hann_window_symmetric(2);
    assert_eq!(w2.len(), 2);
    assert!(w2[0].is_finite());
    assert!(w2[1].is_finite());
}

#[test]
fn test_fft_roundtrip() {
    let fft_size = 256;
    let mut fft = RealFftProcessor::new_bidirectional(fft_size);

    // Fill with a known signal
    let original: Vec<f32> = (0..fft_size)
        .map(|i| (2.0 * std::f32::consts::PI * 10.0 * i as f32 / fft_size as f32).sin())
        .collect();
    fft.time_buffer.copy_from_slice(&original);

    // Forward then inverse
    fft.forward();
    fft.inverse();

    // Inverse FFT scales by fft_size, so divide
    let scale = 1.0 / fft_size as f32;
    for i in 0..fft_size {
        let recovered = fft.time_buffer[i] * scale;
        assert!(
            (recovered - original[i]).abs() < 1e-4,
            "FFT roundtrip mismatch at i={}: expected {}, got {}",
            i,
            original[i],
            recovered,
        );
    }
}

#[test]
#[should_panic(expected = "window_size must be greater than zero")]
fn test_ring_accumulator_rejects_zero_window_size() {
    let _ = RingAccumulator::new(0, 4);
}

#[test]
#[should_panic(expected = "hop_size must be greater than zero")]
fn test_ring_accumulator_rejects_zero_hop_size() {
    let _ = RingAccumulator::new(8, 0);
}

#[test]
fn test_ring_accumulator_trigger_timing() {
    let window_size = 8;
    let hop_size = 4;
    let mut ring = RingAccumulator::new(window_size, hop_size);

    let mut triggers = Vec::new();
    for i in 0..24 {
        if ring.push(i as f32) {
            triggers.push(i);
        }
    }

    // First trigger at sample 7 (index 7 = 8th sample, filling window)
    // Then every hop_size (4) samples: 11, 15, 19, 23
    assert_eq!(triggers, vec![7, 11, 15, 19, 23]);
}

#[test]
fn test_ring_accumulator_window_readout() {
    let window_size = 4;
    let hop_size = 2;
    let mut ring = RingAccumulator::new(window_size, hop_size);

    // Push 6 samples: [0, 1, 2, 3, 4, 5]
    // After 4 samples, ring is filled. After 6 samples (2 more = hop), trigger.
    // Ring state: write_pos = 2, buffer = [4, 5, 2, 3]
    // oldest-first read: [2, 3, 4, 5]
    for i in 0..6 {
        ring.push(i as f32);
    }

    let mut dest = vec![0.0; 4];
    ring.read_window(&mut dest);
    assert_eq!(dest, vec![2.0, 3.0, 4.0, 5.0]);
}

#[test]
fn test_ring_accumulator_reset() {
    let mut ring = RingAccumulator::new(8, 4);

    // Fill and trigger
    for i in 0..12 {
        ring.push(i as f32);
    }
    assert!(ring.filled);

    ring.reset();
    assert!(!ring.filled);
    assert_eq!(ring.write_pos, 0);
    assert_eq!(ring.samples_since_trigger, 0);

    // Should not trigger until filled again
    let mut triggered = false;
    for _ in 0..4 {
        triggered |= ring.push(1.0);
    }
    assert!(!triggered, "Should not trigger before ring is filled again");
}

#[test]
fn test_dual_window_design() {
    let analysis_size = 1024;
    let synthesis_size = 256;
    let hop_size = 128;

    let (w_a, w_s) = design_dual_windows(analysis_size, synthesis_size, hop_size);
    assert_eq!(w_a.len(), analysis_size);
    assert_eq!(w_s.len(), analysis_size);

    // Synthesis window should be non-zero only in the center
    let offset = (analysis_size - synthesis_size) / 2;
    for i in 0..offset {
        assert_eq!(w_s[i], 0.0, "Synthesis window should be zero before offset");
    }
    for i in (offset + synthesis_size)..analysis_size {
        assert_eq!(w_s[i], 0.0, "Synthesis window should be zero after support");
    }
}

#[test]
fn test_dual_window_design_satisfies_pointwise_cola() {
    let analysis_size = 1024;
    let synthesis_size = 384;
    let hop_size = 128;
    let (analysis, synthesis) = design_dual_windows(analysis_size, synthesis_size, hop_size);

    for residue in 0..hop_size {
        let cola: f32 = (residue..analysis_size)
            .step_by(hop_size)
            .map(|i| analysis[i] * synthesis[i])
            .sum();
        assert!(
            (cola - 1.0).abs() < 1e-5,
            "COLA residue {residue} must equal one, got {cola}"
        );
    }
}

#[test]
fn test_dual_window_stft_passthrough() {
    let analysis_size = 512;
    let synthesis_size = 128;
    let hop_size = 64;

    let mut stft = DualWindowStft::new(analysis_size, synthesis_size, hop_size);

    // Generate a tone
    let num_samples = 4096;
    let signal: Vec<f32> = (0..num_samples)
        .map(|i| (2.0 * std::f32::consts::PI * 440.0 * i as f32 / 48000.0).sin())
        .collect();

    let mut output = vec![0.0f32; num_samples];

    // Pass-through (no spectral modification)
    stft.process_block(&signal, &mut output, |_spectrum| {
        // Identity: don't modify spectrum
    });

    // After latency, output should approximate input
    let latency = stft.latency_samples();
    let check_start = latency + 512; // skip transient
    let check_end = num_samples - 512;

    if check_end > check_start {
        let rms_error: f32 = output[check_start..check_end]
            .iter()
            .zip(&signal[check_start - latency..check_end - latency])
            .map(|(o, s)| (o - s).powi(2))
            .sum::<f32>()
            / (check_end - check_start) as f32;

        // Identity passthrough is a pure delay by exactly `latency_samples()`;
        // with correct alignment the residual should be at float-noise level.
        assert!(
            rms_error < 1e-4,
            "Dual-window STFT passthrough RMS error too high: {rms_error:.6}"
        );
    }
}

/// An impulse must reappear in the output delayed by exactly
/// `latency_samples()` samples: `output[n] == input[n - latency]`.
#[test]
fn test_dual_window_stft_impulse_peak_at_latency() {
    let analysis_size = 512;
    let synthesis_size = 128;
    let hop_size = 64;

    let mut stft = DualWindowStft::new(analysis_size, synthesis_size, hop_size);

    let num_samples = 4096;
    let impulse_idx = 2048;
    let mut signal = vec![0.0f32; num_samples];
    signal[impulse_idx] = 1.0;
    let mut output = vec![0.0f32; num_samples];

    stft.process_block(&signal, &mut output, |_| {});

    let (peak_idx, peak) = output
        .iter()
        .enumerate()
        .max_by(|a, b| a.1.partial_cmp(b.1).unwrap())
        .map(|(i, &v)| (i, v))
        .unwrap();
    let latency = stft.latency_samples();
    assert!(
        (peak - 1.0).abs() < 1e-4,
        "Identity passthrough impulse peak should be ~1.0, got {peak}"
    );
    assert_eq!(
        peak_idx,
        impulse_idx + latency,
        "Impulse peak at {peak_idx}, expected input index {impulse_idx} + latency {latency}"
    );
}

/// Round-trip identity test for DualWindowStft.
///
/// A pass-through (no spectral modification) on a DC signal must recover
/// unit amplitude after the latency period. This verifies that the synthesis
/// window COLA normalization and the 1/N IFFT correction yield unity gain.
#[test]
fn test_dual_window_stft_roundtrip_unity_gain() {
    let analysis_size = 512;
    let synthesis_size = 128;
    let hop_size = 64;

    let mut stft = DualWindowStft::new(analysis_size, synthesis_size, hop_size);

    // DC signal at amplitude 0.5 — easy to verify amplitude recovery.
    let num_samples = 6144;
    let signal = vec![0.5_f32; num_samples];
    let mut output = vec![0.0_f32; num_samples];

    stft.process_block(&signal, &mut output, |_spectrum| {});

    // Skip latency + two extra analysis windows for transient to settle.
    let latency = stft.latency_samples();
    let check_start = latency + 2 * analysis_size;
    let check_end = num_samples - analysis_size;

    if check_end > check_start {
        let rms_error: f32 = output[check_start..check_end]
            .iter()
            .zip(&signal[check_start - latency..check_end - latency])
            .map(|(o, s)| (o - s).powi(2))
            .sum::<f32>()
            / (check_end - check_start) as f32;

        assert!(
            rms_error < 1e-4,
            "DualWindowStft round-trip RMS error too high ({rms_error:.6}); \
                 IFFT scale or synthesis-window normalization may be wrong"
        );
    }
}

#[test]
fn test_dual_window_stft_latency_reports_input_output_delay() {
    let stft = DualWindowStft::new(512, 128, 64);
    assert_eq!(stft.latency_samples(), 511);
}

#[test]
fn test_dual_window_stft_reset() {
    let mut stft = DualWindowStft::new(512, 128, 64);

    // Process some data
    let signal: Vec<f32> = (0..2048).map(|i| (i as f32 * 0.1).sin()).collect();
    let mut output = vec![0.0; 2048];
    stft.process_block(&signal, &mut output, |_| {});

    // Reset
    stft.reset();

    // Process silence — output should be near zero
    let silence = vec![0.0f32; 1024];
    let mut output2 = vec![0.0; 1024];
    stft.process_block(&silence, &mut output2, |_| {});

    let max_output: f32 = output2.iter().map(|x| x.abs()).fold(0.0f32, f32::max);
    assert!(
        max_output < 0.01,
        "After reset + silence, max output should be ~0, got {max_output}"
    );
}

#[cfg(test)]
mod batched_real_fft_processor_tests {
    use super::*;

    const EPSILON: f32 = 1e-3;

    fn fill_signal(buffer: &mut [f32], ch: usize) {
        for (i, sample) in buffer.iter_mut().enumerate() {
            let phase = i as f32 * 0.13 + ch as f32 * 0.37;
            *sample = phase.sin() + 0.25 * (phase * 2.7).cos();
        }
    }

    fn assert_complex_close(actual: Complex<f32>, expected: Complex<f32>) {
        assert!((actual.re - expected.re).abs() <= EPSILON);
        assert!((actual.im - expected.im).abs() <= EPSILON);
    }

    fn assert_slice_close(actual: &[f32], expected: &[f32]) {
        assert_eq!(actual.len(), expected.len());
        for (actual, expected) in actual.iter().zip(expected) {
            assert!((actual - expected).abs() <= EPSILON);
        }
    }

    #[test]
    fn forward_matches_independent_processors_for_representative_channel_counts() {
        for channels in [1, 2, 8, 16, 24] {
            let fft_size = 64;
            let mut batched = BatchedRealFftProcessor::new_forward_only(channels, fft_size);

            for ch in 0..channels {
                fill_signal(batched.time_channel_mut(ch), ch);
            }

            let inputs = batched.time_buffers().to_vec();
            batched.forward_all();

            for ch in 0..channels {
                let mut independent = RealFftProcessor::new_forward_only(fft_size);
                independent
                    .time_buffer
                    .copy_from_slice(&inputs[ch * fft_size..(ch + 1) * fft_size]);
                independent.forward();

                for (actual, expected) in batched
                    .freq_channel(ch)
                    .iter()
                    .zip(&independent.freq_buffer)
                {
                    assert_complex_close(*actual, *expected);
                }
            }
        }
    }

    #[test]
    fn bidirectional_round_trip_restores_each_channel_after_scaling() {
        let channels = 8;
        let fft_size = 128;
        let mut batched = BatchedRealFftProcessor::new_bidirectional(channels, fft_size);

        for ch in 0..channels {
            fill_signal(batched.time_channel_mut(ch), ch);
        }

        let original = batched.time_buffers().to_vec();
        batched.forward_all();
        batched.inverse_all();

        for ch in 0..channels {
            let mut expected = original[ch * fft_size..(ch + 1) * fft_size].to_vec();
            for sample in &mut expected {
                *sample *= fft_size as f32;
            }
            assert_slice_close(batched.time_channel(ch), &expected);
        }
    }

    #[test]
    fn channel_slices_use_flat_channel_major_layout() {
        let channels = 3;
        let fft_size = 4;
        let spectrum_size = fft_size / 2 + 1;
        let mut batched = BatchedRealFftProcessor::new_forward_only(channels, fft_size);

        for ch in 0..channels {
            for (i, sample) in batched.time_channel_mut(ch).iter_mut().enumerate() {
                *sample = (ch * 10 + i) as f32;
            }
            for (i, bin) in batched.freq_channel_mut(ch).iter_mut().enumerate() {
                *bin = Complex::new((ch * 10 + i) as f32, ch as f32);
            }
        }

        assert_eq!(
            batched.time_buffers(),
            &[
                0.0, 1.0, 2.0, 3.0, 10.0, 11.0, 12.0, 13.0, 20.0, 21.0, 22.0, 23.0
            ]
        );
        assert_eq!(batched.freq_buffers().len(), channels * spectrum_size);
        assert_eq!(batched.freq_channel(2)[1], Complex::new(21.0, 2.0));
    }
}
