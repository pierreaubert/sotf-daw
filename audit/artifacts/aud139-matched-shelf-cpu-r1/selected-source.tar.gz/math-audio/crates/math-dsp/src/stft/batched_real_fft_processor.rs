use realfft::{ComplexToReal, RealFftPlanner, RealToComplex};
use rustfft::num_complex::Complex;
use std::sync::Arc;

/// Batched wrapper around `realfft` for independent real FFTs that share the
/// same FFT size.
///
/// Buffers are stored flat in channel-major order:
/// - `time_buffers`: `[channel][sample]`
/// - `freq_buffers`: `[channel][bin]`
///
/// This keeps each channel contiguous for `realfft`, avoids one allocation per
/// channel, and reuses the same FFT plans and scratch buffers across all
/// channels. The FFTs are still computed sequentially; this type is a portable
/// baseline rather than a platform-specific batched FFT backend.
pub struct BatchedRealFftProcessor {
    pub(super) channels: usize,
    pub(super) fft_size: usize,
    pub(super) spectrum_size: usize,
    pub(super) fft_forward: Arc<dyn RealToComplex<f32>>,
    pub(super) fft_inverse: Option<Arc<dyn ComplexToReal<f32>>>,
    pub(super) forward_scratch: Vec<Complex<f32>>,
    pub(super) inverse_scratch: Vec<Complex<f32>>,
    pub(super) time_buffers: Vec<f32>,
    pub(super) freq_buffers: Vec<Complex<f32>>,
}

impl BatchedRealFftProcessor {
    /// Create a forward-only batched FFT processor.
    pub fn new_forward_only(channels: usize, fft_size: usize) -> Self {
        Self::new(channels, fft_size, false)
    }

    /// Create a bidirectional batched FFT processor.
    pub fn new_bidirectional(channels: usize, fft_size: usize) -> Self {
        Self::new(channels, fft_size, true)
    }

    pub(super) fn new(channels: usize, fft_size: usize, include_inverse: bool) -> Self {
        assert!(
            channels > 0,
            "BatchedRealFftProcessor requires at least one channel"
        );

        let spectrum_size = fft_size / 2 + 1;
        let mut planner = RealFftPlanner::<f32>::new();
        let fft_forward = planner.plan_fft_forward(fft_size);
        let fft_inverse = if include_inverse {
            Some(planner.plan_fft_inverse(fft_size))
        } else {
            None
        };

        let forward_scratch = vec![Complex::new(0.0, 0.0); fft_forward.get_scratch_len()];
        let inverse_scratch = fft_inverse
            .as_ref()
            .map(|fft| vec![Complex::new(0.0, 0.0); fft.get_scratch_len()])
            .unwrap_or_default();

        Self {
            channels,
            fft_size,
            spectrum_size,
            fft_forward,
            fft_inverse,
            forward_scratch,
            inverse_scratch,
            time_buffers: vec![0.0; channels * fft_size],
            freq_buffers: vec![Complex::new(0.0, 0.0); channels * spectrum_size],
        }
    }

    pub fn channels(&self) -> usize {
        self.channels
    }

    pub fn fft_size(&self) -> usize {
        self.fft_size
    }

    pub fn spectrum_size(&self) -> usize {
        self.spectrum_size
    }

    pub fn time_buffers(&self) -> &[f32] {
        &self.time_buffers
    }

    pub fn time_buffers_mut(&mut self) -> &mut [f32] {
        &mut self.time_buffers
    }

    pub fn freq_buffers(&self) -> &[Complex<f32>] {
        &self.freq_buffers
    }

    pub fn freq_buffers_mut(&mut self) -> &mut [Complex<f32>] {
        &mut self.freq_buffers
    }

    pub fn time_channel(&self, ch: usize) -> &[f32] {
        debug_assert!(ch < self.channels);
        let range = self.time_range(ch);
        &self.time_buffers[range]
    }

    pub fn time_channel_mut(&mut self, ch: usize) -> &mut [f32] {
        debug_assert!(ch < self.channels);
        let range = self.time_range(ch);
        &mut self.time_buffers[range]
    }

    pub fn freq_channel(&self, ch: usize) -> &[Complex<f32>] {
        debug_assert!(ch < self.channels);
        let range = self.freq_range(ch);
        &self.freq_buffers[range]
    }

    pub fn freq_channel_mut(&mut self, ch: usize) -> &mut [Complex<f32>] {
        debug_assert!(ch < self.channels);
        let range = self.freq_range(ch);
        &mut self.freq_buffers[range]
    }

    /// Perform forward FFTs for all channels.
    /// The caller should fill each time-domain channel buffer before calling this.
    pub fn forward_all(&mut self) {
        for ch in 0..self.channels {
            let time_range = self.time_range(ch);
            let freq_range = self.freq_range(ch);
            self.fft_forward
                .process_with_scratch(
                    &mut self.time_buffers[time_range],
                    &mut self.freq_buffers[freq_range],
                    &mut self.forward_scratch,
                )
                .expect("FFT forward failed");
        }
    }

    /// Perform inverse FFTs for all channels.
    /// Panics if this processor was created with `new_forward_only`.
    pub fn inverse_all(&mut self) {
        let fft_inverse = self
            .fft_inverse
            .as_ref()
            .expect("Inverse FFT not available (forward-only processor)");

        for ch in 0..self.channels {
            let time_range = self.time_range(ch);
            let freq_range = self.freq_range(ch);
            fft_inverse
                .process_with_scratch(
                    &mut self.freq_buffers[freq_range],
                    &mut self.time_buffers[time_range],
                    &mut self.inverse_scratch,
                )
                .expect("FFT inverse failed");
        }
    }

    pub(super) fn time_range(&self, ch: usize) -> std::ops::Range<usize> {
        ch * self.fft_size..(ch + 1) * self.fft_size
    }

    pub(super) fn freq_range(&self, ch: usize) -> std::ops::Range<usize> {
        ch * self.spectrum_size..(ch + 1) * self.spectrum_size
    }
}
