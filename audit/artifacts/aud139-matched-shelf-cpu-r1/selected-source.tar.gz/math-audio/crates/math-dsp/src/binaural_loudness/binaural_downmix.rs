use super::types::SurroundLayout;

/// Per-channel binaural downmix gain matrix.
///
/// Each row holds the `[L_ear, R_ear]` linear gains applied to one source
/// channel when summing into the binaural pair. This is a **level-only**
/// approximation of HRTF rendering: it captures channel weighting and
/// stereo placement but not spectral cues (HRTF magnitude response) or
/// interaural time differences. It is suitable for BS.1770-4 loudness
/// estimation of how multichannel content will sit on headphones, not
/// for spatial-quality assessment.
///
/// Preset constructors implement the ITU-R BS.775 stereo downmix
/// coefficients (centre → both ears at −3 dB; surrounds → same-side ear
/// at −3 dB; LFE excluded per BS.1770-4). Callers with HRTF magnitude
/// data should derive broadband per-channel gains and supply them via
/// [`BinauralDownmix::from_matrix`].
#[derive(Debug, Clone)]
pub struct BinauralDownmix {
    pub(super) coeffs: Vec<[f64; 2]>,
}

impl BinauralDownmix {
    /// Build a downmix from explicit per-channel `[L, R]` gains.
    pub fn from_matrix(coeffs: Vec<[f64; 2]>) -> Result<Self, String> {
        if coeffs.is_empty() {
            return Err("binaural downmix matrix must have at least one channel".into());
        }
        Ok(Self { coeffs })
    }

    /// ITU-R BS.775 binaural-equivalent stereo downmix for the given layout.
    pub fn bs775(layout: SurroundLayout) -> Self {
        // -3 dB amplitude factor used by BS.775 for centre and surround mix.
        let a = std::f64::consts::FRAC_1_SQRT_2;
        let coeffs: Vec<[f64; 2]> = match layout {
            // L,  R,  C,    Ls,    Rs
            SurroundLayout::FiveZero => vec![[1.0, 0.0], [0.0, 1.0], [a, a], [a, 0.0], [0.0, a]],
            // L,  R,  C,    LFE, Ls,    Rs
            SurroundLayout::FiveOne => vec![
                [1.0, 0.0],
                [0.0, 1.0],
                [a, a],
                [0.0, 0.0],
                [a, 0.0],
                [0.0, a],
            ],
            // L, R, C, LFE, Ls, Rs, Lrs, Rrs
            SurroundLayout::SevenOne => vec![
                [1.0, 0.0],
                [0.0, 1.0],
                [a, a],
                [0.0, 0.0],
                [a, 0.0],
                [0.0, a],
                [a, 0.0],
                [0.0, a],
            ],
        };
        Self { coeffs }
    }

    /// Number of source channels expected by this matrix.
    pub fn channels(&self) -> usize {
        self.coeffs.len()
    }

    /// Per-channel `[L, R]` gain rows.
    pub fn coeffs(&self) -> &[[f64; 2]] {
        &self.coeffs
    }
}
