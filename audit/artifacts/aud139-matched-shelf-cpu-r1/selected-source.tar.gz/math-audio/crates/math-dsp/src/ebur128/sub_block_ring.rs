/// Ring buffer for sub-block energies (400ms momentary = 4 × 100ms, 3s short-term = 30 × 100ms).
pub(super) struct SubBlockRing {
    pub(super) buf: Vec<f64>,
    pub(super) pos: usize,
    pub(super) count: usize,
}

impl SubBlockRing {
    pub(super) fn new(capacity: usize) -> Self {
        Self {
            buf: vec![0.0; capacity],
            pos: 0,
            count: 0,
        }
    }

    pub(super) fn push(&mut self, energy: f64) {
        self.buf[self.pos] = energy;
        self.pos = (self.pos + 1) % self.buf.len();
        if self.count < self.buf.len() {
            self.count += 1;
        }
    }

    pub(super) fn mean(&self) -> Option<f64> {
        if self.count == 0 {
            return None;
        }
        let sum: f64 = if self.count == self.buf.len() {
            self.buf.iter().sum()
        } else {
            self.buf[..self.count].iter().sum()
        };
        Some(sum / self.count as f64)
    }

    pub(super) fn is_full(&self) -> bool {
        self.count >= self.buf.len()
    }

    pub(super) fn reset(&mut self) {
        self.buf.fill(0.0);
        self.pos = 0;
        self.count = 0;
    }
}
