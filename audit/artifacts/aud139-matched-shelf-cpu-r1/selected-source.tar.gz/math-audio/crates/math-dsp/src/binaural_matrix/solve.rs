use super::transfer_matrix_bin::TransferMatrixBin;
use super::transfer_matrix_bin::condition_number;
use super::transfer_matrix_bin::position_errors;
use super::types::MatrixInverseBin;
use nalgebra::DMatrix;
use num_complex::Complex64;

/// Solve a regularized binaural inverse for one frequency bin.
///
/// Minimizes `sum_p ||H_p F - target||^2 + beta ||F||^2`.
/// `target` is row-major with shape `num_ears x num_ears`; pass identity for
/// ordinary cross-talk cancellation.
pub fn solve_regularized_inverse_bin(
    positions: &[TransferMatrixBin],
    target: &[Complex64],
    beta: f64,
    max_gain_db: Option<f64>,
) -> Result<MatrixInverseBin, String> {
    let weights = vec![1.0; positions.len()];
    solve_weighted_regularized_inverse_bin(positions, &weights, target, beta, max_gain_db)
}

/// Solve a weighted regularized binaural inverse for one frequency bin.
///
/// Each position contributes `weights[p] * ||H_p F - target||^2`.
pub fn solve_weighted_regularized_inverse_bin(
    positions: &[TransferMatrixBin],
    weights: &[f64],
    target: &[Complex64],
    beta: f64,
    max_gain_db: Option<f64>,
) -> Result<MatrixInverseBin, String> {
    let first = positions
        .first()
        .ok_or_else(|| "at least one transfer matrix position is required".to_string())?;
    if weights.len() != positions.len() {
        return Err(format!(
            "weights len {} != positions len {}",
            weights.len(),
            positions.len()
        ));
    }
    if target.len() != first.num_ears * first.num_ears {
        return Err(format!(
            "target has {} entries, expected {}",
            target.len(),
            first.num_ears * first.num_ears
        ));
    }
    if beta < 0.0 || !beta.is_finite() {
        return Err("beta must be finite and non-negative".to_string());
    }

    for (idx, matrix) in positions.iter().enumerate() {
        if !weights[idx].is_finite() || weights[idx] < 0.0 {
            return Err("weights must be finite and non-negative".to_string());
        }
        if matrix.num_ears != first.num_ears || matrix.num_speakers != first.num_speakers {
            return Err("all transfer matrices must have the same shape".to_string());
        }
    }

    let speakers = first.num_speakers;
    let ears = first.num_ears;
    let target_matrix = DMatrix::from_row_slice(ears, ears, target);
    // Copy each position's transfer matrix once and reuse it for both the
    // normal-equation accumulation and the reconstruction-error pass below.
    let h_matrices: Vec<DMatrix<Complex64>> =
        positions.iter().map(TransferMatrixBin::as_matrix).collect();
    let mut normal = DMatrix::<Complex64>::zeros(speakers, speakers);
    let mut rhs = DMatrix::<Complex64>::zeros(speakers, ears);

    for (h, weight) in h_matrices.iter().zip(weights) {
        let h_h = h.adjoint();
        let w = Complex64::new(*weight, 0.0);
        normal += (&h_h * h) * w;
        rhs += (h_h * &target_matrix) * w;
    }

    for idx in 0..speakers {
        normal[(idx, idx)] += Complex64::new(beta, 0.0);
    }

    let mut inverse = normal
        .lu()
        .solve(&rhs)
        .ok_or_else(|| "regularized normal matrix is singular".to_string())?;

    if let Some(max_gain_db) = max_gain_db {
        let max_gain = 10.0_f64.powf(max_gain_db / 20.0);
        for value in inverse.iter_mut() {
            let mag = value.norm();
            if mag > max_gain && mag > 0.0 {
                *value *= max_gain / mag;
            }
        }
    }

    let mut position_errors = Vec::with_capacity(positions.len());
    for h in &h_matrices {
        let delivered = h * &inverse;
        let mut position_error = 0.0;
        let mut count = 0usize;
        for row in 0..ears {
            for col in 0..ears {
                position_error += (delivered[(row, col)] - target_matrix[(row, col)]).norm_sqr();
                count += 1;
            }
        }
        position_errors.push(if count == 0 {
            0.0
        } else {
            position_error / count as f64
        });
    }

    let mut values = Vec::with_capacity(speakers * ears);
    for row in 0..speakers {
        for col in 0..ears {
            values.push(inverse[(row, col)]);
        }
    }

    let reconstruction_error = if position_errors.is_empty() {
        0.0
    } else {
        position_errors.iter().sum::<f64>() / position_errors.len() as f64
    };
    let worst_position_error = position_errors.iter().copied().fold(0.0, f64::max);

    Ok(MatrixInverseBin {
        values,
        condition_number: condition_number(first),
        reconstruction_error,
        worst_position_error,
    })
}

/// Approximate a minimax binaural inverse with iterative worst-position reweighting.
///
/// The exact minimax problem is convex but requires a constrained optimizer. This
/// routine keeps the closed-form weighted Tikhonov solve and repeatedly increases
/// weights for positions whose reconstruction error is close to the current
/// worst case. It returns the lowest worst-position solution encountered.
pub fn solve_minimax_regularized_inverse_bin(
    positions: &[TransferMatrixBin],
    target: &[Complex64],
    beta: f64,
    max_gain_db: Option<f64>,
    iterations: usize,
) -> Result<MatrixInverseBin, String> {
    if positions.is_empty() {
        return Err("at least one transfer matrix position is required".to_string());
    }
    let iterations = iterations.max(1);
    let mut weights = vec![1.0; positions.len()];
    let mut best =
        solve_weighted_regularized_inverse_bin(positions, &weights, target, beta, max_gain_db)?;

    for _ in 1..iterations {
        let errors = position_errors(positions, &best.values, target)?;
        let worst = errors.iter().copied().fold(0.0, f64::max).max(1e-18);
        for (weight, error) in weights.iter_mut().zip(errors) {
            let ratio = (error / worst).clamp(0.0, 1.0);
            *weight = (*weight * (1.0 + 2.0 * ratio * ratio)).clamp(1e-6, 1e6);
        }
        let candidate =
            solve_weighted_regularized_inverse_bin(positions, &weights, target, beta, max_gain_db)?;
        if candidate.worst_position_error < best.worst_position_error {
            best = candidate;
        }
    }

    Ok(best)
}
