#![allow(clippy::needless_range_loop)]
use super::apply::apply_gain_simd;
use super::apply::apply_per_channel_gain_simd;
use super::complex::complex_mul_add_simd;
use super::complex::complex_mul_inplace_simd;
use super::complex::complex_mul_simd;
use super::flush::flush_denormals_complex_inplace;
use super::flush::flush_denormals_inplace;
use super::misc::compute_covariance_simd;
use super::misc::enable_ftz_daz;
use super::scoped_ftz::ScopedFtz;
use super::*;

#[test]
fn test_flush_denormals_basic() {
    // 1e-39 is subnormal (below f32::MIN_POSITIVE ~1.175e-38) and must be zeroed.
    let mut samples = [1e-39_f32, 1e-20, 1e-10, 0.0, -1e-39_f32, 1.0];
    flush_denormals_inplace(&mut samples);
    assert_eq!(samples[0], 0.0);
    assert_eq!(samples[1], 1e-20);
    assert_eq!(samples[2], 1e-10);
    assert_eq!(samples[3], 0.0);
    assert_eq!(samples[4], 0.0);
    assert_eq!(samples[5], 1.0);
}

#[test]
fn test_flush_denormals_complex() {
    use rustfft::num_complex::Complex;
    // re=1e-39 (subnormal) zeroed; im=1e-30 (normal) preserved.
    let mut samples = [
        Complex::new(1e-39_f32, 1e-30_f32),
        Complex::new(1.0, 1e-39_f32),
        Complex::new(0.0, 0.0),
    ];
    flush_denormals_complex_inplace(&mut samples);
    assert_eq!(samples[0].re, 0.0);
    assert!(samples[0].im != 0.0, "normal im 1e-30 must be preserved");
    assert_eq!(samples[1].re, 1.0);
    assert_eq!(samples[1].im, 0.0);
    assert_eq!(samples[2].re, 0.0);
    assert_eq!(samples[2].im, 0.0);
}

#[test]
fn test_flush_denormals_empty() {
    let mut samples: [f32; 0] = [];
    flush_denormals_inplace(&mut samples);
}

#[test]
fn test_flush_denormals_unaligned() {
    let mut samples = [1e-39_f32; 7];
    flush_denormals_inplace(&mut samples);
    for s in samples.iter() {
        assert_eq!(*s, 0.0);
    }
}

#[test]
fn test_enable_ftz_daz_does_not_panic() {
    // enable_ftz_daz() should complete without panicking on any platform.
    // On x86_64 or aarch64 it returns true; on other platforms false.
    let result = enable_ftz_daz();
    #[cfg(any(target_arch = "x86_64", target_arch = "aarch64"))]
    assert!(
        result,
        "enable_ftz_daz should return true on supported platforms"
    );
    #[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
    assert!(
        !result,
        "enable_ftz_daz should return false on unsupported platforms"
    );
}

#[test]
fn test_scoped_ftz_does_not_panic() {
    // ScopedFtz must construct and drop without panicking on any platform.
    {
        let _guard = ScopedFtz::new();
        // FTZ/DAZ active within this scope
    }
    // Previous FPU state restored on drop.
}

#[test]
fn test_apply_gain_simd_known_values() {
    // Apply gain of 2.0 to known input
    let mut buffer = vec![1.0, 2.0, 3.0, 4.0, -1.0, 0.5, -0.5, 0.0, 1.5];
    let expected: Vec<f32> = buffer.iter().map(|&x| x * 2.0).collect();
    apply_gain_simd(&mut buffer, 2.0);
    for (i, (&got, &exp)) in buffer.iter().zip(expected.iter()).enumerate() {
        assert!(
            (got - exp).abs() < 1e-6,
            "apply_gain_simd mismatch at index {}: got {}, expected {}",
            i,
            got,
            exp
        );
    }
}

#[test]
fn test_apply_gain_simd_zero_gain() {
    let mut buffer = vec![1.0, -2.0, 3.5, 0.7];
    apply_gain_simd(&mut buffer, 0.0);
    for (i, &v) in buffer.iter().enumerate() {
        assert_eq!(
            v, 0.0,
            "apply_gain_simd with zero gain: index {} not zero",
            i
        );
    }
}

#[test]
fn test_apply_gain_simd_unity_gain() {
    let original = vec![1.0, -2.0, 3.5, 0.7, 0.0, -0.1];
    let mut buffer = original.clone();
    apply_gain_simd(&mut buffer, 1.0);
    assert_eq!(buffer, original);
}

#[test]
fn test_apply_per_channel_gain_simd_stereo() {
    // Stereo buffer: apply different gains to L and R
    let mut buffer = vec![1.0, 2.0, 3.0, 4.0]; // 2 frames, 2 channels
    let gains = vec![0.5, 2.0]; // L=0.5, R=2.0
    apply_per_channel_gain_simd(&mut buffer, 2, &gains);
    assert!((buffer[0] - 0.5).abs() < 1e-6, "L frame 0");
    assert!((buffer[1] - 4.0).abs() < 1e-6, "R frame 0");
    assert!((buffer[2] - 1.5).abs() < 1e-6, "L frame 1");
    assert!((buffer[3] - 8.0).abs() < 1e-6, "R frame 1");
}

#[test]
fn test_apply_per_channel_gain_simd_zero_channels() {
    // channels == 0 is malformed; the call must not panic (division by zero)
    // and must leave the buffer unchanged.
    let mut buffer = vec![1.0, 2.0, 3.0];
    let gains = vec![0.5];
    apply_per_channel_gain_simd(&mut buffer, 0, &gains);
    assert_eq!(buffer, vec![1.0, 2.0, 3.0]);
}

#[test]
fn test_apply_per_channel_gain_simd_non_multiple_length() {
    // Buffer length is not a multiple of channels: the trailing partial frame
    // must also be scaled (sample i uses gains[i % channels]), not skipped.
    let mut buffer = vec![1.0, 2.0, 3.0, 4.0, 5.0]; // 2 stereo frames + tail (ch 0)
    let gains = vec![0.5, 2.0];
    apply_per_channel_gain_simd(&mut buffer, 2, &gains);
    let expected = [0.5, 4.0, 1.5, 8.0, 2.5];
    for (i, (&got, &exp)) in buffer.iter().zip(expected.iter()).enumerate() {
        assert!(
            (got - exp).abs() < 1e-6,
            "non-multiple length mismatch at index {}: got {}, expected {}",
            i,
            got,
            exp
        );
    }
}

#[test]
fn test_apply_per_channel_gain_simd_non_multiple_length_multichannel() {
    // Same tail contract for a non-SIMD channel count (3 channels, 7 samples:
    // 2 full frames + tail covering channels 0 and 1).
    let mut buffer = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0];
    let gains = vec![2.0, 0.5, 3.0];
    apply_per_channel_gain_simd(&mut buffer, 3, &gains);
    let expected = [2.0, 1.0, 9.0, 8.0, 2.5, 18.0, 14.0];
    for (i, (&got, &exp)) in buffer.iter().zip(expected.iter()).enumerate() {
        assert!(
            (got - exp).abs() < 1e-6,
            "multichannel tail mismatch at index {}: got {}, expected {}",
            i,
            got,
            exp
        );
    }
}

#[test]
fn test_apply_per_channel_gain_simd_gains_shorter_than_channels() {
    // gains.len() < channels is malformed; the call must not panic with an
    // out-of-bounds index and must leave the buffer unchanged.
    let mut buffer = vec![1.0, 2.0, 3.0, 4.0];
    let gains = vec![0.5]; // only 1 gain for 4 channels
    apply_per_channel_gain_simd(&mut buffer, 4, &gains);
    assert_eq!(buffer, vec![1.0, 2.0, 3.0, 4.0]);
}

#[test]
fn test_apply_per_channel_gain_simd_gains_shorter_stereo() {
    // Same malformed-input contract through the stereo fast path.
    let mut buffer = vec![1.0, 2.0, 3.0, 4.0];
    let gains = vec![0.5]; // missing channel 1 gain
    apply_per_channel_gain_simd(&mut buffer, 2, &gains);
    assert_eq!(buffer, vec![1.0, 2.0, 3.0, 4.0]);
}

#[test]
fn test_simd_complex_mul_add_correctness() {
    // Test SIMD complex multiply-accumulate against scalar reference
    use rustfft::num_complex::Complex;

    // Test with 8 complex numbers (to test both AVX2 and NEON code paths)
    let src = vec![
        Complex::new(1.0, 2.0),
        Complex::new(3.0, 4.0),
        Complex::new(-1.0, 0.5),
        Complex::new(0.0, -2.0),
        Complex::new(2.5, -1.5),
        Complex::new(-3.5, 2.5),
        Complex::new(1.1, -0.9),
        Complex::new(-0.8, 1.2),
    ];

    let hrtf = vec![
        Complex::new(0.5, 0.25),
        Complex::new(-1.0, 1.5),
        Complex::new(2.0, -0.5),
        Complex::new(0.75, 0.75),
        Complex::new(-0.5, 2.0),
        Complex::new(1.5, -1.0),
        Complex::new(0.9, 0.3),
        Complex::new(-1.1, 0.7),
    ];

    let initial = vec![
        Complex::new(0.1, 0.2),
        Complex::new(0.3, 0.4),
        Complex::new(0.5, 0.6),
        Complex::new(0.7, 0.8),
        Complex::new(0.9, 1.0),
        Complex::new(1.1, 1.2),
        Complex::new(1.3, 1.4),
        Complex::new(1.5, 1.6),
    ];

    // Scalar reference computation
    let mut expected = initial.clone();
    for i in 0..src.len() {
        expected[i] += src[i] * hrtf[i];
    }

    // SIMD computation
    let mut result = initial.clone();
    complex_mul_add_simd(&mut result, &src, &hrtf);

    // Compare results with tolerance for floating point errors
    const EPSILON: f32 = 1e-6;
    for i in 0..src.len() {
        assert!(
            (result[i].re - expected[i].re).abs() < EPSILON,
            "SIMD result[{}].re = {}, expected = {} (diff = {})",
            i,
            result[i].re,
            expected[i].re,
            (result[i].re - expected[i].re).abs()
        );
        assert!(
            (result[i].im - expected[i].im).abs() < EPSILON,
            "SIMD result[{}].im = {}, expected = {} (diff = {})",
            i,
            result[i].im,
            expected[i].im,
            (result[i].im - expected[i].im).abs()
        );
    }
}

#[test]
fn test_simd_complex_mul_correctness() {
    // Test SIMD complex multiplication (without accumulation)
    use rustfft::num_complex::Complex;

    let src = vec![
        Complex::new(2.0, 3.0),
        Complex::new(-1.5, 2.5),
        Complex::new(0.5, -1.0),
        Complex::new(4.0, -2.0),
    ];

    let hrtf = vec![
        Complex::new(1.0, 0.5),
        Complex::new(2.0, -1.0),
        Complex::new(-0.5, 1.5),
        Complex::new(0.75, 0.25),
    ];

    // Scalar reference
    let expected: Vec<Complex<f32>> = src.iter().zip(hrtf.iter()).map(|(a, b)| a * b).collect();

    // SIMD computation
    let mut result = vec![Complex::new(0.0, 0.0); src.len()];
    complex_mul_simd(&mut result, &src, &hrtf);

    // Compare
    const EPSILON: f32 = 1e-6;
    for i in 0..src.len() {
        assert!(
            (result[i].re - expected[i].re).abs() < EPSILON,
            "SIMD result[{}].re = {}, expected = {}",
            i,
            result[i].re,
            expected[i].re
        );
        assert!(
            (result[i].im - expected[i].im).abs() < EPSILON,
            "SIMD result[{}].im = {}, expected = {}",
            i,
            result[i].im,
            expected[i].im
        );
    }
}

#[test]
fn test_simd_edge_cases() {
    // Test edge cases: zeros, ones, conjugates
    use rustfft::num_complex::Complex;

    // Test 1: Multiply by zero
    let src = vec![
        Complex::new(1.0, 2.0),
        Complex::new(3.0, 4.0),
        Complex::new(5.0, 6.0),
        Complex::new(7.0, 8.0),
    ];
    let zero = vec![Complex::new(0.0, 0.0); 4];
    let mut result = src.clone();
    let input = result.clone();
    complex_mul_simd(&mut result, &input, &zero);
    for i in 0..4 {
        assert_eq!(result[i].re, 0.0);
        assert_eq!(result[i].im, 0.0);
    }

    // Test 2: Multiply by one (identity)
    let one = vec![Complex::new(1.0, 0.0); 4];
    let mut result = vec![Complex::new(0.0, 0.0); 4];
    complex_mul_simd(&mut result, &src, &one);
    for i in 0..4 {
        assert!((result[i].re - src[i].re).abs() < 1e-6);
        assert!((result[i].im - src[i].im).abs() < 1e-6);
    }

    // Test 3: Multiply by conjugate (should give real result)
    let a = Complex::new(3.0, 4.0);
    let a_conj = Complex::new(3.0, -4.0);
    let src = vec![a, a, a, a];
    let conj = vec![a_conj, a_conj, a_conj, a_conj];
    let mut result = vec![Complex::new(0.0, 0.0); 4];
    complex_mul_simd(&mut result, &src, &conj);

    // a * conj(a) = |a|^2 = 3^2 + 4^2 = 25
    for i in 0..4 {
        assert!((result[i].re - 25.0).abs() < 1e-5);
        assert!(result[i].im.abs() < 1e-5); // Should be approximately zero
    }
}

#[test]
fn test_simd_large_buffer() {
    // Test with realistic FFT buffer sizes
    use rustfft::num_complex::Complex;

    for fft_size in [512, 1024, 2048, 4096] {
        let mut src = Vec::with_capacity(fft_size);
        let mut hrtf = Vec::with_capacity(fft_size);

        // Fill with test pattern
        for i in 0..fft_size {
            let phase = (i as f32) * 0.01;
            src.push(Complex::new(phase.cos(), phase.sin()));
            hrtf.push(Complex::new(0.5, 0.25));
        }

        // Scalar reference
        let mut expected = vec![Complex::new(0.1, 0.2); fft_size];
        for i in 0..fft_size {
            expected[i] += src[i] * hrtf[i];
        }

        // SIMD computation
        let mut result = vec![Complex::new(0.1, 0.2); fft_size];
        complex_mul_add_simd(&mut result, &src, &hrtf);

        // Verify all elements match
        for i in 0..fft_size {
            assert!(
                (result[i].re - expected[i].re).abs() < 1e-5,
                "FFT size {}, index {}: SIMD mismatch",
                fft_size,
                i
            );
            assert!(
                (result[i].im - expected[i].im).abs() < 1e-5,
                "FFT size {}, index {}: SIMD mismatch",
                fft_size,
                i
            );
        }
    }
}

#[test]
fn test_simd_unaligned_sizes() {
    // Test with buffer sizes that don't align to SIMD width
    // This ensures the scalar remainder loop works correctly
    use rustfft::num_complex::Complex;

    for size in [1, 3, 5, 7, 9, 13, 17] {
        let src: Vec<Complex<f32>> = (0..size)
            .map(|i| Complex::new(i as f32, (i as f32) * 0.5))
            .collect();
        let hrtf: Vec<Complex<f32>> = (0..size)
            .map(|i| Complex::new(0.5, (i as f32) * 0.1))
            .collect();

        // Scalar reference
        let expected: Vec<Complex<f32>> = src.iter().zip(hrtf.iter()).map(|(a, b)| a * b).collect();

        // SIMD computation
        let mut result = vec![Complex::new(0.0, 0.0); size];
        complex_mul_simd(&mut result, &src, &hrtf);

        // Verify
        for i in 0..size {
            assert!(
                (result[i].re - expected[i].re).abs() < 1e-6,
                "Size {}, index {}: re mismatch",
                size,
                i
            );
            assert!(
                (result[i].im - expected[i].im).abs() < 1e-6,
                "Size {}, index {}: im mismatch",
                size,
                i
            );
        }
    }
}

#[test]
fn test_simd_complex_mul_inplace_correctness() {
    // Basic correctness test for in-place complex multiplication
    use rustfft::num_complex::Complex;

    let src = vec![
        Complex::new(2.0, 3.0),
        Complex::new(-1.5, 2.5),
        Complex::new(0.5, -1.0),
        Complex::new(4.0, -2.0),
    ];

    let hrtf = vec![
        Complex::new(1.0, 0.5),
        Complex::new(2.0, -1.0),
        Complex::new(-0.5, 1.5),
        Complex::new(0.75, 0.25),
    ];

    // Scalar reference
    let mut expected = src.clone();
    for i in 0..expected.len() {
        expected[i] *= hrtf[i];
    }

    // SIMD in-place computation
    let mut result = src.clone();
    complex_mul_inplace_simd(&mut result, &hrtf);

    const EPSILON: f32 = 1e-6;
    for i in 0..result.len() {
        assert!(
            (result[i].re - expected[i].re).abs() < EPSILON,
            "Index {}: re mismatch {} vs {}",
            i,
            result[i].re,
            expected[i].re
        );
        assert!(
            (result[i].im - expected[i].im).abs() < EPSILON,
            "Index {}: im mismatch {} vs {}",
            i,
            result[i].im,
            expected[i].im
        );
    }
}

#[test]
fn test_simd_inplace_large_buffers() {
    // Test in-place multiplication with realistic FFT buffer sizes
    use rustfft::num_complex::Complex;

    for fft_size in [128, 256, 512, 1024, 2048] {
        let mut src: Vec<Complex<f32>> = (0..fft_size)
            .map(|i| {
                let phase = (i as f32) * 0.01;
                Complex::new(phase.cos(), phase.sin())
            })
            .collect();

        let hrtf: Vec<Complex<f32>> = (0..fft_size)
            .map(|i| Complex::new(0.5 + (i as f32) * 0.001, 0.25))
            .collect();

        // Scalar reference
        let mut expected = src.clone();
        for i in 0..fft_size {
            expected[i] *= hrtf[i];
        }

        // SIMD computation
        complex_mul_inplace_simd(&mut src, &hrtf);

        // Verify all elements match
        for i in 0..fft_size {
            assert!(
                (src[i].re - expected[i].re).abs() < 1e-5,
                "FFT size {}, index {}: re mismatch",
                fft_size,
                i
            );
            assert!(
                (src[i].im - expected[i].im).abs() < 1e-5,
                "FFT size {}, index {}: im mismatch",
                fft_size,
                i
            );
        }
    }
}

#[test]
fn test_simd_inplace_unaligned() {
    // Test with sizes that don't align to SIMD width (4 for AVX2, 2 for NEON)
    use rustfft::num_complex::Complex;

    for size in [1, 2, 3, 5, 6, 7, 9, 10, 11, 15, 17, 19, 23] {
        let mut src: Vec<Complex<f32>> = (0..size)
            .map(|i| Complex::new((i as f32) * 0.5, (i as f32) * -0.3))
            .collect();

        let hrtf: Vec<Complex<f32>> = (0..size)
            .map(|i| Complex::new(1.0 + (i as f32) * 0.1, 0.5))
            .collect();

        // Scalar reference
        let mut expected = src.clone();
        for i in 0..size {
            expected[i] *= hrtf[i];
        }

        // SIMD computation
        complex_mul_inplace_simd(&mut src, &hrtf);

        // Verify
        for i in 0..size {
            assert!(
                (src[i].re - expected[i].re).abs() < 1e-6,
                "Size {}, index {}: re mismatch",
                size,
                i
            );
            assert!(
                (src[i].im - expected[i].im).abs() < 1e-6,
                "Size {}, index {}: im mismatch",
                size,
                i
            );
        }
    }
}

#[test]
fn test_simd_inplace_edge_cases() {
    // Test edge cases: zeros, ones, conjugates, negative values
    use rustfft::num_complex::Complex;

    // Test 1: Multiply by zero (should zero out the buffer)
    let mut src = vec![
        Complex::new(1.0, 2.0),
        Complex::new(3.0, 4.0),
        Complex::new(5.0, 6.0),
        Complex::new(7.0, 8.0),
    ];
    let zero = vec![Complex::new(0.0, 0.0); 4];
    complex_mul_inplace_simd(&mut src, &zero);
    for i in 0..4 {
        assert!(src[i].re.abs() < 1e-6, "Expected zero, got {}", src[i].re);
        assert!(src[i].im.abs() < 1e-6, "Expected zero, got {}", src[i].im);
    }

    // Test 2: Multiply by one (should be identity)
    let original = vec![
        Complex::new(1.5, 2.5),
        Complex::new(-3.5, 4.5),
        Complex::new(5.5, -6.5),
        Complex::new(-7.5, -8.5),
    ];
    let mut src = original.clone();
    let one = vec![Complex::new(1.0, 0.0); 4];
    complex_mul_inplace_simd(&mut src, &one);
    for i in 0..4 {
        assert!((src[i].re - original[i].re).abs() < 1e-6);
        assert!((src[i].im - original[i].im).abs() < 1e-6);
    }

    // Test 3: Multiply by conjugate (should give real result with magnitude |a|^2)
    let a = Complex::new(3.0, 4.0);
    let a_conj = Complex::new(3.0, -4.0);
    let mut src = vec![a; 8];
    let conj = vec![a_conj; 8];
    complex_mul_inplace_simd(&mut src, &conj);
    // a * conj(a) = |a|^2 = 3^2 + 4^2 = 25
    for i in 0..8 {
        assert!(
            (src[i].re - 25.0).abs() < 1e-5,
            "Expected 25.0, got {}",
            src[i].re
        );
        assert!(src[i].im.abs() < 1e-5, "Expected ~0, got {}", src[i].im);
    }

    // Test 4: Multiply by i (rotation by 90 degrees)
    let mut src = vec![Complex::new(1.0, 0.0); 4];
    let i_val = vec![Complex::new(0.0, 1.0); 4];
    complex_mul_inplace_simd(&mut src, &i_val);
    for idx in 0..4 {
        assert!(src[idx].re.abs() < 1e-6, "Expected 0, got {}", src[idx].re);
        assert!(
            (src[idx].im - 1.0).abs() < 1e-6,
            "Expected 1, got {}",
            src[idx].im
        );
    }
}

#[test]
fn test_simd_inplace_negative_values() {
    // Test with all negative values
    use rustfft::num_complex::Complex;

    let mut src = vec![
        Complex::new(-1.0, -2.0),
        Complex::new(-3.0, -4.0),
        Complex::new(-5.0, -6.0),
        Complex::new(-7.0, -8.0),
    ];

    let hrtf = vec![
        Complex::new(-0.5, -0.25),
        Complex::new(-1.0, -1.5),
        Complex::new(-2.0, 0.5),
        Complex::new(0.75, -0.75),
    ];

    // Scalar reference
    let mut expected = src.clone();
    for i in 0..expected.len() {
        expected[i] *= hrtf[i];
    }

    // SIMD computation
    complex_mul_inplace_simd(&mut src, &hrtf);

    const EPSILON: f32 = 1e-6;
    for i in 0..src.len() {
        assert!((src[i].re - expected[i].re).abs() < EPSILON);
        assert!((src[i].im - expected[i].im).abs() < EPSILON);
    }
}

#[test]
fn test_covariance_basic_correctness() {
    // Test basic covariance computation against scalar reference
    use rustfft::num_complex::Complex;

    let left = vec![
        Complex::new(1.0, 2.0),
        Complex::new(3.0, 4.0),
        Complex::new(-1.0, 0.5),
        Complex::new(0.0, -2.0),
        Complex::new(2.5, -1.5),
        Complex::new(-3.5, 2.5),
        Complex::new(1.1, -0.9),
        Complex::new(-0.8, 1.2),
    ];

    let right = vec![
        Complex::new(0.5, 0.25),
        Complex::new(-1.0, 1.5),
        Complex::new(2.0, -0.5),
        Complex::new(0.75, 0.75),
        Complex::new(-0.5, 2.0),
        Complex::new(1.5, -1.0),
        Complex::new(0.9, 0.3),
        Complex::new(-1.1, 0.7),
    ];

    // Scalar reference
    let mut expected_xx = 0.0_f32;
    let mut expected_yy = 0.0_f32;
    let mut expected_xy = Complex::new(0.0, 0.0);
    for i in 0..left.len() {
        expected_xx += left[i].norm_sqr();
        expected_yy += right[i].norm_sqr();
        expected_xy += left[i] * right[i].conj();
    }

    // SIMD computation
    let (cov_xx, cov_yy, cov_xy) = compute_covariance_simd(&left, &right, 0, left.len());

    const EPSILON: f32 = 1e-5;
    assert!(
        (cov_xx - expected_xx).abs() < EPSILON,
        "cov_xx mismatch: {} vs {}",
        cov_xx,
        expected_xx
    );
    assert!(
        (cov_yy - expected_yy).abs() < EPSILON,
        "cov_yy mismatch: {} vs {}",
        cov_yy,
        expected_yy
    );
    assert!(
        (cov_xy.re - expected_xy.re).abs() < EPSILON,
        "cov_xy.re mismatch: {} vs {}",
        cov_xy.re,
        expected_xy.re
    );
    assert!(
        (cov_xy.im - expected_xy.im).abs() < EPSILON,
        "cov_xy.im mismatch: {} vs {}",
        cov_xy.im,
        expected_xy.im
    );
}

#[test]
fn test_covariance_cross_term_is_conjugate_product() {
    // Regression test for the AVX2 kernel: cov_xy must accumulate
    // l * conj(r) = (ac + bd) + (bc - ad)i per element (matching the scalar
    // reference and the docstring), not some other sign combination.
    //
    // With l = r = 1 + i the correct per-element cross term is
    // (1 + i)(1 - i) = 2 + 0i. The buggy AVX2 sign pattern
    // (bd - ac) + (bc + ad)i would instead give 0 + 2i per element, and the
    // plain (non-conjugated) product (ac - bd) + (ad + bc)i would give 0 + 2i
    // as well — so this data distinguishes all three kernels.
    //
    // Note: on machines without AVX2 this exercises the scalar path; the AVX2
    // kernel itself is covered by CI builds with RUSTFLAGS=-C target-feature=+avx2.
    use rustfft::num_complex::Complex;

    let left = vec![Complex::new(1.0, 1.0); 8];
    let right = vec![Complex::new(1.0, 1.0); 8];
    let (cov_xx, cov_yy, cov_xy) = compute_covariance_simd(&left, &right, 0, 8);

    const EPSILON: f32 = 1e-5;
    assert!((cov_xx - 16.0).abs() < EPSILON, "cov_xx = {}", cov_xx);
    assert!((cov_yy - 16.0).abs() < EPSILON, "cov_yy = {}", cov_yy);
    assert!(
        (cov_xy.re - 16.0).abs() < EPSILON,
        "cov_xy.re = {}, expected 16.0 (sum of l * conj(r))",
        cov_xy.re
    );
    assert!(
        cov_xy.im.abs() < EPSILON,
        "cov_xy.im = {}, expected 0.0 (sum of l * conj(r))",
        cov_xy.im
    );

    // Mixed-sign data, checked against the scalar l * r.conj() reference.
    let left = [
        Complex::new(1.0, 2.0),
        Complex::new(-3.0, 0.5),
        Complex::new(0.25, -1.5),
        Complex::new(2.0, 2.0),
    ];
    let right = [
        Complex::new(0.5, -0.25),
        Complex::new(1.5, 1.0),
        Complex::new(-0.75, 2.0),
        Complex::new(-1.0, -0.5),
    ];
    let mut expected_xy = Complex::new(0.0, 0.0);
    for i in 0..left.len() {
        expected_xy += left[i] * right[i].conj();
    }
    let (_, _, cov_xy) = compute_covariance_simd(&left, &right, 0, left.len());
    assert!(
        (cov_xy.re - expected_xy.re).abs() < EPSILON,
        "cov_xy.re mismatch: {} vs {}",
        cov_xy.re,
        expected_xy.re
    );
    assert!(
        (cov_xy.im - expected_xy.im).abs() < EPSILON,
        "cov_xy.im mismatch: {} vs {}",
        cov_xy.im,
        expected_xy.im
    );
}

#[test]
fn test_covariance_with_ranges() {
    // Test covariance computation with different start/end ranges
    use rustfft::num_complex::Complex;

    let left: Vec<Complex<f32>> = (0..32)
        .map(|i| Complex::new(i as f32 * 0.5, i as f32 * -0.3))
        .collect();
    let right: Vec<Complex<f32>> = (0..32)
        .map(|i| Complex::new(i as f32 * -0.4, i as f32 * 0.6))
        .collect();

    // Test various ranges
    for (start, end) in [(0, 8), (4, 12), (10, 20), (5, 25), (0, 32)] {
        // Scalar reference
        let mut expected_xx = 0.0_f32;
        let mut expected_yy = 0.0_f32;
        let mut expected_xy = Complex::new(0.0, 0.0);
        for i in start..end {
            expected_xx += left[i].norm_sqr();
            expected_yy += right[i].norm_sqr();
            expected_xy += left[i] * right[i].conj();
        }

        // SIMD computation
        let (cov_xx, cov_yy, cov_xy) = compute_covariance_simd(&left, &right, start, end);

        // SIMD sums groups of four elements differently than the scalar loop,
        // so allow a small relative tolerance on top of an absolute floor.
        const REL_EPSILON: f32 = 1e-4;
        const ABS_EPSILON: f32 = 1e-5;
        assert!(
            (cov_xx - expected_xx).abs() < REL_EPSILON * expected_xx.abs() + ABS_EPSILON,
            "Range [{}, {}): cov_xx mismatch: {} vs {}",
            start,
            end,
            cov_xx,
            expected_xx
        );
        assert!(
            (cov_yy - expected_yy).abs() < REL_EPSILON * expected_yy.abs() + ABS_EPSILON,
            "Range [{}, {}): cov_yy mismatch: {} vs {}",
            start,
            end,
            cov_yy,
            expected_yy
        );
        assert!(
            (cov_xy.re - expected_xy.re).abs() < REL_EPSILON * expected_xy.re.abs() + ABS_EPSILON,
            "Range [{}, {}): cov_xy.re mismatch: {} vs {}",
            start,
            end,
            cov_xy.re,
            expected_xy.re
        );
        assert!(
            (cov_xy.im - expected_xy.im).abs() < REL_EPSILON * expected_xy.im.abs() + ABS_EPSILON,
            "Range [{}, {}): cov_xy.im mismatch: {} vs {}",
            start,
            end,
            cov_xy.im,
            expected_xy.im
        );
    }
}

#[test]
fn test_covariance_large_buffers() {
    // Test with realistic FFT buffer sizes
    use rustfft::num_complex::Complex;

    for fft_size in [128, 256, 512, 1024, 2048, 4096] {
        let left: Vec<Complex<f32>> = (0..fft_size)
            .map(|i| {
                let phase = (i as f32) * 0.01;
                Complex::new(phase.cos(), phase.sin())
            })
            .collect();

        let right: Vec<Complex<f32>> = (0..fft_size)
            .map(|i| {
                let phase = (i as f32) * 0.02;
                Complex::new(phase.sin(), phase.cos())
            })
            .collect();

        // Scalar reference
        let mut expected_xx = 0.0_f32;
        let mut expected_yy = 0.0_f32;
        let mut expected_xy = Complex::new(0.0, 0.0);
        for i in 0..fft_size {
            expected_xx += left[i].norm_sqr();
            expected_yy += right[i].norm_sqr();
            expected_xy += left[i] * right[i].conj();
        }

        // SIMD computation
        let (cov_xx, cov_yy, cov_xy) = compute_covariance_simd(&left, &right, 0, fft_size);

        // Relative tolerance for larger sums
        let rel_epsilon = 1e-4;
        assert!(
            (cov_xx - expected_xx).abs() < expected_xx * rel_epsilon,
            "FFT size {}: cov_xx mismatch",
            fft_size
        );
        assert!(
            (cov_yy - expected_yy).abs() < expected_yy * rel_epsilon,
            "FFT size {}: cov_yy mismatch",
            fft_size
        );
        assert!(
            (cov_xy.re - expected_xy.re).abs() < expected_xy.re.abs() * rel_epsilon + 1e-5,
            "FFT size {}: cov_xy.re mismatch",
            fft_size
        );
        assert!(
            (cov_xy.im - expected_xy.im).abs() < expected_xy.im.abs() * rel_epsilon + 1e-5,
            "FFT size {}: cov_xy.im mismatch",
            fft_size
        );
    }
}

#[test]
fn test_covariance_unaligned_ranges() {
    // Test with ranges that don't align to SIMD width
    use rustfft::num_complex::Complex;

    let left: Vec<Complex<f32>> = (0..50)
        .map(|i| Complex::new(i as f32 * 0.2, i as f32 * 0.3))
        .collect();
    let right: Vec<Complex<f32>> = (0..50)
        .map(|i| Complex::new(i as f32 * -0.1, i as f32 * 0.4))
        .collect();

    // Test with various unaligned ranges
    for (start, end) in [(0, 1), (0, 3), (1, 4), (2, 7), (5, 11), (10, 23), (15, 37)] {
        // Scalar reference
        let mut expected_xx = 0.0_f32;
        let mut expected_yy = 0.0_f32;
        let mut expected_xy = Complex::new(0.0, 0.0);
        for i in start..end {
            expected_xx += left[i].norm_sqr();
            expected_yy += right[i].norm_sqr();
            expected_xy += left[i] * right[i].conj();
        }

        // SIMD computation
        let (cov_xx, cov_yy, cov_xy) = compute_covariance_simd(&left, &right, start, end);

        // SIMD sums groups of four elements differently than the scalar loop,
        // so allow a small relative tolerance on top of an absolute floor.
        const REL_EPSILON: f32 = 1e-4;
        const ABS_EPSILON: f32 = 1e-5;
        assert!(
            (cov_xx - expected_xx).abs() < REL_EPSILON * expected_xx.abs() + ABS_EPSILON,
            "Range [{}, {}): cov_xx mismatch: {} vs {}",
            start,
            end,
            cov_xx,
            expected_xx
        );
        assert!(
            (cov_yy - expected_yy).abs() < REL_EPSILON * expected_yy.abs() + ABS_EPSILON,
            "Range [{}, {}): cov_yy mismatch: {} vs {}",
            start,
            end,
            cov_yy,
            expected_yy
        );
        assert!(
            (cov_xy.re - expected_xy.re).abs() < REL_EPSILON * expected_xy.re.abs() + ABS_EPSILON,
            "Range [{}, {}): cov_xy.re mismatch: {} vs {}",
            start,
            end,
            cov_xy.re,
            expected_xy.re
        );
        assert!(
            (cov_xy.im - expected_xy.im).abs() < REL_EPSILON * expected_xy.im.abs() + ABS_EPSILON,
            "Range [{}, {}): cov_xy.im mismatch: {} vs {}",
            start,
            end,
            cov_xy.im,
            expected_xy.im
        );
    }
}

#[test]
fn test_covariance_empty_range() {
    // An empty range (start == end) must return zeros, not panic.
    use rustfft::num_complex::Complex;

    let left: Vec<Complex<f32>> = (0..8)
        .map(|i| Complex::new(i as f32, i as f32 * -0.5))
        .collect();
    let right: Vec<Complex<f32>> = (0..8)
        .map(|i| Complex::new(i as f32 * 0.25, i as f32))
        .collect();

    for (start, end) in [(0, 0), (4, 4), (8, 8)] {
        let (cov_xx, cov_yy, cov_xy) = compute_covariance_simd(&left, &right, start, end);
        assert_eq!(cov_xx, 0.0, "Range [{}, {}): cov_xx", start, end);
        assert_eq!(cov_yy, 0.0, "Range [{}, {}): cov_yy", start, end);
        assert_eq!(
            cov_xy,
            Complex::new(0.0, 0.0),
            "Range [{}, {}): cov_xy",
            start,
            end
        );
    }
}

#[test]
fn test_covariance_edge_cases() {
    // Test covariance with edge cases
    use rustfft::num_complex::Complex;

    // Test 1: All zeros
    let zero_left = vec![Complex::new(0.0, 0.0); 8];
    let zero_right = vec![Complex::new(0.0, 0.0); 8];
    let (cov_xx, cov_yy, cov_xy) = compute_covariance_simd(&zero_left, &zero_right, 0, 8);
    assert!(cov_xx.abs() < 1e-6, "Expected zero cov_xx");
    assert!(cov_yy.abs() < 1e-6, "Expected zero cov_yy");
    assert!(cov_xy.norm_sqr() < 1e-6, "Expected zero cov_xy");

    // Test 2: Real-only signals
    let real_left: Vec<Complex<f32>> = (0..8).map(|i| Complex::new(i as f32, 0.0)).collect();
    let real_right: Vec<Complex<f32>> = (0..8)
        .map(|i| Complex::new((i as f32) * 0.5, 0.0))
        .collect();
    let (cov_xx, cov_yy, cov_xy) = compute_covariance_simd(&real_left, &real_right, 0, 8);

    // cov_xy should be real (imaginary part should be ~0)
    assert!(
        cov_xy.im.abs() < 1e-5,
        "Expected real cov_xy for real signals"
    );

    // Verify values match scalar computation
    let mut expected_xx = 0.0;
    let mut expected_yy = 0.0;
    for i in 0..8 {
        expected_xx += (i * i) as f32;
        expected_yy += ((i as f32) * 0.5).powi(2);
    }
    assert!((cov_xx - expected_xx).abs() < 1e-5);
    assert!((cov_yy - expected_yy).abs() < 1e-5);

    // Test 3: Imaginary-only signals
    let imag_left: Vec<Complex<f32>> = (0..8).map(|i| Complex::new(0.0, i as f32)).collect();
    let imag_right: Vec<Complex<f32>> = (0..8)
        .map(|i| Complex::new(0.0, (i as f32) * 2.0))
        .collect();
    let (_cov_xx, _cov_yy, cov_xy) = compute_covariance_simd(&imag_left, &imag_right, 0, 8);

    // cov_xy should be real (because conj flips imaginary sign)
    assert!(
        cov_xy.im.abs() < 1e-5,
        "Expected real cov_xy for imaginary signals"
    );

    // Test 4: Single element range
    let single_left = vec![Complex::new(3.0, 4.0)];
    let single_right = vec![Complex::new(1.0, 2.0)];
    let (cov_xx, cov_yy, cov_xy) = compute_covariance_simd(&single_left, &single_right, 0, 1);
    assert!((cov_xx - 25.0).abs() < 1e-5); // 3^2 + 4^2 = 25
    assert!((cov_yy - 5.0).abs() < 1e-5); // 1^2 + 2^2 = 5
    // (3 + 4i) * (1 - 2i) = 3 - 6i + 4i - 8i^2 = 3 - 2i + 8 = 11 - 2i
    assert!((cov_xy.re - 11.0).abs() < 1e-5);
    assert!((cov_xy.im - (-2.0)).abs() < 1e-5);
}

#[test]
fn test_numerical_accuracy_small_values() {
    // Test with very small values to check for denormal handling
    use rustfft::num_complex::Complex;

    let small = 1e-20_f32;
    let src = vec![
        Complex::new(small, small),
        Complex::new(small * 2.0, small * 3.0),
        Complex::new(small * 4.0, small * 5.0),
        Complex::new(small * 6.0, small * 7.0),
    ];

    let hrtf = vec![
        Complex::new(1.0, 0.5),
        Complex::new(2.0, -1.0),
        Complex::new(-0.5, 1.5),
        Complex::new(0.75, 0.25),
    ];

    // Scalar reference
    let expected: Vec<Complex<f32>> = src.iter().zip(hrtf.iter()).map(|(a, b)| a * b).collect();

    // SIMD computation
    let mut result = vec![Complex::new(0.0, 0.0); src.len()];
    complex_mul_simd(&mut result, &src, &hrtf);

    // Relative tolerance for very small numbers
    for i in 0..src.len() {
        let re_diff = (result[i].re - expected[i].re).abs();
        let im_diff = (result[i].im - expected[i].im).abs();

        // For very small numbers, check relative error or absolute error for near-zero
        if expected[i].re.abs() > 1e-15 {
            assert!(re_diff / expected[i].re.abs() < 1e-3);
        } else {
            assert!(re_diff < 1e-25);
        }

        if expected[i].im.abs() > 1e-15 {
            assert!(im_diff / expected[i].im.abs() < 1e-3);
        } else {
            assert!(im_diff < 1e-25);
        }
    }
}

#[test]
fn test_numerical_accuracy_large_values() {
    // Test with large values to check for overflow handling
    use rustfft::num_complex::Complex;

    let large = 1e10_f32;
    let src = vec![
        Complex::new(large, large * 0.5),
        Complex::new(large * 2.0, large * 1.5),
        Complex::new(large * 0.3, large * 0.7),
        Complex::new(large * 1.2, large * 0.8),
    ];

    let hrtf = vec![
        Complex::new(1e-5, 5e-6),
        Complex::new(2e-5, -1e-5),
        Complex::new(-5e-6, 1.5e-5),
        Complex::new(7.5e-6, 2.5e-6),
    ];

    // Scalar reference
    let mut expected = vec![Complex::new(0.0, 0.0); src.len()];
    for i in 0..src.len() {
        expected[i] = src[i] * hrtf[i];
    }

    // SIMD computation
    let mut result = vec![Complex::new(0.0, 0.0); src.len()];
    complex_mul_simd(&mut result, &src, &hrtf);

    // Relative tolerance
    for i in 0..src.len() {
        let re_rel_err = (result[i].re - expected[i].re).abs() / expected[i].re.abs().max(1.0);
        let im_rel_err = (result[i].im - expected[i].im).abs() / expected[i].im.abs().max(1.0);
        assert!(
            re_rel_err < 1e-5,
            "Index {}: re rel error too large: {}",
            i,
            re_rel_err
        );
        assert!(
            im_rel_err < 1e-5,
            "Index {}: im rel error too large: {}",
            i,
            im_rel_err
        );
    }
}

#[test]
fn test_accumulation_accuracy() {
    // Test that repeated accumulation doesn't degrade accuracy significantly
    use rustfft::num_complex::Complex;

    let src = vec![
        Complex::new(0.1, 0.2),
        Complex::new(0.3, 0.4),
        Complex::new(0.5, 0.6),
        Complex::new(0.7, 0.8),
    ];

    let hrtf = vec![
        Complex::new(0.5, 0.25),
        Complex::new(-1.0, 1.5),
        Complex::new(2.0, -0.5),
        Complex::new(0.75, 0.75),
    ];

    // Scalar reference: accumulate 100 times
    let mut expected = vec![Complex::new(0.0, 0.0); src.len()];
    for _ in 0..100 {
        for i in 0..src.len() {
            expected[i] += src[i] * hrtf[i];
        }
    }

    // SIMD computation: accumulate 100 times
    let mut result = vec![Complex::new(0.0, 0.0); src.len()];
    for _ in 0..100 {
        complex_mul_add_simd(&mut result, &src, &hrtf);
    }

    // Check relative error
    const REL_EPSILON: f32 = 1e-4;
    for i in 0..src.len() {
        let re_abs_err = (result[i].re - expected[i].re).abs();
        let im_abs_err = (result[i].im - expected[i].im).abs();

        // Use relative error if expected value is large enough, otherwise use absolute error
        let re_err = if expected[i].re.abs() > 1e-6 {
            re_abs_err / expected[i].re.abs()
        } else {
            re_abs_err
        };
        let im_err = if expected[i].im.abs() > 1e-6 {
            im_abs_err / expected[i].im.abs()
        } else {
            im_abs_err
        };

        assert!(
            re_err < REL_EPSILON,
            "Index {}: re accumulated error too large: {} (abs: {}, expected: {})",
            i,
            re_err,
            re_abs_err,
            expected[i].re
        );
        assert!(
            im_err < REL_EPSILON,
            "Index {}: im accumulated error too large: {} (abs: {}, expected: {})",
            i,
            im_err,
            im_abs_err,
            expected[i].im
        );
    }
}

#[test]
fn test_platform_specific_simd_widths() {
    // Test that SIMD code paths are correctly exercised
    use rustfft::num_complex::Complex;

    // Test sizes that exercise SIMD boundaries:
    // - AVX2 processes 4 complex at a time
    // - NEON processes 2 complex at a time
    let test_sizes = vec![
        1,  // No SIMD, scalar only
        2,  // NEON: 1 iteration, AVX2: scalar only
        3,  // NEON: 1 iteration + 1 scalar, AVX2: scalar only
        4,  // NEON: 2 iterations, AVX2: 1 iteration
        5,  // NEON: 2 iterations + 1 scalar, AVX2: 1 iteration + 1 scalar
        8,  // NEON: 4 iterations, AVX2: 2 iterations
        9,  // Mixed
        12, // NEON: 6 iterations, AVX2: 3 iterations
        16, // NEON: 8 iterations, AVX2: 4 iterations
    ];

    for size in test_sizes {
        let src: Vec<Complex<f32>> = (0..size)
            .map(|i| Complex::new(i as f32 * 0.3, i as f32 * -0.2))
            .collect();
        let hrtf: Vec<Complex<f32>> = (0..size)
            .map(|i| Complex::new(1.0 + i as f32 * 0.1, 0.5))
            .collect();

        // Test all three functions

        // 1. complex_mul_add_simd
        let mut result_add = vec![Complex::new(1.0, 2.0); size];
        let mut expected_add = result_add.clone();
        for i in 0..size {
            expected_add[i] += src[i] * hrtf[i];
        }
        complex_mul_add_simd(&mut result_add, &src, &hrtf);
        for i in 0..size {
            assert!(
                (result_add[i].re - expected_add[i].re).abs() < 1e-6,
                "mul_add size {}, index {}: re mismatch",
                size,
                i
            );
            assert!(
                (result_add[i].im - expected_add[i].im).abs() < 1e-6,
                "mul_add size {}, index {}: im mismatch",
                size,
                i
            );
        }

        // 2. complex_mul_simd
        let mut result_mul = vec![Complex::new(0.0, 0.0); size];
        let expected_mul: Vec<Complex<f32>> =
            src.iter().zip(hrtf.iter()).map(|(a, b)| a * b).collect();
        complex_mul_simd(&mut result_mul, &src, &hrtf);
        for i in 0..size {
            assert!(
                (result_mul[i].re - expected_mul[i].re).abs() < 1e-6,
                "mul size {}, index {}: re mismatch",
                size,
                i
            );
            assert!(
                (result_mul[i].im - expected_mul[i].im).abs() < 1e-6,
                "mul size {}, index {}: im mismatch",
                size,
                i
            );
        }

        // 3. complex_mul_inplace_simd
        let mut result_inplace = src.clone();
        let mut expected_inplace = src.clone();
        for i in 0..size {
            expected_inplace[i] *= hrtf[i];
        }
        complex_mul_inplace_simd(&mut result_inplace, &hrtf);
        for i in 0..size {
            assert!(
                (result_inplace[i].re - expected_inplace[i].re).abs() < 1e-6,
                "inplace size {}, index {}: re mismatch",
                size,
                i
            );
            assert!(
                (result_inplace[i].im - expected_inplace[i].im).abs() < 1e-6,
                "inplace size {}, index {}: im mismatch",
                size,
                i
            );
        }
    }
}

#[test]
fn test_stress_test_random_data() {
    // Stress test with pseudo-random data
    use rustfft::num_complex::Complex;

    // Simple LCG for deterministic "random" values
    let mut seed = 12345_u32;
    let lcg = |s: &mut u32| -> f32 {
        *s = s.wrapping_mul(1103515245).wrapping_add(12345);
        ((*s / 65536) % 32768) as f32 / 32768.0 - 0.5
    };

    for size in [64, 128, 256, 512] {
        let src: Vec<Complex<f32>> = (0..size)
            .map(|_| Complex::new(lcg(&mut seed), lcg(&mut seed)))
            .collect();
        let hrtf: Vec<Complex<f32>> = (0..size)
            .map(|_| Complex::new(lcg(&mut seed), lcg(&mut seed)))
            .collect();

        // Scalar reference
        let expected: Vec<Complex<f32>> = src.iter().zip(hrtf.iter()).map(|(a, b)| a * b).collect();

        // SIMD computation
        let mut result = vec![Complex::new(0.0, 0.0); size];
        complex_mul_simd(&mut result, &src, &hrtf);

        // Verify
        for i in 0..size {
            assert!(
                (result[i].re - expected[i].re).abs() < 1e-5,
                "Stress test size {}, index {}: re mismatch",
                size,
                i
            );
            assert!(
                (result[i].im - expected[i].im).abs() < 1e-5,
                "Stress test size {}, index {}: im mismatch",
                size,
                i
            );
        }
    }
}

#[test]
fn test_blend_simd_known_values() {
    let original = vec![0.0f32, 1.0, 2.0, 3.0, 4.0, 5.0, 7.0];
    let prev = vec![1.0f32, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0];
    let mut dst = original.clone();
    blend_simd(&mut dst, &prev, 0.5);
    for i in 0..dst.len() {
        let expected = prev[i] + 0.5 * (original[i] - prev[i]);
        assert!(
            (dst[i] - expected).abs() < 1e-6,
            "index {i}: got {} expected {}",
            dst[i],
            expected
        );
    }
}

#[test]
fn test_blend_simd_unaligned_sizes() {
    for size in [1usize, 3, 5, 7, 9, 13, 17] {
        let original: Vec<f32> = (0..size).map(|i| i as f32).collect();
        let prev = vec![1.0f32; size];
        let mut dst = original.clone();
        blend_simd(&mut dst, &prev, 0.25);
        for i in 0..size {
            let expected = prev[i] + 0.25 * (original[i] - prev[i]);
            assert!((dst[i] - expected).abs() < 1e-6, "size {size} index {i}");
        }
    }
}

#[test]
fn test_deinterleave_stereo_basic() {
    let interleaved = vec![1.0f32, 2.0, 3.0, 4.0, 5.0, 6.0];
    let mut left = vec![0.0f32; 3];
    let mut right = vec![0.0f32; 3];
    deinterleave_stereo(&interleaved, &mut left, &mut right);
    assert_eq!(left, vec![1.0, 3.0, 5.0]);
    assert_eq!(right, vec![2.0, 4.0, 6.0]);
}

#[test]
fn test_deinterleave_stereo_unaligned() {
    for frames in [1usize, 3, 5, 7, 9] {
        let interleaved: Vec<f32> = (0..frames * 2).map(|i| i as f32).collect();
        let mut left = vec![0.0f32; frames];
        let mut right = vec![0.0f32; frames];
        deinterleave_stereo(&interleaved, &mut left, &mut right);
        for i in 0..frames {
            assert_eq!(left[i], interleaved[i * 2]);
            assert_eq!(right[i], interleaved[i * 2 + 1]);
        }
    }
}

#[test]
fn test_interleave_stereo_basic() {
    let left = vec![1.0f32, 3.0, 5.0];
    let right = vec![2.0f32, 4.0, 6.0];
    let mut out = vec![0.0f32; 6];
    interleave_stereo(&left, &right, &mut out);
    assert_eq!(out, vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0]);
}

#[test]
fn test_fast_inv_sqrt_accuracy() {
    for x in [1.0f32, 4.0, 9.0, 16.0, 100.0, 0.5, 2.0] {
        let expected = 1.0 / x.sqrt();
        let got = fast_inv_sqrt(x);
        let rel_err = (got - expected).abs() / expected;
        assert!(
            rel_err < 1e-6,
            "x={x} got={got} expected={expected} rel_err={rel_err}"
        );
    }
}

#[test]
fn test_fast_inv_sqrt_nonpositive_domain() {
    assert!(fast_inv_sqrt(0.0).is_infinite());
    assert!(fast_inv_sqrt(-1.0).is_nan());
}

#[test]
fn test_find_max_abs_simd_basic() {
    assert_eq!(find_max_abs_simd(&[]), 0.0);
    assert_eq!(find_max_abs_simd(&[1.0f32, -3.0, 2.0, -2.5]), 3.0);
    assert_eq!(find_max_abs_simd(&[-7.0f32, -2.0, -3.0]), 7.0);
}

#[test]
fn test_find_max_abs_simd_unaligned() {
    for size in [1usize, 3, 5, 7, 9, 13, 17] {
        let samples: Vec<f32> = (0..size)
            .map(|i| (i as f32) * (-1.0f32).powi(i as i32))
            .collect();
        let expected = samples.iter().map(|&s| s.abs()).fold(0.0f32, f32::max);
        assert!(
            (find_max_abs_simd(&samples) - expected).abs() < 1e-6,
            "size {size}"
        );
    }
}

#[test]
fn test_scale_add_simd_known_values() {
    let dst_orig = vec![1.0f32, 2.0, 3.0, 4.0, 5.0];
    let src = vec![0.5f32, 1.0, 1.5, 2.0, 2.5];
    let mut dst = dst_orig.clone();
    scale_add_simd(&mut dst, &src, 2.0);
    for i in 0..dst.len() {
        let expected = dst_orig[i] + src[i] * 2.0;
        assert!((dst[i] - expected).abs() < 1e-6, "index {i}");
    }
}

#[test]
fn test_scale_add_simd_inplace_known_values() {
    let mut data = vec![1.0f32, 2.0, 3.0, 4.0, 5.0];
    scale_add_simd_inplace(&mut data, 3.0);
    for i in 0..data.len() {
        let expected = (i as f32 + 1.0) * 3.0;
        assert!((data[i] - expected).abs() < 1e-6, "index {i}");
    }
}

#[test]
fn test_window_mul_simd_known_values() {
    let mut dst = vec![0.0f32; 6];
    let src = vec![1.0f32, 2.0, 3.0, 4.0, 5.0, 6.0];
    let win = vec![0.5f32; 6];
    window_mul_simd(&mut dst, &src, &win);
    for i in 0..dst.len() {
        let expected = src[i] * win[i];
        assert!((dst[i] - expected).abs() < 1e-6, "index {i}");
    }
}

#[test]
fn test_window_mul_simd_inplace_known_values() {
    let mut data = vec![1.0f32, 2.0, 3.0, 4.0];
    let win = vec![0.5f32; 4];
    window_mul_simd_inplace(&mut data, &win);
    for i in 0..data.len() {
        let expected = (i as f32 + 1.0) * 0.5;
        assert!((data[i] - expected).abs() < 1e-6, "index {i}");
    }
}

#[test]
fn test_simd_complex_mul_add_empty() {
    use rustfft::num_complex::Complex;
    let mut dst: Vec<Complex<f32>> = vec![];
    let src: Vec<Complex<f32>> = vec![];
    let hrtf: Vec<Complex<f32>> = vec![];
    complex_mul_add_simd(&mut dst, &src, &hrtf);
    assert!(dst.is_empty());
}

#[test]
fn test_simd_complex_mul_empty() {
    use rustfft::num_complex::Complex;
    let mut dst: Vec<Complex<f32>> = vec![];
    let src: Vec<Complex<f32>> = vec![];
    let hrtf: Vec<Complex<f32>> = vec![];
    complex_mul_simd(&mut dst, &src, &hrtf);
    assert!(dst.is_empty());
}

#[test]
fn test_simd_complex_mul_inplace_empty() {
    use rustfft::num_complex::Complex;
    let mut dst: Vec<Complex<f32>> = vec![];
    let hrtf: Vec<Complex<f32>> = vec![];
    complex_mul_inplace_simd(&mut dst, &hrtf);
    assert!(dst.is_empty());
}

#[test]
#[should_panic(expected = "src length must match dst length")]
fn test_complex_mul_add_simd_mismatched_src_len_panics() {
    use rustfft::num_complex::Complex;
    // src is shorter than dst: must panic instead of reading out of bounds
    // through raw SIMD pointers.
    let mut dst = vec![Complex::new(0.0, 0.0); 8];
    let src = vec![Complex::new(1.0, 0.0); 4];
    let hrtf = vec![Complex::new(1.0, 0.0); 8];
    complex_mul_add_simd(&mut dst, &src, &hrtf);
}

#[test]
#[should_panic(expected = "hrtf length must match dst length")]
fn test_complex_mul_add_simd_mismatched_hrtf_len_panics() {
    use rustfft::num_complex::Complex;
    let mut dst = vec![Complex::new(0.0, 0.0); 8];
    let src = vec![Complex::new(1.0, 0.0); 8];
    let hrtf = vec![Complex::new(1.0, 0.0); 4];
    complex_mul_add_simd(&mut dst, &src, &hrtf);
}

#[test]
#[should_panic(expected = "src length must match dst length")]
fn test_complex_mul_simd_mismatched_src_len_panics() {
    use rustfft::num_complex::Complex;
    let mut dst = vec![Complex::new(0.0, 0.0); 8];
    let src = vec![Complex::new(1.0, 0.0); 4];
    let hrtf = vec![Complex::new(1.0, 0.0); 8];
    complex_mul_simd(&mut dst, &src, &hrtf);
}

#[test]
#[should_panic(expected = "hrtf length must match dst length")]
fn test_complex_mul_simd_mismatched_hrtf_len_panics() {
    use rustfft::num_complex::Complex;
    let mut dst = vec![Complex::new(0.0, 0.0); 8];
    let src = vec![Complex::new(1.0, 0.0); 8];
    let hrtf = vec![Complex::new(1.0, 0.0); 4];
    complex_mul_simd(&mut dst, &src, &hrtf);
}

#[test]
#[should_panic(expected = "hrtf length must match dst length")]
fn test_complex_mul_inplace_simd_mismatched_hrtf_len_panics() {
    use rustfft::num_complex::Complex;
    let mut dst = vec![Complex::new(1.0, 0.0); 8];
    let hrtf = vec![Complex::new(1.0, 0.0); 4];
    complex_mul_inplace_simd(&mut dst, &hrtf);
}
