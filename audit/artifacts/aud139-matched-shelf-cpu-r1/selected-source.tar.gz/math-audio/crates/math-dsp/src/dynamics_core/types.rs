/// Whether the dynamics processor compresses (above threshold) or expands (below threshold).
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum DynamicsMode {
    Compress,
    Expand,
}

/// Gate state for expansion mode.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum GateState {
    Open,
    Hold,
    Closing,
}

/// Sidechain filter mode for the detection path.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum SidechainFilterMode {
    /// No sidechain filtering.
    Off,
    /// High-pass filter at the given frequency.
    /// `order_index`: 0 = 2nd order, 1 = 4th order.
    Hpf { freq_hz: f32, order_index: usize },
    /// Spectral tilt filter: positive = emphasize HF in detection, negative = emphasize LF.
    /// Implemented as a 1st-order high-shelf at 1 kHz with the given gain.
    Tilt { tilt_db: f32 },
}
