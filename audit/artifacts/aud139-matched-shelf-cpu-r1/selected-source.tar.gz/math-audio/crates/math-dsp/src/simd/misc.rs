use rustfft::num_complex::Complex;

#[cfg(all(target_arch = "aarch64", target_feature = "fcma"))]
#[inline(always)]
pub(super) unsafe fn fcmla_mul_acc(
    mut r: std::arch::aarch64::float32x4_t,
    a: std::arch::aarch64::float32x4_t,
    b: std::arch::aarch64::float32x4_t,
) -> std::arch::aarch64::float32x4_t {
    unsafe {
        std::arch::asm!(
            "fcmla {r:v}.4s, {a:v}.4s, {b:v}.4s, #0",
            "fcmla {r:v}.4s, {a:v}.4s, {b:v}.4s, #90",
            r = inout(vreg) r,
            a = in(vreg) a,
            b = in(vreg) b,
            options(pure, nomem, nostack),
        );
    }
    r
}

#[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
pub(super) const SHUFFLE_SWAP_RE_IM: i32 = 0b10110001; // Swaps: [re, im] -> [im, re]

/// SIMD-optimized linear interpolation (blend) between two buffers
///
/// Computes: `dst[i] = prev[i] + alpha * (dst[i] - prev[i])` for all `i`
/// Equivalent to: `dst[i] = (1 - alpha) * prev[i] + alpha * dst[i]`
///
/// Used for crossfading between old and new filter outputs in STFT plugins.
#[inline]
pub fn blend_simd(dst: &mut [f32], prev: &[f32], alpha: f32) {
    debug_assert_eq!(dst.len(), prev.len());
    let len = dst.len();

    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    {
        use std::arch::x86_64::*;

        let alpha_vec = unsafe { _mm256_set1_ps(alpha) };
        let simd_len = (len / 8) * 8;

        for i in (0..simd_len).step_by(8) {
            unsafe {
                let prev_ptr = prev.as_ptr().add(i);
                let dst_ptr = dst.as_mut_ptr().add(i);

                let p = _mm256_loadu_ps(prev_ptr);
                let d = _mm256_loadu_ps(dst_ptr);

                // prev + alpha * (dst - prev)
                let diff = _mm256_sub_ps(d, p);
                let result = _mm256_fmadd_ps(alpha_vec, diff, p);

                _mm256_storeu_ps(dst_ptr, result);
            }
        }

        for i in simd_len..len {
            dst[i] = prev[i] + alpha * (dst[i] - prev[i]);
        }
    }

    #[cfg(all(target_arch = "aarch64", target_feature = "neon"))]
    {
        use std::arch::aarch64::*;

        let alpha_vec = unsafe { vdupq_n_f32(alpha) };
        let simd_len = (len / 4) * 4;

        for i in (0..simd_len).step_by(4) {
            unsafe {
                let prev_ptr = prev.as_ptr().add(i);
                let dst_ptr = dst.as_mut_ptr().add(i);

                let p = vld1q_f32(prev_ptr);
                let d = vld1q_f32(dst_ptr);

                // prev + alpha * (dst - prev)
                let diff = vsubq_f32(d, p);
                let result = vfmaq_f32(p, alpha_vec, diff);

                vst1q_f32(dst_ptr, result);
            }
        }

        for i in simd_len..len {
            dst[i] = prev[i] + alpha * (dst[i] - prev[i]);
        }
    }

    #[cfg(not(any(
        all(target_arch = "x86_64", target_feature = "avx2"),
        all(target_arch = "aarch64", target_feature = "neon")
    )))]
    {
        for i in 0..len {
            dst[i] = prev[i] + alpha * (dst[i] - prev[i]);
        }
    }
}

/// Deinterleave stereo buffer into separate L/R channels
///
/// Input: [L0, R0, L1, R1, L2, R2, ...]
/// Output: left = [L0, L1, L2, ...], right = [R0, R1, R2, ...]
#[inline]
pub fn deinterleave_stereo(input: &[f32], left: &mut [f32], right: &mut [f32]) {
    debug_assert_eq!(input.len(), left.len() * 2);
    debug_assert_eq!(left.len(), right.len());

    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    {
        use std::arch::x86_64::*;

        let len = left.len();
        let simd_len = (len / 8) * 8;

        for i in (0..simd_len).step_by(8) {
            unsafe {
                // Load 16 floats (8 stereo pairs)
                let in_ptr = input.as_ptr().add(i * 2);
                let v0 = _mm256_loadu_ps(in_ptr); // L0 R0 L1 R1 L2 R2 L3 R3
                let v1 = _mm256_loadu_ps(in_ptr.add(8)); // L4 R4 L5 R5 L6 R6 L7 R7

                // Shuffle to separate L and R
                // Within 256-bit lanes, shuffle to group L/R
                let shuf_l = _mm256_shuffle_ps(v0, v1, 0b10_00_10_00); // L0 L1 L4 L5 | L2 L3 L6 L7
                let shuf_r = _mm256_shuffle_ps(v0, v1, 0b11_01_11_01); // R0 R1 R4 R5 | R2 R3 R6 R7

                // Permute to get correct order
                let left_vec = _mm256_permute4x64_pd(
                    std::mem::transmute::<__m256, __m256d>(shuf_l),
                    0b11_01_10_00,
                );
                let right_vec = _mm256_permute4x64_pd(
                    std::mem::transmute::<__m256, __m256d>(shuf_r),
                    0b11_01_10_00,
                );

                _mm256_storeu_ps(
                    left.as_mut_ptr().add(i),
                    std::mem::transmute::<__m256d, __m256>(left_vec),
                );
                _mm256_storeu_ps(
                    right.as_mut_ptr().add(i),
                    std::mem::transmute::<__m256d, __m256>(right_vec),
                );
            }
        }

        // Scalar remainder
        for i in simd_len..len {
            left[i] = input[i * 2];
            right[i] = input[i * 2 + 1];
        }
    }

    #[cfg(not(all(target_arch = "x86_64", target_feature = "avx2")))]
    {
        // Scalar fallback (compiler will auto-vectorize for NEON)
        for (i, chunk) in input.chunks_exact(2).enumerate() {
            left[i] = chunk[0];
            right[i] = chunk[1];
        }
    }
}

/// Interleave separate L/R channels into stereo buffer
///
/// Input: left = [L0, L1, L2, ...], right = [R0, R1, R2, ...]
/// Output: [L0, R0, L1, R1, L2, R2, ...]
#[inline]
#[allow(dead_code)]
pub fn interleave_stereo(left: &[f32], right: &[f32], output: &mut [f32]) {
    debug_assert_eq!(left.len(), right.len());
    debug_assert_eq!(output.len(), left.len() * 2);

    // Scalar version - compiler auto-vectorizes well
    for i in 0..left.len() {
        output[i * 2] = left[i];
        output[i * 2 + 1] = right[i];
    }
}

/// Enable FTZ (Flush To Zero) and DAZ (Denormals Are Zero) CPU flags.
///
/// When enabled, denormal floating-point numbers are automatically flushed to zero
/// by the CPU hardware. This prevents the severe performance degradation that occurs
/// when IIR filter state variables (like biquad y1/y2) contain denormals.
///
/// This function is idempotent and should be called once per audio processing thread.
/// On unsupported platforms, this is a no-op. The register change remains active
/// on the calling thread; use [`ScopedFtz`] when the effect must be limited to a
/// lexical scope.
///
/// Returns true if the flags were successfully set, false otherwise (e.g., unsupported platform).
#[inline]
pub fn enable_ftz_daz() -> bool {
    #[cfg(target_arch = "x86_64")]
    {
        // MXCSR register bits:
        // Bit 15: FTZ (Flush To Zero) - flush denormal results to zero
        // Bit 6: DAZ (Denormals Are Zero) - treat denormal inputs as zero
        unsafe {
            let mut mxcsr: u32 = 0;
            std::arch::asm!("stmxcsr [{}]", in(reg) &mut mxcsr, options(nostack, preserves_flags));
            mxcsr |= (1 << 15) | (1 << 6); // FTZ | DAZ
            std::arch::asm!("ldmxcsr [{}]", in(reg) &mxcsr, options(nostack, preserves_flags));
        }
        true
    }

    #[cfg(target_arch = "aarch64")]
    {
        // On AArch64, use the FPCR register
        // Bit 24: FZ (Flush-to-Zero)
        // Note: AArch64 always treats denormal inputs as zero in FZ mode
        unsafe {
            let mut fpcr: u64;
            std::arch::asm!("mrs {}, fpcr", out(reg) fpcr);
            fpcr |= 1 << 24; // FZ bit
            std::arch::asm!("msr fpcr, {}", in(reg) fpcr);
        }
        true
    }

    #[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
    {
        false
    }
}

/// SIMD-accelerated covariance calculation for ERB bands
///
/// Returns (cov_xx, cov_yy, cov_xy) where:
/// - cov_xx: sum of left channel energy
/// - cov_yy: sum of right channel energy
/// - cov_xy: complex cross-correlation
///
/// An empty range (`start == end`) returns zeros.
pub fn compute_covariance_simd(
    left: &[Complex<f32>],
    right: &[Complex<f32>],
    start: usize,
    end: usize,
) -> (f32, f32, Complex<f32>) {
    assert_eq!(left.len(), right.len());
    assert!(end <= left.len());
    assert!(start <= end);

    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    let count = end - start;

    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    {
        use std::arch::x86_64::*;

        let mut cov_xx;
        let mut cov_yy;
        let mut cov_xy = Complex::new(0.0, 0.0);

        // SIMD path: process 4 complex numbers at once
        let simd_len = (count / 4) * 4;
        let simd_end = start + simd_len;

        unsafe {
            let mut sum_xx = _mm256_setzero_ps();
            let mut sum_yy = _mm256_setzero_ps();
            let mut sum_xy_re = _mm256_setzero_ps();

            // Sign mask used to conjugate the right channel: flips the sign of
            // the imaginary (odd) lanes, leaves the real (even) lanes untouched.
            let conj_mask = _mm256_set_ps(-0.0, 0.0, -0.0, 0.0, -0.0, 0.0, -0.0, 0.0);

            for i in (start..simd_end).step_by(4) {
                let left_ptr = left.as_ptr().add(i) as *const f32;
                let right_ptr = right.as_ptr().add(i) as *const f32;

                // Load 4 complex numbers: [re0, im0, re1, im1, re2, im2, re3, im3]
                let l = _mm256_loadu_ps(left_ptr);
                let r = _mm256_loadu_ps(right_ptr);

                // Compute norm_sqr: re^2 + im^2
                let l_sqr = _mm256_mul_ps(l, l);
                let r_sqr = _mm256_mul_ps(r, r);

                // Horizontal add pairs: [re0^2 + im0^2, re1^2 + im1^2, ...]
                let l_norm = _mm256_hadd_ps(l_sqr, l_sqr);
                let r_norm = _mm256_hadd_ps(r_sqr, r_sqr);

                sum_xx = _mm256_add_ps(sum_xx, l_norm);
                sum_yy = _mm256_add_ps(sum_yy, r_norm);

                // Compute cross-correlation: left * conj(right)
                // (a + bi) * (c - di) = (ac + bd) + (bc - ad)i
                let l_re = _mm256_moveldup_ps(l);
                let l_im = _mm256_movehdup_ps(l);

                // Conjugate r by flipping the sign of its imaginary (odd)
                // lanes: r_conj = [c, -d, ...]
                let r_conj = _mm256_xor_ps(r, conj_mask);

                // ac_ad = [a*c, -a*d]
                let ac_ad = _mm256_mul_ps(l_re, r_conj);

                // r_conj_swap = [-d, c] so that im * swap gives [-b*d, b*c]
                let r_conj_swap = _mm256_shuffle_ps(r_conj, r_conj, SHUFFLE_SWAP_RE_IM);
                let bd_bc = _mm256_mul_ps(l_im, r_conj_swap);

                // addsub(ac_ad, bd_bc) -> [a*c - (-b*d), (-a*d) + b*c]
                //                      = [ac + bd, bc - ad] = [re, im]
                let result = _mm256_addsub_ps(ac_ad, bd_bc);

                // Accumulate real parts (even indices) and imaginary parts (odd indices)
                sum_xy_re = _mm256_add_ps(sum_xy_re, result);
            }

            // Horizontal reduction to scalars
            let xx_arr = std::mem::transmute::<__m256, [f32; 8]>(sum_xx);
            let yy_arr = std::mem::transmute::<__m256, [f32; 8]>(sum_yy);
            let xy_arr = std::mem::transmute::<__m256, [f32; 8]>(sum_xy_re);

            // Sum hadd results (each norm appears twice in each lane)
            // Lane 0: [norm0, norm1, norm0, norm1], Lane 1: [norm2, norm3, norm2, norm3]
            cov_xx = xx_arr[0] + xx_arr[1] + xx_arr[4] + xx_arr[5];
            cov_yy = yy_arr[0] + yy_arr[1] + yy_arr[4] + yy_arr[5];

            // Sum re (even) and im (odd) separately
            cov_xy.re = xy_arr[0] + xy_arr[2] + xy_arr[4] + xy_arr[6];
            cov_xy.im = xy_arr[1] + xy_arr[3] + xy_arr[5] + xy_arr[7];
        }

        // Scalar tail for remaining elements
        for i in simd_end..end {
            let l = left[i];
            let r = right[i];
            cov_xx += l.norm_sqr();
            cov_yy += r.norm_sqr();
            cov_xy += l * r.conj();
        }

        (cov_xx, cov_yy, cov_xy)
    }

    #[cfg(not(all(target_arch = "x86_64", target_feature = "avx2")))]
    {
        let mut cov_xx = 0.0_f32;
        let mut cov_yy = 0.0_f32;
        let mut cov_xy = Complex::new(0.0, 0.0);

        for i in start..end {
            let l = left[i];
            let r = right[i];
            cov_xx += l.norm_sqr();
            cov_yy += r.norm_sqr();
            cov_xy += l * r.conj();
        }

        (cov_xx, cov_yy, cov_xy)
    }
}

/// Inverse square root (`1 / sqrt(x)`).
///
/// Returns positive infinity for `x == 0` and NaN for negative inputs, matching
/// the corresponding IEEE-754 square-root and reciprocal operations. Modern
/// targets optimize this expression directly, without the Quake approximation's
/// input-domain surprises and ~0.1% relative error.
#[inline(always)]
pub fn fast_inv_sqrt(x: f32) -> f32 {
    x.sqrt().recip()
}

/// SIMD-optimized peak detection (maximum absolute value)
#[inline]
pub fn find_max_abs_simd(samples: &[f32]) -> f32 {
    let len = samples.len();
    if len == 0 {
        return 0.0;
    }

    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    {
        use std::arch::x86_64::*;
        let mut max_vec = unsafe { _mm256_setzero_ps() };
        let abs_mask = unsafe { _mm256_set1_ps(-0.0) };
        let simd_len = (len / 8) * 8;

        for i in (0..simd_len).step_by(8) {
            unsafe {
                let ptr = samples.as_ptr().add(i);
                let v = _mm256_loadu_ps(ptr);
                let av = _mm256_andnot_ps(abs_mask, v);
                max_vec = _mm256_max_ps(max_vec, av);
            }
        }

        let mut max_val = 0.0_f32;
        unsafe {
            let arr = std::mem::transmute::<__m256, [f32; 8]>(max_vec);
            for &v in &arr {
                if v > max_val {
                    max_val = v;
                }
            }
        }

        for sample in samples.iter().take(len).skip(simd_len) {
            let v = sample.abs();
            if v > max_val {
                max_val = v;
            }
        }
        max_val
    }

    #[cfg(all(target_arch = "aarch64", target_feature = "neon"))]
    {
        use std::arch::aarch64::*;
        let mut max_vec = unsafe { vdupq_n_f32(0.0) };
        let simd_len = (len / 4) * 4;

        for i in (0..simd_len).step_by(4) {
            unsafe {
                let ptr = samples.as_ptr().add(i);
                let v = vld1q_f32(ptr);
                let av = vabsq_f32(v);
                max_vec = vmaxq_f32(max_vec, av);
            }
        }

        let mut max_val = unsafe { vmaxvq_f32(max_vec) };

        for sample in &samples[simd_len..len] {
            let v = sample.abs();
            if v > max_val {
                max_val = v;
            }
        }
        max_val
    }

    #[cfg(not(any(
        all(target_arch = "x86_64", target_feature = "avx2"),
        all(target_arch = "aarch64", target_feature = "neon")
    )))]
    {
        let mut max_val = 0.0_f32;
        for &s in samples {
            let v = s.abs();
            if v > max_val {
                max_val = v;
            }
        }
        max_val
    }
}
