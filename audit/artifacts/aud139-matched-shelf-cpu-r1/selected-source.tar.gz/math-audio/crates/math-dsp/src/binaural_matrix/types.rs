use num_complex::Complex64;

/// Result of one frequency-bin regularized inverse solve.
#[derive(Debug, Clone, PartialEq)]
pub struct MatrixInverseBin {
    /// Row-major correction matrix with shape `num_speakers x num_ears`.
    pub values: Vec<Complex64>,
    /// Estimated condition number of the primary transfer matrix.
    pub condition_number: f64,
    /// Mean squared reconstruction error over all supplied positions.
    pub reconstruction_error: f64,
    /// Worst-position mean squared reconstruction error.
    pub worst_position_error: f64,
}
