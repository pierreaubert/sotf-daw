use super::biquad::Biquad;
use std::f64::consts::PI;

/// K-weighting: pre-filter (high shelf) + RLB high-pass.
/// Coefficients from ITU-R BS.1770-4, computed via bilinear transform.
#[derive(Clone)]
pub(super) struct KWeightFilter {
    pub(super) stage1: Biquad,
    pub(super) stage2: Biquad,
}

impl KWeightFilter {
    pub(super) fn new(sample_rate: u32) -> Self {
        let (s1, s2) = if sample_rate == 48000 {
            Self::coeffs_48k()
        } else {
            Self::compute_coeffs(sample_rate as f64)
        };
        Self {
            stage1: s1,
            stage2: s2,
        }
    }

    /// Hardcoded coefficients for 48 kHz (most common case).
    pub(super) fn coeffs_48k() -> (Biquad, Biquad) {
        // Stage 1: Pre-filter (high shelf)
        let s1 = Biquad {
            b0: 1.53512485958697,
            b1: -2.69169618940638,
            b2: 1.19839281085285,
            a1: -1.69065929318241,
            a2: 0.73248077421585,
            z1: 0.0,
            z2: 0.0,
        };
        // Stage 2: RLB high-pass
        let s2 = Biquad {
            b0: 1.0,
            b1: -2.0,
            b2: 1.0,
            a1: -1.99004745483398,
            a2: 0.99007225036621,
            z1: 0.0,
            z2: 0.0,
        };
        (s1, s2)
    }

    /// Compute coefficients for arbitrary sample rate via bilinear transform.
    pub(super) fn compute_coeffs(fs: f64) -> (Biquad, Biquad) {
        // Stage 1: High shelf from BS.1770-4 analog prototype
        // Analog: H(s) = Vh * (s^2 + (sqrt(Vh)/Q)*s + 1) / (s^2 + (1/(Q*sqrt(Vh)))*s + 1)
        // with fc=1681.974450955533, Q=0.7071752369554196, dB_gain=3.999843853973347
        let fc1 = 1681.974450955533;
        let q1 = 0.7071752369554196;
        let db1 = 3.999843853973347;
        let vh = 10.0_f64.powf(db1 / 20.0);
        let vb = vh.powf(0.4996667741545416);
        let k1 = (PI * fc1 / fs).tan();
        let k1sq = k1 * k1;
        let denom1 = 1.0 + k1 / q1 + k1sq;
        let s1 = Biquad {
            b0: (vh + vb * k1 / q1 + k1sq) / denom1,
            b1: 2.0 * (k1sq - vh) / denom1,
            b2: (vh - vb * k1 / q1 + k1sq) / denom1,
            a1: 2.0 * (k1sq - 1.0) / denom1,
            a2: (1.0 - k1 / q1 + k1sq) / denom1,
            z1: 0.0,
            z2: 0.0,
        };

        // Stage 2: RLB high-pass (2nd order Butterworth high-pass at 38.13547087602444 Hz)
        let fc2 = 38.13547087602444;
        let q2 = 0.5003270373238773;
        let k2 = (PI * fc2 / fs).tan();
        let k2sq = k2 * k2;
        let denom2 = 1.0 + k2 / q2 + k2sq;
        let s2 = Biquad {
            // Per BS.1770-4 / libebur128 the numerator stays unnormalised
            // [1, -2, 1]; only the denominator is divided by denom2. This
            // makes compute_coeffs(48000) reproduce coeffs_48k().
            b0: 1.0,
            b1: -2.0,
            b2: 1.0,
            a1: 2.0 * (k2sq - 1.0) / denom2,
            a2: (1.0 - k2 / q2 + k2sq) / denom2,
            z1: 0.0,
            z2: 0.0,
        };

        (s1, s2)
    }

    pub(super) fn process(&mut self, x: f64) -> f64 {
        let y1 = self.stage1.process(x);
        self.stage2.process(y1)
    }

    pub(super) fn reset(&mut self) {
        self.stage1.reset();
        self.stage2.reset();
    }
}
