use super::apply::apply_tukey_window;
use super::estimate::estimate_rt60_broadband;
use super::interpolate::interpolate_fr;
use super::interpolate::interpolate_log;
use super::misc::next_power_of_two;
use super::misc::unwrap_phase_deg;
use super::plan::plan_fft_forward;
use super::plan::plan_fft_inverse;
use super::plan::plan_real_fft_forward;
use super::smooth::smooth_response_f32;
use super::types::SpectrumResult;
use super::types::WindowType;
use super::types::WindowedFrequencyResponse;
use math_audio_iir_fir::{Biquad, BiquadFilterType};
use rustfft::num_complex::Complex;
use std::cell::RefCell;
use std::collections::HashMap;
use std::f32::consts::PI;
use std::sync::Arc;

/// Reusable per-size buffers for Welch spectrum estimation.
///
/// Kept in a thread-local cache so repeated calls with the same FFT size do
/// not reallocate the Hann window, FFT input/scratch buffers, or accumulation
/// arrays. The cache is keyed by `fft_size`.
pub(super) struct WelchBuffers {
    pub(super) hann_window: Vec<f32>,
    pub(super) scaled_window: Vec<f32>,
    pub(super) real_buffer: Vec<f32>,
    pub(super) spectrum: Vec<Complex<f32>>,
    pub(super) real_scratch: Vec<Complex<f32>>,
    pub(super) magnitude_sum: Vec<f32>,
    pub(super) phase_real_sum: Vec<f32>,
    pub(super) phase_imag_sum: Vec<f32>,
    pub(super) freqs: Vec<f32>,
    pub(super) magnitudes_db: Vec<f32>,
    pub(super) phases_deg: Vec<f32>,
}

impl WelchBuffers {
    fn new(fft_size: usize) -> Self {
        let num_bins = fft_size / 2;
        let hann_window = crate::stft::generate_hann_window_symmetric(fft_size);
        let coherent_sum: f32 = hann_window.iter().sum();
        let scale_rest = 2.0 / coherent_sum;
        let scaled_window: Vec<f32> = hann_window.iter().map(|w| w * scale_rest).collect();
        Self {
            hann_window,
            scaled_window,
            real_buffer: vec![0.0_f32; fft_size],
            spectrum: vec![Complex::new(0.0, 0.0); fft_size / 2 + 1],
            real_scratch: Vec::new(),
            magnitude_sum: vec![0.0_f32; num_bins],
            phase_real_sum: vec![0.0_f32; num_bins],
            phase_imag_sum: vec![0.0_f32; num_bins],
            freqs: vec![0.0_f32; num_bins],
            magnitudes_db: vec![0.0_f32; num_bins],
            phases_deg: vec![0.0_f32; num_bins],
        }
    }

    /// Make sure the real-to-complex FFT scratch buffer is large enough.
    fn ensure_scratch(&mut self, fft: &Arc<dyn realfft::RealToComplex<f32>>) {
        let required = fft.get_scratch_len();
        if self.real_scratch.len() < required {
            self.real_scratch.resize(required, Complex::new(0.0, 0.0));
        }
    }
}

thread_local! {
    static WELCH_BUFFER_CACHE: RefCell<HashMap<usize, WelchBuffers>> =
        RefCell::new(HashMap::new());
}

/// Borrow (creating if necessary) a `WelchBuffers` entry for `fft_size` and
/// size its scratch buffer for the real-to-complex `fft`, then run `f` with
/// mutable access.
pub(super) fn with_welch_buffers<F, R>(
    fft_size: usize,
    fft: &Arc<dyn realfft::RealToComplex<f32>>,
    f: F,
) -> R
where
    F: FnOnce(&mut WelchBuffers) -> R,
{
    WELCH_BUFFER_CACHE.with(|cache| {
        let mut cache = cache.borrow_mut();
        let buffers = cache
            .entry(fft_size)
            .or_insert_with(|| WelchBuffers::new(fft_size));
        buffers.ensure_scratch(fft);
        f(buffers)
    })
}

/// Compute a peak-amplitude-calibrated spectrum using Welch RMS averaging.
///
/// This is an amplitude spectrum, not a power spectral density: each frame is
/// corrected for the Hann coherent gain before squared magnitudes are averaged.
///
/// This entry point reuses thread-local buffers for the window, FFT input and
/// scratch, and accumulation/output arrays. It still allocates the three
/// returned vectors so that the public call sites receive owned data.
#[allow(dead_code)]
pub(super) fn compute_welch_spectrum_internal(
    signal: &[f32],
    sample_rate: u32,
    fft_size: usize,
    overlap: f32,
) -> SpectrumResult {
    if signal.is_empty() {
        return Err("Signal is empty".to_string());
    }
    let fft = plan_real_fft_forward(fft_size);
    let num_bins = fft_size / 2;
    with_welch_buffers(fft_size, &fft, |bufs| {
        compute_welch_spectrum_into(
            signal,
            sample_rate,
            fft_size,
            overlap,
            &bufs.hann_window,
            &bufs.scaled_window,
            &fft,
            &mut bufs.real_buffer,
            &mut bufs.spectrum,
            &mut bufs.real_scratch,
            &mut bufs.magnitude_sum,
            &mut bufs.phase_real_sum,
            &mut bufs.phase_imag_sum,
            &mut bufs.freqs,
            &mut bufs.magnitudes_db,
            &mut bufs.phases_deg,
        )?;
        Ok((
            bufs.freqs[..num_bins].to_vec(),
            bufs.magnitudes_db[..num_bins].to_vec(),
            bufs.phases_deg[..num_bins].to_vec(),
        ))
    })
}

/// Low-level Welch spectrum computation that writes directly into caller-owned
/// output slices, avoiding intermediate allocations.
///
/// All working slices are zeroed/reused as needed; their previous contents are
/// overwritten. Output slices must be at least `fft_size / 2` long.
#[allow(clippy::too_many_arguments)]
pub(super) fn compute_welch_spectrum_into(
    signal: &[f32],
    sample_rate: u32,
    fft_size: usize,
    overlap: f32,
    hann_window: &[f32],
    scaled_window: &[f32],
    fft: &Arc<dyn realfft::RealToComplex<f32>>,
    real_buffer: &mut [f32],
    spectrum: &mut [Complex<f32>],
    scratch: &mut [Complex<f32>],
    magnitude_sum: &mut [f32],
    phase_real_sum: &mut [f32],
    phase_imag_sum: &mut [f32],
    freqs_out: &mut [f32],
    mags_db_out: &mut [f32],
    phases_deg_out: &mut [f32],
) -> Result<(), String> {
    if signal.is_empty() {
        return Err("Signal is empty".to_string());
    }

    let overlap_samples = (fft_size as f32 * overlap.clamp(0.0, 0.95)) as usize;
    let hop_size = fft_size - overlap_samples;
    let num_windows = 1 + signal.len().saturating_sub(1) / hop_size;
    let num_bins = fft_size / 2;

    magnitude_sum[..num_bins].fill(0.0);
    phase_real_sum[..num_bins].fill(0.0);
    phase_imag_sum[..num_bins].fill(0.0);

    let full_coherent_sum: f32 = hann_window.iter().sum();
    if full_coherent_sum <= 1e-10 {
        return Err("Window has zero coherent gain".to_string());
    }

    let mut processed_windows = 0_usize;

    for window_idx in 0..num_windows {
        let start = window_idx * hop_size;
        let end = (start + fft_size).min(signal.len());
        let window_len = end - start;

        // Skip a trailing frame whose samples were all covered by the
        // previous frame (e.g. len == fft_size with 50% overlap): it adds
        // no new data and would only dilute the average.
        if window_idx > 0 && start - hop_size + fft_size >= signal.len() {
            continue;
        }

        if window_len == fft_size {
            // Fast path: window and scale the signal directly into the real FFT buffer.
            // The coherent-gain scaling is fused into the window so the per-bin
            // post-FFT scaling can be removed.
            for i in 0..fft_size {
                real_buffer[i] = signal[start + i] * scaled_window[i];
            }

            fft.process_with_scratch(real_buffer, spectrum, scratch)
                .map_err(|e| format!("Real FFT failed: {:?}", e))?;

            // Accumulate squared magnitude directly via norm_sqr() to avoid the
            // per-bin sqrt() that `norm()` performs inside the window loop.
            for i in 0..num_bins {
                magnitude_sum[i] += spectrum[i].norm_sqr();
                phase_real_sum[i] += spectrum[i].re;
                phase_imag_sum[i] += spectrum[i].im;
            }
        } else {
            // Final partial window: only the overlapping region contributes.
            let coherent_sum: f32 = hann_window[..window_len].iter().sum();
            if coherent_sum <= 1e-10 {
                continue;
            }
            let scale_rest = 2.0 / coherent_sum;
            for i in 0..window_len {
                real_buffer[i] = signal[start + i] * hann_window[i] * scale_rest;
            }
            real_buffer[window_len..fft_size].fill(0.0);

            fft.process_with_scratch(real_buffer, spectrum, scratch)
                .map_err(|e| format!("Real FFT failed: {:?}", e))?;

            // Accumulate squared magnitude directly via norm_sqr().
            for i in 0..num_bins {
                magnitude_sum[i] += spectrum[i].norm_sqr();
                phase_real_sum[i] += spectrum[i].re;
                phase_imag_sum[i] += spectrum[i].im;
            }
        }
        processed_windows += 1;
    }

    let processed_windows = processed_windows.max(1);

    for i in 0..num_bins {
        // The 2x one-sided folding is fused into `scaled_window` (and the
        // partial-window scale factor) for every bin, but DC has no negative
        // frequency image to fold in — divide its accumulated power by 4
        // (2x in amplitude) to match the single-FFT path's 1/coherent_sum.
        let mag_sq = if i == 0 {
            magnitude_sum[i] * 0.25
        } else {
            magnitude_sum[i]
        };
        let mag = (mag_sq / processed_windows as f32).sqrt();
        mags_db_out[i] = if mag > 1e-10 {
            20.0 * mag.log10()
        } else {
            -200.0
        };

        let re = phase_real_sum[i] / processed_windows as f32;
        let im = phase_imag_sum[i] / processed_windows as f32;
        // A phase angle is only meaningful when the windows agree. Compare
        // the mean phasor magnitude with the RMS magnitude; cancellation from
        // an unaligned/non-stationary signal otherwise produces an arbitrary
        // angle that looks deceptively precise.
        let phase_coherence = (re * re + im * im).sqrt() / mag.max(1e-10);
        phases_deg_out[i] = if phase_coherence >= 0.1 {
            im.atan2(re) * 180.0 / PI
        } else {
            0.0
        };

        freqs_out[i] = i as f32 * sample_rate as f32 / fft_size as f32;
    }

    Ok(())
}

/// Compute a peak-amplitude-calibrated Welch spectrum with caller-provided buffers.
#[allow(clippy::too_many_arguments)]
pub(super) fn compute_welch_spectrum_with_buffers(
    signal: &[f32],
    sample_rate: u32,
    fft_size: usize,
    overlap: f32,
    hann_window: &[f32],
    scaled_window: &[f32],
    fft: &Arc<dyn realfft::RealToComplex<f32>>,
    real_buffer: &mut [f32],
    spectrum: &mut [Complex<f32>],
    scratch: &mut [Complex<f32>],
    magnitude_sum: &mut [f32],
    phase_real_sum: &mut [f32],
    phase_imag_sum: &mut [f32],
) -> SpectrumResult {
    if signal.is_empty() {
        return Err("Signal is empty".to_string());
    }

    let num_bins = fft_size / 2;
    let mut freqs = vec![0.0_f32; num_bins];
    let mut magnitudes_db = vec![0.0_f32; num_bins];
    let mut phases_deg = vec![0.0_f32; num_bins];

    compute_welch_spectrum_into(
        signal,
        sample_rate,
        fft_size,
        overlap,
        hann_window,
        scaled_window,
        fft,
        real_buffer,
        spectrum,
        scratch,
        magnitude_sum,
        phase_real_sum,
        phase_imag_sum,
        &mut freqs,
        &mut magnitudes_db,
        &mut phases_deg,
    )?;

    Ok((freqs, magnitudes_db, phases_deg))
}

/// Compute a peak-amplitude-calibrated spectrum using a single FFT.
pub(super) fn compute_single_fft_spectrum_internal(
    signal: &[f32],
    sample_rate: u32,
    fft_size: usize,
    no_window: bool,
) -> SpectrumResult {
    if signal.is_empty() {
        return Err("Signal is empty".to_string());
    }

    let mut windowed = vec![0.0_f32; fft_size];
    let copy_len = signal.len().min(fft_size);
    windowed[..copy_len].copy_from_slice(&signal[..copy_len]);

    let coherent_sum = if no_window {
        copy_len as f32
    } else {
        let hann_window = crate::stft::generate_hann_window_symmetric(fft_size);

        for (i, sample) in windowed.iter_mut().enumerate() {
            *sample *= hann_window[i];
        }

        hann_window[..copy_len].iter().sum::<f32>()
    };

    if coherent_sum <= 1e-10 {
        return Err("Window has zero coherent gain".to_string());
    }

    let mut buffer: Vec<Complex<f32>> = windowed.iter().map(|&x| Complex::new(x, 0.0)).collect();

    let fft = plan_fft_forward(fft_size);
    fft.process(&mut buffer);

    let num_bins = fft_size / 2;
    let magnitudes_db: Vec<f32> = buffer[..num_bins]
        .iter()
        .enumerate()
        .map(|(i, c)| {
            let one_sided_scale = if i == 0 {
                1.0 / coherent_sum
            } else {
                2.0 / coherent_sum
            };
            let mag = c.norm() * one_sided_scale;
            if mag > 1e-10 {
                20.0 * mag.log10()
            } else {
                -200.0
            }
        })
        .collect();

    let phases_deg: Vec<f32> = buffer[..num_bins]
        .iter()
        .map(|c| c.arg() * 180.0 / PI)
        .collect();

    let freqs: Vec<f32> = (0..num_bins)
        .map(|i| i as f32 * sample_rate as f32 / fft_size as f32)
        .collect();

    Ok((freqs, magnitudes_db, phases_deg))
}

/// Compute Total Harmonic Distortion (THD) from Impulse Response
///
/// Uses Farina's method to extract harmonics from the impulse response of a log sweep.
///
/// Per-frequency mapping convention: `harmonics_db[k][i]` is the magnitude of
/// the (k+2)-th harmonic's transfer function evaluated at `frequencies[i]`
/// itself — i.e. `|H_k(f)|`, not `|H_k(k·f)|` — and `thd_percent[i]` is
/// `sqrt(Σ_k |H_k(f)|²) / |H_1(f)|` with every term taken at the same
/// frequency `f = frequencies[i]`.
pub(super) fn compute_thd_from_ir(
    impulse: &[f32],
    sample_rate: f32,
    frequencies: &[f32],
    fundamental_db: &[f32],
    start_freq: f32,
    end_freq: f32,
    duration: f32,
) -> (Vec<f32>, Vec<Vec<f32>>) {
    if frequencies.is_empty() {
        return (Vec::new(), Vec::new());
    }

    let n = impulse.len();
    if n == 0 {
        return (vec![0.0; frequencies.len()], Vec::new());
    }

    if !sample_rate.is_finite()
        || sample_rate <= 0.0
        || !start_freq.is_finite()
        || !end_freq.is_finite()
        || start_freq <= 0.0
        || end_freq <= start_freq
        || !duration.is_finite()
        || duration <= 0.0
        || fundamental_db.len() != frequencies.len()
    {
        return (
            vec![0.0; frequencies.len()],
            vec![vec![-120.0; frequencies.len()]; 4],
        );
    }

    let num_harmonics = 4; // Compute 2nd, 3rd, 4th, 5th
    // Initialize to -120 dB (very low but not absurdly so)
    let mut harmonics_db = vec![vec![-120.0; frequencies.len()]; num_harmonics];

    // Find main peak index (t=0)
    let peak_idx = impulse
        .iter()
        .enumerate()
        .max_by(|(_, a), (_, b)| a.abs().total_cmp(&b.abs()))
        .map(|(i, _)| i)
        .unwrap_or(0);

    let sweep_ratio = end_freq / start_freq;
    log::debug!(
        "[THD] Impulse len={}, peak_idx={}, duration={:.3}s, sweep {:.0}-{:.0} Hz (ratio {:.1})",
        n,
        peak_idx,
        duration,
        start_freq,
        end_freq,
        sweep_ratio
    );

    // Compute harmonics
    for (k_idx, harmonic_db) in harmonics_db.iter_mut().enumerate().take(num_harmonics) {
        let harmonic_order = k_idx + 2; // 2nd harmonic is k=2

        // Calculate delay for this harmonic
        // dt = T * ln(k) / ln(f2/f1)
        let dt = duration * (harmonic_order as f32).ln() / sweep_ratio.ln();
        let dn = (dt * sample_rate).round() as isize;

        // Center of harmonic impulse (negative time wraps to end of array)
        let center = peak_idx as isize - dn;
        let center_wrapped = center.rem_euclid(n as isize) as usize;

        // Window size logic: distance to next harmonic * 0.8 to avoid overlap.
        // Issue #6: the old hardcoded floor of 256 samples did not scale with
        // sample rate or fundamental frequency.  We now use at least 3 periods
        // of the lowest harmonic (start of sweep), capped at 16 samples minimum.
        let dt_next_rel = duration
            * ((harmonic_order as f32 + 1.0).ln() - (harmonic_order as f32).ln())
            / sweep_ratio.ln();
        let min_win_len = (3.0 * sample_rate / (harmonic_order as f32 * start_freq)).max(16.0);
        let win_len = ((dt_next_rel * sample_rate * 0.8).max(min_win_len) as usize).min(n / 2);

        // Extract windowed harmonic IR
        let mut harmonic_ir = vec![0.0f32; win_len];
        let mut max_harmonic_sample = 0.0f32;
        let mut weighted_window_sum = 0.0f32;
        let mut sample_abs_sum = 0.0f32;
        for (i, harmonic_ir_val) in harmonic_ir.iter_mut().enumerate() {
            let src_idx =
                (center - (win_len as isize / 2) + i as isize).rem_euclid(n as isize) as usize;
            // Apply Hann window
            let w = 0.5 * (1.0 - (2.0 * PI * i as f32 / (win_len as f32 - 1.0)).cos());
            let u = impulse[src_idx];
            *harmonic_ir_val = u * w;
            max_harmonic_sample = max_harmonic_sample.max(harmonic_ir_val.abs());
            weighted_window_sum += u.abs() * w;
            sample_abs_sum += u.abs();
        }

        // Amplitude-weighted coherent gain of the Hann window over the actual
        // harmonic content: ~1.0 for a compact impulse near the window centre
        // (where the window is ~1), ~0.5 for content spread across the whole
        // window. Compensating by its inverse recovers the unwindowed
        // transfer-function magnitude instead of reading up to ~6 dB low for
        // spread harmonic IRs.
        let window_gain = if sample_abs_sum > 1e-12 {
            weighted_window_sum / sample_abs_sum
        } else {
            1.0
        };

        if k_idx == 0 {
            log::debug!(
                "[THD] H{}: dt={:.3}s, dn={}, center_wrapped={}, win_len={}, max_sample={:.2e}",
                harmonic_order,
                dt,
                dn,
                center_wrapped,
                win_len,
                max_harmonic_sample
            );
        }

        // Compute spectrum
        let fft_size = next_power_of_two(win_len);
        let nyquist_bin = fft_size / 2; // Only use positive frequency bins
        if let Ok(spectrum) = compute_fft_padded(&harmonic_ir, fft_size) {
            let freq_resolution = sample_rate / fft_size as f32;

            for (i, &f) in frequencies.iter().enumerate() {
                let bin = (f / freq_resolution).round() as usize;
                // Only access positive frequency bins (0 to nyquist)
                if bin < nyquist_bin && bin < spectrum.len() {
                    // `harmonic_ir` is an impulse response, so its DFT is a
                    // transfer function. Undo compute_fft_padded's signal-level
                    // 1/N convention: unlike the fundamental's recorded/reference
                    // ratio, there is no second spectrum here for that factor to
                    // cancel against. Also undo the window's effective coherent
                    // gain so spread harmonic content is not underreported.
                    let mag = spectrum[bin].norm() * fft_size as f32 / window_gain;
                    // Convert to dB (threshold at -120 dB to avoid log of tiny values)
                    if mag > 1e-6 {
                        harmonic_db[i] = 20.0 * mag.log10();
                    }
                }
            }
        }
    }

    // Log a summary of detected harmonic levels
    if !frequencies.is_empty() {
        let mid_idx = frequencies.len() / 2;
        log::debug!(
            "[THD] Harmonic levels at {:.0} Hz: H2={:.1}dB, H3={:.1}dB, H4={:.1}dB, H5={:.1}dB, fundamental={:.1}dB",
            frequencies[mid_idx],
            harmonics_db[0][mid_idx],
            harmonics_db[1][mid_idx],
            harmonics_db[2][mid_idx],
            harmonics_db[3][mid_idx],
            fundamental_db[mid_idx]
        );
    }

    // Compute THD %
    let mut thd_percent = Vec::with_capacity(frequencies.len());
    for i in 0..frequencies.len() {
        let fundamental = 10.0f32.powf(fundamental_db[i] / 20.0);
        let mut harmonic_sum_sq = 0.0;

        for harmonic_db in harmonics_db.iter().take(num_harmonics) {
            let h_mag = 10.0f32.powf(harmonic_db[i] / 20.0);
            harmonic_sum_sq += h_mag * h_mag;
        }

        // THD = sqrt(sum(harmonics^2)) / fundamental
        let thd = if fundamental > 1e-9 {
            (harmonic_sum_sq.sqrt() / fundamental) * 100.0
        } else {
            0.0
        };
        thd_percent.push(thd);
    }

    // Log THD summary
    if !thd_percent.is_empty() {
        let max_thd = thd_percent.iter().fold(0.0f32, |a, &b| a.max(b));
        let min_thd = thd_percent.iter().fold(f32::INFINITY, |a, &b| a.min(b));
        log::debug!("[THD] THD range: {:.4}% to {:.4}%", min_thd, max_thd);
    }

    (thd_percent, harmonics_db)
}

/// Compute frequency responses for different time windows of the impulse response.
///
/// Uses SSIR segmentation boundaries to separate:
/// - Direct sound: \[0, first_reflection_onset)
/// - Early reflections: \[first_reflection_onset, mixing_time)
/// - Late reverb: \[mixing_time, end)
///
/// Each window gets a half-Hann fade at edges to avoid spectral leakage,
/// then FFT -> magnitude -> 1/24 octave smoothing.
pub fn compute_windowed_fr(
    impulse_response: &[f32],
    direct_end_sample: usize,
    early_end_sample: usize,
    sample_rate: u32,
    num_output_points: usize,
) -> Result<WindowedFrequencyResponse, String> {
    if impulse_response.is_empty() {
        return Err("Impulse response must be non-empty".to_string());
    }
    if num_output_points == 0 {
        return Err("num_output_points must be > 0".to_string());
    }

    let ir_len = impulse_response.len();
    let direct_end = direct_end_sample.min(ir_len);
    let early_end = early_end_sample.max(direct_end).min(ir_len);

    let direct_end_ms = direct_end as f64 / sample_rate as f64 * 1000.0;
    let early_end_ms = early_end as f64 / sample_rate as f64 * 1000.0;

    // Fade length: 1ms or half the window, whichever is smaller
    let fade_1ms = (sample_rate as usize) / 1000;

    let window_to_fr = |start: usize, end: usize| -> (Vec<f32>, Vec<f32>) {
        let win_len = end.saturating_sub(start);
        if win_len == 0 {
            // Return silence at the output frequencies
            let log_start = 20.0_f32.ln();
            let log_end = 20000.0_f32.ln();
            let freqs: Vec<f32> = (0..num_output_points)
                .map(|i| {
                    (log_start
                        + (log_end - log_start) * i as f32 / (num_output_points.max(2) - 1) as f32)
                        .exp()
                })
                .collect();
            let spl = vec![-200.0_f32; num_output_points];
            return (freqs, spl);
        }

        if win_len < 4 {
            // A 1-3 sample window has no usable frequency resolution (the FFT
            // has too few bins for the log-frequency mapping below). Report a
            // flat spectrum at the window's RMS level: for a single sample
            // this is exact, since the DFT of [x] is a constant |x|.
            let rms = (impulse_response[start..end]
                .iter()
                .map(|s| s * s)
                .sum::<f32>()
                / win_len as f32)
                .sqrt();
            let db = if rms > 1e-20 {
                20.0 * rms.log10()
            } else {
                -200.0
            };
            let log_start = 20.0_f32.ln();
            let log_end = 20000.0_f32.ln();
            let freqs: Vec<f32> = (0..num_output_points)
                .map(|i| {
                    (log_start
                        + (log_end - log_start) * i as f32 / (num_output_points.max(2) - 1) as f32)
                        .exp()
                })
                .collect();
            return (freqs, vec![db; num_output_points]);
        }

        // Extract and fade the window edges to reduce spectral leakage.
        // Skip fade-in at the physical start of the IR (start==0) to avoid
        // attenuating the direct sound impulse.
        let mut window: Vec<f32> = impulse_response[start..end].to_vec();
        let fade_len = fade_1ms.min(win_len / 2).max(1);
        if start > 0 {
            crate::signals::apply_fade_in(&mut window, fade_len);
        }
        crate::signals::apply_fade_out(&mut window, fade_len);

        // Zero-pad to next power of 2
        let fft_size = next_power_of_two(win_len);
        let fft_forward = plan_fft_forward(fft_size);

        let mut buf: Vec<Complex<f32>> = vec![Complex::new(0.0, 0.0); fft_size];
        for (dst, &src) in buf.iter_mut().zip(window.iter()) {
            dst.re = src;
        }
        fft_forward.process(&mut buf);

        // Normalize by FFT size
        let norm = 1.0 / fft_size as f32;

        // Generate log-spaced output frequencies and compute magnitude in dB
        let log_start = 20.0_f32.ln();
        let log_end = 20000.0_f32.ln();
        let freq_resolution = sample_rate as f32 / fft_size as f32;
        let num_bins = fft_size / 2;

        let mut freqs = Vec::with_capacity(num_output_points);
        let mut raw_db = Vec::with_capacity(num_output_points);

        for i in 0..num_output_points {
            let target_freq = (log_start
                + (log_end - log_start) * i as f32 / (num_output_points.max(2) - 1) as f32)
                .exp();
            freqs.push(target_freq);

            // Map to nearest FFT bin
            let bin = ((target_freq / freq_resolution).round() as usize).clamp(1, num_bins - 1);
            let mag = buf[bin].norm() * norm;
            let db = if mag > 1e-20 {
                20.0 * mag.log10()
            } else {
                -200.0
            };
            raw_db.push(db);
        }

        // Apply 1/24 octave smoothing
        let smoothed = smooth_response_f32(&freqs, &raw_db, 1.0 / 24.0);
        (freqs, smoothed)
    };

    let (direct_sound_freq, direct_sound_spl) = window_to_fr(0, direct_end);
    let (early_reflections_freq, early_reflections_spl) = window_to_fr(direct_end, early_end);
    let (late_reverb_freq, late_reverb_spl) = window_to_fr(early_end, ir_len);

    Ok(WindowedFrequencyResponse {
        direct_sound_freq,
        direct_sound_spl,
        early_reflections_freq,
        early_reflections_spl,
        late_reverb_freq,
        late_reverb_spl,
        direct_end_ms,
        early_end_ms,
    })
}

/// Compute FFT of a signal with specified windowing
///
/// # Arguments
/// * `signal` - Input signal
/// * `fft_size` - FFT size (should be power of 2)
/// * `window_type` - Type of window to apply
///
/// # Returns
/// Complex FFT spectrum
pub(super) fn compute_fft(
    signal: &[f32],
    fft_size: usize,
    window_type: WindowType,
) -> Result<Vec<Complex<f32>>, String> {
    // Apply window
    let windowed = match window_type {
        WindowType::Tukey(alpha) => apply_tukey_window(signal, alpha),
    };

    compute_fft_padded(&windowed, fft_size)
}

/// Compute FFT with zero-padding
pub(super) fn compute_fft_padded(
    signal: &[f32],
    fft_size: usize,
) -> Result<Vec<Complex<f32>>, String> {
    // Single allocation at final size; trailing elements are already zero-padded
    let mut buffer = vec![Complex::new(0.0, 0.0); fft_size];
    for (dst, &src) in buffer.iter_mut().zip(signal.iter()) {
        dst.re = src;
    }

    // Compute FFT
    let fft = plan_fft_forward(fft_size);
    fft.process(&mut buffer);

    // Normalize by FFT size (standard FFT normalization)
    let norm_factor = 1.0 / fft_size as f32;
    for val in buffer.iter_mut() {
        *val *= norm_factor;
    }

    Ok(buffer)
}

/// Compute group delay from phase data
/// Group delay = -d(phase)/d(frequency) / (2*pi)
///
/// Phase is unwrapped before differentiation to avoid spurious spikes
/// at ±180° wrap boundaries.
pub fn compute_group_delay(frequencies: &[f32], phase_deg: &[f32]) -> Vec<f32> {
    if frequencies.len() < 2
        || frequencies.len() != phase_deg.len()
        || frequencies
            .iter()
            .chain(phase_deg)
            .any(|value| !value.is_finite())
        || frequencies.windows(2).any(|window| window[1] <= window[0])
    {
        return vec![0.0; frequencies.len()];
    }

    // Unwrap phase to remove ±180° discontinuities before differentiation
    let unwrapped = unwrap_phase_deg(phase_deg);

    let mut group_delay_ms = Vec::with_capacity(frequencies.len());

    for i in 0..frequencies.len() {
        let delay = if i == 0 {
            // Forward difference at start
            let df = frequencies[1] - frequencies[0];
            let dp = unwrapped[1] - unwrapped[0];
            if df.abs() > 1e-6 {
                -dp / df / 360.0 * 1000.0 // Convert to ms
            } else {
                0.0
            }
        } else if i == frequencies.len() - 1 {
            // Backward difference at end
            let df = frequencies[i] - frequencies[i - 1];
            let dp = unwrapped[i] - unwrapped[i - 1];
            if df.abs() > 1e-6 {
                -dp / df / 360.0 * 1000.0
            } else {
                0.0
            }
        } else {
            // Central difference
            let df = frequencies[i + 1] - frequencies[i - 1];
            let dp = unwrapped[i + 1] - unwrapped[i - 1];
            if df.abs() > 1e-6 {
                -dp / df / 360.0 * 1000.0
            } else {
                0.0
            }
        };
        group_delay_ms.push(delay);
    }

    group_delay_ms
}

/// Compute impulse response from frequency response via inverse FFT.
///
/// The input frequency/magnitude/phase data (possibly irregularly spaced) is
/// interpolated onto a uniform FFT frequency grid, assembled into a complex
/// spectrum with Hermitian symmetry, and transformed with an inverse FFT.
///
/// Returns (times_ms, impulse) where impulse is peak-normalized to [-1, 1].
pub fn compute_impulse_response_from_fr(
    frequencies: &[f32],
    magnitude_db: &[f32],
    phase_deg: &[f32],
    sample_rate: f32,
) -> (Vec<f32>, Vec<f32>) {
    // A response grid with M positive-frequency samples can carry roughly
    // 2*(M-1) time-domain samples. Preserve at least the legacy 1024-sample
    // resolution while allowing denser input grids to request a longer IR.
    let fft_size = frequencies
        .len()
        .saturating_sub(1)
        .saturating_mul(2)
        .next_power_of_two()
        .max(1024);
    let half = fft_size / 2; // Number of positive-frequency bins (excluding DC)
    let freq_bin = sample_rate / fft_size as f32;

    // Unwrap phase before interpolation to avoid discontinuities
    let unwrapped_phase = unwrap_phase_deg(phase_deg);

    // Build complex spectrum on uniform FFT grid via linear interpolation
    let mut spectrum = vec![Complex::new(0.0_f32, 0.0); fft_size];

    for (k, spectrum_bin) in spectrum.iter_mut().enumerate().take(half + 1) {
        let f = k as f32 * freq_bin;

        // Interpolate magnitude (dB) and phase (deg) at this bin frequency
        let (mag_db, phase_d) = interpolate_fr(frequencies, magnitude_db, &unwrapped_phase, f);

        let mag_linear = 10.0_f32.powf(mag_db / 20.0);
        let phase_rad = phase_d * PI / 180.0;

        *spectrum_bin = Complex::new(mag_linear * phase_rad.cos(), mag_linear * phase_rad.sin());
    }

    // Enforce Hermitian symmetry: X[N-k] = conj(X[k])
    for k in 1..half {
        spectrum[fft_size - k] = spectrum[k].conj();
    }

    // Inverse FFT (uses thread-local cached planner)
    let ifft = plan_fft_inverse(fft_size);
    ifft.process(&mut spectrum);

    // Extract real part and scale by 1/N (rustfft doesn't normalize)
    let scale = 1.0 / fft_size as f32;
    let mut impulse: Vec<f32> = spectrum.iter().map(|c| c.re * scale).collect();

    // Normalize to [-1, 1]
    let max_val = impulse.iter().map(|v| v.abs()).fold(0.0_f32, f32::max);
    if max_val > 0.0 {
        for v in &mut impulse {
            *v /= max_val;
        }
    }

    let time_step = 1.0 / sample_rate;
    let times: Vec<f32> = (0..fft_size)
        .map(|i| i as f32 * time_step * 1000.0)
        .collect();

    (times, impulse)
}

/// Compute Schroeder energy decay curve
pub(super) fn compute_schroeder_decay(impulse: &[f32]) -> Vec<f32> {
    let mut energy = 0.0;
    let mut decay = vec![0.0; impulse.len()];

    // Backward integration
    for i in (0..impulse.len()).rev() {
        energy += impulse[i] * impulse[i];
        decay[i] = energy;
    }

    // Normalize to 0dB max (1.0 linear)
    let max_energy = decay.first().copied().unwrap_or(1.0);
    if max_energy > 0.0 {
        for v in &mut decay {
            *v /= max_energy;
        }
    }

    decay
}

/// Compute RT60 from Impulse Response (Broadband)
/// Uses Schroeder backward integration and least-squares T30/T20 extrapolation.
/// Returns the reverberation time in **seconds** (0.0 when no fit is possible).
pub fn compute_rt60_broadband(impulse: &[f32], sample_rate: f32) -> f32 {
    estimate_rt60_broadband(impulse, sample_rate)
        .map(|fit| fit.rt60_seconds)
        .unwrap_or(0.0)
}

/// Compute Clarity (C50, C80) from Impulse Response (Broadband)
/// Returns (C50_dB, C80_dB)
pub fn compute_clarity_broadband(impulse: &[f32], sample_rate: f32) -> (f32, f32) {
    let mut energy_0_50 = 0.0;
    let mut energy_50_inf = 0.0;
    let mut energy_0_80 = 0.0;
    let mut energy_80_inf = 0.0;

    let samp_50ms = (0.050 * sample_rate) as usize;
    let samp_80ms = (0.080 * sample_rate) as usize;

    for (i, &samp) in impulse.iter().enumerate() {
        let sq = samp * samp;

        if i < samp_50ms {
            energy_0_50 += sq;
        } else {
            energy_50_inf += sq;
        }

        if i < samp_80ms {
            energy_0_80 += sq;
        } else {
            energy_80_inf += sq;
        }
    }

    // When late energy is negligible, clarity is very high (capped at 60 dB)
    // When early energy is negligible, clarity is very low (capped at -60 dB)
    const MAX_CLARITY_DB: f32 = 60.0;

    let c50 = if energy_50_inf > 1e-12 && energy_0_50 > 1e-12 {
        let ratio = energy_0_50 / energy_50_inf;
        (10.0 * ratio.log10()).clamp(-MAX_CLARITY_DB, MAX_CLARITY_DB)
    } else if energy_0_50 > energy_50_inf {
        MAX_CLARITY_DB // Early energy dominates - excellent clarity
    } else {
        -MAX_CLARITY_DB // Late energy dominates - poor clarity
    };

    let c80 = if energy_80_inf > 1e-12 && energy_0_80 > 1e-12 {
        let ratio = energy_0_80 / energy_80_inf;
        (10.0 * ratio.log10()).clamp(-MAX_CLARITY_DB, MAX_CLARITY_DB)
    } else if energy_0_80 > energy_80_inf {
        MAX_CLARITY_DB // Early energy dominates - excellent clarity
    } else {
        -MAX_CLARITY_DB // Late energy dominates - poor clarity
    };

    (c50, c80)
}

/// Compute RT60 spectrum using octave band filtering.
///
/// Returns RT60 values in **milliseconds** interpolated onto `frequencies`,
/// matching the `AnalysisResult::rt60_ms` field and the `rt60_ms` CSV column.
pub fn compute_rt60_spectrum(impulse: &[f32], sample_rate: f32, frequencies: &[f32]) -> Vec<f32> {
    if impulse.is_empty() {
        return vec![0.0; frequencies.len()];
    }

    // Octave band center frequencies
    let centers = [
        63.0f32, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0,
    ];
    let mut band_rt60s = Vec::with_capacity(centers.len());
    let mut valid_centers = Vec::with_capacity(centers.len());
    let mut fit_summaries = Vec::with_capacity(centers.len());

    // Compute RT60 for each band
    for &freq in &centers {
        // Skip if frequency is too high for sample rate
        if freq >= sample_rate / 2.0 {
            continue;
        }

        // Apply bandpass filter
        // Q=1.414 (sqrt(2)) gives approx 1 octave bandwidth
        let mut biquad = Biquad::new(
            BiquadFilterType::Bandpass,
            freq as f64,
            sample_rate as f64,
            1.414,
            0.0,
        );

        // Process in f64
        let mut filtered: Vec<f64> = impulse.iter().map(|&x| x as f64).collect();
        biquad.process_block(&mut filtered);
        let filtered_f32: Vec<f32> = filtered.iter().map(|&x| x as f32).collect();

        // Compute RT60 for this band
        let fit = estimate_rt60_broadband(&filtered_f32, sample_rate);
        // Public contract is milliseconds (AnalysisResult.rt60_ms, CSV rt60_ms).
        let rt60_ms = fit.map(|fit| fit.rt60_seconds * 1000.0).unwrap_or(0.0);
        fit_summaries.push(match fit {
            Some(fit) => format!(
                "{:.0}Hz:{:.3}s({:?},r2={:.3},{:.0}-{:.0}ms)",
                freq,
                fit.rt60_seconds,
                fit.method,
                fit.r_squared,
                fit.fit_start_seconds * 1000.0,
                fit.fit_end_seconds * 1000.0,
            ),
            None => format!("{:.0}Hz:invalid", freq),
        });

        band_rt60s.push(rt60_ms);
        valid_centers.push(freq);
    }

    // Log per-band values
    log::info!("[RT60] Per-band values: {:?}", fit_summaries);

    if valid_centers.is_empty() {
        return vec![0.0; frequencies.len()];
    }

    // Interpolate to output frequencies
    interpolate_log(&valid_centers, &band_rt60s, frequencies)
}

/// Compute Clarity spectrum (C50, C80) using octave band filtering
/// Returns (C50_vec, C80_vec)
pub fn compute_clarity_spectrum(
    impulse: &[f32],
    sample_rate: f32,
    frequencies: &[f32],
) -> (Vec<f32>, Vec<f32>) {
    if impulse.is_empty() || frequencies.is_empty() {
        return (vec![0.0; frequencies.len()], vec![0.0; frequencies.len()]);
    }

    // Octave band center frequencies
    let centers = [
        63.0f32, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0,
    ];
    let mut band_c50s = Vec::with_capacity(centers.len());
    let mut band_c80s = Vec::with_capacity(centers.len());
    let mut valid_centers = Vec::with_capacity(centers.len());

    // Time boundaries for clarity calculation
    let samp_50ms = (0.050 * sample_rate) as usize;
    let samp_80ms = (0.080 * sample_rate) as usize;

    // Compute Clarity for each band using cascaded bandpass for better selectivity
    for &freq in &centers {
        if freq >= sample_rate / 2.0 {
            continue;
        }

        // Use cascaded biquads for sharper filter response (reduces filter ringing effects)
        let mut biquad1 = Biquad::new(
            BiquadFilterType::Bandpass,
            freq as f64,
            sample_rate as f64,
            0.707, // Lower Q per stage, cascaded gives Q ~ 1.0
            0.0,
        );
        let mut biquad2 = Biquad::new(
            BiquadFilterType::Bandpass,
            freq as f64,
            sample_rate as f64,
            0.707,
            0.0,
        );

        let mut filtered: Vec<f64> = impulse.iter().map(|&x| x as f64).collect();
        biquad1.process_block(&mut filtered);
        biquad2.process_block(&mut filtered);

        // Compute energy in early and late windows directly
        let mut energy_0_50 = 0.0f64;
        let mut energy_50_inf = 0.0f64;
        let mut energy_0_80 = 0.0f64;
        let mut energy_80_inf = 0.0f64;

        for (i, &samp) in filtered.iter().enumerate() {
            let sq = samp * samp;

            if i < samp_50ms {
                energy_0_50 += sq;
            } else {
                energy_50_inf += sq;
            }

            if i < samp_80ms {
                energy_0_80 += sq;
            } else {
                energy_80_inf += sq;
            }
        }

        // Compute C50 and C80 with proper handling
        // When late energy is very small, clarity is high (capped at 40 dB for display)
        const MAX_CLARITY_DB: f32 = 40.0;
        const MIN_ENERGY: f64 = 1e-20;

        let c50 = if energy_50_inf > MIN_ENERGY && energy_0_50 > MIN_ENERGY {
            let ratio = energy_0_50 / energy_50_inf;
            (10.0 * ratio.log10() as f32).clamp(-MAX_CLARITY_DB, MAX_CLARITY_DB)
        } else if energy_0_50 > energy_50_inf {
            MAX_CLARITY_DB
        } else {
            -MAX_CLARITY_DB
        };

        let c80 = if energy_80_inf > MIN_ENERGY && energy_0_80 > MIN_ENERGY {
            let ratio = energy_0_80 / energy_80_inf;
            (10.0 * ratio.log10() as f32).clamp(-MAX_CLARITY_DB, MAX_CLARITY_DB)
        } else if energy_0_80 > energy_80_inf {
            MAX_CLARITY_DB
        } else {
            -MAX_CLARITY_DB
        };

        band_c50s.push(c50);
        band_c80s.push(c80);
        valid_centers.push(freq);
    }

    // Log per-band values
    log::info!(
        "[Clarity] Per-band C50: {:?}",
        valid_centers
            .iter()
            .zip(band_c50s.iter())
            .map(|(f, v)| format!("{:.0}Hz:{:.1}dB", f, v))
            .collect::<Vec<_>>()
    );

    if valid_centers.is_empty() {
        return (vec![0.0; frequencies.len()], vec![0.0; frequencies.len()]);
    }

    // Interpolate to output frequency grid
    let c50_interp = interpolate_log(&valid_centers, &band_c50s, frequencies);
    let c80_interp = interpolate_log(&valid_centers, &band_c80s, frequencies);

    (c50_interp, c80_interp)
}

/// Compute RT60 and Clarity (C50, C80) spectra in a single band-filtering
/// pass over the impulse response, returning `(rt60_ms, c50_db, c80_db)`.
///
/// [`compute_rt60_spectrum`] and [`compute_clarity_spectrum`] iterate the same
/// octave bands and each convert the IR to f64 per band; this shared pass
/// converts once and reuses scratch buffers across bands. The per-band filter
/// chains are unchanged, so outputs are bit-identical to calling the two
/// public functions separately (pinned by
/// `tests::rt60_clarity_shared_pass_matches_separate_public_paths`).
pub(super) fn compute_rt60_clarity_spectra(
    impulse: &[f32],
    sample_rate: f32,
    frequencies: &[f32],
) -> (Vec<f32>, Vec<f32>, Vec<f32>) {
    if impulse.is_empty() {
        return (
            vec![0.0; frequencies.len()],
            vec![0.0; frequencies.len()],
            vec![0.0; frequencies.len()],
        );
    }

    // Octave band center frequencies
    let centers = [
        63.0f32, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0,
    ];
    let mut band_rt60s = Vec::with_capacity(centers.len());
    let mut band_c50s = Vec::with_capacity(centers.len());
    let mut band_c80s = Vec::with_capacity(centers.len());
    let mut valid_centers = Vec::with_capacity(centers.len());
    let mut fit_summaries = Vec::with_capacity(centers.len());

    // Time boundaries for clarity calculation
    let samp_50ms = (0.050 * sample_rate) as usize;
    let samp_80ms = (0.080 * sample_rate) as usize;

    // Convert to f64 once; every band's filter chain starts from this data.
    let impulse_f64: Vec<f64> = impulse.iter().map(|&x| x as f64).collect();
    let mut scratch = impulse_f64.clone();
    let mut filtered_f32 = vec![0.0f32; impulse.len()];

    for &freq in &centers {
        // Skip if frequency is too high for sample rate
        if freq >= sample_rate / 2.0 {
            continue;
        }

        // --- RT60: single bandpass biquad, Q=1.414 (sqrt(2)) ~ 1 octave ---
        let mut biquad = Biquad::new(
            BiquadFilterType::Bandpass,
            freq as f64,
            sample_rate as f64,
            1.414,
            0.0,
        );
        scratch.copy_from_slice(&impulse_f64);
        biquad.process_block(&mut scratch);
        for (out, &x) in filtered_f32.iter_mut().zip(scratch.iter()) {
            *out = x as f32;
        }

        // Compute RT60 for this band
        let fit = estimate_rt60_broadband(&filtered_f32, sample_rate);
        // Public contract is milliseconds (AnalysisResult.rt60_ms, CSV rt60_ms).
        let rt60_ms = fit.map(|fit| fit.rt60_seconds * 1000.0).unwrap_or(0.0);
        fit_summaries.push(match fit {
            Some(fit) => format!(
                "{:.0}Hz:{:.3}s({:?},r2={:.3},{:.0}-{:.0}ms)",
                freq,
                fit.rt60_seconds,
                fit.method,
                fit.r_squared,
                fit.fit_start_seconds * 1000.0,
                fit.fit_end_seconds * 1000.0,
            ),
            None => format!("{:.0}Hz:invalid", freq),
        });
        band_rt60s.push(rt60_ms);

        // --- Clarity: cascaded bandpass biquads (Q=0.707 per stage) ---
        let mut biquad1 = Biquad::new(
            BiquadFilterType::Bandpass,
            freq as f64,
            sample_rate as f64,
            0.707, // Lower Q per stage, cascaded gives Q ~ 1.0
            0.0,
        );
        let mut biquad2 = Biquad::new(
            BiquadFilterType::Bandpass,
            freq as f64,
            sample_rate as f64,
            0.707,
            0.0,
        );
        scratch.copy_from_slice(&impulse_f64);
        biquad1.process_block(&mut scratch);
        biquad2.process_block(&mut scratch);

        // Compute energy in early and late windows directly
        let mut energy_0_50 = 0.0f64;
        let mut energy_50_inf = 0.0f64;
        let mut energy_0_80 = 0.0f64;
        let mut energy_80_inf = 0.0f64;

        for (i, &samp) in scratch.iter().enumerate() {
            let sq = samp * samp;

            if i < samp_50ms {
                energy_0_50 += sq;
            } else {
                energy_50_inf += sq;
            }

            if i < samp_80ms {
                energy_0_80 += sq;
            } else {
                energy_80_inf += sq;
            }
        }

        // Compute C50 and C80 with proper handling
        // When late energy is very small, clarity is high (capped at 40 dB for display)
        const MAX_CLARITY_DB: f32 = 40.0;
        const MIN_ENERGY: f64 = 1e-20;

        let c50 = if energy_50_inf > MIN_ENERGY && energy_0_50 > MIN_ENERGY {
            let ratio = energy_0_50 / energy_50_inf;
            (10.0 * ratio.log10() as f32).clamp(-MAX_CLARITY_DB, MAX_CLARITY_DB)
        } else if energy_0_50 > energy_50_inf {
            MAX_CLARITY_DB
        } else {
            -MAX_CLARITY_DB
        };

        let c80 = if energy_80_inf > MIN_ENERGY && energy_0_80 > MIN_ENERGY {
            let ratio = energy_0_80 / energy_80_inf;
            (10.0 * ratio.log10() as f32).clamp(-MAX_CLARITY_DB, MAX_CLARITY_DB)
        } else if energy_0_80 > energy_80_inf {
            MAX_CLARITY_DB
        } else {
            -MAX_CLARITY_DB
        };

        band_c50s.push(c50);
        band_c80s.push(c80);
        valid_centers.push(freq);
    }

    // Log per-band values
    log::info!("[RT60] Per-band values: {:?}", fit_summaries);
    log::info!(
        "[Clarity] Per-band C50: {:?}",
        valid_centers
            .iter()
            .zip(band_c50s.iter())
            .map(|(f, v)| format!("{:.0}Hz:{:.1}dB", f, v))
            .collect::<Vec<_>>()
    );

    if valid_centers.is_empty() {
        return (
            vec![0.0; frequencies.len()],
            vec![0.0; frequencies.len()],
            vec![0.0; frequencies.len()],
        );
    }

    // Interpolate to output frequency grid
    let rt60_interp = interpolate_log(&valid_centers, &band_rt60s, frequencies);
    let c50_interp = interpolate_log(&valid_centers, &band_c50s, frequencies);
    let c80_interp = interpolate_log(&valid_centers, &band_c80s, frequencies);

    (rt60_interp, c50_interp, c80_interp)
}

/// Compute Spectrogram from Impulse Response
/// Returns peak-amplitude-calibrated dBFS values as
/// `(spectrogram_matrix_db, frequency_bins, time_bins)`. A bin-centred sine
/// with peak amplitude 1.0 is reported as 0 dBFS independently of window size.
/// `window_size` samples (e.g. 512), `hop_size` samples (e.g. 128).
pub fn compute_spectrogram(
    impulse: &[f32],
    sample_rate: f32,
    window_size: usize,
    hop_size: usize,
) -> (Vec<Vec<f32>>, Vec<f32>, Vec<f32>) {
    use rustfft::num_complex::Complex;

    if window_size < 2 || hop_size == 0 || !sample_rate.is_finite() || sample_rate <= 0.0 {
        return (Vec::new(), Vec::new(), Vec::new());
    }
    if impulse.len() < window_size {
        return (Vec::new(), Vec::new(), Vec::new());
    }

    let num_frames = 1 + (impulse.len() - window_size) / hop_size;
    let num_bins = window_size / 2;
    let mut spectrogram = vec![vec![0.0f32; num_bins]; num_frames];
    let mut times = Vec::with_capacity(num_frames);

    // Precompute Hann window
    let window: Vec<f32> = (0..window_size)
        .map(|i| 0.5 * (1.0 - (2.0 * PI * i as f32 / (window_size as f32 - 1.0)).cos()))
        .collect();
    let coherent_sum: f32 = window.iter().sum();

    // Setup FFT
    let fft = plan_fft_forward(window_size);

    // Reuse one FFT buffer across all frames instead of allocating per frame.
    let mut buffer = vec![Complex::new(0.0f32, 0.0); window_size];

    for (i, magnitude_db) in spectrogram.iter_mut().enumerate() {
        let start = i * hop_size;
        let time_ms = (start as f32 / sample_rate) * 1000.0;
        times.push(time_ms);

        for (j, slot) in buffer.iter_mut().enumerate() {
            let sample = impulse.get(start + j).copied().unwrap_or(0.0);
            *slot = Complex::new(sample * window[j], 0.0);
        }

        fft.process(&mut buffer);

        // Take magnitude of first half (up to Nyquist)
        // Store as dB
        for (bin, (out, c)) in magnitude_db.iter_mut().zip(buffer.iter()).enumerate() {
            let one_sided_scale = if bin == 0 {
                1.0 / coherent_sum
            } else {
                2.0 / coherent_sum
            };
            let mag = c.norm() * one_sided_scale;
            *out = if mag > 1e-9 {
                20.0 * mag.log10()
            } else {
                -180.0
            };
        }
    }

    // Generate frequency bins
    let freq_step = sample_rate / window_size as f32;
    let freqs: Vec<f32> = (0..num_bins).map(|i| i as f32 * freq_step).collect();

    (spectrogram, freqs, times)
}

/// Compute a log-frequency weighted reference response level in dB.
///
/// # Arguments
/// * `frequencies` - Frequency points in Hz
/// * `magnitude_db` - Magnitude in dB
/// * `freq_range` - Optional (start_freq, end_freq) to limit the averaging range.
///   If None, averages over the full bandwidth.
///
/// # Returns
/// The log-frequency weighted average in the dB domain.
///
/// This is intended as a stable acoustic reference level for comparison and
/// normalization. It is not a pressure- or energy-domain average.
pub fn compute_average_response(
    frequencies: &[f32],
    magnitude_db: &[f32],
    freq_range: Option<(f32, f32)>,
) -> f32 {
    if frequencies.len() < 2 || frequencies.len() != magnitude_db.len() {
        return magnitude_db.first().copied().unwrap_or(0.0);
    }

    let (start_freq, end_freq) =
        freq_range.unwrap_or((frequencies[0], frequencies[frequencies.len() - 1]));

    let mut sum_weighted_db = 0.0;
    let mut sum_weights = 0.0;

    for i in 0..frequencies.len() - 1 {
        let f0 = frequencies[i];
        let f1 = frequencies[i + 1];

        // Check if this segment overlaps with the target range
        if f1 < start_freq || f0 > end_freq {
            continue;
        }

        // Clamp segment to target range
        let fa = f0.max(start_freq);
        let fb = f1.min(end_freq);

        if fb <= fa {
            continue;
        }

        // For acoustic data, we weight by log frequency (octaves)
        // weight = log2(fb/fa)
        let weight = (fb / fa).log2();

        // Average magnitude in this segment
        // We'll use the midpoint value of the segment (or average of endpoints)
        // If the segment is partially outside start_freq/end_freq, we should interpolate
        // but for many points simple average of endpoints in the segment is fine.
        let m0 = magnitude_db[i];
        let m1 = magnitude_db[i + 1];
        let avg_m = (m0 + m1) / 2.0;

        sum_weighted_db += avg_m * weight;
        sum_weights += weight;
    }

    if sum_weights > 0.0 {
        sum_weighted_db / sum_weights
    } else {
        magnitude_db.first().copied().unwrap_or(0.0)
    }
}

/// Magnitude-squared coherence γ²(f) across N complex spectra that
/// should be measurements of the same deterministic transfer
/// function. Per `docs/gd_opt_v2_plan.md` §2.2:
///
/// ```text
///    γ²(f) = |H̄(f)|² / ⟨|H(f)|²⟩
///    H̄(f) = (1/N) Σ_i H_i(f)              (complex average)
///    ⟨|H(f)|²⟩ = (1/N) Σ_i |H_i(f)|²       (power average)
/// ```
///
/// Returns a vector of per-bin γ² in `[0, 1]`. For N = 1 γ² ≡ 1 by
/// construction — a single measurement is trivially "consistent with
/// itself" so callers must enforce the "at least 4 sweeps" rule at
/// a higher level (the `"insufficient_bass_duration"` advisory in
/// GD-1g).
///
/// Returns `Err` iff `realizations` is empty or any realization has
/// a different length than the first.
pub fn compute_coherence_from_realizations(
    realizations: &[Vec<Complex<f32>>],
) -> Result<Vec<f32>, String> {
    let n = realizations.len();
    if n == 0 {
        return Err("compute_coherence: empty realizations".to_string());
    }
    // Issue #7: a single realization is trivially "coherent with itself"
    // but the result is statistically meaningless.  Require N ≥ 4.
    if n < 4 {
        return Err(format!(
            "compute_coherence: need at least 4 realizations, got {n}"
        ));
    }
    let bins = realizations[0].len();
    if bins == 0 {
        return Ok(Vec::new());
    }
    for (i, r) in realizations.iter().enumerate() {
        if r.len() != bins {
            return Err(format!(
                "compute_coherence: realization {i} has {} bins, expected {bins}",
                r.len()
            ));
        }
    }

    let mut coherence = Vec::with_capacity(bins);
    for k in 0..bins {
        let mut sum = Complex::new(0.0_f64, 0.0_f64);
        let mut sum_sq = 0.0_f64;
        for r in realizations {
            let h = Complex::new(r[k].re as f64, r[k].im as f64);
            sum += h;
            sum_sq += h.re * h.re + h.im * h.im;
        }
        let mean = sum / (n as f64);
        let mean_sq = sum_sq / (n as f64);
        if mean_sq <= f64::EPSILON {
            // Dead bin — report as zero-confidence rather than NaN so
            // downstream thresholds just drop it.
            coherence.push(0.0);
        } else {
            let coh = (mean.norm_sqr() / mean_sq).clamp(0.0, 1.0);
            coherence.push(coh as f32);
        }
    }

    Ok(coherence)
}
