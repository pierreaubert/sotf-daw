/// Second-order IIR section (biquad) in Direct Form II Transposed.
#[derive(Clone)]
pub(super) struct Biquad {
    pub(super) b0: f64,
    pub(super) b1: f64,
    pub(super) b2: f64,
    pub(super) a1: f64,
    pub(super) a2: f64,
    pub(super) z1: f64,
    pub(super) z2: f64,
}

impl Biquad {
    pub(super) fn process(&mut self, x: f64) -> f64 {
        let y = self.b0 * x + self.z1;
        self.z1 = self.b1 * x - self.a1 * y + self.z2;
        self.z2 = self.b2 * x - self.a2 * y;
        y
    }

    pub(super) fn reset(&mut self) {
        self.z1 = 0.0;
        self.z2 = 0.0;
    }
}
