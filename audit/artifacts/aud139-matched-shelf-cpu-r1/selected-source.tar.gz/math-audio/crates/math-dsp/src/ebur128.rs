//! Pure Rust implementation of ITU-R BS.1770-4 / EBU R128 loudness measurement.
//!
//! Implements K-weighting, momentary/short-term/integrated loudness,
//! sample peak, and true peak (4x oversampling).
//!
//! The true-peak FIR phase table is the ITU-R BS.1770-4 48 kHz reference
//! filter. Non-48 kHz meters still run, but their true-peak values should be
//! treated as approximate unless the input has been resampled to 48 kHz.

mod biquad;
mod consts;
mod ebu_r128;
mod kweight_filter;
mod misc;
mod mode;
mod sub_block_ring;
#[cfg(test)]
mod tests;
mod true_peak_detector;

pub use ebu_r128::*;
pub use misc::*;
pub use mode::*;
