/// Measurement modes (bitflags).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Mode(pub(super) u32);

impl Mode {
    pub const M: Mode = Mode(1 << 0);
    pub const S: Mode = Mode(1 << 1);
    pub const I: Mode = Mode(1 << 2);
    pub const SAMPLE_PEAK: Mode = Mode(1 << 3);
    /// 4x true-peak mode using the BS.1770-4 48 kHz reference FIR table.
    pub const TRUE_PEAK: Mode = Mode(1 << 4);

    pub const fn all() -> Mode {
        Mode(0x1F)
    }

    pub(super) fn has(self, flag: Mode) -> bool {
        self.0 & flag.0 != 0
    }
}

impl std::ops::BitOr for Mode {
    type Output = Mode;
    fn bitor(self, rhs: Mode) -> Mode {
        Mode(self.0 | rhs.0)
    }
}
