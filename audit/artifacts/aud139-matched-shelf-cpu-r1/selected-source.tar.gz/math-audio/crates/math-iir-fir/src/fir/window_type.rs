use super::misc::bessel_i0;
use crate::traits::{FilterFloat, lit};

/// Window function types for FIR filter design
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum WindowType {
    /// Rectangular window (no windowing)
    Rectangular,
    /// Hamming window
    Hamming,
    /// Hann (Hanning) window
    Hann,
    /// Blackman window
    Blackman,
    /// Kaiser window (requires beta parameter)
    Kaiser,
}

impl WindowType {
    /// Returns the short string representation of the window type.
    pub fn short_name(&self) -> &'static str {
        match self {
            WindowType::Rectangular => "RECT",
            WindowType::Hamming => "HAMM",
            WindowType::Hann => "HANN",
            WindowType::Blackman => "BLKM",
            WindowType::Kaiser => "KAIS",
        }
    }

    /// Returns the long string representation of the window type.
    pub fn long_name(&self) -> &'static str {
        match self {
            WindowType::Rectangular => "Rectangular",
            WindowType::Hamming => "Hamming",
            WindowType::Hann => "Hann",
            WindowType::Blackman => "Blackman",
            WindowType::Kaiser => "Kaiser",
        }
    }
}

/// Generates a window function for FIR filter design.
///
/// # Arguments
/// * `n` - Window length
/// * `window_type` - Type of window to generate
/// * `kaiser_beta` - Beta parameter for Kaiser window (ignored for other types)
///
/// # Returns
/// Vector of window coefficients
pub fn generate_window<T: FilterFloat>(
    n: usize,
    window_type: WindowType,
    kaiser_beta: T,
) -> Vec<T> {
    if n == 0 {
        return vec![];
    }
    if n == 1 {
        return vec![T::one()];
    }
    let mut window = vec![T::zero(); n];

    let two_pi: T = lit::<T>(2.0) * T::PI();

    match window_type {
        WindowType::Rectangular => {
            window.fill(T::one());
        }
        WindowType::Hamming => {
            for (i, w) in window.iter_mut().enumerate() {
                *w = lit::<T>(0.54)
                    - lit::<T>(0.46)
                        * (two_pi * lit::<T>(i as f64) / lit::<T>((n - 1) as f64)).cos();
            }
        }
        WindowType::Hann => {
            for (i, w) in window.iter_mut().enumerate() {
                *w = lit::<T>(0.5)
                    * (T::one() - (two_pi * lit::<T>(i as f64) / lit::<T>((n - 1) as f64)).cos());
            }
        }
        WindowType::Blackman => {
            for (i, w) in window.iter_mut().enumerate() {
                let arg = two_pi * lit::<T>(i as f64) / lit::<T>((n - 1) as f64);
                *w = lit::<T>(0.42) - lit::<T>(0.5) * arg.cos()
                    + lit::<T>(0.08) * (lit::<T>(2.0) * arg).cos();
            }
        }
        WindowType::Kaiser => {
            let i0_beta = bessel_i0(kaiser_beta);
            let n_minus_1: T = lit((n - 1) as f64);
            for (i, w) in window.iter_mut().enumerate() {
                let ratio = (lit::<T>(2.0) * lit::<T>(i as f64) - n_minus_1) / n_minus_1;
                let x = kaiser_beta * (T::one() - ratio * ratio).sqrt();
                *w = bessel_i0(x) / i0_beta;
            }
        }
    }

    window
}
