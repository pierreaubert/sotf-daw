/// Solve the regularized least-squares problem `min ||Φ·g − t||² + λ·||g||²`
/// using modified Gram–Schmidt QR on the augmented system `[Φ; √λ·I]`.
///
/// The augmented matrix has `n + m` rows and `m` columns.  Regularization
/// rows prevent rank-deficiency when basis functions are nearly linearly
/// dependent (closely-spaced poles).
pub(super) fn qr_least_squares(
    n: usize,
    m: usize,
    phi: &[f64],
    t: &[f64],
    lambda: f64,
) -> Option<Vec<f64>> {
    let aug_n = n + m;
    let mut q = vec![0.0f64; aug_n * m];
    let mut r = vec![0.0f64; m * m];

    // Copy Φ into the top of the augmented matrix.
    for i in 0..n {
        for j in 0..m {
            q[i * m + j] = phi[i * m + j];
        }
    }
    // Append √(λ)·I at the bottom.
    let sqrt_lambda = lambda.sqrt();
    for j in 0..m {
        q[(n + j) * m + j] = sqrt_lambda;
    }

    // Augmented target vector: [t; 0].
    let mut aug_t = vec![0.0f64; aug_n];
    aug_t[..n].copy_from_slice(&t[..n]);

    // Modified Gram–Schmidt.
    for k in 0..m {
        let mut norm_sq = 0.0;
        for i in 0..aug_n {
            norm_sq += q[i * m + k] * q[i * m + k];
        }
        let norm = norm_sq.sqrt();
        if norm < 1e-20 {
            return None;
        }
        r[k * m + k] = norm;
        for i in 0..aug_n {
            q[i * m + k] /= norm;
        }
        for j in (k + 1)..m {
            let mut dot = 0.0;
            for i in 0..aug_n {
                dot += q[i * m + k] * q[i * m + j];
            }
            r[k * m + j] = dot;
            for i in 0..aug_n {
                q[i * m + j] -= dot * q[i * m + k];
            }
        }
    }

    // Qᵀ · aug_t  (m-dimensional).
    let mut qt = vec![0.0f64; m];
    for j in 0..m {
        let mut sum = 0.0;
        for i in 0..aug_n {
            sum += q[i * m + j] * aug_t[i];
        }
        qt[j] = sum;
    }

    // Back-substitution: R·g = Qᵀ·aug_t.
    let mut g = vec![0.0f64; m];
    for i in (0..m).rev() {
        let mut sum = qt[i];
        for j in (i + 1)..m {
            sum -= r[i * m + j] * g[j];
        }
        if r[i * m + i].abs() < 1e-20 {
            return None;
        }
        g[i] = sum / r[i * m + i];
    }

    Some(g)
}
