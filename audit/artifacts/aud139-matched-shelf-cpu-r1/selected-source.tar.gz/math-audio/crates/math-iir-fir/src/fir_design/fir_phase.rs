use super::super::fir::{WindowType, generate_window};
use super::pre_ringing_config::PreRingingConfig;
use super::pre_ringing_config::suppress_pre_ringing;

/// Phase type for FIR generation
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize, Default)]
pub enum FirPhase {
    /// Linear phase (symmetrical impulse response, constant delay)
    #[default]
    Linear,
    /// Minimum phase (causal, minimum delay, concentrates energy at start)
    Minimum,
    /// Kirkeby regularized inversion (mixed phase, good for room correction)
    Kirkeby,
}

impl FirPhase {
    /// Returns the short string representation of the phase type.
    pub fn short_name(&self) -> &'static str {
        match self {
            FirPhase::Linear => "LIN",
            FirPhase::Minimum => "MIN",
            FirPhase::Kirkeby => "KIRK",
        }
    }

    /// Returns the long string representation of the phase type.
    pub fn long_name(&self) -> &'static str {
        match self {
            FirPhase::Linear => "Linear",
            FirPhase::Minimum => "Minimum",
            FirPhase::Kirkeby => "Kirkeby",
        }
    }
}

/// Finalize impulse response with windowing and centering
pub(super) fn finalize_impulse_response(
    ir: &[f64],
    n_taps: usize,
    phase: FirPhase,
    window_type: &WindowType,
    pre_ringing: Option<&PreRingingConfig>,
    sample_rate: f64,
) -> Vec<f64> {
    let fft_size = ir.len();
    let mut final_ir;

    if phase == FirPhase::Linear {
        // Rotate to center for linear phase
        let center = n_taps / 2;
        final_ir = vec![0.0; n_taps];

        for (i, val) in final_ir.iter_mut().enumerate().take(n_taps) {
            let shift = i as isize - center as isize;
            let ir_idx = if shift < 0 {
                fft_size as isize + shift
            } else {
                shift
            };
            *val = ir[ir_idx as usize];
        }
    } else {
        // Minimum phase: Impulse is already at 0. Just truncate.
        final_ir = ir[..n_taps].to_vec();
    }

    // Apply window
    let window = generate_window(n_taps, *window_type, 0.0);
    for (x, w) in final_ir.iter_mut().zip(window.iter()) {
        *x *= w;
    }

    // Apply pre-ringing suppression if configured
    if let Some(config) = pre_ringing {
        suppress_pre_ringing(&mut final_ir, config, sample_rate);
    }

    final_ir
}
