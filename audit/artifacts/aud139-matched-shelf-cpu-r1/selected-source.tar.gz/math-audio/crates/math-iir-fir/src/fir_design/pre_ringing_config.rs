/// Configuration for pre-ringing suppression on FIR filters.
///
/// Pre-ringing occurs in linear-phase and Kirkeby FIR filters as energy arriving
/// before the main impulse tap. When it exceeds the audibility threshold (~-30 dB
/// relative to the main tap), it's perceived as a "ringing" artifact before transients.
///
/// Reference: Brännmark & Sternad, Patent EP2104374B1 — pre-ringing envelope constraint
#[derive(Debug, Clone)]
pub struct PreRingingConfig {
    /// Maximum pre-ringing level in dB relative to the main tap.
    /// Taps before the main tap exceeding this threshold will be attenuated.
    /// Default: -30.0 dB (psychoacoustically inaudible)
    pub threshold_db: f64,

    /// Maximum pre-ringing time in seconds. Pre-ringing energy beyond this
    /// duration before the main tap will be fully suppressed.
    /// Default: 0.005 (5 ms)
    pub max_time_s: f64,
}

impl Default for PreRingingConfig {
    fn default() -> Self {
        Self {
            threshold_db: -30.0,
            max_time_s: 0.005,
        }
    }
}

/// Suppress pre-ringing in an FIR impulse response.
///
/// Finds the main tap (peak absolute value), then attenuates all taps before it
/// that exceed the threshold. Also applies a time limit: taps further than
/// `max_time_s` before the main tap are fully suppressed.
///
/// The attenuation uses a smooth envelope to avoid introducing new artifacts.
pub fn suppress_pre_ringing(ir: &mut [f64], config: &PreRingingConfig, sample_rate: f64) {
    if ir.is_empty() {
        return;
    }

    // Find the main tap (peak absolute value)
    let main_tap_idx = ir
        .iter()
        .enumerate()
        .max_by(|(_, a), (_, b)| a.abs().total_cmp(&b.abs()))
        .map(|(i, _)| i)
        .unwrap_or(0);

    let main_tap_abs = ir[main_tap_idx].abs();
    if main_tap_abs == 0.0 {
        return;
    }

    // Threshold in linear scale
    let threshold_linear = main_tap_abs * 10.0_f64.powf(config.threshold_db / 20.0);

    // Maximum number of samples of pre-ringing allowed
    let max_pre_samples = (config.max_time_s * sample_rate).round() as usize;

    // Process all taps before the main tap
    for (i, sample) in ir[..main_tap_idx].iter_mut().enumerate() {
        let samples_before = main_tap_idx - i;

        if max_pre_samples == 0 || samples_before > max_pre_samples {
            // Beyond time limit (or zero time limit): fully suppress
            *sample = 0.0;
        } else if sample.abs() > threshold_linear {
            // Use a time-varying cap: the audible threshold is allowed close
            // to the main impulse and fades smoothly to zero at the limit.
            let time_ratio = samples_before as f64 / max_pre_samples as f64;
            let fade = 0.5 * (1.0 + (std::f64::consts::PI * time_ratio).cos());
            *sample = sample.signum() * threshold_linear * fade;
        }
    }
}
