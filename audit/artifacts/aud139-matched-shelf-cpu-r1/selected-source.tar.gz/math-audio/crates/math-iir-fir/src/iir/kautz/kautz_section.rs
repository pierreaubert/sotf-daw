use crate::traits::{FilterFloat, lit};
use num_complex::Complex;
use std::f64::consts::PI;

/// A second-order Kautz section with pole tuned to a specific frequency.
///
/// Implements a real fixed-pole resonant basis chained by a second-order allpass.
/// The pole is placed at `pole_freq` with radius `pole_radius`, concentrating
/// frequency resolution around that frequency.
///
/// # Allpass definition
///
/// ```text
/// A(z) = (r² + a1·z⁻¹ + z⁻²) / (1 + a1·z⁻¹ + r²·z⁻²)
/// ```
///
/// where `a1 = -2r·cos(θ)` and `θ = 2π·pole_freq / srate`.
///
/// # Basis function
///
/// The basis function for this section (assuming allpass outputs from all
/// preceding sections have been accumulated into the input) is:
///
/// ```text
/// φ(z) = sqrt(1 - r²) · (1 - r²)
///        / (1 + a1·z⁻¹ + r²·z⁻²) · chain
/// ```
///
/// In the time domain, each section receives the allpass-filtered output from
/// all previous sections and extracts one resonant component. This is useful as
/// a fixed-pole modal basis, but it is not the complete two-function real
/// orthonormal Kautz pair associated with a complex-conjugate pole pair.
pub struct KautzSection<T: FilterFloat = f64> {
    /// Pole frequency in Hz.
    pub pole_freq: T,
    /// Pole radius in (0, 1). Controls how sharply resolution concentrates.
    /// Derived from room mode Q: `radius = exp(-π · pole_freq / (Q · srate))`.
    pub pole_radius: T,
    /// Gain coefficient — weight of this basis function in the correction filter.
    pub gain: T,
    /// Sample rate in Hz.
    pub srate: T,
    // Allpass denominator coefficients (normalized, denominator leading coeff = 1):
    //   a1 = -2r·cos(θ),  a2 = r²
    pub(super) a1_coeff: T,
    pub(super) a2_coeff: T,
    // Transposed direct form II state for the allpass
    pub(super) s1: T,
    pub(super) s2: T,
    // Transposed direct form II state for the basis function output
    pub(super) b_s1: T,
    pub(super) b_s2: T,
}

impl<T: FilterFloat> KautzSection<T> {
    /// Create a Kautz section with a pole at `pole_freq` Hz and the given Q.
    ///
    /// The pole radius is `exp(-π · pole_freq / (q · srate))`.
    /// `gain` sets the initial weight of this section (typically 0.0 before optimization).
    pub fn new(pole_freq: T, q: T, gain: T, srate: T) -> Self {
        let q_clamped = if q < lit::<T>(0.1) { lit::<T>(0.1) } else { q };
        let theta = lit::<T>(2.0) * T::PI() * pole_freq / srate;
        let radius = (-T::PI() * pole_freq / (q_clamped * srate)).exp();
        // Clamp radius to (0, 0.9999) for stability
        let radius = radius.min(lit::<T>(0.9999)).max(T::zero());

        Self::from_pole(pole_freq, radius, gain, srate, theta)
    }

    /// Create a section directly from a precomputed pole radius and frequency angle.
    pub(super) fn from_pole(pole_freq: T, radius: T, gain: T, srate: T, theta: T) -> Self {
        let r2 = radius * radius;
        let a1_coeff = lit::<T>(-2.0) * radius * theta.cos();
        let a2_coeff = r2;

        KautzSection {
            pole_freq,
            pole_radius: radius,
            gain,
            srate,
            a1_coeff,
            a2_coeff,
            s1: T::zero(),
            s2: T::zero(),
            b_s1: T::zero(),
            b_s2: T::zero(),
        }
    }

    /// Process one sample through this section.
    ///
    /// `x` is the input (allpass-chained output from all preceding sections).
    ///
    /// Returns `(basis_value, allpass_output)`:
    /// - `basis_value`: the resonant basis function value (multiply by `gain` and sum)
    /// - `allpass_output`: the allpass output to pass as input to the next section
    ///
    /// Both the allpass and the basis extraction use transposed direct form II for
    /// numerical stability at high Q.
    #[inline(always)]
    pub fn process_section(&mut self, x: T) -> (T, T) {
        let a1 = self.a1_coeff;
        let a2 = self.a2_coeff; // = r²

        // Allpass: A(z) = (a2 + a1·z⁻¹ + z⁻²) / (1 + a1·z⁻¹ + a2·z⁻²)
        // TDF-II with numerator b0=a2, b1=a1, b2=1 and denominator 1, a1, a2.
        let ap_out = a2 * x + self.s1;
        self.s1 = a1 * x - a1 * ap_out + self.s2;
        self.s2 = x - a2 * ap_out;

        // Basis function: H(z) = sqrt(1-r²)·(1-r²) / (1 + a1·z⁻¹ + r²·z⁻²) · chain
        // Implemented as TDF-II with constant numerator b0 = norm*(1-a2).
        // This matches basis_response() in the frequency domain exactly.
        let norm = (T::one() - a2).sqrt(); // sqrt(1 - r²)
        let b0 = norm * (T::one() - a2); // sqrt(1-r²) * (1-r²)
        let basis_out = b0 * x + self.b_s1;
        self.b_s1 = -a1 * basis_out + self.b_s2;
        self.b_s2 = -a2 * basis_out;

        (basis_out, ap_out)
    }

    /// Compute this section's allpass complex frequency response at `freq` Hz.
    ///
    /// `A(e^jω) = (a2 + a1·e^{-jω} + e^{-2jω}) / (1 + a1·e^{-jω} + a2·e^{-2jω})`
    pub fn allpass_response(&self, freq: f64, srate: f64) -> Complex<f64> {
        let omega = 2.0 * PI * freq / srate;
        let a1 = self.a1_coeff.to_f64().unwrap();
        let a2 = self.a2_coeff.to_f64().unwrap();
        let z_inv = Complex::from_polar(1.0, -omega);
        let z_inv2 = z_inv * z_inv;
        let num = Complex::new(a2, 0.0) + z_inv * a1 + z_inv2;
        let den = Complex::new(1.0, 0.0) + z_inv * a1 + z_inv2 * a2;
        num / den
    }

    /// Compute this section's basis function complex frequency response at `freq` Hz,
    /// given that the accumulated allpass chain from all preceding sections is `chain`.
    pub fn basis_response(&self, freq: f64, srate: f64, chain: Complex<f64>) -> Complex<f64> {
        let omega = 2.0 * PI * freq / srate;
        let r = self.pole_radius.to_f64().unwrap();
        let r2 = r * r;
        let a1 = self.a1_coeff.to_f64().unwrap();
        let a2 = self.a2_coeff.to_f64().unwrap();
        let z_inv = Complex::from_polar(1.0, -omega);
        let z_inv2 = z_inv * z_inv;

        let norm = (1.0 - r2).sqrt();
        // H_basis(z) = sqrt(1-r²) * (1 - a2) / (1 + a1*z^-1 + a2*z^-2)
        // This is the frequency-domain form of the basis extraction
        let den = Complex::new(1.0, 0.0) + z_inv * a1 + z_inv2 * a2;
        let num = Complex::new(norm * (1.0 - a2), 0.0);
        (num / den) * chain
    }

    /// Reset all filter state to zero.
    #[inline]
    pub fn reset(&mut self) {
        self.s1 = T::zero();
        self.s2 = T::zero();
        self.b_s1 = T::zero();
        self.b_s2 = T::zero();
    }
}
