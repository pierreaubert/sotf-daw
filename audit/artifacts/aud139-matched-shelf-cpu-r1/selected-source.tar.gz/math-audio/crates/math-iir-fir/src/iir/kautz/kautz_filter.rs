use super::kautz_section::KautzSection;
use super::misc::qr_least_squares;
use crate::traits::FilterFloat;
use ndarray::Array1;
use num_complex::Complex;

/// Complete Kautz filter: parallel bank of [`KautzSection`]s.
///
/// Each section targets a specific room mode. The filter output is the
/// weighted sum of all sections' basis function values:
///
/// ```text
/// y[n] = Σ_k  gain_k · φ_k(x[n])
/// ```
///
/// Gains are initialized to zero and should be set via [`optimize_gains`] or
/// manually before processing.
///
/// [`optimize_gains`]: KautzFilter::optimize_gains
pub struct KautzFilter<T: FilterFloat = f64> {
    /// The individual Kautz sections (one per room mode).
    pub sections: Vec<KautzSection<T>>,
    /// Sample rate in Hz.
    pub srate: T,
}

impl KautzFilter<f64> {
    /// Create a Kautz filter from detected room modes.
    ///
    /// `modes` is a slice of `(frequency_hz, q_factor)` pairs.
    /// Pole radii are derived from `radius = exp(-π·f / (Q·srate))`.
    /// All gains are initialized to `0.0`.
    pub fn from_room_modes(modes: &[(f64, f64)], sample_rate: f64) -> Self {
        let sections = modes
            .iter()
            .map(|&(freq, q)| KautzSection::new(freq, q, 0.0, sample_rate))
            .collect();

        KautzFilter {
            sections,
            srate: sample_rate,
        }
    }

    /// Optimize section gains using linear least-squares to match the target correction.
    ///
    /// Solves `Φ g = t` where:
    /// - `Φ[i][j]` = section j's basis function dB response at `freqs[i]`
    /// - `t[i]` = `target_spl[i] - measured_spl[i]` (correction needed in dB)
    ///
    /// Uses modified Gram-Schmidt QR on the augmented regularized system
    /// `[Φ; sqrt(λ) I]`. This is more robust than normal equations for
    /// closely spaced room-mode poles because it does not square the condition
    /// number of `Φ`.
    pub fn optimize_gains(&mut self, freqs: &[f64], measured_spl: &[f64], target_spl: &[f64]) {
        let n = freqs.len();
        let m = self.sections.len();
        if n == 0 || m == 0 {
            return;
        }

        // Build Φ matrix (n × m): each column j holds section j's basis function
        // magnitude response (linear, not dB) over the frequency grid.
        // Target vector t holds the required correction in dB at each frequency.
        //
        // We work in linear magnitude for Φ so that the column values are
        // positive and peak near the section's pole.  The gains then act as
        // dB multipliers: total_correction_db(f) ≈ Σ_k gain_k · |Φ_k(f)|.
        let mut phi = vec![0.0f64; n * m];
        let mut t = vec![0.0f64; n];

        for (i, (&freq, (&meas, &tgt))) in freqs
            .iter()
            .zip(measured_spl.iter().zip(target_spl.iter()))
            .enumerate()
        {
            t[i] = tgt - meas;

            // Accumulate the allpass chain across sections
            let mut chain = Complex::new(1.0, 0.0);
            for (j, section) in self.sections.iter().enumerate() {
                let basis = section.basis_response(freq, self.srate, chain);
                phi[i * m + j] = basis.norm();
                // Advance chain by this section's allpass
                chain *= section.allpass_response(freq, self.srate);
            }
        }

        // Normalize each column so its maximum value is 1.0.
        // This ensures each gain has the same scale (dB boost/cut at the pole)
        // and makes the sign relationship intuitive: negative gain = attenuation.
        for j in 0..m {
            let col_max = (0..n).map(|i| phi[i * m + j]).fold(0.0f64, f64::max);
            if col_max > 1.0e-20 {
                for i in 0..n {
                    phi[i * m + j] /= col_max;
                }
            }
        }

        // Regularization strength: λ = 1e-6 * max column norm prevents
        // division by near-zero values when sections have very similar responses.
        let max_col_norm_sq = (0..m)
            .map(|j| (0..n).map(|i| phi[i * m + j] * phi[i * m + j]).sum::<f64>())
            .fold(0.0f64, f64::max);
        let lambda = 1.0e-4 * max_col_norm_sq.max(1.0);

        // Issue #4: solve via QR on the augmented system instead of normal
        // equations + Cholesky.  QR avoids squaring the condition number of Φ.
        if let Some(gains) = qr_least_squares(n, m, &phi, &t, lambda) {
            for (section, &g) in self.sections.iter_mut().zip(gains.iter()) {
                section.gain = g;
            }
        }
    }

    /// Process one sample through all sections in parallel, returning the
    /// weighted sum of all basis function outputs.
    #[inline]
    pub fn process(&mut self, sample: f64) -> f64 {
        let mut ap_input = sample;
        let mut output = 0.0f64;

        for section in self.sections.iter_mut() {
            let (basis_val, ap_out) = section.process_section(ap_input);
            output += section.gain * basis_val;
            ap_input = ap_out;
        }

        output
    }

    /// Process a block of samples in-place.
    pub fn process_block(&mut self, buf: &mut [f64]) {
        for sample in buf.iter_mut() {
            *sample = self.process(*sample);
        }
    }

    /// Compute the complex frequency response of the entire filter at `freq` Hz.
    pub fn complex_response(&self, freq: f64) -> Complex<f64> {
        let mut total = Complex::new(0.0, 0.0);
        let mut chain = Complex::new(1.0, 0.0);

        for section in &self.sections {
            let basis = section.basis_response(freq, self.srate, chain);
            total += basis * section.gain;
            chain *= section.allpass_response(freq, self.srate);
        }

        total
    }

    /// Compute magnitude response in dB at each frequency in `freqs`.
    pub fn np_log_result(&self, freqs: &Array1<f64>) -> Array1<f64> {
        freqs.mapv(|f| {
            let h = self.complex_response(f);
            let mag = h.norm();
            if mag > 1.0e-20 {
                20.0 * mag.log10()
            } else {
                -400.0
            }
        })
    }

    /// Reset all section states to zero.
    pub fn reset(&mut self) {
        for section in self.sections.iter_mut() {
            section.reset();
        }
    }
}
