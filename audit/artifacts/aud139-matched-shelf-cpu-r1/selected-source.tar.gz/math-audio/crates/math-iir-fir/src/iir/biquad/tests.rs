use super::Biquad;
use super::biquad_filter_type::BiquadFilterType;

use ndarray::array;
use num_traits::Float;

mod misc;

#[test]
fn test_biquad_np_log_result_is_finite() {
    let bq = Biquad::new(BiquadFilterType::Peak, 1_000.0, 48_000.0, 1.0, 6.0);
    let freqs = array![20.0, 100.0, 1_000.0, 10_000.0, 20_000.0];
    let resp = bq.np_log_result(&freqs);
    for (i, v) in resp.iter().enumerate() {
        assert!(v.is_finite(), "response at idx {} not finite: {}", i, v);
    }
}

#[test]
fn peak_with_zero_q_is_safely_clamped() {
    let bq = Biquad::new(BiquadFilterType::Peak, 1_000.0, 48_000.0, 0.0, 3.0);
    let freqs = array![20.0, 100.0, 1_000.0, 10_000.0, 20_000.0];
    let resp = bq.np_log_result(&freqs);
    for (i, v) in resp.iter().enumerate() {
        assert!(v.is_finite(), "response at idx {} not finite: {}", i, v);
    }
}

#[test]
fn test_bandpass_filter_response() {
    let center = 1000.0;
    let bp = Biquad::new(BiquadFilterType::Bandpass, center, 48000.0, 1.0, 0.0);
    let center_response = bp.log_result(center);
    let low_response = bp.log_result(100.0);
    assert!(
        low_response < center_response - 10.0,
        "Bandpass below center should be attenuated"
    );
    let high_response = bp.log_result(10000.0);
    assert!(
        high_response < center_response - 10.0,
        "Bandpass above center should be attenuated"
    );
}

#[test]
fn test_notch_with_explicit_q_wider_notch() {
    let narrow = Biquad::new(BiquadFilterType::Notch, 1000.0, 48000.0, 0.0, 0.0); // Q=30
    let wide = Biquad::new(BiquadFilterType::Notch, 1000.0, 48000.0, 2.0, 0.0); // Q=2
    let narrow_off = narrow.log_result(900.0);
    let wide_off = wide.log_result(900.0);
    assert!(
        wide_off < narrow_off,
        "Wider notch (Q=2) should attenuate more at 900Hz: wide={}, narrow={}",
        wide_off,
        narrow_off
    );
}

#[test]
fn test_try_new_valid_parameters() {
    let result = Biquad::try_new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 3.0);
    assert!(result.is_ok());
    let bq = result.unwrap();
    assert_eq!(bq.filter_type, BiquadFilterType::Peak);
    assert_eq!(bq.freq, 1000.0);
    assert_eq!(bq.srate, 48000.0);
    assert_eq!(bq.q, 2.0);
    assert_eq!(bq.db_gain, 3.0);
}

#[test]
fn test_try_new_invalid_sample_rate_zero() {
    let result = Biquad::try_new(BiquadFilterType::Peak, 1000.0, 0.0, 2.0, 3.0);
    assert!(result.is_err());
    let err = result.unwrap_err();
    assert!(matches!(
        err,
        crate::error::IirError::InvalidSampleRate { .. }
    ));
}

#[test]
fn test_try_new_invalid_sample_rate_negative() {
    let result = Biquad::try_new(BiquadFilterType::Peak, 1000.0, -48000.0, 2.0, 3.0);
    assert!(result.is_err());
}

#[test]
fn test_try_new_invalid_frequency_zero() {
    let result = Biquad::try_new(BiquadFilterType::Peak, 0.0, 48000.0, 2.0, 3.0);
    assert!(result.is_err());
    let err = result.unwrap_err();
    assert!(matches!(
        err,
        crate::error::IirError::InvalidFrequency { .. }
    ));
}

#[test]
fn test_try_new_invalid_frequency_above_nyquist() {
    let result = Biquad::try_new(BiquadFilterType::Peak, 30000.0, 48000.0, 2.0, 3.0);
    assert!(result.is_err());
    let err = result.unwrap_err();
    assert!(matches!(
        err,
        crate::error::IirError::InvalidFrequency { .. }
    ));
}

#[test]
fn test_new_clamps_frequency_into_open_nyquist_interval() {
    for frequency in [0.0, -100.0, 24_000.0, 30_000.0, f64::NAN] {
        let biquad = Biquad::new(BiquadFilterType::Lowpass, frequency, 48_000.0, 0.707, 0.0);
        assert!(
            biquad.freq > 0.0 && biquad.freq < 24_000.0,
            "frequency {frequency} was stored as {}",
            biquad.freq
        );
        let coefficients = biquad.coefficients();
        assert!(
            [
                coefficients.b0,
                coefficients.b1,
                coefficients.b2,
                coefficients.a1,
                coefficients.a2,
            ]
            .iter()
            .all(|coefficient| coefficient.is_finite())
        );
        if !frequency.is_finite() || frequency <= 0.0 {
            assert!(
                coefficients.b0 > 0.0,
                "clamping {frequency} must avoid a degenerate zero-frequency lowpass"
            );
        }
    }
}

#[test]
fn test_update_params_clamps_frequency_into_open_nyquist_interval() {
    let mut biquad = Biquad::new(BiquadFilterType::Lowpass, 1000.0, 48_000.0, 0.707, 0.0);
    biquad.update_params(BiquadFilterType::Highpass, 48_000.0, 48_000.0, 0.707, 0.0);
    assert!(biquad.freq > 0.0 && biquad.freq < 24_000.0);
}

#[test]
fn test_try_new_invalid_q_negative() {
    let result = Biquad::try_new(BiquadFilterType::Peak, 1000.0, 48000.0, -1.0, 3.0);
    assert!(result.is_err());
    let err = result.unwrap_err();
    assert!(matches!(err, crate::error::IirError::InvalidQ { .. }));
}

#[test]
fn test_try_new_invalid_gain_infinite() {
    let result = Biquad::try_new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, f64::INFINITY);
    assert!(result.is_err());
    let err = result.unwrap_err();
    assert!(matches!(err, crate::error::IirError::InvalidGain { .. }));
}

#[test]
fn test_try_new_invalid_gain_nan() {
    let result = Biquad::try_new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, f64::NAN);
    assert!(result.is_err());
}

#[test]
fn test_biquad_process_dc_highpass() {
    let mut hp = Biquad::new(BiquadFilterType::Highpass, 1000.0_f64, 48000.0, 0.0, 0.0);
    let mut output = 0.0_f64;
    for _ in 0..1000 {
        output = hp.process(1.0);
    }
    assert!(
        output.abs() < 0.01,
        "Highpass should block DC, got {}",
        output
    );
}

#[test]
fn test_biquad_process_impulse_response() {
    let mut peak = Biquad::new(BiquadFilterType::Peak, 1000.0_f64, 48000.0, 2.0, 6.0);
    let first: f64 = peak.process(1.0);
    let second: f64 = peak.process(0.0);
    let third: f64 = peak.process(0.0);
    assert!(first.abs() > 0.0, "Impulse response should be non-zero");
    assert!(
        second.abs() > 0.0 || third.abs() > 0.0,
        "Peak filter should ring after impulse"
    );
}

#[test]
fn test_biquad_constants() {
    let bq = Biquad::new(BiquadFilterType::Peak, 1000.0_f64, 48000.0, 2.0, 6.0);
    let (a1, a2, b0, b1, b2): (f64, f64, f64, f64, f64) = bq.constants();
    assert!(a1.is_finite());
    assert!(a2.is_finite());
    assert!(b0.is_finite());
    assert!(b1.is_finite());
    assert!(b2.is_finite());
    assert!(b0.abs() > 0.0);
}

#[test]
fn test_biquad_display() {
    let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
    let display = format!("{}", bq);
    assert!(display.contains("PK"));
    assert!(display.contains("1000"));
    assert!(display.contains("48000"));
    assert!(display.contains("2.0"));
    assert!(display.contains("6.0"));
}

#[test]
fn test_filter_type_short_names() {
    assert_eq!(BiquadFilterType::Lowpass.short_name(), "LP");
    assert_eq!(BiquadFilterType::Highpass.short_name(), "HP");
    assert_eq!(BiquadFilterType::HighpassVariableQ.short_name(), "HPQ");
    assert_eq!(BiquadFilterType::Bandpass.short_name(), "BP");
    assert_eq!(BiquadFilterType::Peak.short_name(), "PK");
    assert_eq!(BiquadFilterType::Notch.short_name(), "NO");
    assert_eq!(BiquadFilterType::Lowshelf.short_name(), "LS");
    assert_eq!(BiquadFilterType::Highshelf.short_name(), "HS");
}

#[test]
fn test_filter_type_long_names() {
    assert_eq!(BiquadFilterType::Lowpass.long_name(), "Lowpass");
    assert_eq!(BiquadFilterType::Highpass.long_name(), "Highpass");
    assert_eq!(
        BiquadFilterType::HighpassVariableQ.long_name(),
        "HighpassVariableQ"
    );
    assert_eq!(BiquadFilterType::Bandpass.long_name(), "Bandpass");
    assert_eq!(BiquadFilterType::Peak.long_name(), "Peak");
    assert_eq!(BiquadFilterType::Notch.long_name(), "Notch");
    assert_eq!(BiquadFilterType::Lowshelf.long_name(), "Lowshelf");
    assert_eq!(BiquadFilterType::Highshelf.long_name(), "Highshelf");
}

#[test]
fn test_biquad_f32_instantiation() {
    let bq = Biquad::<f32>::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 3.0);
    let resp = bq.log_result(1000.0);
    assert!((resp - 3.0).abs() < 0.5); // f32 has less precision
}

#[test]
fn test_filter_type_long_names_complete() {
    assert_eq!(BiquadFilterType::Lowpass.long_name(), "Lowpass");
    assert_eq!(BiquadFilterType::Highpass.long_name(), "Highpass");
    assert_eq!(
        BiquadFilterType::HighpassVariableQ.long_name(),
        "HighpassVariableQ"
    );
    assert_eq!(BiquadFilterType::Bandpass.long_name(), "Bandpass");
    assert_eq!(BiquadFilterType::Peak.long_name(), "Peak");
    assert_eq!(BiquadFilterType::Notch.long_name(), "Notch");
    assert_eq!(BiquadFilterType::Lowshelf.long_name(), "Lowshelf");
    assert_eq!(BiquadFilterType::Highshelf.long_name(), "Highshelf");
    assert_eq!(BiquadFilterType::AllPass.long_name(), "AllPass");
    assert_eq!(BiquadFilterType::LowshelfOrf.long_name(), "LowshelfOrf");
    assert_eq!(BiquadFilterType::HighshelfOrf.long_name(), "HighshelfOrf");
    assert_eq!(BiquadFilterType::PeakMatched.long_name(), "PeakMatched");
}

#[test]
fn test_compute_coeffs_all_filter_types_finite() {
    // Verify compute_coeffs produces finite coefficients for all filter types
    let types = [
        BiquadFilterType::Lowpass,
        BiquadFilterType::Highpass,
        BiquadFilterType::HighpassVariableQ,
        BiquadFilterType::Bandpass,
        BiquadFilterType::Notch,
        BiquadFilterType::Peak,
        BiquadFilterType::Lowshelf,
        BiquadFilterType::Highshelf,
        BiquadFilterType::AllPass,
        BiquadFilterType::LowshelfOrf,
        BiquadFilterType::HighshelfOrf,
        BiquadFilterType::PeakMatched,
    ];
    for &ft in &types {
        let mut bq = Biquad::<f64>::new(ft, 1000.0, 48000.0, 1.0, 0.0);
        bq.compute_coeffs();
        let (a1, a2, b0, b1, b2) = bq.constants();
        assert!(
            a1.is_finite(),
            "{}: a1 should be finite after compute_coeffs",
            ft.short_name()
        );
        assert!(a2.is_finite(), "{}: a2 should be finite", ft.short_name());
        assert!(b0.is_finite(), "{}: b0 should be finite", ft.short_name());
        assert!(b1.is_finite(), "{}: b1 should be finite", ft.short_name());
        assert!(b2.is_finite(), "{}: b2 should be finite", ft.short_name());
    }
}

#[test]
fn test_compute_coeffs_a0_guard_path() {
    // Extreme parameters can drive a0 to near-zero; verify fallback identity coeffs.
    // A valid but extremely small in-band LowshelfOrf frequency with extreme
    // negative gain produces a0 < 1e-15. (Exactly zero is now sanitized by
    // Biquad::new before coefficient generation.)
    let mut bq = Biquad::<f64>::new(BiquadFilterType::LowshelfOrf, 1.0e-10, 48000.0, 0.7, -640.0);
    bq.compute_coeffs();
    let (a1, a2, b0, b1, b2) = bq.constants();
    // When a0 guard triggers, coefficients become identity (pass-through)
    assert_eq!(b0, 1.0, "a0 guard should set b0=1, got {b0}");
    assert_eq!(b1, 0.0, "a0 guard should set b1=0, got {b1}");
    assert_eq!(b2, 0.0, "a0 guard should set b2=0, got {b2}");
    assert_eq!(a1, 0.0, "a0 guard should set a1=0, got {a1}");
    assert_eq!(a2, 0.0, "a0 guard should set a2=0, got {a2}");
}

#[test]
fn test_compute_coeffs_recomputes_after_update() {
    let mut bq = Biquad::<f64>::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 0.0);
    let (_, _, b0_before, _, _) = bq.constants();

    bq.update_params(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 12.0);
    let (_, _, b0_after, _, _) = bq.constants();

    assert_ne!(
        b0_before, b0_after,
        "compute_coeffs should update b0 when gain changes"
    );
}

#[test]
fn test_compute_coeffs_normalization() {
    // Coefficients should be normalized (a0 absorbed into b0,b1,b2,a1,a2)
    let bq = Biquad::<f64>::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
    let (a1, a2, b0, b1, b2) = bq.constants();
    // The effective denominator at DC is 1 + a1 + a2
    // For a peak filter, DC gain should be close to 0 dB
    let dc_gain = (b0 + b1 + b2) / (1.0 + a1 + a2);
    assert!(
        dc_gain.abs() < 10.0,
        "DC gain should be reasonable, got {dc_gain}"
    );
}
