use super::WarpedBiquad;
use super::misc::bark_lambda;
use super::misc::compute_implicit_consts;
use super::misc::unwarp_frequency;
use super::misc::warp_frequency;
use crate::iir::biquad::{Biquad, BiquadFilterType};

#[test]
fn test_bark_lambda_48khz() {
    // Smith & Abel (1999) formula: λ = 1.0674 * sqrt(2/π * arctan(0.06583 * fs)) - 0.1916
    // At 48kHz: arctan(3159.84) ≈ π/2, so λ ≈ 1.0674 * 1.0 - 0.1916 ≈ 0.876
    let lambda = bark_lambda(48000.0_f64);
    assert!(
        (lambda - 0.876).abs() < 0.01,
        "λ at 48 kHz should be ~0.876 (Smith & Abel), got {}",
        lambda
    );
}

#[test]
fn test_bark_lambda_44khz() {
    let lambda: f64 = bark_lambda(44100.0);
    // At 44.1kHz: arctan(2903) ≈ π/2, similar to 48kHz
    assert!(
        lambda > 0.85 && lambda < 0.90,
        "λ at 44.1 kHz should be ~0.875, got {}",
        lambda
    );
}

#[test]
fn test_warp_unwarp_roundtrip() {
    let lambda = bark_lambda(48000.0_f64);
    for &freq in &[50.0, 200.0, 500.0, 1000.0, 5000.0, 10000.0] {
        let warped = warp_frequency(freq, 48000.0, lambda);
        let unwarped = unwarp_frequency(warped, 48000.0, lambda);
        assert!(
            (freq - unwarped).abs() < 0.01,
            "roundtrip failed at {} Hz: warped={:.2} unwarped={:.4}",
            freq,
            warped,
            unwarped
        );
    }
}

#[test]
fn test_warp_is_monotonic_and_expansive() {
    let lambda = bark_lambda(48000.0_f64);
    // Warping should be monotonically increasing and should expand LF
    // relative to HF (the ratio warped/physical should decrease with frequency)
    let freqs = [50.0, 100.0, 500.0, 1000.0, 5000.0, 10000.0];
    let warped: Vec<f64> = freqs
        .iter()
        .map(|&f| warp_frequency(f, 48000.0, lambda))
        .collect();

    // Monotonic
    for i in 1..warped.len() {
        assert!(
            warped[i] > warped[i - 1],
            "Warped frequencies should be monotonic: {:.1}Hz -> {:.1}Hz",
            warped[i - 1],
            warped[i]
        );
    }

    // LF gets relatively more "space" than HF
    let ratio_low = warped[0] / freqs[0]; // warped(50Hz) / 50Hz
    let ratio_high = warped[5] / freqs[5]; // warped(10kHz) / 10kHz
    assert!(
        ratio_low > ratio_high,
        "LF should get more relative expansion: ratio_50Hz={:.3}, ratio_10kHz={:.3}",
        ratio_low,
        ratio_high
    );
}

#[test]
fn test_warped_biquad_zero_lambda_matches_standard() {
    // With λ=0 every allpass degenerates to z^-1, so the warped biquad
    // must produce identical output to a standard biquad.
    let mut standard = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, -6.0);
    let mut warped = WarpedBiquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, -6.0, 0.0);

    let signal: Vec<f64> = (0..1000).map(|i| ((i as f64) * 0.1).sin()).collect();

    for (n, &x) in signal.iter().enumerate() {
        let y_std = standard.process(x);
        let y_wrp = warped.process(x);
        assert!(
            (y_std - y_wrp).abs() < 1e-12,
            "λ=0 mismatch at sample {}: standard={} warped={}",
            n,
            y_std,
            y_wrp
        );
    }
}

#[test]
fn test_warped_biquad_bark_resolution() {
    // With Bark λ, the effective linear-frequency bandwidth of a fixed-Q peak
    // filter should be narrower at 100 Hz than at 10 kHz, because the warping
    // concentrates resolution at low frequencies.
    let lambda = bark_lambda(48000.0_f64);
    let srate = 48000.0_f64;

    let low_filter = WarpedBiquad::new(BiquadFilterType::Peak, 100.0, srate, 2.0, -6.0, lambda);
    let high_filter = WarpedBiquad::new(BiquadFilterType::Peak, 10000.0, srate, 2.0, -6.0, lambda);

    let measure_bw = |filter: &WarpedBiquad<f64>, center: f64| -> f64 {
        let peak_db = filter.log_result(center);
        // For a cut filter, the "passband" target is 3 dB above the trough.
        let threshold = peak_db + 3.0;
        let mut first_cross = 0.0_f64;
        let mut in_band = false;
        let nyquist = (srate / 2.0) as usize;
        for i in 1..nyquist {
            let f = i as f64;
            let db = filter.log_result(f);
            if !in_band && db < threshold {
                in_band = true;
                first_cross = f;
            }
            if in_band && db >= threshold {
                return f - first_cross;
            }
        }
        0.0
    };

    let low_bw = measure_bw(&low_filter, 100.0);
    let high_bw = measure_bw(&high_filter, 10000.0);

    assert!(
        low_bw > 0.0 && high_bw > 0.0,
        "bandwidth detection failed: low_bw={} high_bw={}",
        low_bw,
        high_bw
    );
    assert!(
        low_bw < high_bw,
        "expected narrower BW at 100 Hz than at 10 kHz with Bark warping, \
             got low_bw={:.1} high_bw={:.1}",
        low_bw,
        high_bw
    );
}

#[test]
fn test_center_gain_matches_design() {
    // The warped filter at its physical center frequency should produce
    // approximately the designed gain (within 0.5 dB).
    let lambda = bark_lambda(48000.0_f64);
    let gain_db = -6.0_f64;
    let filter = WarpedBiquad::new(BiquadFilterType::Peak, 500.0, 48000.0, 4.0, gain_db, lambda);
    let actual_db = filter.log_result(500.0);
    assert!(
        (actual_db - gain_db).abs() < 0.5,
        "center gain mismatch: expected {} dB, got {} dB",
        gain_db,
        actual_db
    );
}

#[test]
fn test_warped_biquad_f32() {
    let lambda: f32 = bark_lambda(48000.0_f32);
    let mut filter =
        WarpedBiquad::<f32>::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 3.0, lambda);
    for i in 0..100 {
        let x = (i as f32 * 0.1).sin();
        let y = filter.process(x);
        assert!(y.is_finite(), "f32 output not finite at sample {}", i);
    }
}

#[test]
fn test_process_block_matches_process() {
    let lambda = bark_lambda(48000.0_f64);
    let mut sample_by_sample =
        WarpedBiquad::new(BiquadFilterType::Peak, 400.0, 48000.0, 2.0, -3.0, lambda);
    let mut block = WarpedBiquad::new(BiquadFilterType::Peak, 400.0, 48000.0, 2.0, -3.0, lambda);

    let signal: Vec<f64> = (0..256).map(|i| ((i as f64) * 0.05).sin()).collect();
    let mut block_signal = signal.clone();

    let mut expected: Vec<f64> = Vec::with_capacity(256);
    for &x in &signal {
        expected.push(sample_by_sample.process(x));
    }

    block.process_block(&mut block_signal);

    for (i, (&e, &g)) in expected.iter().zip(block_signal.iter()).enumerate() {
        assert!(
            (e - g).abs() < 1e-14,
            "process vs process_block mismatch at sample {}: {} vs {}",
            i,
            e,
            g
        );
    }
}

#[test]
fn test_small_denom_clamped_f32() {
    // Issue #3: compute_implicit_consts uses an absolute 1e-15 threshold
    // that is smaller than f32::EPSILON.  For a raw denominator of ~1e-6
    // the old code returns inv_denom ≈ 1e6, which is numerically unstable.
    let lambda = 0.876f32;
    // Coefficients chosen so that raw_denom ≈ 1e-6 in f32 arithmetic.
    let a1 = (1e-6f32 - 1.0f32) / lambda;
    let (inv_denom, _) = compute_implicit_consts::<f32>(a1, 0.0f32, lambda);
    // After the fix inv_denom should be clamped to a reasonable magnitude.
    assert!(
        inv_denom.abs() < 1e4,
        "inv_denom should be clamped for small denominators in f32, got {}",
        inv_denom
    );
}

#[test]
fn test_small_denom_preserves_sign_f32() {
    // When the denominator is clamped the sign must be preserved so that
    // the filter phase is not silently flipped.
    let lambda = 0.876f32;
    // Negative raw_denom ≈ -1e-6
    let a1 = (-1e-6f32 - 1.0f32) / lambda;
    let (inv_denom, _) = compute_implicit_consts::<f32>(a1, 0.0f32, lambda);
    assert!(
        inv_denom < 0.0,
        "clamped inv_denom should preserve negative sign, got {}",
        inv_denom
    );
}
