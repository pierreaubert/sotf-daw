use crate::traits::{FilterFloat, lit};

/// Compute the Bark-scale warping coefficient for a given sample rate.
///
/// Formula: λ = 1.0674 * sqrt(2/π * arctan(0.06583 * fs)) - 0.1916
///
/// At 48 kHz, λ ≈ 0.876, which approximates the Bark frequency scale,
/// concentrating filter resolution where human hearing is most sensitive
/// to room modes (below ~500 Hz).
pub fn bark_lambda<T: FilterFloat>(sample_rate: T) -> T {
    let two_over_pi = lit::<T>(2.0) / T::PI();
    let inner = (lit::<T>(0.06583) * sample_rate).atan();
    lit::<T>(1.0674) * (two_over_pi * inner).sqrt() - lit::<T>(0.1916)
}

/// Map a physical frequency to the warped frequency domain.
///
/// ω_physical = 2π·freq / srate
/// ω_warped   = arctan((1 - λ²)·sin(ω) / ((1 + λ²)·cos(ω) - 2λ))
///
/// The returned value is in Hz (suitable for passing to a standard biquad
/// constructor as its `freq` argument).
pub fn warp_frequency<T: FilterFloat>(freq_hz: T, sample_rate: T, lambda: T) -> T {
    let omega = lit::<T>(2.0) * T::PI() * freq_hz / sample_rate;

    // The first-order allpass D(z) = (z^-1 - λ)/(1 - λz^-1) maps
    // e^(jω) → e^(jω_w) where:
    //   ω_w = ω + 2·arctan(λ·sin(ω) / (1 - λ·cos(ω)))
    // With λ > 0, this expands LF and compresses HF (Bark-like).
    let correction = lit::<T>(2.0) * (lambda * omega.sin()).atan2(T::one() - lambda * omega.cos());
    let omega_w = omega + correction;

    // Convert back to Hz, clamped to [0, Nyquist]
    let hz = omega_w * sample_rate / (lit::<T>(2.0) * T::PI());
    hz.max(T::zero()).min(sample_rate / lit::<T>(2.0))
}

/// Map a warped frequency back to the physical frequency domain.
///
/// Inverse of [`warp_frequency`]. The sign of the `2λ` term is flipped
/// relative to the forward transform.
pub fn unwarp_frequency<T: FilterFloat>(warped_hz: T, sample_rate: T, lambda: T) -> T {
    let omega_w = lit::<T>(2.0) * T::PI() * warped_hz / sample_rate;
    // Inverse of warp: use -λ in the same formula
    let neg_lambda = T::zero() - lambda;
    let correction =
        lit::<T>(2.0) * (neg_lambda * omega_w.sin()).atan2(T::one() - neg_lambda * omega_w.cos());
    let omega = omega_w + correction;

    let hz = omega * sample_rate / (lit::<T>(2.0) * T::PI());
    hz.max(T::zero()).min(sample_rate / lit::<T>(2.0))
}

/// Apply one first-order allpass section and return its output.
///
/// Transfer function: A(z) = (z^-1 − λ)/(1 − λ·z^-1)
///
/// Recurrence:
/// ```text
/// w      = input − λ·state
/// output = λ·w + state
/// state  ← w
/// ```
/// With λ = 0 this reduces to a unit delay: output = state, state ← input.
#[inline(always)]
pub(super) fn allpass_step<T: FilterFloat>(input: T, state: &mut T, lambda: T) -> T {
    let w = input - lambda * *state;
    let out = lambda * w + *state;
    *state = w;
    out
}

/// Precompute the constants needed for the closed-form implicit-equation solution.
///
/// Returns `(inv_denom, one_minus_lam_sq)` where:
/// - `inv_denom = 1 / (1 + a1·λ + a2·λ²)` — the denominator of the solved y[n]
/// - `one_minus_lam_sq = 1 − λ²`
#[inline]
pub(super) fn compute_implicit_consts<T: FilterFloat>(a1: T, a2: T, lambda: T) -> (T, T) {
    let lambda_sq = lambda * lambda;
    let one_minus_lam_sq = T::one() - lambda_sq;
    let raw_denom = T::one() + a1 * lambda + a2 * lambda_sq;

    // Issue #3: use a type-aware threshold based on the coefficient scale
    // rather than an absolute 1e-15 that is below f32::EPSILON.
    let coeff_scale = (T::one() + a1.abs() + a2.abs()).max(T::one());
    let eps = T::epsilon() * lit(1000.0) * coeff_scale;
    let inv_denom = if raw_denom.abs() > eps {
        T::one() / raw_denom
    } else {
        // Sign-preserving clamped fallback instead of pass-through.
        let sign = if raw_denom >= T::zero() {
            T::one()
        } else {
            -T::one()
        };
        T::one() / (sign * eps)
    };
    (inv_denom, one_minus_lam_sq)
}
