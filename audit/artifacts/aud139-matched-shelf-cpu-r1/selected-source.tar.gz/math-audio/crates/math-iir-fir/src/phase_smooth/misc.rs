use std::f64::consts::PI;

/// Interpolate phase in the complex domain to avoid wrap artifacts
///
/// This function interpolates phase by converting to unit complex numbers,
/// interpolating in the complex plane, and converting back to phase.
/// This avoids artifacts that occur when linearly interpolating near ±π.
///
/// # Arguments
/// * `src_freqs` - Source frequency points in Hz
/// * `src_phase_rad` - Source phase values in radians
/// * `target_freqs` - Target frequency points for interpolation
///
/// # Returns
/// * Interpolated phase values in radians at target frequencies
pub fn interpolate_phase_complex(
    src_freqs: &[f64],
    src_phase_rad: &[f64],
    target_freqs: &[f64],
) -> Vec<f64> {
    if src_freqs.is_empty() || src_phase_rad.is_empty() {
        return vec![0.0; target_freqs.len()];
    }

    target_freqs
        .iter()
        .map(|&f| {
            // Find bracketing indices
            let (lower_idx, upper_idx, t) = find_interpolation_indices(src_freqs, f);

            if lower_idx == upper_idx {
                return src_phase_rad[lower_idx];
            }

            // Convert to unit complex numbers
            let phase_low = src_phase_rad[lower_idx];
            let phase_high = src_phase_rad[upper_idx];

            let z_low = (phase_low.cos(), phase_low.sin());
            let z_high = (phase_high.cos(), phase_high.sin());

            // Interpolate in complex plane
            let z_interp = (
                z_low.0 + t * (z_high.0 - z_low.0),
                z_low.1 + t * (z_high.1 - z_low.1),
            );

            // Convert back to phase
            z_interp.1.atan2(z_interp.0)
        })
        .collect()
}

/// Unwrap phase by removing 2π discontinuities
///
/// This function detects jumps greater than π and adjusts subsequent
/// values to create a continuous phase curve.
///
/// # Arguments
/// * `phase_rad` - Phase values in radians (may have wrapping)
///
/// # Returns
/// * Unwrapped phase values (continuous)
pub fn unwrap_phase(phase_rad: &[f64]) -> Vec<f64> {
    if phase_rad.is_empty() {
        return Vec::new();
    }

    let two_pi = 2.0 * PI;
    let mut unwrapped = Vec::with_capacity(phase_rad.len());
    unwrapped.push(phase_rad[0]);

    for i in 1..phase_rad.len() {
        let diff = phase_rad[i] - phase_rad[i - 1];
        // Wrap diff to [-π, π], handling arbitrarily large jumps
        let wrapped_diff = diff - two_pi * (diff / two_pi).round();
        unwrapped.push(unwrapped[i - 1] + wrapped_diff);
    }

    unwrapped
}

/// Compute group delay from unwrapped phase
///
/// Group delay is defined as: τ_g(ω) = -dφ/dω = -dφ/df * (1/2π)
///
/// This function uses central differences for interior points and
/// forward/backward differences at the boundaries.
///
/// # Arguments
/// * `freqs` - Frequency points in Hz
/// * `phase_rad` - Unwrapped phase values in radians
///
/// # Returns
/// * Group delay in seconds at each frequency point
pub(super) fn compute_group_delay(freqs: &[f64], phase_rad: &[f64]) -> Vec<f64> {
    let n = freqs.len();
    if n < 2 {
        return vec![0.0; n];
    }

    let mut group_delay = Vec::with_capacity(n);

    const MIN_DF: f64 = 1e-9;

    // Forward difference at start
    let df_start = (freqs[1] - freqs[0]).max(MIN_DF);
    let dphi_start = phase_rad[1] - phase_rad[0];
    group_delay.push(-dphi_start / (2.0 * PI * df_start));

    // Central differences for interior points
    for i in 1..n - 1 {
        let df = (freqs[i + 1] - freqs[i - 1]).max(MIN_DF);
        let dphi = phase_rad[i + 1] - phase_rad[i - 1];
        group_delay.push(-dphi / (2.0 * PI * df));
    }

    // Backward difference at end
    let df_end = (freqs[n - 1] - freqs[n - 2]).max(MIN_DF);
    let dphi_end = phase_rad[n - 1] - phase_rad[n - 2];
    group_delay.push(-dphi_end / (2.0 * PI * df_end));

    group_delay
}

/// Integrate group delay back to phase
///
/// Uses trapezoidal integration: φ(f) = φ₀ - 2π ∫ τ_g(f) df
///
/// # Arguments
/// * `freqs` - Frequency points in Hz
/// * `group_delay` - Group delay values in seconds
/// * `initial_phase` - Initial phase value (at first frequency)
///
/// # Returns
/// * Reconstructed phase values in radians
pub(super) fn integrate_group_delay(
    freqs: &[f64],
    group_delay: &[f64],
    initial_phase: f64,
) -> Vec<f64> {
    if freqs.is_empty() || group_delay.is_empty() {
        return Vec::new();
    }

    let mut phase = Vec::with_capacity(freqs.len());
    phase.push(initial_phase);

    for i in 1..freqs.len() {
        let df = freqs[i] - freqs[i - 1];
        // Trapezoidal integration
        let avg_gd = (group_delay[i] + group_delay[i - 1]) / 2.0;
        // φ = φ_prev - 2π * τ_g * Δf
        let new_phase = phase[i - 1] - 2.0 * PI * avg_gd * df;
        phase.push(new_phase);
    }

    phase
}

/// Find interpolation indices and parameter for a target frequency
///
/// Returns (lower_idx, upper_idx, t) where t is the interpolation parameter [0, 1]
/// in log space.
pub(super) fn find_interpolation_indices(freqs: &[f64], target_freq: f64) -> (usize, usize, f64) {
    if freqs.is_empty() {
        return (0, 0, 0.0);
    }

    if target_freq <= freqs[0] || target_freq <= 0.0 {
        return (0, 0, 0.0);
    }

    if target_freq >= freqs[freqs.len() - 1] {
        let last = freqs.len() - 1;
        return (last, last, 0.0);
    }

    // Binary search for the interval
    let mut lower = 0;
    let mut upper = freqs.len() - 1;

    while upper - lower > 1 {
        let mid = (lower + upper) / 2;
        if freqs[mid] <= target_freq {
            lower = mid;
        } else {
            upper = mid;
        }
    }

    // Compute log-space interpolation parameter
    let log_target = target_freq.ln();
    let log_low = freqs[lower].ln();
    let log_high = freqs[upper].ln();

    let t = if (log_high - log_low).abs() > 1e-10 {
        (log_target - log_low) / (log_high - log_low)
    } else {
        0.0
    };

    (lower, upper, t.clamp(0.0, 1.0))
}
