use super::misc::compute_group_delay;
use super::misc::integrate_group_delay;
use super::misc::unwrap_phase;

/// Smooth phase via group delay smoothing
///
/// This function takes measured phase data and smooths it by:
/// 1. Unwrapping the phase to remove 2π discontinuities
/// 2. Computing group delay (negative derivative of phase vs frequency)
/// 3. Smoothing the group delay using octave-based averaging
/// 4. Integrating back to get smoothed phase
///
/// # Arguments
/// * `freqs` - Frequency points in Hz (must be positive and sorted ascending)
/// * `phase_rad` - Phase values in radians at each frequency point
/// * `smoothing_octaves` - Smoothing width in octaves (e.g., 0.167 for 1/6 octave)
///
/// # Returns
/// * Smoothed phase values in radians
///
/// # Example
/// ```
/// use math_audio_iir_fir::smooth_phase_via_group_delay;
///
/// let freqs = vec![100.0, 200.0, 400.0, 800.0, 1600.0];
/// let phase_rad = vec![0.0, -0.5, -1.0, -1.5, -2.0];
/// let smoothed = smooth_phase_via_group_delay(&freqs, &phase_rad, 0.167);
/// assert_eq!(smoothed.len(), phase_rad.len());
/// ```
pub fn smooth_phase_via_group_delay(
    freqs: &[f64],
    phase_rad: &[f64],
    smoothing_octaves: f64,
) -> Vec<f64> {
    if freqs.is_empty() || phase_rad.is_empty() {
        return Vec::new();
    }

    if freqs.len() != phase_rad.len() {
        return phase_rad.to_vec(); // Return unchanged if mismatched
    }

    if freqs.len() < 3 {
        return phase_rad.to_vec(); // Need at least 3 points for derivatives
    }

    // Step 1: Unwrap phase
    let unwrapped = unwrap_phase(phase_rad);

    // Step 2: Compute group delay
    let group_delay = compute_group_delay(freqs, &unwrapped);

    // Step 3: Smooth group delay using octave averaging
    let smoothed_gd = smooth_octave(freqs, &group_delay, smoothing_octaves);

    // Step 4: Integrate back to phase
    integrate_group_delay(freqs, &smoothed_gd, unwrapped[0])
}

/// Smooth data using octave-based averaging
///
/// For each frequency point, averages all values within ±half_octaves
/// of that frequency (in log space).
///
/// # Arguments
/// * `freqs` - Frequency points in Hz
/// * `values` - Values to smooth
/// * `smoothing_octaves` - Total smoothing width in octaves
///
/// # Returns
/// * Smoothed values
pub(super) fn smooth_octave(freqs: &[f64], values: &[f64], smoothing_octaves: f64) -> Vec<f64> {
    if freqs.is_empty() || values.is_empty() || smoothing_octaves <= 0.0 {
        return values.to_vec();
    }

    let half_octaves = smoothing_octaves / 2.0;
    let ratio = 2.0_f64.powf(half_octaves);

    freqs
        .iter()
        .enumerate()
        .map(|(i, &f)| {
            if f <= 0.0 {
                return values[i];
            }

            let f_low = f / ratio;
            let f_high = f * ratio;

            let mut sum = 0.0;
            let mut count = 0;

            for (j, &freq) in freqs.iter().enumerate() {
                if freq >= f_low && freq <= f_high {
                    sum += values[j];
                    count += 1;
                }
            }

            if count > 0 {
                sum / count as f64
            } else {
                values[i]
            }
        })
        .collect()
}
