use super::super::biquad::BiquadFilterType;
use super::consts::K_AUNBANDEQ_FILTER_TYPE_BAND_PASS;
use super::consts::K_AUNBANDEQ_FILTER_TYPE_HIGH_SHELF;
use super::consts::K_AUNBANDEQ_FILTER_TYPE_LOW_SHELF;
use super::consts::K_AUNBANDEQ_FILTER_TYPE_PARAMETRIC;
use super::consts::K_AUNBANDEQ_FILTER_TYPE_RESONANT_HIGH_PASS;
use super::consts::K_AUNBANDEQ_FILTER_TYPE_RESONANT_LOW_PASS;

/// Convert BiquadFilterType to RME format code
///
/// # Arguments
/// * `filter_type` - The biquad filter type
/// * `pos` - The position (1-based index) of the filter in the chain
///
/// # Returns
/// * RME type code as f64, or -1.0 if unsupported
///
/// # Notes
/// RME format codes depend on both filter type and position:
/// - PK (Peak): 0.0
/// - LP (Lowpass): 3.0 at pos 1, 2.0 at pos 3 or 9
/// - HP (Highpass): 2.0 at pos 1, 3.0 at pos 3 or 9
/// - LS/HS (Lowshelf/Highshelf): 1.0 at pos 1, 3, or 9
pub(super) fn biquad_to_rme_type(filter_type: BiquadFilterType, pos: usize) -> f64 {
    match filter_type {
        BiquadFilterType::Peak => 0.0,
        BiquadFilterType::Lowpass => {
            if pos == 1 {
                3.0
            } else if pos == 3 || pos == 9 {
                2.0
            } else {
                -1.0
            }
        }
        BiquadFilterType::Highpass | BiquadFilterType::HighpassVariableQ => {
            if pos == 1 {
                2.0
            } else if pos == 3 || pos == 9 {
                3.0
            } else {
                -1.0
            }
        }
        BiquadFilterType::Lowshelf | BiquadFilterType::Highshelf
            if (pos == 1 || pos == 3 || pos == 9) =>
        {
            1.0
        }
        _ => -1.0,
    }
}

/// Convert BiquadFilterType to Apple AUNBandEQ filter type constant
///
/// # Arguments
/// * `filter_type` - The biquad filter type
///
/// # Returns
/// * Apple AUNBandEQ filter type constant, or -1 if unsupported
pub(super) fn biquad_to_apple_type(filter_type: BiquadFilterType) -> i32 {
    match filter_type {
        BiquadFilterType::Peak => K_AUNBANDEQ_FILTER_TYPE_PARAMETRIC,
        BiquadFilterType::Highshelf => K_AUNBANDEQ_FILTER_TYPE_HIGH_SHELF,
        BiquadFilterType::Lowshelf => K_AUNBANDEQ_FILTER_TYPE_LOW_SHELF,
        BiquadFilterType::Highpass | BiquadFilterType::HighpassVariableQ => {
            K_AUNBANDEQ_FILTER_TYPE_RESONANT_HIGH_PASS
        }
        BiquadFilterType::Lowpass => K_AUNBANDEQ_FILTER_TYPE_RESONANT_LOW_PASS,
        BiquadFilterType::Bandpass => K_AUNBANDEQ_FILTER_TYPE_BAND_PASS,
        _ => -1,
    }
}
