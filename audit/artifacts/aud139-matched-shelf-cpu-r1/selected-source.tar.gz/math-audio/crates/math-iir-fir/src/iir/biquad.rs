//! Biquad IIR filter types and implementations.

use crate::error::IirError;
use crate::traits::{FilterFloat, lit};
use crate::{DEFAULT_Q_HIGH_LOW_PASS, DEFAULT_Q_HIGH_LOW_SHELF};
use ndarray::Array1;
use num_complex::Complex;
use std::fmt;

mod biquad_coefficients;
mod biquad_filter_type;
#[cfg(test)]
mod tests;
mod types;

pub use biquad_coefficients::*;
pub use biquad_filter_type::*;
pub use types::*;

/// Represents a single biquad IIR filter.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(bound = "")]
pub struct Biquad<T: FilterFloat = f64> {
    /// The type of filter
    pub filter_type: BiquadFilterType,
    /// Center frequency in Hz
    pub freq: T,
    /// Sample rate in Hz
    pub srate: T,
    /// Q factor (quality factor)
    pub q: T,
    /// Gain in dB (for peaking and shelving filters)
    pub db_gain: T,
    /// Filter coefficients
    a1: T,
    a2: T,
    b0: T,
    b1: T,
    b2: T,
    /// Filter state for DF-I (for processing samples)
    x1: T,
    x2: T,
    y1: T,
    y2: T,
    /// Filter state for Transposed Direct Form II
    s1: T,
    s2: T,
    /// When true, use Transposed Direct Form II instead of Direct Form I.
    /// TDF-II has better numerical properties for high-Q narrow filters.
    #[serde(default)]
    pub use_tdf2: bool,
    /// Pre-computed coefficients for fast frequency response calculation
    r_up0: T,
    r_up1: T,
    r_up2: T,
    r_dw0: T,
    r_dw1: T,
    r_dw2: T,
}

/// Private form marker used for compile-time specialization of
/// `Biquad::process_block`.  The runtime `use_tdf2` flag is resolved once per
/// block; the inner loop is monomorphized for the selected form and contains
/// no per-sample branch.
trait BiquadForm {
    fn process_sample<T: FilterFloat>(b: &mut Biquad<T>, input: T) -> T;
}

struct Tdf2Form;
impl BiquadForm for Tdf2Form {
    #[inline(always)]
    fn process_sample<T: FilterFloat>(b: &mut Biquad<T>, input: T) -> T {
        let output = b.b0 * input + b.s1;
        b.s1 = b.b1 * input - b.a1 * output + b.s2;
        b.s2 = b.b2 * input - b.a2 * output;
        output
    }
}

impl<T: FilterFloat> Biquad<T> {
    /// Creates and initializes a new Biquad filter.
    ///
    /// This constructor applies default Q values for certain filter types and clamps
    /// invalid Q values to a minimum of 0.01 for numerical stability.
    ///
    /// # Arguments
    ///
    /// * `filter_type` - The type of filter to create
    /// * `freq` - Center/cutoff frequency in Hz
    /// * `srate` - Sample rate in Hz
    /// * `q` - Q factor (quality factor). Use 0.0 for default.
    /// * `db_gain` - Gain in dB (only used for Peak, Lowshelf, Highshelf)
    ///
    /// # Panics
    ///
    /// This method does not panic but silently clamps invalid parameters.
    /// Use [`try_new`](Self::try_new) for explicit error handling.
    pub fn new(filter_type: BiquadFilterType, freq: T, srate: T, q: T, db_gain: T) -> Self {
        let zero = T::zero();
        let srate = if srate.is_finite() && srate > zero {
            srate
        } else {
            lit(48_000.0)
        };
        let nyquist = srate / lit(2.0);
        // RBJ formulas contain `1 - cos(omega)`, which rounds to zero when
        // omega is only machine epsilon away from an endpoint. A sqrt(epsilon)
        // relative margin keeps fallback coefficients non-degenerate for both
        // f32 and f64 while leaving every valid in-band frequency untouched.
        let frequency_margin = nyquist * T::epsilon().sqrt();
        let freq = if !freq.is_finite() || freq <= zero {
            frequency_margin
        } else if freq >= nyquist {
            nyquist - frequency_margin
        } else {
            freq
        };
        let db_gain = if db_gain.is_finite() { db_gain } else { zero };
        let mut biquad = Biquad {
            filter_type,
            freq,
            srate,
            q,
            db_gain,
            a1: zero,
            a2: zero,
            b0: zero,
            b1: zero,
            b2: zero,
            x1: zero,
            x2: zero,
            y1: zero,
            y2: zero,
            s1: zero,
            s2: zero,
            use_tdf2: false,
            r_up0: zero,
            r_up1: zero,
            r_up2: zero,
            r_dw0: zero,
            r_dw1: zero,
            r_dw2: zero,
        };

        // Adjust Q based on filter type, matching Python logic
        if biquad.q == zero {
            match biquad.filter_type {
                BiquadFilterType::Notch => {
                    biquad.q = lit(30.0);
                }
                BiquadFilterType::Bandpass
                | BiquadFilterType::Highpass
                | BiquadFilterType::Lowpass => {
                    biquad.q = lit(DEFAULT_Q_HIGH_LOW_PASS);
                }
                BiquadFilterType::Lowshelf
                | BiquadFilterType::Highshelf
                | BiquadFilterType::LowshelfOrf
                | BiquadFilterType::HighshelfOrf => {
                    biquad.q = lit(DEFAULT_Q_HIGH_LOW_SHELF);
                }
                _ => {}
            }
        }

        // Safety clamp: ensure strictly positive Q to avoid division by zero in alpha = sn/(2*q)
        if biquad.q <= zero {
            biquad.q = lit(1.0e-2);
        }

        biquad.compute_coeffs();
        biquad
    }

    /// Creates a new Biquad filter with validation.
    ///
    /// Unlike [`new`](Self::new), this method returns an error for invalid parameters
    /// instead of silently clamping them.
    ///
    /// # Arguments
    ///
    /// * `filter_type` - The type of filter to create
    /// * `freq` - Center/cutoff frequency in Hz (must be > 0 and < Nyquist)
    /// * `srate` - Sample rate in Hz (must be > 0)
    /// * `q` - Q factor (must be > 0, or 0.0 for default)
    /// * `db_gain` - Gain in dB (must be finite)
    ///
    /// # Errors
    ///
    /// Returns `IirError::InvalidSampleRate` if sample rate is <= 0.
    /// Returns `IirError::InvalidFrequency` if frequency is <= 0 or >= Nyquist.
    /// Returns `IirError::InvalidQ` if Q is negative (but not zero, which uses default).
    /// Returns `IirError::InvalidGain` if gain is not finite.
    ///
    /// # Example
    ///
    /// ```rust
    /// use math_audio_iir_fir::{Biquad, BiquadFilterType};
    ///
    /// // Valid filter
    /// let filter = Biquad::try_new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 3.0)
    ///     .expect("valid parameters");
    ///
    /// // Invalid frequency (above Nyquist)
    /// let result = Biquad::try_new(BiquadFilterType::Peak, 30000.0, 48000.0, 2.0, 0.0);
    /// assert!(result.is_err());
    /// ```
    pub fn try_new(
        filter_type: BiquadFilterType,
        freq: T,
        srate: T,
        q: T,
        db_gain: T,
    ) -> Result<Self, IirError> {
        let zero = T::zero();

        // Validate sample rate
        if srate <= zero || !srate.is_finite() {
            return Err(IirError::InvalidSampleRate {
                sample_rate: srate.to_f64().unwrap_or(0.0),
            });
        }

        let nyquist = srate / lit(2.0);

        // Validate frequency
        if freq <= zero || freq >= nyquist || !freq.is_finite() {
            return Err(IirError::InvalidFrequency {
                freq: freq.to_f64().unwrap_or(0.0),
                nyquist: nyquist.to_f64().unwrap_or(0.0),
            });
        }

        // Validate Q (0.0 is allowed as it means "use default")
        if q < zero || (q != zero && !q.is_finite()) {
            return Err(IirError::InvalidQ {
                q: q.to_f64().unwrap_or(0.0),
            });
        }

        // Validate gain
        if !db_gain.is_finite() {
            return Err(IirError::InvalidGain {
                gain_db: db_gain.to_f64().unwrap_or(0.0),
            });
        }

        Ok(Self::new(filter_type, freq, srate, q, db_gain))
    }

    /// Update filter parameters and recompute coefficients **without** resetting
    /// the internal delay state (x1, x2, y1, y2). This allows click-free
    /// parameter changes on a running filter.
    pub fn update_params(
        &mut self,
        filter_type: BiquadFilterType,
        freq: T,
        srate: T,
        q: T,
        db_gain: T,
    ) {
        let zero = T::zero();
        let srate = if srate.is_finite() && srate > zero {
            srate
        } else {
            lit(48_000.0)
        };
        let nyquist = srate / lit(2.0);
        let frequency_margin = nyquist * T::epsilon().sqrt();
        let freq = if !freq.is_finite() || freq <= zero {
            frequency_margin
        } else if freq >= nyquist {
            nyquist - frequency_margin
        } else {
            freq
        };
        let db_gain = if db_gain.is_finite() { db_gain } else { zero };
        self.filter_type = filter_type;
        self.freq = freq;
        self.srate = srate;
        self.q = if q == zero {
            match filter_type {
                BiquadFilterType::Notch => lit(30.0),
                BiquadFilterType::Bandpass
                | BiquadFilterType::Highpass
                | BiquadFilterType::Lowpass => lit(DEFAULT_Q_HIGH_LOW_PASS),
                BiquadFilterType::Lowshelf
                | BiquadFilterType::Highshelf
                | BiquadFilterType::LowshelfOrf
                | BiquadFilterType::HighshelfOrf => lit(DEFAULT_Q_HIGH_LOW_SHELF),
                _ => q,
            }
        } else {
            q
        };
        if self.q <= zero {
            self.q = lit(1.0e-2);
        }
        self.db_gain = db_gain;
        self.compute_coeffs();
    }

    fn compute_coeffs(&mut self) {
        // Intermediate variables
        let a: T = lit::<T>(10.0).powf(self.db_gain / lit(40.0));
        let omega: T = lit::<T>(2.0) * T::PI() * self.freq / self.srate;
        let sn = omega.sin();
        let cs = omega.cos();
        let alpha = sn / (lit::<T>(2.0) * self.q);
        let beta = (a + a).sqrt();

        // Raw coefficients
        let (b0, b1, b2, a0, a1, a2);

        let zero = T::zero();
        let one = T::one();
        let two: T = lit(2.0);
        let four: T = lit(4.0);
        let half: T = lit(0.5);

        match self.filter_type {
            BiquadFilterType::Lowpass => {
                b0 = (one - cs) / two;
                b1 = one - cs;
                b2 = (one - cs) / two;
                a0 = one + alpha;
                a1 = -two * cs;
                a2 = one - alpha;
            }
            BiquadFilterType::Highpass | BiquadFilterType::HighpassVariableQ => {
                b0 = (one + cs) / two;
                b1 = -(one + cs);
                b2 = (one + cs) / two;
                a0 = one + alpha;
                a1 = -two * cs;
                a2 = one - alpha;
            }
            BiquadFilterType::Bandpass => {
                b0 = alpha;
                b1 = zero;
                b2 = -alpha;
                a0 = one + alpha;
                a1 = -two * cs;
                a2 = one - alpha;
            }
            BiquadFilterType::Notch => {
                b0 = one;
                b1 = -two * cs;
                b2 = one;
                a0 = one + alpha;
                a1 = -two * cs;
                a2 = one - alpha;
            }
            BiquadFilterType::Peak => {
                b0 = one + (alpha * a);
                b1 = -two * cs;
                b2 = one - (alpha * a);
                a0 = one + (alpha / a);
                a1 = -two * cs;
                a2 = one - (alpha / a);
            }
            BiquadFilterType::Lowshelf => {
                b0 = a * ((a + one) - (a - one) * cs + beta * sn);
                b1 = two * a * ((a - one) - (a + one) * cs);
                b2 = a * ((a + one) - (a - one) * cs - beta * sn);
                a0 = (a + one) + (a - one) * cs + beta * sn;
                a1 = -two * ((a - one) + (a + one) * cs);
                a2 = (a + one) + (a - one) * cs - beta * sn;
            }
            BiquadFilterType::Highshelf => {
                b0 = a * ((a + one) + (a - one) * cs + beta * sn);
                b1 = -two * a * ((a - one) + (a + one) * cs);
                b2 = a * ((a + one) + (a - one) * cs - beta * sn);
                a0 = (a + one) - (a - one) * cs + beta * sn;
                a1 = two * ((a - one) - (a + one) * cs);
                a2 = (a + one) - (a - one) * cs - beta * sn;
            }
            BiquadFilterType::AllPass => {
                b0 = one - alpha;
                b1 = -two * cs;
                b2 = one + alpha;
                a0 = one + alpha;
                a1 = -two * cs;
                a2 = one - alpha;
            }
            BiquadFilterType::LowshelfOrf => {
                let g: T = lit::<T>(10.0).powf(self.db_gain / lit(20.0));
                let a_val: T = lit::<T>(10.0).powf(self.db_gain / lit(40.0));
                let beta_rbj = (a_val + a_val).sqrt();
                a0 = (a_val + one) + (a_val - one) * cs + beta_rbj * sn;
                a1 = -two * ((a_val - one) + (a_val + one) * cs);
                a2 = (a_val + one) + (a_val - one) * cs - beta_rbj * sn;

                let sum_a = a0 + a1 + a2;
                let diff_a = a0 - a1 + a2;
                let sum_b = g * sum_a;
                let diff_b = diff_a;

                b1 = (sum_b - diff_b) / two;
                let p = (sum_b + diff_b) / two;

                let w0 = omega;
                let cos_2w0 = (two * w0).cos();
                let sin_2w0 = (two * w0).sin();

                let a_re = a0 + a1 * cs + a2 * cos_2w0;
                let a_im = -a1 * sn - a2 * sin_2w0;
                let den_w0_sq = a_re * a_re + a_im * a_im;
                let target = g * den_w0_sq;

                let c1 = two * b1 * p * cs;
                let known = p * p / two + b1 * b1 + c1 + p * p / two * cos_2w0;
                let d_coeff = half - half * cos_2w0;

                // Orfanidis solves a quadratic for the remaining numerator
                // split. At pathological frequencies, the quadratic
                // coefficient can vanish; use the symmetric split (`d = 0`)
                // instead of amplifying roundoff with a near-zero divide.
                let eps: T = lit(1e-15);
                let d_sq = if d_coeff.abs() > eps {
                    (target - known) / d_coeff
                } else {
                    zero
                };
                let d_val = if d_sq >= zero { d_sq.sqrt() } else { zero };
                let d_signed = if g >= one { d_val } else { -d_val };

                b0 = (p + d_signed) / two;
                b2 = (p - d_signed) / two;
            }
            BiquadFilterType::HighshelfOrf => {
                let g: T = lit::<T>(10.0).powf(self.db_gain / lit(20.0));
                let a_val: T = lit::<T>(10.0).powf(self.db_gain / lit(40.0));
                let beta_rbj = (a_val + a_val).sqrt();
                a0 = (a_val + one) - (a_val - one) * cs + beta_rbj * sn;
                a1 = two * ((a_val - one) - (a_val + one) * cs);
                a2 = (a_val + one) - (a_val - one) * cs - beta_rbj * sn;

                let sum_a = a0 + a1 + a2;
                let diff_a = a0 - a1 + a2;
                let sum_b = sum_a;
                let diff_b = g * diff_a;

                b1 = (sum_b - diff_b) / two;
                let p = (sum_b + diff_b) / two;

                let w0 = omega;
                let cos_2w0 = (two * w0).cos();
                let sin_2w0 = (two * w0).sin();

                let a_re = a0 + a1 * cs + a2 * cos_2w0;
                let a_im = -a1 * sn - a2 * sin_2w0;
                let den_w0_sq = a_re * a_re + a_im * a_im;
                let target = g * den_w0_sq;

                let c1 = two * b1 * p * cs;
                let known = p * p / two + b1 * b1 + c1 + p * p / two * cos_2w0;
                let d_coeff = half - half * cos_2w0;

                // See the low-shelf Orfanidis fallback above.
                let eps: T = lit(1e-15);
                let d_sq = if d_coeff.abs() > eps {
                    (target - known) / d_coeff
                } else {
                    zero
                };
                let d_val = if d_sq >= zero { d_sq.sqrt() } else { zero };
                let d_signed = if g >= one { d_val } else { -d_val };

                b0 = (p + d_signed) / two;
                b2 = (p - d_signed) / two;
            }
            BiquadFilterType::PeakMatched => {
                let gain_lin: T = lit::<T>(10.0).powf(self.db_gain / lit(20.0));
                let gain_sq = gain_lin * gain_lin;
                let w0 = omega;
                let bw = w0 / self.q;
                let sigma = bw / two;
                let r = (-sigma).exp();
                let r_sq = r * r;

                a0 = one;
                a1 = -two * r * cs;
                a2 = r_sq;

                let sum_a = one + a1 + a2;
                let diff_a = one - a1 + a2;
                let sum_b = sum_a;
                let diff_b = diff_a;

                b1 = (sum_b - diff_b) / two;
                let p = (sum_b + diff_b) / two;

                let cos_2w0 = (two * w0).cos();
                let sin_2w0 = (two * w0).sin();
                let a_re = one + a1 * cs + a2 * cos_2w0;
                let a_im = -a1 * sn - a2 * sin_2w0;
                let den_w0_sq = a_re * a_re + a_im * a_im;
                let target_num_sq = gain_sq * den_w0_sq;

                let c1 = two * b1 * p * cs;
                let known = (p * p) / two + b1 * b1 + c1 + (p * p) / two * cos_2w0;
                let d_coeff = half - half * cos_2w0;

                // Vicanek's matched peak uses the same quadratic split; when
                // the coefficient collapses, use the symmetric numerator.
                let eps: T = lit(1e-15);
                let d_sq = if d_coeff.abs() > eps {
                    (target_num_sq - known) / d_coeff
                } else {
                    zero
                };
                let d_val = if d_sq >= zero { d_sq.sqrt() } else { zero };
                let d_signed = if gain_lin >= one { d_val } else { -d_val };

                b0 = (p + d_signed) / two;
                b2 = (p - d_signed) / two;
            }
        }

        // Guard against degenerate a0 (extreme parameter combos)
        let eps_a0: T = lit(1e-15);
        if a0.abs() < eps_a0 {
            self.b0 = one;
            self.b1 = zero;
            self.b2 = zero;
            self.a1 = zero;
            self.a2 = zero;
            self.r_up0 = one;
            self.r_up1 = zero;
            self.r_up2 = zero;
            self.r_dw0 = one;
            self.r_dw1 = zero;
            self.r_dw2 = zero;
            return;
        }

        // Normalize coefficients
        self.b0 = b0 / a0;
        self.b1 = b1 / a0;
        self.b2 = b2 / a0;
        self.a1 = a1 / a0;
        self.a2 = a2 / a0;

        // Pre-compute for result()
        self.r_up0 = (self.b0 + self.b1 + self.b2).powi(2);
        self.r_up1 = -four * (self.b0 * self.b1 + four * self.b0 * self.b2 + self.b1 * self.b2);
        self.r_up2 = lit::<T>(16.0) * self.b0 * self.b2;
        self.r_dw0 = (one + self.a1 + self.a2).powi(2);
        self.r_dw1 = -four * (self.a1 + four * self.a2 + self.a1 * self.a2);
        self.r_dw2 = lit::<T>(16.0) * self.a2;
    }

    /// Processes a single audio sample through the filter.
    ///
    /// When `use_tdf2` is true, uses Transposed Direct Form II which has
    /// better numerical properties for high-Q narrow filters.
    ///
    /// Denormal handling is caller-owned here; see the
    /// [FTZ policy](crate::denormals). For hot sample loops, wrap the loop in
    /// [`ScopedFlushToZero`](crate::denormals::ScopedFlushToZero) yourself, or
    /// prefer [`Biquad::process_block`], which enables FTZ for the whole block.
    pub fn process(&mut self, x: T) -> T {
        if self.use_tdf2 {
            self.process_tdf2(x)
        } else {
            self.process_df1(x)
        }
    }

    /// Processes a single sample using Direct Form I.
    #[inline(always)]
    fn process_df1(&mut self, x: T) -> T {
        let y = self.b0 * x + self.b1 * self.x1 + self.b2 * self.x2
            - self.a1 * self.y1
            - self.a2 * self.y2;

        self.x2 = self.x1;
        self.x1 = x;
        self.y2 = self.y1;
        self.y1 = y;

        y
    }

    /// Processes a single sample using Transposed Direct Form II.
    ///
    /// TDF-II uses two state variables (s1, s2) instead of four (x1, x2, y1, y2):
    /// ```text
    /// y  = b0*x + s1
    /// s1 = b1*x - a1*y + s2
    /// s2 = b2*x - a2*y
    /// ```
    ///
    /// This form has better numerical properties for high-Q narrow filters
    /// because it minimizes internal signal magnitudes.
    #[inline(always)]
    fn process_tdf2(&mut self, x: T) -> T {
        let y = self.b0 * x + self.s1;
        self.s1 = self.b1 * x - self.a1 * y + self.s2;
        self.s2 = self.b2 * x - self.a2 * y;
        y
    }

    /// Processes a block of audio samples in-place.
    ///
    /// This method is more efficient than calling `process` for each sample
    /// as it avoids repeated struct field access and allows for better optimization.
    ///
    /// The runtime `use_tdf2` flag is resolved once per block; the inner loop
    /// is monomorphized for the selected form and contains no per-sample
    /// branch.
    ///
    /// Enables Flush-to-Zero / Denormals-Are-Zero for the duration of the
    /// block via [`ScopedFlushToZero`](crate::denormals::ScopedFlushToZero)
    /// (restored on return); see the [FTZ policy](crate::denormals).
    #[inline(always)]
    pub fn process_block(&mut self, samples: &mut [T]) {
        let _ftz = crate::denormals::ScopedFlushToZero::new();
        // AVX2 fast path: on x86_64 with AVX2/FMA, process f64 DF1 blocks four
        // samples at a time in the main loop, then a two-sample tail, then a
        // scalar tail. TDF2 and non-f64 types keep the scalar fallback below.
        #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
        {
            if !self.use_tdf2 && std::any::TypeId::of::<T>() == std::any::TypeId::of::<f64>() {
                unsafe {
                    let b = &mut *(self as *mut Biquad<T> as *mut Biquad<f64>);
                    let s = std::slice::from_raw_parts_mut(
                        samples.as_mut_ptr() as *mut f64,
                        samples.len(),
                    );
                    Self::process_block_df1_avx2(b, s);
                }
                return;
            }
        }

        if self.use_tdf2 {
            self.process_block_form::<Tdf2Form>(samples);
        } else {
            self.process_block_df1_scalar(samples);
        }
    }

    /// Scalar DF1 block processor unrolled two samples per iteration.
    /// Coefficients and delay-line state are held in locals for the block so
    /// the inner loop has no struct-field traffic.  The second sample's
    /// feed-forward path is evaluated in parallel with the first sample's
    /// output, reducing the serial dependency chain while keeping the exact
    /// `Df1Form` arithmetic grouping (and therefore the checksum).
    #[inline(always)]
    fn process_block_df1_scalar(&mut self, samples: &mut [T]) {
        let b0 = self.b0;
        let b1 = self.b1;
        let b2 = self.b2;
        let a1 = self.a1;
        let a2 = self.a2;

        let mut x1 = self.x1;
        let mut x2 = self.x2;
        let mut y1 = self.y1;
        let mut y2 = self.y2;

        let mut ptr = samples.as_mut_ptr();
        let end = unsafe { ptr.add(samples.len()) };
        let pair_end = unsafe { ptr.add(samples.len() & !1) };

        unsafe {
            while ptr < pair_end {
                let x0 = *ptr;
                let x1_in = *ptr.add(1);

                // Sample 0: full output using the current state.
                let ff0 = b0.mul_add(x0, b1.mul_add(x1, b2 * x2));
                let fb0 = a1.mul_add(y1, a2 * y2);
                let y0 = ff0 - fb0;

                // Sample 1: feed-forward path is independent of y0.
                let ff1 = b0.mul_add(x1_in, b1.mul_add(x0, b2 * x1));
                let a2_y1 = a2 * y1;
                let fb1 = a1.mul_add(y0, a2_y1);
                let y1_out = ff1 - fb1;

                *ptr = y0;
                *ptr.add(1) = y1_out;

                // State after processing the second sample.
                x2 = x0;
                x1 = x1_in;
                y2 = y0;
                y1 = y1_out;

                ptr = ptr.add(2);
            }

            while ptr < end {
                let xi = *ptr;
                let yi = b0.mul_add(xi, b1.mul_add(x1, b2 * x2)) - a1.mul_add(y1, a2 * y2);
                *ptr = yi;
                x2 = x1;
                x1 = xi;
                y2 = y1;
                y1 = yi;
                ptr = ptr.add(1);
            }
        }

        self.x1 = x1;
        self.x2 = x2;
        self.y1 = y1;
        self.y2 = y2;
    }

    #[inline(always)]
    fn process_block_form<F: BiquadForm>(&mut self, samples: &mut [T]) {
        // Pointer walk avoids any per-iteration iterator bookkeeping and gives
        // the backend a contiguous memory access pattern to reason about.
        let mut ptr = samples.as_mut_ptr();
        let end = unsafe { ptr.add(samples.len()) };
        while ptr < end {
            let input = unsafe { *ptr };
            let output = F::process_sample(self, input);
            unsafe {
                *ptr = output;
                ptr = ptr.add(1);
            }
        }
    }

    /// AVX2/FMA fast path for f64 DF1 block processing.
    ///
    /// Processes four samples per main-loop iteration using 256-bit loads and
    /// stores, then falls back to the original two-sample AVX2 body and a
    /// scalar tail for any remaining samples.
    #[cfg(all(target_arch = "x86_64", target_feature = "avx2"))]
    #[target_feature(enable = "avx2,fma")]
    unsafe fn process_block_df1_avx2(b: &mut Biquad<f64>, samples: &mut [f64]) {
        use std::arch::x86_64::*;

        let mut x1 = b.x1;
        let mut x2 = b.x2;
        let mut y1 = b.y1;
        let mut y2 = b.y2;

        let len = samples.len();
        let mut ptr = samples.as_mut_ptr();
        let full_end = unsafe { ptr.add(len) };

        let quad_end = unsafe { ptr.add(len & !3) };
        while ptr < quad_end {
            let xvec = unsafe { _mm256_loadu_pd(ptr) };
            let x01 = _mm256_castpd256_pd128(xvec);
            let x23 = _mm256_extractf128_pd(xvec, 1);

            let xi0 = _mm_cvtsd_f64(x01);
            let xj0 = _mm_cvtsd_f64(_mm_unpackhi_pd(x01, x01));

            let state1_0 = _mm256_setr_pd(x2, y2, x1, y1);
            let coeff1_0 = _mm256_setr_pd(b.b2, b.a2, b.b2, b.a2);
            let mut acc0 = _mm256_mul_pd(coeff1_0, state1_0);
            let state2_0 = _mm256_setr_pd(x1, y1, xi0, 0.0);
            let coeff2_0 = _mm256_setr_pd(b.b1, b.a1, b.b1, 0.0);
            acc0 = _mm256_fmadd_pd(coeff2_0, state2_0, acc0);
            let state3_0 = _mm256_setr_pd(xi0, 0.0, xj0, 0.0);
            let coeff3_0 = _mm256_setr_pd(b.b0, 0.0, b.b0, 0.0);
            acc0 = _mm256_fmadd_pd(coeff3_0, state3_0, acc0);

            let term1_i0 = _mm256_cvtsd_f64(acc0);
            let term2_i0 = _mm256_cvtsd_f64(_mm256_permute4x64_pd(acc0, 0x55));
            let yi0 = term1_i0 - term2_i0;
            let term1_j0 = _mm256_cvtsd_f64(_mm256_permute4x64_pd(acc0, 0xAA));
            let term2_j_partial0 = _mm256_cvtsd_f64(_mm256_permute4x64_pd(acc0, 0xFF));
            let term2_j0 = b.a1.mul_add(yi0, term2_j_partial0);
            let yj0 = term1_j0 - term2_j0;

            let nx2 = xi0;
            let nx1 = xj0;
            let ny2 = yi0;
            let ny1 = yj0;

            let xi1 = _mm_cvtsd_f64(x23);
            let xj1 = _mm_cvtsd_f64(_mm_unpackhi_pd(x23, x23));

            let state1_1 = _mm256_setr_pd(nx2, ny2, nx1, ny1);
            let coeff1_1 = _mm256_setr_pd(b.b2, b.a2, b.b2, b.a2);
            let mut acc1 = _mm256_mul_pd(coeff1_1, state1_1);
            let state2_1 = _mm256_setr_pd(nx1, ny1, xi1, 0.0);
            let coeff2_1 = _mm256_setr_pd(b.b1, b.a1, b.b1, 0.0);
            acc1 = _mm256_fmadd_pd(coeff2_1, state2_1, acc1);
            let state3_1 = _mm256_setr_pd(xi1, 0.0, xj1, 0.0);
            let coeff3_1 = _mm256_setr_pd(b.b0, 0.0, b.b0, 0.0);
            acc1 = _mm256_fmadd_pd(coeff3_1, state3_1, acc1);

            let term1_i1 = _mm256_cvtsd_f64(acc1);
            let term2_i1 = _mm256_cvtsd_f64(_mm256_permute4x64_pd(acc1, 0x55));
            let yi1 = term1_i1 - term2_i1;
            let term1_j1 = _mm256_cvtsd_f64(_mm256_permute4x64_pd(acc1, 0xAA));
            let term2_j_partial1 = _mm256_cvtsd_f64(_mm256_permute4x64_pd(acc1, 0xFF));
            let term2_j1 = b.a1.mul_add(yi1, term2_j_partial1);
            let yj1 = term1_j1 - term2_j1;

            let y01 = _mm_setr_pd(yi0, yj0);
            let y23 = _mm_setr_pd(yi1, yj1);
            let yvec = _mm256_insertf128_pd(_mm256_castpd128_pd256(y01), y23, 1);
            unsafe { _mm256_storeu_pd(ptr, yvec) };

            x2 = xi1;
            x1 = xj1;
            y2 = yi1;
            y1 = yj1;
            ptr = unsafe { ptr.add(4) };
        }

        while (full_end as usize - ptr as usize) >= 2 * std::mem::size_of::<f64>() {
            let xi = unsafe { *ptr };
            let xj = unsafe { *ptr.add(1) };

            let state1 = _mm256_setr_pd(x2, y2, x1, y1);
            let coeff1 = _mm256_setr_pd(b.b2, b.a2, b.b2, b.a2);
            let mut acc = _mm256_mul_pd(coeff1, state1);
            let state2 = _mm256_setr_pd(x1, y1, xi, 0.0);
            let coeff2 = _mm256_setr_pd(b.b1, b.a1, b.b1, 0.0);
            acc = _mm256_fmadd_pd(coeff2, state2, acc);
            let state3 = _mm256_setr_pd(xi, 0.0, xj, 0.0);
            let coeff3 = _mm256_setr_pd(b.b0, 0.0, b.b0, 0.0);
            acc = _mm256_fmadd_pd(coeff3, state3, acc);

            let term1_i = _mm256_cvtsd_f64(acc);
            let term2_i = _mm256_cvtsd_f64(_mm256_permute4x64_pd(acc, 0x55));
            let yi = term1_i - term2_i;
            let term1_j = _mm256_cvtsd_f64(_mm256_permute4x64_pd(acc, 0xAA));
            let term2_j_partial = _mm256_cvtsd_f64(_mm256_permute4x64_pd(acc, 0xFF));
            let term2_j = b.a1.mul_add(yi, term2_j_partial);
            let yj = term1_j - term2_j;

            unsafe {
                *ptr = yi;
                *ptr.add(1) = yj;
                ptr = ptr.add(2);
            }
            x2 = xi;
            x1 = xj;
            y2 = yi;
            y1 = yj;
        }

        while ptr < full_end {
            let xi = unsafe { *ptr };
            let term1 = b.b0.mul_add(xi, b.b1.mul_add(x1, b.b2 * x2));
            let term2 = b.a1.mul_add(y1, b.a2 * y2);
            let yi = term1 - term2;
            unsafe {
                *ptr = yi;
                ptr = ptr.add(1);
            }
            x2 = x1;
            x1 = xi;
            y2 = y1;
            y1 = yi;
        }

        b.x1 = x1;
        b.x2 = x2;
        b.y1 = y1;
        b.y2 = y2;
    }

    /// Reset all internal state to zero while preserving coefficients.
    pub fn reset(&mut self) {
        let zero = T::zero();
        self.x1 = zero;
        self.x2 = zero;
        self.y1 = zero;
        self.y2 = zero;
        self.s1 = zero;
        self.s2 = zero;
    }

    /// Calculates the filter's complex frequency response at a single frequency `f`.
    pub fn complex_response(&self, f: T) -> Complex<T> {
        let omega = lit::<T>(2.0) * T::PI() * f / self.srate;
        let z_inv = Complex::<T>::from_polar(T::one(), -omega);
        let z_inv2 = z_inv * z_inv;

        // Note: coeffs are already normalized by a0.
        // Use Complex<T> * T (not T * Complex<T>) because num_complex only
        // implements Mul<T> for Complex<T>, not the reverse.
        let num = Complex::new(self.b0, T::zero()) + z_inv * self.b1 + z_inv2 * self.b2;
        let den = Complex::new(T::one(), T::zero()) + z_inv * self.a1 + z_inv2 * self.a2;

        num / den
    }

    /// Calculates the filter's magnitude response at a single frequency `f`.
    pub fn result(&self, f: T) -> T {
        let phi = (T::PI() * f / self.srate).sin().powi(2);
        let phi2 = phi * phi;

        let numerator = self.r_up0 + self.r_up1 * phi + self.r_up2 * phi2;
        let denominator = self.r_dw0 + self.r_dw1 * phi + self.r_dw2 * phi2;

        let result = (numerator / denominator).max(T::zero());
        result.sqrt()
    }

    /// Calculates the filter's response in dB at a single frequency `f`.
    pub fn log_result(&self, f: T) -> T {
        let result = self.result(f);
        if result > T::zero() {
            lit::<T>(20.0) * result.log10()
        } else {
            lit(-200.0) // Return a large negative number for silence
        }
    }

    /// Vectorized version to compute the SPL response for a vector of frequencies.
    /// This is the fast equivalent of the `np_log_result` Python method.
    pub fn np_log_result(&self, freq: &Array1<T>) -> Array1<T> {
        let mut out = Array1::zeros(freq.len());
        self.np_log_result_into(freq, &mut out);
        out
    }

    /// Vectorized SPL response written into a pre-allocated output buffer.
    ///
    /// Reuses `out` to avoid allocating a new `Array1<T>` for every biquad in
    /// a PEQ response chain.
    pub fn np_log_result_into(&self, freq: &Array1<T>, out: &mut Array1<T>) {
        debug_assert_eq!(freq.len(), out.len());
        let coeff = T::PI() / self.srate;
        let min_val: T = lit(1.0e-20);
        let scale: T = lit(20.0);

        for i in 0..freq.len() {
            let phi = (freq[i] * coeff).sin().powi(2);
            let phi2 = phi * phi;
            let r_up = phi * self.r_up1 + phi2 * self.r_up2 + self.r_up0;
            let r_dw = phi * self.r_dw1 + phi2 * self.r_dw2 + self.r_dw0;
            let r = (r_up / r_dw).max(min_val);
            out[i] = scale * r.sqrt().log10();
        }
    }

    /// Returns the normalized filter coefficients (a1, a2, b0, b1, b2).
    pub fn coefficients(&self) -> BiquadCoefficients<T> {
        BiquadCoefficients {
            b0: self.b0,
            b1: self.b1,
            b2: self.b2,
            a1: self.a1,
            a2: self.a2,
        }
    }

    /// Processes a single sample using explicitly provided coefficients (DF-I).
    ///
    /// Used for coefficient interpolation during parameter transitions.
    #[inline(always)]
    pub fn process_with_coefficients(&mut self, x: T, coeffs: &BiquadCoefficients<T>) -> T {
        if self.use_tdf2 {
            let y = coeffs.b0 * x + self.s1;
            self.s1 = coeffs.b1 * x - coeffs.a1 * y + self.s2;
            self.s2 = coeffs.b2 * x - coeffs.a2 * y;
            y
        } else {
            let y = coeffs.b0 * x + coeffs.b1 * self.x1 + coeffs.b2 * self.x2
                - coeffs.a1 * self.y1
                - coeffs.a2 * self.y2;
            self.x2 = self.x1;
            self.x1 = x;
            self.y2 = self.y1;
            self.y1 = y;
            y
        }
    }

    /// Returns the filter coefficients as a tuple.
    pub fn constants(&self) -> (T, T, T, T, T) {
        (self.a1, self.a2, self.b0, self.b1, self.b2)
    }
}

/// Implement the Display trait for pretty-printing, similar to __str__.
impl<T: FilterFloat> fmt::Display for Biquad<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "Type:{},Freq:{:.1},Rate:{:.1},Q:{:.1},Gain:{:.1}",
            self.filter_type.short_name(),
            self.freq,
            self.srate,
            self.q,
            self.db_gain
        )
    }
}
