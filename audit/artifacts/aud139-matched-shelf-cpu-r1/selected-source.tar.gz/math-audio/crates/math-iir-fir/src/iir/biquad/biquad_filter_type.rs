/// Filter types for biquad filters
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum BiquadFilterType {
    /// Low-pass filter
    Lowpass,
    /// High-pass filter
    Highpass,
    /// High-pass filter
    HighpassVariableQ,
    /// Band-pass filter
    Bandpass,
    /// Peaking filter
    Peak,
    /// Notch filter
    Notch,
    /// Low-shelf filter
    Lowshelf,
    /// High-shelf filter
    Highshelf,
    /// All-pass filter
    AllPass,
    /// Low-shelf filter (Orfanidis design with prescribed Nyquist gain).
    /// Rare near-degenerate solve cases fall back to a symmetric numerator
    /// (`d = 0`) rather than dividing by a near-zero quadratic coefficient.
    LowshelfOrf,
    /// High-shelf filter (Orfanidis design with prescribed Nyquist gain).
    /// Rare near-degenerate solve cases fall back to a symmetric numerator
    /// (`d = 0`) rather than dividing by a near-zero quadratic coefficient.
    HighshelfOrf,
    /// Peaking filter (Vicanek matched analog response). Rare
    /// near-degenerate solve cases fall back to a symmetric numerator
    /// (`d = 0`) rather than dividing by a near-zero quadratic coefficient.
    PeakMatched,
}

impl BiquadFilterType {
    /// Returns the short string representation of the filter type (e.g., "LP").
    pub fn short_name(&self) -> &'static str {
        match self {
            BiquadFilterType::Lowpass => "LP",
            BiquadFilterType::Highpass => "HP",
            BiquadFilterType::HighpassVariableQ => "HPQ",
            BiquadFilterType::Bandpass => "BP",
            BiquadFilterType::Peak => "PK",
            BiquadFilterType::Notch => "NO",
            BiquadFilterType::Lowshelf => "LS",
            BiquadFilterType::Highshelf => "HS",
            BiquadFilterType::AllPass => "AP",
            BiquadFilterType::LowshelfOrf => "LSO",
            BiquadFilterType::HighshelfOrf => "HSO",
            BiquadFilterType::PeakMatched => "PKM",
        }
    }

    /// Returns the long string representation of the filter type (e.g., "Lowpass").
    pub fn long_name(&self) -> &'static str {
        match self {
            BiquadFilterType::Lowpass => "Lowpass",
            BiquadFilterType::Highpass => "Highpass",
            BiquadFilterType::HighpassVariableQ => "HighpassVariableQ",
            BiquadFilterType::Bandpass => "Bandpass",
            BiquadFilterType::Peak => "Peak",
            BiquadFilterType::Notch => "Notch",
            BiquadFilterType::Lowshelf => "Lowshelf",
            BiquadFilterType::Highshelf => "Highshelf",
            BiquadFilterType::AllPass => "AllPass",
            BiquadFilterType::LowshelfOrf => "LowshelfOrf",
            BiquadFilterType::HighshelfOrf => "HighshelfOrf",
            BiquadFilterType::PeakMatched => "PeakMatched",
        }
    }
}
