use crate::traits::{FilterFloat, lit};

/// Modified Bessel function of the first kind (I0), used for Kaiser window.
pub(super) fn bessel_i0<T: FilterFloat>(x: T) -> T {
    let mut sum = T::one();
    let mut term = T::one();
    let mut k = T::one();

    let half_x_sq = (x / lit(2.0)) * (x / lit(2.0));

    // Series expansion: I₀(x) = Σ ((x/2)^k / k!)²
    // Each term is: term_k = term_{k-1} * (x/2)² / k²
    loop {
        term = term * half_x_sq / (k * k);
        sum += term;
        if term < lit::<T>(1e-12) * sum {
            break;
        }
        k += T::one();
    }

    sum
}
