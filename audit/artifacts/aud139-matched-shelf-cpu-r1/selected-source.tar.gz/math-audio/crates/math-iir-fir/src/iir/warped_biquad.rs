//! Warped biquad IIR filter for perceptual room EQ.
//!
//! A warped biquad replaces each unit delay (z^-1) in a standard biquad with
//! a first-order allpass section: A(z) = (z^-1 - λ)/(1 - λz^-1).
//!
//! When λ ≈ 0.876 at 48 kHz, the frequency axis maps to approximate the Bark
//! scale, concentrating filter resolution in the bass/low-mid range where room
//! modes are most problematic.
//!
//! # Design approach
//!
//! 1. Compute the "warped" prototype frequency using [`warp_frequency`].
//! 2. Design a standard biquad at that warped frequency.
//! 3. During sample processing, replace each z^-1 with the allpass section
//!    to produce the warped response.
//!
//! # Frequency response
//!
//! The warped filter's response at physical frequency f equals the standard
//! biquad's response at `warp_frequency(f, srate, lambda)`.

use crate::iir::biquad::{Biquad, BiquadFilterType};
use crate::traits::{FilterFloat, lit};
use ndarray::Array1;
use num_complex::Complex;

mod misc;
#[cfg(test)]
mod tests;

pub use misc::*;

use misc::allpass_step;
use misc::compute_implicit_consts;

/// Warped biquad IIR filter.
///
/// Provides perceptually-weighted frequency resolution by warping the frequency
/// axis to approximate the Bark scale (when using [`bark_lambda`] for `lambda`).
///
/// With λ = 0 this degenerates to a standard biquad with identical output.
/// With λ ≈ 0.876 (48 kHz Bark via Smith & Abel), low frequencies get
/// finer resolution at the expense of high-frequency accuracy.
///
/// # Sample-by-sample processing algorithm
///
/// The standard biquad difference equation replaces each unit delay z^-1 with
/// the first-order allpass A(z) = (z^-1 − λ)/(1 − λz^-1):
///
/// ```text
/// y[n] = b0·x[n] + b1·(A·x)[n] + b2·(A²·x)[n] − a1·(A·y)[n] − a2·(A²·y)[n]
/// ```
///
/// The input chain `(A·x)[n]`, `(A²·x)[n]` is computed causally from x[n].
/// The output chain is **implicit**: `(A·y)[n]` depends on `y[n]`.
///
/// Expanding the allpass recurrence for the y-chain:
/// ```text
/// (A·y)[n]  = λ·y[n] + (1−λ²)·s_y1
/// (A²·y)[n] = λ·(A·y)[n] + (1−λ²)·s_y2
/// ```
/// Substituting and solving for y[n] gives the closed-form update:
/// ```text
/// ff    = b0·x + b1·(A·x)[n] + b2·(A²·x)[n]
/// numer = ff − (1−λ²)·[(a1 + a2·λ)·s_y1 + a2·s_y2]
/// y[n]  = numer · inv_denom        where inv_denom = 1/(1 + a1·λ + a2·λ²)
/// ```
/// After computing y[n] the allpass states s_y1, s_y2 are advanced.
///
/// When λ = 0: `inv_denom = 1`, `one_minus_lam_sq = 1`, and the allpass
/// states hold exactly `y[n-1]` and `y[n-2]`, reproducing standard DF-I.
///
/// # Frequency response
///
/// The response at physical frequency f equals the prototype biquad's
/// response at `warp_frequency(f, srate, lambda)`.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(bound = "")]
pub struct WarpedBiquad<T: FilterFloat = f64> {
    /// Prototype biquad coefficients (designed at the warped center frequency)
    a1: T,
    a2: T,
    b0: T,
    b1: T,
    b2: T,
    /// Warping coefficient λ
    pub lambda: T,
    /// Precomputed 1/(1 + a1·λ + a2·λ²)
    inv_denom: T,
    /// Precomputed (1 − λ²)
    one_minus_lam_sq: T,
    /// Filter type
    pub filter_type: BiquadFilterType,
    /// Center frequency in Hz (physical domain)
    pub freq: T,
    /// Sample rate in Hz
    pub srate: T,
    /// Q factor
    pub q: T,
    /// Gain in dB (for peak/shelf types)
    pub db_gain: T,
    // Allpass internal states for the input (x) chain.
    // With λ=0 these degenerate to x[n-1] and x[n-2].
    ap_x1_s: T,
    ap_x2_s: T,
    // Allpass internal states for the output (y) chain.
    // With λ=0: s_y1 = y[n-1], s_y2 = y[n-2] (standard DF-I feedback).
    s_y1: T,
    s_y2: T,
}

impl<T: FilterFloat> WarpedBiquad<T> {
    /// Creates a new warped biquad filter.
    ///
    /// # Arguments
    ///
    /// * `filter_type` - The biquad filter topology to apply
    /// * `freq`        - Center frequency in Hz (physical domain)
    /// * `srate`       - Sample rate in Hz
    /// * `q`           - Q factor (0.0 uses the same defaults as [`Biquad::new`])
    /// * `db_gain`     - Gain in dB (peak/shelf types only)
    /// * `lambda`      - Warping coefficient; use [`bark_lambda`] for Bark-scale,
    ///   or 0.0 for standard biquad behavior
    pub fn new(
        filter_type: BiquadFilterType,
        freq: T,
        srate: T,
        q: T,
        db_gain: T,
        lambda: T,
    ) -> Self {
        let zero = T::zero();

        let freq_warped = if lambda == zero {
            freq
        } else {
            warp_frequency(freq, srate, lambda)
        };

        let proto = Biquad::new(filter_type, freq_warped, srate, q, db_gain);
        let coeffs = proto.coefficients();
        let (inv_denom, one_minus_lam_sq) = compute_implicit_consts(coeffs.a1, coeffs.a2, lambda);

        WarpedBiquad {
            a1: coeffs.a1,
            a2: coeffs.a2,
            b0: coeffs.b0,
            b1: coeffs.b1,
            b2: coeffs.b2,
            lambda,
            inv_denom,
            one_minus_lam_sq,
            filter_type,
            freq,
            srate,
            q: proto.q, // clamped/defaulted Q from Biquad::new
            db_gain,
            ap_x1_s: zero,
            ap_x2_s: zero,
            s_y1: zero,
            s_y2: zero,
        }
    }

    /// Update filter parameters and recompute coefficients without resetting state.
    pub fn update_params(
        &mut self,
        filter_type: BiquadFilterType,
        freq: T,
        srate: T,
        q: T,
        db_gain: T,
        lambda: T,
    ) {
        self.filter_type = filter_type;
        self.freq = freq;
        self.srate = srate;
        self.db_gain = db_gain;
        self.lambda = lambda;

        let freq_warped = if lambda == T::zero() {
            freq
        } else {
            warp_frequency(freq, srate, lambda)
        };

        let proto = Biquad::new(filter_type, freq_warped, srate, q, db_gain);
        self.q = proto.q;
        let coeffs = proto.coefficients();
        self.a1 = coeffs.a1;
        self.a2 = coeffs.a2;
        self.b0 = coeffs.b0;
        self.b1 = coeffs.b1;
        self.b2 = coeffs.b2;
        let (inv_denom, one_minus_lam_sq) = compute_implicit_consts(coeffs.a1, coeffs.a2, lambda);
        self.inv_denom = inv_denom;
        self.one_minus_lam_sq = one_minus_lam_sq;
    }

    /// Process a single audio sample through the warped biquad.
    ///
    /// See struct-level documentation for the derivation of the closed-form
    /// implicit solution used here.
    #[inline]
    pub fn process(&mut self, x: T) -> T {
        let lambda = self.lambda;

        // Advance input allpass chain
        let x_d1 = allpass_step(x, &mut self.ap_x1_s, lambda);
        let x_d2 = allpass_step(x_d1, &mut self.ap_x2_s, lambda);

        // Feedforward sum
        let ff = self.b0 * x + self.b1 * x_d1 + self.b2 * x_d2;

        // Closed-form solution for the implicit feedback term.
        // Derived by substituting (A·y)[n] = λ·y[n] + (1-λ²)·s_y1 and solving.
        let fb_corr = self.one_minus_lam_sq
            * ((self.a1 + self.a2 * lambda) * self.s_y1 + self.a2 * self.s_y2);

        let y = (ff - fb_corr) * self.inv_denom;

        // Advance output allpass states using the newly computed y[n]
        let y_d1 = allpass_step(y, &mut self.s_y1, lambda);
        allpass_step(y_d1, &mut self.s_y2, lambda);

        y
    }

    /// Process a block of audio samples in-place.
    pub fn process_block(&mut self, samples: &mut [T]) {
        let lambda = self.lambda;
        let b0 = self.b0;
        let b1 = self.b1;
        let b2 = self.b2;
        let a1 = self.a1;
        let a2 = self.a2;
        let inv_denom = self.inv_denom;
        let one_minus_lam_sq = self.one_minus_lam_sq;

        let mut ap_x1_s = self.ap_x1_s;
        let mut ap_x2_s = self.ap_x2_s;
        let mut s_y1 = self.s_y1;
        let mut s_y2 = self.s_y2;

        for sample in samples.iter_mut() {
            let x = *sample;

            let x_d1 = allpass_step(x, &mut ap_x1_s, lambda);
            let x_d2 = allpass_step(x_d1, &mut ap_x2_s, lambda);

            let ff = b0 * x + b1 * x_d1 + b2 * x_d2;
            let fb_corr = one_minus_lam_sq * ((a1 + a2 * lambda) * s_y1 + a2 * s_y2);

            let y = (ff - fb_corr) * inv_denom;

            let y_d1 = allpass_step(y, &mut s_y1, lambda);
            allpass_step(y_d1, &mut s_y2, lambda);

            *sample = y;
        }

        self.ap_x1_s = ap_x1_s;
        self.ap_x2_s = ap_x2_s;
        self.s_y1 = s_y1;
        self.s_y2 = s_y2;
    }

    /// Complex frequency response at a single physical frequency `f`.
    ///
    /// Evaluates the prototype biquad at the warped frequency corresponding to `f`.
    pub fn complex_response(&self, f: T) -> Complex<T> {
        let f_w = if self.lambda == T::zero() {
            f
        } else {
            warp_frequency(f, self.srate, self.lambda)
        };

        let omega = lit::<T>(2.0) * T::PI() * f_w / self.srate;
        let z_inv = Complex::<T>::from_polar(T::one(), -omega);
        let z_inv2 = z_inv * z_inv;

        let num = Complex::new(self.b0, T::zero()) + z_inv * self.b1 + z_inv2 * self.b2;
        let den = Complex::new(T::one(), T::zero()) + z_inv * self.a1 + z_inv2 * self.a2;

        num / den
    }

    /// Magnitude response at a single physical frequency `f`.
    pub fn result(&self, f: T) -> T {
        self.complex_response(f).norm()
    }

    /// Response in dB at a single physical frequency `f`.
    pub fn log_result(&self, f: T) -> T {
        let mag = self.result(f);
        if mag > T::zero() {
            lit::<T>(20.0) * mag.log10()
        } else {
            lit(-200.0)
        }
    }

    /// Vectorized dB response over an array of physical frequencies.
    pub fn np_log_result(&self, freqs: &Array1<T>) -> Array1<T> {
        freqs.mapv(|f| self.log_result(f))
    }

    /// Returns the normalized prototype coefficients as `(a1, a2, b0, b1, b2)`.
    pub fn coefficients(&self) -> (T, T, T, T, T) {
        (self.a1, self.a2, self.b0, self.b1, self.b2)
    }
}

impl<T: FilterFloat> std::fmt::Display for WarpedBiquad<T> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "WarpedBiquad(Type:{},Freq:{:.1},Rate:{:.1},Q:{:.1},Gain:{:.1},Lambda:{:.4})",
            self.filter_type.short_name(),
            self.freq,
            self.srate,
            self.q,
            self.db_gain,
            self.lambda,
        )
    }
}
