use super::biquad::biquad_to_apple_type;
use super::biquad::biquad_to_rme_type;
use super::consts::K_AUNBANDEQ_FILTER_TYPE_BAND_PASS;
use super::consts::K_AUNBANDEQ_FILTER_TYPE_HIGH_SHELF;
use super::consts::K_AUNBANDEQ_FILTER_TYPE_LOW_SHELF;
use super::consts::K_AUNBANDEQ_FILTER_TYPE_PARAMETRIC;
use super::consts::K_AUNBANDEQ_FILTER_TYPE_RESONANT_HIGH_PASS;
use super::consts::K_AUNBANDEQ_FILTER_TYPE_RESONANT_LOW_PASS;
use super::misc::a_weighting_db;
use super::misc::compute_peq_response;
use super::misc::compute_peq_response_into;
use super::misc::enforce_rme_room_filter_constraints;
use super::misc::filter_peqs_by_gain;
use super::misc::get_filter_priority;
use super::misc::k_weighting_db;

#[cfg(test)]
mod peq_tests {
    use super::super::*;
    use super::*;
    use ndarray::array;

    fn approx_eq(a: f64, b: f64, tol: f64) -> bool {
        (a - b).abs() <= tol
    }

    #[test]
    fn test_peq_equal() {
        let bq1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let bq2 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let bq3 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 4.0);

        let peq1 = vec![(1.0, bq1.clone()), (0.5, bq2.clone())];
        let peq2 = vec![(1.0, bq1), (0.5, bq2)];
        let peq3 = vec![(1.0, bq3)];

        assert!(peq_equal(&peq1, &peq2));
        assert!(!peq_equal(&peq1, &peq3));
        assert!(!peq_equal(&peq1, &vec![]));
    }

    #[test]
    fn test_peq_spl() {
        let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 6.0);
        let peq = vec![(1.0, bq)];
        let freq = array![100.0, 1000.0, 10000.0];

        let spl = peq_spl(&freq, &peq);

        // Should have gain close to 6 dB at 1kHz
        assert!(spl[1] > 5.0 && spl[1] < 7.0);
        // Should have less gain at other frequencies
        assert!(spl[0].abs() < 1.0);
        assert!(spl[2].abs() < 1.0);
    }

    #[test]
    fn test_peq_preamp_gain() {
        let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 6.0);
        let peq = vec![(1.0, bq)];

        let gain = peq_preamp_gain(&peq);

        // Should be negative to prevent clipping
        assert!(gain < 0.0);
        // Should be around -6 dB to compensate for the +6 dB boost
        assert!(gain > -7.0 && gain < -5.0);
    }

    #[test]
    fn test_peq_format_apo() {
        let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let peq = vec![(1.0, bq)];

        let apo_str = peq_format_apo("Test EQ", &peq);

        assert!(apo_str.contains("Test EQ"));
        assert!(apo_str.contains("Preamp:"));
        assert!(apo_str.contains("Filter  1:"));
        assert!(apo_str.contains("PK"));
        assert!(apo_str.contains("1000 Hz"));
        assert!(apo_str.contains("+3.00 dB"));
    }

    #[test]
    fn test_butterworth_q() {
        let q_values = peq_butterworth_q(4);
        assert_eq!(q_values.len(), 2);

        // For 4th order Butterworth, should have specific Q values
        assert!((q_values[0] - 1.3065630).abs() < 1e-6);
        assert!((q_values[1] - 0.5411961).abs() < 1e-6);
    }

    #[test]
    fn test_butterworth_filters() {
        let lp = peq_butterworth_lowpass(4, 1000.0, 48000.0);
        let hp = peq_butterworth_highpass(4, 1000.0, 48000.0);

        assert_eq!(lp.len(), 2);
        assert_eq!(hp.len(), 2);

        // All filters should have weight 1.0 and correct type
        for (weight, bq) in &lp {
            assert_eq!(*weight, 1.0);
            assert_eq!(bq.filter_type, BiquadFilterType::Lowpass);
            assert_eq!(bq.freq, 1000.0);
        }

        for (weight, bq) in &hp {
            assert_eq!(*weight, 1.0);
            assert_eq!(bq.filter_type, BiquadFilterType::Highpass);
            assert_eq!(bq.freq, 1000.0);
        }
    }

    #[test]
    fn test_linkwitzriley_lr12() {
        let srate = 48000.0;
        let freq = 1000.0;
        let lp = peq_linkwitzriley_lowpass(2, freq, srate);
        let hp = peq_linkwitzriley_highpass(2, freq, srate);

        // LR12 = 2nd order = 1 biquad section with Q=0.5
        assert_eq!(lp.len(), 1);
        assert_eq!(hp.len(), 1);
        assert!((lp[0].1.q - 0.5).abs() < 1e-10);
        assert!((hp[0].1.q - 0.5).abs() < 1e-10);

        // At crossover: each should be -6 dB
        let lp_resp = lp[0].1.complex_response(freq).norm().log10() * 20.0;
        let hp_resp = hp[0].1.complex_response(freq).norm().log10() * 20.0;
        assert!(
            (lp_resp - (-6.0)).abs() < 0.1,
            "LR12 LP at crossover: {lp_resp} dB"
        );
        assert!(
            (hp_resp - (-6.0)).abs() < 0.1,
            "LR12 HP at crossover: {hp_resp} dB"
        );

        // LR2 needs polarity inversion on HP for flat sum (order/2 is odd)
        let sum = lp[0].1.complex_response(freq) - hp[0].1.complex_response(freq);
        let sum_db = sum.norm().log10() * 20.0;
        assert!(
            sum_db.abs() < 0.1,
            "LR12 sum at crossover (HP inverted): {sum_db} dB"
        );
    }

    #[test]
    fn test_linkwitzriley_lr24() {
        let srate = 48000.0;
        let freq = 1000.0;
        let lp = peq_linkwitzriley_lowpass(4, freq, srate);
        let hp = peq_linkwitzriley_highpass(4, freq, srate);

        // LR24 = 4th order = 2 biquad sections with Q ≈ 0.7071
        assert_eq!(lp.len(), 2);
        assert_eq!(hp.len(), 2);
        for (weight, bq) in &lp {
            assert_eq!(*weight, 1.0);
            assert!((bq.q - std::f64::consts::FRAC_1_SQRT_2).abs() < 1e-10);
        }

        // At crossover: combined response should be -6 dB
        let lp_mag: f64 = lp
            .iter()
            .map(|(_, bq)| bq.complex_response(freq).norm())
            .product();
        let hp_mag: f64 = hp
            .iter()
            .map(|(_, bq)| bq.complex_response(freq).norm())
            .product();
        let lp_db = lp_mag.log10() * 20.0;
        let hp_db = hp_mag.log10() * 20.0;
        assert!(
            (lp_db - (-6.0)).abs() < 0.1,
            "LR24 LP at crossover: {lp_db} dB"
        );
        assert!(
            (hp_db - (-6.0)).abs() < 0.1,
            "LR24 HP at crossover: {hp_db} dB"
        );
    }

    #[test]
    fn test_linkwitzriley_lr48() {
        let srate = 48000.0;
        let freq = 1000.0;
        let lp = peq_linkwitzriley_lowpass(8, freq, srate);
        let hp = peq_linkwitzriley_highpass(8, freq, srate);

        // LR48 = 8th order = 4 biquad sections
        assert_eq!(lp.len(), 4);
        assert_eq!(hp.len(), 4);

        for (weight, _) in &lp {
            assert_eq!(*weight, 1.0);
        }
        for (weight, _) in &hp {
            assert_eq!(*weight, 1.0);
        }

        // At crossover: combined response should be -6 dB
        let lp_mag: f64 = lp
            .iter()
            .map(|(_, bq)| bq.complex_response(freq).norm())
            .product();
        let hp_mag: f64 = hp
            .iter()
            .map(|(_, bq)| bq.complex_response(freq).norm())
            .product();
        let lp_db = lp_mag.log10() * 20.0;
        let hp_db = hp_mag.log10() * 20.0;
        assert!(
            (lp_db - (-6.0)).abs() < 0.1,
            "LR48 LP at crossover: {lp_db} dB"
        );
        assert!(
            (hp_db - (-6.0)).abs() < 0.1,
            "LR48 HP at crossover: {hp_db} dB"
        );

        // Verify steep rolloff: at 2x crossover freq, LP should be well below -40 dB
        let lp_2x: f64 = lp
            .iter()
            .map(|(_, bq)| bq.complex_response(freq * 2.0).norm())
            .product();
        let lp_2x_db = lp_2x.log10() * 20.0;
        assert!(
            lp_2x_db < -40.0,
            "LR48 LP at 2x crossover: {lp_2x_db} dB (expected < -40)"
        );
    }

    #[test]
    #[should_panic(expected = "Linkwitz-Riley order must be even and >= 2")]
    fn test_linkwitzriley_rejects_odd_order() {
        peq_linkwitzriley_q(3);
    }

    #[test]
    #[should_panic(expected = "Linkwitz-Riley order must be even and >= 2")]
    fn test_linkwitzriley_rejects_order_zero() {
        peq_linkwitzriley_q(0);
    }

    // Tests moved from mod tests

    #[test]
    fn test_a_weighting() {
        // Test A-weighting at specific frequencies
        // At 1kHz, A-weighting should be close to 0 dB
        let w_1k = a_weighting_db(1000.0);
        assert!(
            (w_1k - 0.0).abs() < 1.0,
            "A-weighting at 1kHz should be ~0 dB"
        );

        // At 100Hz, A-weighting should be significantly negative (low frequencies attenuated)
        let w_100 = a_weighting_db(100.0);
        assert!(w_100 < -15.0, "A-weighting at 100Hz should be < -15 dB");

        // At 4kHz, A-weighting should be slightly positive
        let w_4k = a_weighting_db(4000.0);
        assert!(w_4k > 0.0, "A-weighting at 4kHz should be positive");
    }

    #[test]
    fn test_k_weighting() {
        // Test K-weighting approximation
        // Below 38Hz should be heavily attenuated
        let w_30 = k_weighting_db(30.0);
        assert!(w_30 < -5.0, "K-weighting at 30Hz should be attenuated");

        // Mid-frequencies should have less attenuation
        let w_1k = k_weighting_db(1000.0);
        assert!(
            w_1k > w_30,
            "K-weighting at 1kHz should be less attenuated than 30Hz"
        );

        // High frequencies should have boost
        let w_5k = k_weighting_db(5000.0);
        assert!(
            w_5k > w_1k,
            "K-weighting at 5kHz should have more gain than 1kHz"
        );
    }

    #[test]
    fn test_peq_loudness_gain_flat() {
        // Empty PEQ should return 0 dB
        let peq: Peq = vec![];
        let gain = peq_loudness_gain(&peq, "k");
        assert_eq!(gain, 0.0);
    }

    #[test]
    fn test_peq_loudness_gain_boost() {
        // PEQ with +6 dB peak at 1kHz should require negative gain compensation
        let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 6.0);
        let peq = vec![(1.0, bq)];

        let gain_k = peq_loudness_gain(&peq, "k");
        let gain_a = peq_loudness_gain(&peq, "a");

        println!("Test: +6 dB peak at 1kHz");
        println!("  K-weighted gain: {:.2} dB", gain_k);
        println!("  A-weighted gain: {:.2} dB", gain_a);

        // Should be negative (reducing gain to compensate for boost)
        assert!(
            gain_k < 0.0,
            "Gain compensation for boost should be negative (K-weighting)"
        );
        assert!(
            gain_a < 0.0,
            "Gain compensation for boost should be negative (A-weighting)"
        );

        // Should be roughly in the range of -1 to -4 dB for a +6 dB peak
        assert!(
            gain_k > -5.0 && gain_k < 0.0,
            "K-weighted gain should be between -5 and 0 dB"
        );
        assert!(
            gain_a > -5.0 && gain_a < 0.0,
            "A-weighted gain should be between -5 and 0 dB"
        );
    }

    #[test]
    fn test_peq_loudness_gain_demo() {
        println!("\n=== PEQ Loudness Compensation Demo ===\n");

        // Example 1: Mid-range boost
        println!("1. +6 dB peak at 1 kHz:");
        let bq1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 6.0);
        let peq1 = vec![(1.0, bq1)];
        println!(
            "   Anti-clip: {:.2} dB, K-weighted: {:.2} dB, A-weighted: {:.2} dB",
            peq_preamp_gain(&peq1),
            peq_loudness_gain(&peq1, "k"),
            peq_loudness_gain(&peq1, "a")
        );

        // Example 2: Bass boost
        println!("2. +6 dB bass at 100 Hz:");
        let bq2 = Biquad::new(BiquadFilterType::Peak, 100.0, 48000.0, 1.0, 6.0);
        let peq2 = vec![(1.0, bq2)];
        println!(
            "   Anti-clip: {:.2} dB, K-weighted: {:.2} dB, A-weighted: {:.2} dB",
            peq_preamp_gain(&peq2),
            peq_loudness_gain(&peq2, "k"),
            peq_loudness_gain(&peq2, "a")
        );

        // Example 3: Treble boost
        println!("3. +6 dB treble at 8 kHz:");
        let bq3 = Biquad::new(BiquadFilterType::Peak, 8000.0, 48000.0, 1.0, 6.0);
        let peq3 = vec![(1.0, bq3)];
        println!(
            "   Anti-clip: {:.2} dB, K-weighted: {:.2} dB, A-weighted: {:.2} dB",
            peq_preamp_gain(&peq3),
            peq_loudness_gain(&peq3, "k"),
            peq_loudness_gain(&peq3, "a")
        );

        // Example 4: V-shape EQ
        println!("4. V-shape: bass+4dB, mid-3dB, treble+3dB:");
        let bass = Biquad::new(BiquadFilterType::Lowshelf, 150.0, 48000.0, 0.7, 4.0);
        let mid = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, -3.0);
        let treble = Biquad::new(BiquadFilterType::Highshelf, 8000.0, 48000.0, 0.7, 3.0);
        let peq4 = vec![(1.0, bass), (1.0, mid), (1.0, treble)];
        println!(
            "   Anti-clip: {:.2} dB, K-weighted: {:.2} dB, A-weighted: {:.2} dB",
            peq_preamp_gain(&peq4),
            peq_loudness_gain(&peq4, "k"),
            peq_loudness_gain(&peq4, "a")
        );

        println!("\nNote: Anti-clip prevents clipping, K/A-weighted maintains loudness balance");
    }

    #[test]
    fn test_peq_loudness_gain_cut() {
        // PEQ with -6 dB cut at 1kHz should require positive gain compensation
        let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, -6.0);
        let peq = vec![(1.0, bq)];

        let gain_k = peq_loudness_gain(&peq, "k");
        let gain_a = peq_loudness_gain(&peq, "a");

        // Should be positive (increasing gain to compensate for cut)
        assert!(
            gain_k > 0.0,
            "Gain compensation for cut should be positive (K-weighting)"
        );
        assert!(
            gain_a > 0.0,
            "Gain compensation for cut should be positive (A-weighting)"
        );
    }

    #[test]
    fn test_peq_loudness_gain_bass_boost() {
        // Bass boost (100 Hz) should have different impact with K vs A weighting
        let bq = Biquad::new(BiquadFilterType::Peak, 100.0, 48000.0, 1.0, 6.0);
        let peq = vec![(1.0, bq)];

        let gain_k = peq_loudness_gain(&peq, "k");
        let gain_a = peq_loudness_gain(&peq, "a");

        // Both should be negative (compensation for boost)
        assert!(gain_k < 0.0);
        assert!(gain_a < 0.0);

        // A-weighting attenuates low frequencies more, so compensation should be less negative
        assert!(
            gain_a > gain_k,
            "A-weighted gain should be less negative (bass is less perceptually important)"
        );
    }

    #[test]
    fn test_peq_equal_identical() {
        let bq1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
        let bq2 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
        let peq1 = vec![(1.0, bq1)];
        let peq2 = vec![(1.0, bq2)];

        assert!(peq_equal(&peq1, &peq2));
    }

    #[test]
    fn test_peq_equal_different_weight() {
        let bq1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
        let bq2 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
        let peq1 = vec![(1.0, bq1)];
        let peq2 = vec![(0.5, bq2)];

        assert!(!peq_equal(&peq1, &peq2));
    }

    #[test]
    fn test_peq_equal_different_filter_type() {
        let bq1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
        let bq2 = Biquad::new(BiquadFilterType::Lowshelf, 1000.0, 48000.0, 2.0, 6.0);
        let peq1 = vec![(1.0, bq1)];
        let peq2 = vec![(1.0, bq2)];

        assert!(!peq_equal(&peq1, &peq2));
    }

    #[test]
    fn test_peq_equal_different_length() {
        let bq1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
        let bq2 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
        let bq3 = Biquad::new(BiquadFilterType::Peak, 2000.0, 48000.0, 2.0, 3.0);
        let peq1 = vec![(1.0, bq1)];
        let peq2 = vec![(1.0, bq2), (1.0, bq3)];

        assert!(!peq_equal(&peq1, &peq2));
    }

    #[test]
    fn test_peq_equal_empty() {
        let peq1: Peq = vec![];
        let peq2: Peq = vec![];

        assert!(peq_equal(&peq1, &peq2));
    }

    #[test]
    fn test_compute_peq_response_empty() {
        let peq: Peq = vec![];
        let freqs = array![100.0, 1000.0, 10000.0];
        let response = compute_peq_response(&freqs, &peq, 48000.0);

        assert_eq!(response.len(), 3);
        for val in response.iter() {
            assert_eq!(*val, 0.0);
        }
    }

    #[test]
    fn test_compute_peq_response_single_filter() {
        let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
        let peq = vec![(1.0, bq.clone())];
        let freqs = array![100.0, 1000.0, 10000.0];
        let response = compute_peq_response(&freqs, &peq, 48000.0);

        // Response at center should be ~6 dB
        assert!(approx_eq(response[1], 6.0, 0.5));

        // Response away from center should be ~0 dB
        assert!(response[0].abs() < 1.0);
        assert!(response[2].abs() < 1.0);
    }

    #[test]
    fn test_compute_peq_response_weighted() {
        let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
        let peq = vec![(0.5, bq)]; // Half weight
        let freqs = array![1000.0];
        let response = compute_peq_response(&freqs, &peq, 48000.0);

        // Response should be half of 6 dB = 3 dB
        assert!(approx_eq(response[0], 3.0, 0.5));
    }

    #[test]
    fn test_compute_peq_response_multiple_filters() {
        let bq1 = Biquad::new(BiquadFilterType::Peak, 500.0, 48000.0, 2.0, 3.0);
        let bq2 = Biquad::new(BiquadFilterType::Peak, 2000.0, 48000.0, 2.0, 3.0);
        let peq = vec![(1.0, bq1), (1.0, bq2)];
        let freqs = array![500.0, 1000.0, 2000.0];
        let response = compute_peq_response(&freqs, &peq, 48000.0);

        // Peaks at 500 Hz and 2000 Hz
        assert!(response[0] > response[1]); // 500 Hz peak
        assert!(response[2] > response[1]); // 2000 Hz peak
    }

    #[test]
    fn test_peq_spl_matches_compute_peq_response() {
        let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
        let peq = vec![(1.0, bq)];
        let freqs = array![100.0, 1000.0, 10000.0];

        let spl = peq_spl(&freqs, &peq);
        let response = compute_peq_response(&freqs, &peq, 48000.0);

        for (s, r) in spl.iter().zip(response.iter()) {
            assert!(approx_eq(*s, *r, 1e-10));
        }
    }

    #[test]
    fn test_peq_spl_into_matches_allocating_api_and_overwrites_output() {
        let peq = vec![
            (
                1.0,
                Biquad::new(BiquadFilterType::Peak, 500.0, 48000.0, 2.0, 3.0),
            ),
            (
                0.5,
                Biquad::new(BiquadFilterType::Peak, 2000.0, 48000.0, 1.0, -4.0),
            ),
        ];
        let freqs = array![100.0, 500.0, 1000.0, 2000.0, 10000.0];
        let expected = peq_spl(&freqs, &peq);
        let mut response = Array1::from_elem(freqs.len(), 1234.0);
        let mut scratch = Array1::from_elem(freqs.len(), -5678.0);

        peq_spl_into(&freqs, &peq, &mut response, &mut scratch);
        assert!(
            response
                .iter()
                .zip(expected.iter())
                .all(|(actual, expected)| approx_eq(*actual, *expected, 1e-12))
        );

        response.fill(-99.0);
        peq_spl_into(&freqs, &peq, &mut response, &mut scratch);
        assert!(
            response
                .iter()
                .zip(expected.iter())
                .all(|(actual, expected)| approx_eq(*actual, *expected, 1e-12))
        );
    }

    #[test]
    fn test_compute_peq_response_into_clears_empty_peq() {
        let freqs = array![100.0, 1000.0, 10000.0];
        let mut response = Array1::from_elem(freqs.len(), 42.0);
        let mut scratch = Array1::from_elem(freqs.len(), 7.0);

        compute_peq_response_into(&freqs, &Peq::new(), 48000.0, &mut response, &mut scratch);

        assert_eq!(response, Array1::<f64>::zeros(freqs.len()));
    }

    #[test]
    #[should_panic(expected = "response length must match frequency grid")]
    fn test_peq_spl_into_rejects_mismatched_response() {
        let freqs = array![100.0, 1000.0];
        let mut response = Array1::zeros(1);
        let mut scratch = Array1::zeros(2);

        peq_spl_into(&freqs, &Peq::new(), &mut response, &mut scratch);
    }

    #[test]
    fn test_filter_row_default() {
        let row = FilterRow::default();
        assert_eq!(row.freq, 0.0);
        assert_eq!(row.q, 0.0);
        assert_eq!(row.gain, 0.0);
        assert_eq!(row.kind, "");
    }

    #[test]
    fn test_filter_row_creation() {
        let row = FilterRow {
            freq: 1000.0,
            q: 2.0,
            gain: 6.0,
            kind: "PK",
        };
        assert_eq!(row.freq, 1000.0);
        assert_eq!(row.q, 2.0);
        assert_eq!(row.gain, 6.0);
        assert_eq!(row.kind, "PK");
    }

    #[test]
    fn test_peq_loudness_gain_multiple_filters() {
        let bq1 = Biquad::new(BiquadFilterType::Peak, 100.0, 48000.0, 1.0, 6.0);
        let bq2 = Biquad::new(BiquadFilterType::Peak, 8000.0, 48000.0, 1.0, 6.0);
        let peq = vec![(1.0, bq1), (1.0, bq2)];
        let gain = peq_loudness_gain(&peq, "k");
        // Multiple boosts should require more negative compensation
        assert!(gain < 0.0);
        assert!(gain > -60.0);
    }

    #[test]
    fn test_peq_loudness_gain_unknown_weighting() {
        let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 6.0);
        let peq = vec![(1.0, bq)];
        let gain = peq_loudness_gain(&peq, "unknown");
        // Unknown weighting defaults to 0.0 weight, so result should still be finite
        assert!(gain.is_finite());
    }

    #[test]
    fn test_peq_loudness_gain_clamped() {
        // Extreme pathological filter: very large broadband boost
        let pk1 = Biquad::new(BiquadFilterType::Peak, 500.0, 48000.0, 0.7, 120.0);
        let pk2 = Biquad::new(BiquadFilterType::Peak, 2000.0, 48000.0, 0.7, 120.0);
        let pk3 = Biquad::new(BiquadFilterType::Peak, 8000.0, 48000.0, 0.7, 120.0);
        let peq = vec![(1.0, pk1), (1.0, pk2), (1.0, pk3)];
        let gain = peq_loudness_gain(&peq, "k");
        // Should be clamped to -60 dB (or within clamp range)
        assert_eq!(gain, -60.0, "extreme boost should be clamped to -60 dB");
    }

    #[test]
    fn test_biquad_to_rme_type_lowpass_highpass_edge_positions() {
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowpass, 1), 3.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowpass, 3), 2.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowpass, 9), 2.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowpass, 5), -1.0);

        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highpass, 1), 2.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highpass, 3), 3.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highpass, 9), 3.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highpass, 7), -1.0);
    }

    #[test]
    fn test_enforce_rme_room_filter_constraints_unsupported_types() {
        // Notch and AllPass should be converted to Peak
        let notch = Biquad::new(BiquadFilterType::Notch, 1000.0, 48000.0, 1.0, 0.0);
        let ap = Biquad::new(BiquadFilterType::AllPass, 2000.0, 48000.0, 1.0, 0.0);
        let peq = vec![(1.0, notch), (1.0, ap)];
        let result = enforce_rme_room_filter_constraints(&peq);
        assert_eq!(result.len(), 9);
        // Both should have been converted to Peak
        assert_eq!(result[0].1.filter_type, BiquadFilterType::Peak);
        assert_eq!(result[1].1.filter_type, BiquadFilterType::Peak);
    }

    #[test]
    fn test_enforce_rme_room_filter_constraints_lowpass_highpass() {
        let lp = Biquad::new(BiquadFilterType::Lowpass, 100.0, 48000.0, 0.7, 0.0);
        let hp = Biquad::new(BiquadFilterType::Highpass, 8000.0, 48000.0, 0.7, 0.0);
        let pk = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let peq = vec![(1.0, pk), (1.0, lp), (1.0, hp)];
        let result = enforce_rme_room_filter_constraints(&peq);
        assert_eq!(result.len(), 9);
        // Position 1: lowest freq non-PK → Lowpass at 100Hz
        assert_eq!(result[0].1.filter_type, BiquadFilterType::Lowpass);
        assert!((result[0].1.freq - 100.0).abs() < 1.0);
        // Position 9: highest freq non-PK → Highpass at 8000Hz
        assert_eq!(result[8].1.filter_type, BiquadFilterType::Highpass);
        assert!((result[8].1.freq - 8000.0).abs() < 1.0);
    }

    #[test]
    fn test_enforce_rme_room_filter_constraints_exactly_nine_pk() {
        // Exactly 9 PK filters should fit without dropping
        let mut peq = Vec::new();
        for i in 0..9 {
            let bq = Biquad::new(
                BiquadFilterType::Peak,
                100.0 + i as f64 * 100.0,
                48000.0,
                1.0,
                1.0,
            );
            peq.push((1.0, bq));
        }
        let result = enforce_rme_room_filter_constraints(&peq);
        assert_eq!(result.len(), 9);
        for (_, bq) in &result {
            assert_eq!(bq.filter_type, BiquadFilterType::Peak);
        }
    }

    #[test]
    fn test_enforce_rme_room_filter_constraints_ten_pk() {
        // 10 PK filters: first 9 used, last one dropped
        let mut peq = Vec::new();
        for i in 0..10 {
            let bq = Biquad::new(
                BiquadFilterType::Peak,
                100.0 + i as f64 * 100.0,
                48000.0,
                1.0,
                1.0,
            );
            peq.push((1.0, bq));
        }
        let result = enforce_rme_room_filter_constraints(&peq);
        assert_eq!(result.len(), 9);
        assert_eq!(result[0].1.freq, 100.0);
        assert_eq!(result[8].1.freq, 900.0);
    }
}

#[cfg(test)]
mod format_tests {
    use super::super::*;
    use super::*;

    #[test]
    fn test_peq_format_rme_channel_single_peak() {
        let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let peq = vec![(1.0, bq)];
        let rme_str = peq_format_rme_channel(&peq);

        // Verify structure
        assert!(rme_str.contains("<Preset>"));
        assert!(rme_str.contains("<Equalizer>"));
        assert!(rme_str.contains("<Params>"));
        assert!(rme_str.contains("LC Grade"));
        assert!(rme_str.contains("LC Freq"));
        assert!(rme_str.contains("Band1 Freq"));
        assert!(rme_str.contains("Band1 Q"));
        assert!(rme_str.contains("Band1 Gain"));
        assert!(rme_str.contains("Band1 Type"));
        assert!(rme_str.contains("</Preset>"));

        // Peak filter should have type 0.0
        assert!(rme_str.contains("0.00"));
    }

    #[test]
    fn test_peq_format_rme_channel_empty() {
        let peq: Peq = vec![];
        let rme_str = peq_format_rme_channel(&peq);

        // Should still have basic structure
        assert!(rme_str.contains("<Preset>"));
        assert!(rme_str.contains("<Equalizer>"));
        assert!(rme_str.contains("LC Grade"));
        assert!(rme_str.contains("</Preset>"));
    }

    #[test]
    fn test_peq_format_rme_channel_multiple_bands() {
        let bq1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let bq2 = Biquad::new(BiquadFilterType::Peak, 2000.0, 48000.0, 2.0, -2.0);
        let peq = vec![(1.0, bq1), (1.0, bq2)];
        let rme_str = peq_format_rme_channel(&peq);

        assert!(rme_str.contains("Band1 Freq"));
        assert!(rme_str.contains("Band2 Freq"));
        assert!(rme_str.contains("Band1 Type"));
        assert!(rme_str.contains("Band2 Type"));
    }

    #[test]
    fn test_peq_format_aupreset_single_peak() {
        let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let peq = vec![(1.0, bq)];
        let aupreset_str = peq_format_aupreset(&peq, "Test EQ");

        // Verify plist structure
        assert!(aupreset_str.contains("<?xml version="));
        assert!(aupreset_str.contains("<!DOCTYPE plist"));
        assert!(aupreset_str.contains("<plist version=\"1.0\">"));
        assert!(aupreset_str.contains("<dict>"));
        assert!(aupreset_str.contains("<key>ParametricType</key>"));
        assert!(aupreset_str.contains("<key>data</key>"));
        assert!(aupreset_str.contains("<data>"));
        assert!(aupreset_str.contains("<key>name</key>"));
        assert!(aupreset_str.contains("<string>Test EQ</string>"));
        assert!(aupreset_str.contains("<key>numberOfBands</key>"));
        assert!(aupreset_str.contains("<integer>1</integer>"));
        assert!(aupreset_str.contains("</plist>"));
    }

    #[test]
    fn test_peq_format_aupreset_empty() {
        let peq: Peq = vec![];
        let aupreset_str = peq_format_aupreset(&peq, "Empty EQ");

        // Should still generate valid plist
        assert!(aupreset_str.contains("<?xml version="));
        assert!(aupreset_str.contains("<string>Empty EQ</string>"));
        assert!(aupreset_str.contains("<integer>0</integer>"));
    }

    #[test]
    fn test_peq_format_aupreset_multiple_bands() {
        let bq1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let bq2 = Biquad::new(BiquadFilterType::Highshelf, 8000.0, 48000.0, 0.7, 2.0);
        let bq3 = Biquad::new(BiquadFilterType::Lowshelf, 100.0, 48000.0, 0.7, -1.0);
        let peq = vec![(1.0, bq1), (1.0, bq2), (1.0, bq3)];
        let aupreset_str = peq_format_aupreset(&peq, "Multi Band EQ");

        assert!(aupreset_str.contains("<string>Multi Band EQ</string>"));
        assert!(aupreset_str.contains("<integer>3</integer>"));
        // Should have base64 encoded data
        assert!(aupreset_str.contains("<data>"));
    }

    #[test]
    fn test_peq_format_aupreset_max_bands() {
        // Test with more than 16 bands (should cap at 16)
        let mut peq = Vec::new();
        for i in 0..20 {
            let freq = 100.0 + (i as f64 * 100.0);
            let bq = Biquad::new(BiquadFilterType::Peak, freq, 48000.0, 1.0, 1.0);
            peq.push((1.0, bq));
        }
        let aupreset_str = peq_format_aupreset(&peq, "Max Bands EQ");

        // Should cap at 16 bands
        assert!(aupreset_str.contains("<integer>16</integer>"));
    }

    #[test]
    fn test_biquad_to_apple_type() {
        assert_eq!(
            biquad_to_apple_type(BiquadFilterType::Peak),
            K_AUNBANDEQ_FILTER_TYPE_PARAMETRIC
        );
        assert_eq!(
            biquad_to_apple_type(BiquadFilterType::Highshelf),
            K_AUNBANDEQ_FILTER_TYPE_HIGH_SHELF
        );
        assert_eq!(
            biquad_to_apple_type(BiquadFilterType::Lowshelf),
            K_AUNBANDEQ_FILTER_TYPE_LOW_SHELF
        );
        assert_eq!(
            biquad_to_apple_type(BiquadFilterType::Highpass),
            K_AUNBANDEQ_FILTER_TYPE_RESONANT_HIGH_PASS
        );
        assert_eq!(
            biquad_to_apple_type(BiquadFilterType::Lowpass),
            K_AUNBANDEQ_FILTER_TYPE_RESONANT_LOW_PASS
        );
        assert_eq!(
            biquad_to_apple_type(BiquadFilterType::Bandpass),
            K_AUNBANDEQ_FILTER_TYPE_BAND_PASS
        );
    }

    #[test]
    fn test_biquad_to_rme_type() {
        // Peak should always be 0.0
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Peak, 1), 0.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Peak, 2), 0.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Peak, 3), 0.0);

        // Lowpass position-dependent
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowpass, 1), 3.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowpass, 3), 2.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowpass, 9), 2.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowpass, 2), -1.0);

        // Highpass position-dependent
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highpass, 1), 2.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highpass, 3), 3.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highpass, 9), 3.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highpass, 2), -1.0);

        // Lowshelf position-dependent
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowshelf, 1), 1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowshelf, 3), 1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowshelf, 9), 1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowshelf, 2), -1.0);

        // Highshelf position-dependent
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highshelf, 1), 1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highshelf, 3), 1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highshelf, 9), 1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highshelf, 2), -1.0);
    }

    #[test]
    fn test_biquad_to_rme_type_unsupported_and_edge_positions() {
        // HighpassVariableQ mirrors Highpass
        assert_eq!(
            biquad_to_rme_type(BiquadFilterType::HighpassVariableQ, 1),
            2.0
        );
        assert_eq!(
            biquad_to_rme_type(BiquadFilterType::HighpassVariableQ, 3),
            3.0
        );
        assert_eq!(
            biquad_to_rme_type(BiquadFilterType::HighpassVariableQ, 9),
            3.0
        );
        assert_eq!(
            biquad_to_rme_type(BiquadFilterType::HighpassVariableQ, 2),
            -1.0
        );

        // Unsupported types always return -1.0
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Bandpass, 1), -1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Notch, 1), -1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::AllPass, 1), -1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::LowshelfOrf, 1), -1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::HighshelfOrf, 1), -1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::PeakMatched, 1), -1.0);

        // Edge positions outside allowed set
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowpass, 0), -1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highpass, 0), -1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Lowshelf, 2), -1.0);
        assert_eq!(biquad_to_rme_type(BiquadFilterType::Highshelf, 2), -1.0);
    }

    #[test]
    fn test_get_filter_priority() {
        assert_eq!(get_filter_priority(BiquadFilterType::Lowshelf), 9);
        assert_eq!(get_filter_priority(BiquadFilterType::Highshelf), 9);
        assert_eq!(get_filter_priority(BiquadFilterType::Lowpass), 7);
        assert_eq!(get_filter_priority(BiquadFilterType::Highpass), 7);
        assert_eq!(get_filter_priority(BiquadFilterType::HighpassVariableQ), 7);
        assert_eq!(get_filter_priority(BiquadFilterType::Bandpass), 5);
        assert_eq!(get_filter_priority(BiquadFilterType::Peak), 3);
        assert_eq!(get_filter_priority(BiquadFilterType::Notch), 1);
    }

    #[test]
    fn test_filter_peqs_by_gain_under_limit() {
        let bq1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let bq2 = Biquad::new(BiquadFilterType::Peak, 2000.0, 48000.0, 1.0, 2.0);
        let peq = vec![(1.0, bq1), (1.0, bq2)];
        let filtered = filter_peqs_by_gain(&peq, 5);
        assert_eq!(filtered.len(), 2);
    }

    #[test]
    fn test_filter_peqs_by_gain_over_limit() {
        // Create 12 peak filters with varying gains
        let mut peq = Vec::new();
        for i in 0..12 {
            let gain = (i as f64) * 0.5 + 0.5; // gains from 0.5 to 6.0
            let bq = Biquad::new(
                BiquadFilterType::Peak,
                1000.0 + (i as f64 * 100.0),
                48000.0,
                1.0,
                gain,
            );
            peq.push((1.0, bq));
        }
        let filtered = filter_peqs_by_gain(&peq, 9);
        assert_eq!(filtered.len(), 9);
        // Should keep the ones with higher gains (indices 3-11)
        // First frequency should be from index 3 (1300 Hz)
        assert!((filtered[0].1.freq - 1300.0).abs() < 1.0);
    }

    #[test]
    fn test_filter_peqs_by_gain_priority() {
        // Mix of different filter types with varying gains
        let mut peq = Vec::new();
        // Add 6 peaks with high gains
        for i in 0..6 {
            let bq = Biquad::new(
                BiquadFilterType::Peak,
                1000.0 + (i as f64 * 100.0),
                48000.0,
                1.0,
                5.0,
            );
            peq.push((1.0, bq));
        }
        // Add 2 lowshelf with lower gain but higher priority
        let ls1 = Biquad::new(BiquadFilterType::Lowshelf, 100.0, 48000.0, 0.7, 2.0);
        let ls2 = Biquad::new(BiquadFilterType::Lowshelf, 120.0, 48000.0, 0.7, 2.5);
        peq.push((1.0, ls1));
        peq.push((1.0, ls2));
        // Add 3 more peaks
        for i in 6..9 {
            let bq = Biquad::new(
                BiquadFilterType::Peak,
                1000.0 + (i as f64 * 100.0),
                48000.0,
                1.0,
                4.0,
            );
            peq.push((1.0, bq));
        }
        let filtered = filter_peqs_by_gain(&peq, 9);
        assert_eq!(filtered.len(), 9);
        // Both lowshelf filters should be kept due to higher priority
        let lowshelf_count = filtered
            .iter()
            .filter(|(_, bq)| bq.filter_type == BiquadFilterType::Lowshelf)
            .count();
        assert_eq!(lowshelf_count, 2);
    }

    #[test]
    fn test_enforce_rme_room_filter_constraints_empty() {
        let peq: Peq = vec![];
        let result = enforce_rme_room_filter_constraints(&peq);
        // Should always return exactly 9 bands (filled with zero-gain PK)
        assert_eq!(result.len(), 9);
        // All should be zero-gain PK filters
        for (_, bq) in &result {
            assert_eq!(bq.filter_type, BiquadFilterType::Peak);
            assert_eq!(bq.db_gain, 0.0);
        }
    }

    #[test]
    fn test_enforce_rme_room_filter_constraints_no_shelves() {
        let bq1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let bq2 = Biquad::new(BiquadFilterType::Peak, 2000.0, 48000.0, 1.0, 2.0);
        let peq = vec![(1.0, bq1), (1.0, bq2)];
        let result = enforce_rme_room_filter_constraints(&peq);
        // Should always return exactly 9 bands
        assert_eq!(result.len(), 9);
        // First 2 should be the input PK filters
        assert!((result[0].1.freq - 1000.0).abs() < 1.0);
        assert!((result[1].1.freq - 2000.0).abs() < 1.0);
        // Rest should be zero-gain PK filters
        for item in result.iter().take(9).skip(2) {
            assert_eq!(item.1.filter_type, BiquadFilterType::Peak);
            assert_eq!(item.1.db_gain, 0.0);
        }
    }

    #[test]
    fn test_enforce_rme_room_filter_constraints_single_lowshelf() {
        let ls = Biquad::new(BiquadFilterType::Lowshelf, 100.0, 48000.0, 0.7, 2.0);
        let pk1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let pk2 = Biquad::new(BiquadFilterType::Peak, 2000.0, 48000.0, 1.0, 2.0);
        let peq = vec![(1.0, pk1), (1.0, ls.clone()), (1.0, pk2)];
        let result = enforce_rme_room_filter_constraints(&peq);
        // Should always return exactly 9 bands
        assert_eq!(result.len(), 9);
        // Lowshelf should be in position 1 (lowest freq non-PK)
        assert_eq!(result[0].1.filter_type, BiquadFilterType::Lowshelf);
        assert!((result[0].1.freq - 100.0).abs() < 1.0);
        // PK filters in positions 2-9
        for item in result.iter().take(9).skip(1) {
            assert_eq!(item.1.filter_type, BiquadFilterType::Peak);
        }
    }

    #[test]
    fn test_enforce_rme_room_filter_constraints_multiple_lowshelf() {
        let ls1 = Biquad::new(BiquadFilterType::Lowshelf, 100.0, 48000.0, 0.7, 2.0);
        let ls2 = Biquad::new(BiquadFilterType::Lowshelf, 120.0, 48000.0, 0.7, 4.0);
        let pk = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let peq = vec![(1.0, ls1), (1.0, pk), (1.0, ls2)];
        let result = enforce_rme_room_filter_constraints(&peq);
        // Should always return exactly 9 bands
        assert_eq!(result.len(), 9);
        // Position 1: lowest freq lowshelf (ls1 at 100Hz)
        assert_eq!(result[0].1.filter_type, BiquadFilterType::Lowshelf);
        assert!((result[0].1.freq - 100.0).abs() < 1.0);
        // Position 9: highest freq lowshelf (ls2 at 120Hz)
        assert_eq!(result[8].1.filter_type, BiquadFilterType::Lowshelf);
        assert!((result[8].1.freq - 120.0).abs() < 1.0);
    }

    #[test]
    fn test_enforce_rme_room_filter_constraints_multiple_highshelf() {
        let hs1 = Biquad::new(BiquadFilterType::Highshelf, 8000.0, 48000.0, 0.7, 1.5);
        let hs2 = Biquad::new(BiquadFilterType::Highshelf, 10000.0, 48000.0, 0.7, 3.0);
        let pk = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let peq = vec![(1.0, pk), (1.0, hs1), (1.0, hs2)];
        let result = enforce_rme_room_filter_constraints(&peq);
        // Should always return exactly 9 bands
        assert_eq!(result.len(), 9);
        // Position 1: lowest freq highshelf (hs1 at 8000Hz)
        assert_eq!(result[0].1.filter_type, BiquadFilterType::Highshelf);
        assert!((result[0].1.freq - 8000.0).abs() < 1.0);
        // Position 9: highest freq highshelf (hs2 at 10000Hz)
        assert_eq!(result[8].1.filter_type, BiquadFilterType::Highshelf);
        assert!((result[8].1.freq - 10000.0).abs() < 1.0);
    }

    #[test]
    fn test_enforce_rme_room_filter_constraints_both_shelves() {
        let ls = Biquad::new(BiquadFilterType::Lowshelf, 100.0, 48000.0, 0.7, 2.0);
        let hs = Biquad::new(BiquadFilterType::Highshelf, 8000.0, 48000.0, 0.7, 1.5);
        let pk1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let pk2 = Biquad::new(BiquadFilterType::Peak, 2000.0, 48000.0, 1.0, 2.0);
        let peq = vec![(1.0, pk1), (1.0, ls), (1.0, pk2), (1.0, hs)];
        let result = enforce_rme_room_filter_constraints(&peq);
        // Should always return exactly 9 bands
        assert_eq!(result.len(), 9);
        // Position 1: Lowshelf (lowest freq non-PK at 100Hz)
        assert_eq!(result[0].1.filter_type, BiquadFilterType::Lowshelf);
        assert!((result[0].1.freq - 100.0).abs() < 1.0);
        // Position 9: Highshelf (highest freq non-PK at 8000Hz)
        assert_eq!(result[8].1.filter_type, BiquadFilterType::Highshelf);
        assert!((result[8].1.freq - 8000.0).abs() < 1.0);
        // Positions 2-8 should be PK filters
        for item in result.iter().take(8).skip(1) {
            assert_eq!(item.1.filter_type, BiquadFilterType::Peak);
        }
    }

    #[test]
    fn test_peq_format_rme_room_single_channel() {
        let bq1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let bq2 = Biquad::new(BiquadFilterType::Peak, 2000.0, 48000.0, 2.0, -2.0);
        let left = vec![(1.0, bq1), (1.0, bq2)];
        let right: Peq = vec![];
        let rme_str = peq_format_rme_room(&left, &right);

        // Verify structure
        assert!(rme_str.contains("<Preset>"));
        assert!(rme_str.contains("<Room EQ L>"));
        assert!(rme_str.contains("<Room EQ R>"));
        assert!(rme_str.contains("<Params>"));
        assert!(rme_str.contains("REQ Delay"));
        assert!(rme_str.contains("REQ Band1 Freq"));
        assert!(rme_str.contains("REQ Band1 Q"));
        assert!(rme_str.contains("REQ Band1 Gain"));
        assert!(rme_str.contains("REQ Band1 Type"));
        assert!(rme_str.contains("REQ Band2 Freq"));
        assert!(rme_str.contains("REQ Chan Gain"));
        assert!(rme_str.contains("</Preset>"));
    }

    #[test]
    fn test_peq_format_rme_room_dual_channel() {
        let bq_left = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let bq_right = Biquad::new(BiquadFilterType::Peak, 2000.0, 48000.0, 2.0, -2.0);
        let left = vec![(1.0, bq_left)];
        let right = vec![(1.0, bq_right)];
        let rme_str = peq_format_rme_room(&left, &right);

        // Both channels should have different frequencies
        assert!(rme_str.contains("1000.00"));
        assert!(rme_str.contains("2000.00"));
    }

    #[test]
    fn test_peq_format_rme_room_max_bands() {
        // Test with 9 bands (at limit)
        let mut left = Vec::new();
        for i in 0..9 {
            let freq = 100.0 + (i as f64 * 100.0);
            let bq = Biquad::new(BiquadFilterType::Peak, freq, 48000.0, 1.0, 1.0);
            left.push((1.0, bq));
        }
        let right: Peq = vec![];
        let rme_str = peq_format_rme_room(&left, &right);

        // Should contain all 9 bands
        assert!(rme_str.contains("REQ Band1 Freq"));
        assert!(rme_str.contains("REQ Band9 Freq"));
    }

    #[test]
    fn test_peq_format_rme_room_over_limit() {
        // Test with more than 9 bands (should be filtered)
        let mut left = Vec::new();
        for i in 0..12 {
            let freq = 100.0 + (i as f64 * 100.0);
            let gain = (i as f64) * 0.5 + 0.5;
            let bq = Biquad::new(BiquadFilterType::Peak, freq, 48000.0, 1.0, gain);
            left.push((1.0, bq));
        }
        let right: Peq = vec![];
        let rme_str = peq_format_rme_room(&left, &right);

        // Should only contain 9 bands
        assert!(rme_str.contains("REQ Band9 Freq"));
        assert!(!rme_str.contains("REQ Band10 Freq"));
    }

    #[test]
    fn test_peq_format_rme_room_with_non_pk_filters() {
        let ls = Biquad::new(BiquadFilterType::Lowshelf, 100.0, 48000.0, 0.7, 2.0);
        let hs = Biquad::new(BiquadFilterType::Highshelf, 8000.0, 48000.0, 0.7, 1.5);
        let pk = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let left = vec![(1.0, pk), (1.0, ls), (1.0, hs)];
        let right: Peq = vec![];
        let rme_str = peq_format_rme_room(&left, &right);

        // Should contain room EQ tags
        assert!(rme_str.contains("<Room EQ L>"));
        assert!(rme_str.contains("<Room EQ R>"));
        // Lowshelf should be at position 1 → type 1.0
        assert!(rme_str.contains("1.00"));
        // Highshelf should be at position 9 → type 1.0
        // Peak should be at positions 2-8 → type 0.0
        assert!(rme_str.contains("0.00"));
        assert!(rme_str.contains("REQ Chan Gain"));
    }

    #[test]
    fn test_peq_format_rme_room_empty_left_non_empty_right() {
        let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 3.0);
        let left: Peq = vec![];
        let right = vec![(1.0, bq)];
        let rme_str = peq_format_rme_room(&left, &right);

        // Left empty → constrained to 9 dummy bands
        // Right non-empty → uses right's constrained bands
        assert!(rme_str.contains("<Room EQ L>"));
        assert!(rme_str.contains("<Room EQ R>"));
        assert!(rme_str.contains("REQ Band1 Freq"));
    }
}
