use crate::BiquadCoefficients;
use crate::traits::{FilterFloat, lit};

/// Apply a single-pass IIR filter through a cascade of biquad sections.
///
/// Equivalent to `scipy.signal.sosfilt`. This introduces phase distortion —
/// use [`filtfilt`] for zero-phase filtering.
pub fn sosfilt<T: FilterFloat>(signal: &[T], sections: &[BiquadCoefficients<T>]) -> Vec<T> {
    if signal.is_empty() || sections.is_empty() {
        return signal.to_vec();
    }

    let mut data: Vec<T> = signal.to_vec();

    for section in sections {
        data = biquad_filter(&data, section, [T::zero(), T::zero()]);
    }

    data
}

/// Apply forward-reverse filtering (zero-phase) through a cascade of biquad sections.
///
/// Equivalent to MATLAB's `filtfilt` or `scipy.signal.sosfiltfilt`.
///
/// The signal is extended at both ends using odd reflection to reduce edge
/// transients. Steady-state initial conditions are computed for each section
/// to further minimize startup artifacts.
///
/// Because the filter is applied twice (forward + backward), the effective
/// filter order is doubled and the magnitude response is squared. A 2nd-order
/// Butterworth becomes effectively 4th-order with -80 dB/decade rolloff.
///
/// # Returns
///
/// A filtered signal of the same length as the input, with zero phase distortion.
/// Apply forward-reverse filtering with an explicit padding length.
///
/// See [`filtfilt`] for the filtering algorithm.  The `padlen` argument
/// controls how many samples of odd-reflected padding are added at each
/// end of the signal.  A larger value reduces edge transients for narrow
/// high-order filters but increases computation time.
///
/// # Panics
///
/// Panics if `padlen` exceeds `signal.len() - 1`.
pub fn filtfilt_with_padlen<T: FilterFloat>(
    signal: &[T],
    sections: &[BiquadCoefficients<T>],
    padlen: usize,
) -> Vec<T> {
    if signal.is_empty() || sections.is_empty() {
        return signal.to_vec();
    }

    let n = signal.len();

    // Minimum useful length: need at least 2 samples for reflection
    if n < 2 {
        return signal.to_vec();
    }

    assert!(
        padlen < n,
        "padlen ({padlen}) must not exceed signal.len() - 1 ({n})",
    );

    let two = lit::<T>(2.0);

    // Build padded signal with odd reflection at both ends
    let mut padded = Vec::with_capacity(n + 2 * padlen);

    // Prepend: odd extension at left boundary
    let x0 = signal[0];
    for i in (1..=padlen).rev() {
        padded.push(two * x0 - signal[i]);
    }

    // Original signal
    padded.extend_from_slice(signal);

    // Append: odd extension at right boundary
    let xlast = signal[n - 1];
    for i in (1..=padlen).rev() {
        padded.push(two * xlast - signal[n - 1 - i]);
    }

    // Compute steady-state initial conditions for each section
    let zi_base: Vec<[T; 2]> = sections.iter().map(biquad_zi).collect();

    // Forward pass: cascade all sections
    let mut data = padded;
    for (sec_idx, section) in sections.iter().enumerate() {
        // `data[0]` is the steady-state output level of every preceding
        // section, so non-unity section DC gains are propagated through the
        // cascade before this section's unit-input zi is scaled.
        let scale = data[0];
        let zi = [zi_base[sec_idx][0] * scale, zi_base[sec_idx][1] * scale];
        data = biquad_filter(&data, section, zi);
    }

    // Reverse
    data.reverse();

    // Backward pass: cascade all sections again
    for (sec_idx, section) in sections.iter().enumerate() {
        // As in the forward pass, the first sample carries the cumulative
        // steady-state gain of all preceding sections in this pass.
        let scale = data[0];
        let zi = [zi_base[sec_idx][0] * scale, zi_base[sec_idx][1] * scale];
        data = biquad_filter(&data, section, zi);
    }

    // Reverse back to original order
    data.reverse();

    // Trim padding
    data[padlen..padlen + n].to_vec()
}

/// Apply forward-reverse filtering (zero-phase) through a cascade of biquad sections.
///
/// Equivalent to MATLAB's `filtfilt` or `scipy.signal.sosfiltfilt`.
///
/// The signal is extended at both ends using odd reflection to reduce edge
/// transients. Steady-state initial conditions are computed for each section
/// to further minimize startup artifacts.
///
/// Because the filter is applied twice (forward + backward), the effective
/// filter order is doubled and the magnitude response is squared. A 2nd-order
/// Butterworth becomes effectively 4th-order with -80 dB/decade rolloff.
///
/// The default padding length is `6 * (2 * sections.len() + 1)` samples on
/// each side (capped at `signal.len() - 1`).  For very narrow high-order
/// filters on short signals this may still be insufficient; use
/// [`filtfilt_with_padlen`] to specify a larger value.
///
/// # Returns
///
/// A filtered signal of the same length as the input, with zero phase distortion.
pub fn filtfilt<T: FilterFloat>(signal: &[T], sections: &[BiquadCoefficients<T>]) -> Vec<T> {
    if signal.is_empty() || sections.is_empty() {
        return signal.to_vec();
    }

    let n = signal.len();
    if n < 2 {
        return signal.to_vec();
    }

    // Issue #8: increased multiplier from 3 to 6 for better edge handling
    // with narrow high-order filters.
    let padlen = (6 * (2 * sections.len() + 1)).min(n - 1);
    filtfilt_with_padlen(signal, sections, padlen)
}

/// Compute steady-state initial conditions for a biquad section (direct form II transposed).
///
/// Returns `[z1, z2]` such that filtering a constant signal `x[n] = 1` produces
/// constant output from the very first sample (no transient).
///
/// Usage: multiply by `signal[0]` to get the actual initial conditions.
pub(super) fn biquad_zi<T: FilterFloat>(section: &BiquadCoefficients<T>) -> [T; 2] {
    let one = T::one();
    let denom = one + section.a1 + section.a2;
    if denom.abs() < lit(1e-15) {
        return [T::zero(), T::zero()];
    }
    let z1 = (section.b1 + section.b2 - (section.a1 + section.a2) * section.b0) / denom;
    let z2 = (section.b2 - section.a2 * section.b0) - section.a2 * z1;
    [z1, z2]
}

/// Apply a single biquad section using direct form II transposed.
pub(super) fn biquad_filter<T: FilterFloat>(
    input: &[T],
    section: &BiquadCoefficients<T>,
    zi: [T; 2],
) -> Vec<T> {
    let mut output = Vec::with_capacity(input.len());
    let mut d0 = zi[0];
    let mut d1 = zi[1];

    for &x in input {
        let y = section.b0 * x + d0;
        d0 = section.b1 * x - section.a1 * y + d1;
        d1 = section.b2 * x - section.a2 * y;
        output.push(y);
    }

    output
}
