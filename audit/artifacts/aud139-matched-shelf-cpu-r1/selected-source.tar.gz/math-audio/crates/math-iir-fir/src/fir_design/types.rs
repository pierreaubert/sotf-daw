/// Analyze pre-ringing in an FIR impulse response.
///
/// Returns the peak pre-ringing level in dB relative to the main tap,
/// and the time extent of pre-ringing above the threshold.
pub fn analyze_pre_ringing(ir: &[f64], sample_rate: f64) -> PreRingingAnalysis {
    if ir.is_empty() {
        return PreRingingAnalysis {
            main_tap_index: 0,
            peak_pre_ringing_db: f64::NEG_INFINITY,
            pre_ringing_time_ms: 0.0,
        };
    }

    let main_tap_idx = ir
        .iter()
        .enumerate()
        .max_by(|(_, a), (_, b)| a.abs().total_cmp(&b.abs()))
        .map(|(i, _)| i)
        .unwrap_or(0);

    let main_tap_abs = ir[main_tap_idx].abs();
    if main_tap_abs == 0.0 {
        return PreRingingAnalysis {
            main_tap_index: main_tap_idx,
            peak_pre_ringing_db: f64::NEG_INFINITY,
            pre_ringing_time_ms: 0.0,
        };
    }

    let mut peak_pre_ringing_db = f64::NEG_INFINITY;
    let mut earliest_significant = main_tap_idx;
    let threshold_db = -60.0; // noise floor for analysis

    for (i, &tap) in ir[..main_tap_idx].iter().enumerate() {
        let tap_abs = tap.abs();
        if tap_abs == 0.0 {
            continue; // skip silent taps
        }
        let level_db = 20.0 * (tap_abs / main_tap_abs).log10();
        if level_db > peak_pre_ringing_db {
            peak_pre_ringing_db = level_db;
        }
        if level_db > threshold_db && i < earliest_significant {
            earliest_significant = i;
        }
    }

    let pre_ringing_samples = main_tap_idx.saturating_sub(earliest_significant);
    let pre_ringing_time_ms = pre_ringing_samples as f64 / sample_rate * 1000.0;

    PreRingingAnalysis {
        main_tap_index: main_tap_idx,
        peak_pre_ringing_db,
        pre_ringing_time_ms,
    }
}

/// Analysis results for pre-ringing in an FIR filter.
#[derive(Debug, Clone)]
pub struct PreRingingAnalysis {
    /// Index of the main (peak) tap
    pub main_tap_index: usize,
    /// Peak pre-ringing level in dB relative to main tap
    pub peak_pre_ringing_db: f64,
    /// Time extent of significant pre-ringing in milliseconds
    pub pre_ringing_time_ms: f64,
}
