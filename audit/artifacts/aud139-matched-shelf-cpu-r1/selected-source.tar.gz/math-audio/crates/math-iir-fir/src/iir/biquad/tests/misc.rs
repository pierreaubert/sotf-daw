use super::super::Biquad;
use super::super::biquad_filter_type::BiquadFilterType;

fn approx_eq(a: f64, b: f64, tol: f64) -> bool {
    (a - b).abs() <= tol
}

#[test]
fn test_lowpass_filter_response() {
    let cutoff = 1000.0;
    let lp = Biquad::new(BiquadFilterType::Lowpass, cutoff, 48000.0, 0.0, 0.0);
    let dc_response = lp.log_result(10.0);
    assert!(
        approx_eq(dc_response, 0.0, 0.5),
        "Lowpass DC response should be ~0 dB, got {}",
        dc_response
    );
    let cutoff_response = lp.log_result(cutoff);
    assert!(
        approx_eq(cutoff_response, -3.0, 0.5),
        "Lowpass at cutoff should be ~-3 dB, got {}",
        cutoff_response
    );
    let high_response = lp.log_result(10000.0);
    assert!(
        high_response < -20.0,
        "Lowpass at 10x cutoff should be < -20 dB, got {}",
        high_response
    );
}

#[test]
fn test_highpass_filter_response() {
    let cutoff = 1000.0;
    let hp = Biquad::new(BiquadFilterType::Highpass, cutoff, 48000.0, 0.0, 0.0);
    let low_response = hp.log_result(100.0);
    assert!(
        low_response < -20.0,
        "Highpass at 0.1x cutoff should be < -20 dB, got {}",
        low_response
    );
    let cutoff_response = hp.log_result(cutoff);
    assert!(
        approx_eq(cutoff_response, -3.0, 0.5),
        "Highpass at cutoff should be ~-3 dB, got {}",
        cutoff_response
    );
    let high_response = hp.log_result(10000.0);
    assert!(
        approx_eq(high_response, 0.0, 0.5),
        "Highpass high freq response should be ~0 dB, got {}",
        high_response
    );
}

#[test]
fn test_notch_filter_response() {
    let center = 1000.0;
    let notch = Biquad::new(BiquadFilterType::Notch, center, 48000.0, 0.0, 0.0);
    let center_response = notch.log_result(center);
    assert!(
        center_response < -30.0,
        "Notch at center should be < -30 dB, got {}",
        center_response
    );
    let low_response = notch.log_result(100.0);
    assert!(
        approx_eq(low_response, 0.0, 1.0),
        "Notch away from center should be ~0 dB, got {}",
        low_response
    );
    let high_response = notch.log_result(10000.0);
    assert!(
        approx_eq(high_response, 0.0, 1.0),
        "Notch away from center should be ~0 dB, got {}",
        high_response
    );
}

#[test]
fn test_peak_filter_boost() {
    let center = 1000.0;
    let gain_db = 6.0;
    let peak = Biquad::new(BiquadFilterType::Peak, center, 48000.0, 2.0, gain_db);
    let center_response = peak.log_result(center);
    assert!(
        approx_eq(center_response, gain_db, 0.5),
        "Peak at center should be ~{} dB, got {}",
        gain_db,
        center_response
    );
    let low_response = peak.log_result(100.0);
    assert!(
        low_response.abs() < 1.0,
        "Peak away from center should be ~0 dB, got {}",
        low_response
    );
}

#[test]
fn test_peak_filter_cut() {
    let center = 1000.0;
    let gain_db = -6.0;
    let peak = Biquad::new(BiquadFilterType::Peak, center, 48000.0, 2.0, gain_db);
    let center_response = peak.log_result(center);
    assert!(
        approx_eq(center_response, gain_db, 0.5),
        "Peak cut at center should be ~{} dB, got {}",
        gain_db,
        center_response
    );
}

#[test]
fn test_lowshelf_filter_response() {
    let freq = 200.0;
    let gain_db = 6.0;
    let ls = Biquad::new(BiquadFilterType::Lowshelf, freq, 48000.0, 0.7, gain_db);
    let low_response = ls.log_result(20.0);
    assert!(
        approx_eq(low_response, gain_db, 1.0),
        "Lowshelf below freq should be ~{} dB, got {}",
        gain_db,
        low_response
    );
    let high_response = ls.log_result(5000.0);
    assert!(
        approx_eq(high_response, 0.0, 1.0),
        "Lowshelf above freq should be ~0 dB, got {}",
        high_response
    );
}

#[test]
fn test_highshelf_filter_response() {
    let freq = 5000.0;
    let gain_db = 6.0;
    let hs = Biquad::new(BiquadFilterType::Highshelf, freq, 48000.0, 0.7, gain_db);
    let low_response = hs.log_result(100.0);
    assert!(
        approx_eq(low_response, 0.0, 1.0),
        "Highshelf below freq should be ~0 dB, got {}",
        low_response
    );
    let high_response = hs.log_result(20000.0);
    assert!(
        approx_eq(high_response, gain_db, 1.0),
        "Highshelf above freq should be ~{} dB, got {}",
        gain_db,
        high_response
    );
}

#[test]
fn test_allpass_filter_response() {
    let center = 1000.0;
    let ap = Biquad::new(BiquadFilterType::AllPass, center, 48000.0, 1.0, 0.0);
    let test_freqs = [20.0, 100.0, 1000.0, 5000.0, 20000.0];
    for &f in &test_freqs {
        let resp = ap.log_result(f);
        assert!(
            approx_eq(resp, 0.0, 1e-9),
            "All-Pass magnitude at {}Hz should be 0 dB, got {}",
            f,
            resp
        );
    }
    let resp = ap.complex_response(center);
    let phase = resp.arg();
    assert!(
        approx_eq(phase.abs(), std::f64::consts::PI, 1e-9),
        "All-Pass phase at center freq should be PI, got {}",
        phase
    );
}

#[test]
fn test_lowshelf_orf_response() {
    let freq = 200.0;
    let gain_db = 6.0;
    let ls = Biquad::new(BiquadFilterType::LowshelfOrf, freq, 48000.0, 0.7, gain_db);
    let low_response = ls.log_result(20.0);
    assert!(
        approx_eq(low_response, gain_db, 1.5),
        "LowshelfOrf below freq should be ~{} dB, got {}",
        gain_db,
        low_response
    );
    let high_response = ls.log_result(20000.0);
    assert!(
        approx_eq(high_response, 0.0, 1.5),
        "LowshelfOrf above freq should be ~0 dB, got {}",
        high_response
    );
    let nyquist_response = ls.log_result(23999.0);
    assert!(
        approx_eq(nyquist_response, 0.0, 0.5),
        "LowshelfOrf at Nyquist should be ~0 dB (prescribed), got {}",
        nyquist_response
    );
}

#[test]
fn test_highshelf_orf_response() {
    let freq = 5000.0;
    let gain_db = 6.0;
    let hs = Biquad::new(BiquadFilterType::HighshelfOrf, freq, 48000.0, 0.7, gain_db);
    let low_response = hs.log_result(100.0);
    assert!(
        approx_eq(low_response, 0.0, 1.5),
        "HighshelfOrf below freq should be ~0 dB, got {}",
        low_response
    );
    let high_response = hs.log_result(20000.0);
    assert!(
        approx_eq(high_response, gain_db, 1.5),
        "HighshelfOrf above freq should be ~{} dB, got {}",
        gain_db,
        high_response
    );
    let dc_response = hs.log_result(10.0);
    assert!(
        approx_eq(dc_response, 0.0, 0.5),
        "HighshelfOrf at DC should be ~0 dB (prescribed), got {}",
        dc_response
    );
}

#[test]
fn test_lowshelf_orf_cut() {
    let freq = 200.0;
    let gain_db = -6.0;
    let ls = Biquad::new(BiquadFilterType::LowshelfOrf, freq, 48000.0, 0.7, gain_db);
    let low_response = ls.log_result(20.0);
    assert!(
        approx_eq(low_response, gain_db, 1.5),
        "LowshelfOrf cut below freq should be ~{} dB, got {}",
        gain_db,
        low_response
    );
    let high_response = ls.log_result(20000.0);
    assert!(
        approx_eq(high_response, 0.0, 1.5),
        "LowshelfOrf cut above freq should be ~0 dB, got {}",
        high_response
    );
}

#[test]
fn test_highshelf_orf_cut() {
    let freq = 5000.0;
    let gain_db = -6.0;
    let hs = Biquad::new(BiquadFilterType::HighshelfOrf, freq, 48000.0, 0.7, gain_db);
    let low_response = hs.log_result(100.0);
    assert!(
        approx_eq(low_response, 0.0, 1.5),
        "HighshelfOrf cut below freq should be ~0 dB, got {}",
        low_response
    );
    let high_response = hs.log_result(20000.0);
    assert!(
        approx_eq(high_response, gain_db, 1.5),
        "HighshelfOrf cut above freq should be ~{} dB, got {}",
        gain_db,
        high_response
    );
}

#[test]
fn test_peak_matched_boost() {
    let center = 1000.0;
    let gain_db = 6.0;
    let peak = Biquad::new(BiquadFilterType::PeakMatched, center, 48000.0, 2.0, gain_db);
    let center_response = peak.log_result(center);
    assert!(
        approx_eq(center_response, gain_db, 0.5),
        "PeakMatched at center should be ~{} dB, got {}",
        gain_db,
        center_response
    );
    let low_response = peak.log_result(100.0);
    assert!(
        low_response.abs() < 1.5,
        "PeakMatched away from center should be ~0 dB, got {}",
        low_response
    );
    let dc_response = peak.log_result(10.0);
    assert!(
        approx_eq(dc_response, 0.0, 0.5),
        "PeakMatched at DC should be ~0 dB, got {}",
        dc_response
    );
    let nyquist_response = peak.log_result(23999.0);
    assert!(
        approx_eq(nyquist_response, 0.0, 0.5),
        "PeakMatched at Nyquist should be ~0 dB, got {}",
        nyquist_response
    );
}

#[test]
fn test_peak_matched_cut() {
    let center = 1000.0;
    let gain_db = -6.0;
    let peak = Biquad::new(BiquadFilterType::PeakMatched, center, 48000.0, 2.0, gain_db);
    let center_response = peak.log_result(center);
    assert!(
        approx_eq(center_response, gain_db, 0.5),
        "PeakMatched cut at center should be ~{} dB, got {}",
        gain_db,
        center_response
    );
}

#[test]
fn test_peak_matched_high_frequency() {
    let center = 10000.0;
    let gain_db = 6.0;
    let matched = Biquad::new(BiquadFilterType::PeakMatched, center, 48000.0, 2.0, gain_db);
    let center_response = matched.log_result(center);
    assert!(
        approx_eq(center_response, gain_db, 1.0),
        "PeakMatched at high freq center should be ~{} dB, got {}",
        gain_db,
        center_response
    );
}

#[test]
fn test_notch_explicit_q_respected() {
    let notch = Biquad::new(BiquadFilterType::Notch, 1000.0, 48000.0, 5.0, 0.0);
    assert!(
        approx_eq(notch.q, 5.0, 1e-9),
        "Notch should use explicit Q=5.0, got {}",
        notch.q
    );
}

#[test]
fn test_notch_default_q_when_zero() {
    let notch = Biquad::new(BiquadFilterType::Notch, 1000.0, 48000.0, 0.0, 0.0);
    assert!(
        approx_eq(notch.q, 30.0, 1e-9),
        "Notch with Q=0 should default to 30.0, got {}",
        notch.q
    );
}

#[test]
fn test_notch_update_params_respects_q() {
    let mut notch = Biquad::new(BiquadFilterType::Notch, 1000.0, 48000.0, 0.0, 0.0);
    assert!(approx_eq(notch.q, 30.0, 1e-9));
    notch.update_params(BiquadFilterType::Notch, 1000.0, 48000.0, 5.0, 0.0);
    assert!(
        approx_eq(notch.q, 5.0, 1e-9),
        "update_params should use explicit Q=5.0, got {}",
        notch.q
    );
    notch.update_params(BiquadFilterType::Notch, 1000.0, 48000.0, 0.0, 0.0);
    assert!(
        approx_eq(notch.q, 30.0, 1e-9),
        "update_params with Q=0 should default to 30.0, got {}",
        notch.q
    );
}

#[test]
fn test_try_new_q_zero_uses_default() {
    let result = Biquad::try_new(BiquadFilterType::Lowpass, 1000.0, 48000.0, 0.0, 0.0);
    assert!(result.is_ok());
    let bq = result.unwrap();
    assert!(approx_eq(bq.q, crate::DEFAULT_Q_HIGH_LOW_PASS, 0.01));
}

#[test]
fn test_biquad_process_dc_lowpass() {
    let mut lp = Biquad::new(BiquadFilterType::Lowpass, 1000.0_f64, 48000.0, 0.0, 0.0);
    let mut output = 0.0_f64;
    for _ in 0..1000 {
        output = lp.process(1.0);
    }
    assert!(
        approx_eq(output, 1.0, 0.01),
        "Lowpass should pass DC, got {}",
        output
    );
}

#[test]
fn test_tdf2_matches_df1_for_peak() {
    let mut df1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
    let mut tdf2 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
    tdf2.use_tdf2 = true;
    for i in 0..1000 {
        let x = (i as f64 * 0.1).sin();
        let y_df1 = df1.process(x);
        let y_tdf2 = tdf2.process(x);
        assert!(
            approx_eq(y_df1, y_tdf2, 1e-10),
            "sample {}: df1={} tdf2={} diff={}",
            i,
            y_df1,
            y_tdf2,
            (y_df1 - y_tdf2).abs()
        );
    }
}

#[test]
fn test_tdf2_matches_df1_for_highshelf() {
    let mut df1 = Biquad::new(BiquadFilterType::Highshelf, 2000.0, 48000.0, 0.707, -3.0);
    let mut tdf2 = Biquad::new(BiquadFilterType::Highshelf, 2000.0, 48000.0, 0.707, -3.0);
    tdf2.use_tdf2 = true;
    for i in 0..1000 {
        let x = (i as f64 * 0.3).sin();
        let y_df1 = df1.process(x);
        let y_tdf2 = tdf2.process(x);
        assert!(
            approx_eq(y_df1, y_tdf2, 1e-10),
            "sample {}: df1={} tdf2={} diff={}",
            i,
            y_df1,
            y_tdf2,
            (y_df1 - y_tdf2).abs()
        );
    }
}

#[test]
fn test_tdf2_process_block_matches_single() {
    let mut single = Biquad::new(BiquadFilterType::Peak, 500.0, 48000.0, 4.0, 10.0);
    single.use_tdf2 = true;
    let mut block = Biquad::new(BiquadFilterType::Peak, 500.0, 48000.0, 4.0, 10.0);
    block.use_tdf2 = true;
    let input: Vec<f64> = (0..256).map(|i| (i as f64 * 0.05).sin()).collect();
    let single_out: Vec<f64> = input.iter().map(|&x| single.process(x)).collect();
    let mut block_buf = input.clone();
    block.process_block(&mut block_buf);
    for i in 0..256 {
        assert!(
            approx_eq(single_out[i], block_buf[i], 1e-12),
            "sample {}: single={} block={}",
            i,
            single_out[i],
            block_buf[i]
        );
    }
}

#[test]
fn test_result_matches_complex_response_magnitude() {
    let filters = [
        Biquad::new(BiquadFilterType::Lowpass, 500.0, 48000.0, 0.707, 0.0),
        Biquad::new(BiquadFilterType::Highpass, 2000.0, 48000.0, 0.707, 0.0),
        Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0),
        Biquad::new(BiquadFilterType::Lowshelf, 250.0, 48000.0, 0.707, 3.0),
        Biquad::new(BiquadFilterType::Highshelf, 6000.0, 48000.0, 0.707, -4.0),
    ];
    let freqs = [20.0, 100.0, 500.0, 1000.0, 4000.0, 12000.0, 20000.0];

    for filter in filters {
        for freq in freqs {
            let fast = filter.result(freq);
            let exact = filter.complex_response(freq).norm();
            assert!(
                approx_eq(fast, exact, 1e-9),
                "result({freq})={fast} should match complex_response norm {exact}"
            );
        }
    }
}

#[test]
fn test_coefficients_and_lerp() {
    let f1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 0.0);
    let f2 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 12.0);
    let c1 = f1.coefficients();
    let c2 = f2.coefficients();
    let lerp0 = c1.lerp(&c2, 0.0);
    assert!(approx_eq(lerp0.b0, c1.b0, 1e-15));
    assert!(approx_eq(lerp0.a1, c1.a1, 1e-15));
    let lerp1 = c1.lerp(&c2, 1.0);
    assert!(approx_eq(lerp1.b0, c2.b0, 1e-15));
    assert!(approx_eq(lerp1.a1, c2.a1, 1e-15));
    let lerp_mid = c1.lerp(&c2, 0.5);
    assert!(approx_eq(lerp_mid.b0, (c1.b0 + c2.b0) / 2.0, 1e-15));
}

#[test]
fn test_process_with_coefficients_matches_normal() {
    let mut f1 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
    let mut f2 = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 2.0, 6.0);
    let coeffs = f2.coefficients();
    for i in 0..500 {
        let x = (i as f64 * 0.1).sin();
        let y1 = f1.process(x);
        let y2 = f2.process_with_coefficients(x, &coeffs);
        assert!(
            approx_eq(y1, y2, 1e-12),
            "sample {}: normal={} with_coeffs={}",
            i,
            y1,
            y2
        );
    }
}

#[test]
fn test_coefficients_finite_for_all_filter_types() {
    let types = [
        BiquadFilterType::Lowpass,
        BiquadFilterType::Highpass,
        BiquadFilterType::HighpassVariableQ,
        BiquadFilterType::Bandpass,
        BiquadFilterType::Notch,
        BiquadFilterType::Peak,
        BiquadFilterType::Lowshelf,
        BiquadFilterType::Highshelf,
        BiquadFilterType::AllPass,
        BiquadFilterType::LowshelfOrf,
        BiquadFilterType::HighshelfOrf,
        BiquadFilterType::PeakMatched,
    ];
    for &ft in &types {
        let bq = Biquad::<f64>::new(ft, 1000.0, 48000.0, 1.0, 0.0);
        let c = bq.coefficients();
        assert!(
            f64::is_finite(c.b0),
            "{}: b0 should be finite",
            ft.short_name()
        );
        assert!(
            f64::is_finite(c.b1),
            "{}: b1 should be finite",
            ft.short_name()
        );
        assert!(
            f64::is_finite(c.b2),
            "{}: b2 should be finite",
            ft.short_name()
        );
        assert!(
            f64::is_finite(c.a1),
            "{}: a1 should be finite",
            ft.short_name()
        );
        assert!(
            f64::is_finite(c.a2),
            "{}: a2 should be finite",
            ft.short_name()
        );
        // With these benign parameters the a0 guard should not trigger.
        let identity = c.b0 == 1.0 && c.b1 == 0.0 && c.b2 == 0.0 && c.a1 == 0.0 && c.a2 == 0.0;
        assert!(
            !identity,
            "{}: coefficients should not be identity fallback",
            ft.short_name()
        );
    }
}

#[test]
fn test_update_params_recomputes_for_all_filter_types() {
    let mut bq = Biquad::<f64>::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 0.0);
    let types = [
        BiquadFilterType::Lowpass,
        BiquadFilterType::Highpass,
        BiquadFilterType::HighpassVariableQ,
        BiquadFilterType::Bandpass,
        BiquadFilterType::Notch,
        BiquadFilterType::Peak,
        BiquadFilterType::Lowshelf,
        BiquadFilterType::Highshelf,
        BiquadFilterType::AllPass,
        BiquadFilterType::LowshelfOrf,
        BiquadFilterType::HighshelfOrf,
        BiquadFilterType::PeakMatched,
    ];
    for &ft in &types {
        bq.update_params(ft, 1000.0, 48000.0, 1.0, 0.0);
        assert_eq!(bq.filter_type, ft);
        let resp: f64 = bq.log_result(1000.0);
        assert!(
            f64::is_finite(resp),
            "{}: response should be finite after update_params",
            ft.short_name()
        );
    }
}
