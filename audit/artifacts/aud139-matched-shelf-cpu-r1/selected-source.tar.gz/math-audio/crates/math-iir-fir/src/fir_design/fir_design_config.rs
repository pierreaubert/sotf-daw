use super::super::fir::WindowType;
use super::fir_phase::FirPhase;
use super::pre_ringing_config::PreRingingConfig;

/// Configuration for FIR filter generation
#[derive(Debug, Clone)]
pub struct FirDesignConfig {
    /// Number of taps (coefficients)
    pub n_taps: usize,
    /// Sample rate in Hz
    pub sample_rate: f64,
    /// Phase type
    pub phase: FirPhase,
    /// Minimum frequency for in-band regularization (Kirkeby only)
    pub min_freq: f64,
    /// Maximum frequency for in-band regularization (Kirkeby only)
    pub max_freq: f64,
    /// Window type for final windowing
    pub window: WindowType,
    /// Whether to correct excess phase in Kirkeby mode (default: false)
    /// When true, the filter will correct both magnitude and excess phase.
    /// When false, only magnitude is corrected (produces linear-phase FIR).
    /// Note: Excess phase correction requires clean phase measurements to be effective.
    pub correct_excess_phase: bool,
    /// Phase smoothing width in octaves (default: 0.167 = 1/6 octave)
    /// Applied via group delay smoothing when excess phase correction is enabled.
    /// Set to 0.0 to disable smoothing.
    pub phase_smoothing_octaves: f64,
    /// Optional pre-ringing suppression. When set, taps before the main impulse
    /// exceeding the threshold are attenuated to reduce audible pre-ringing.
    pub pre_ringing: Option<PreRingingConfig>,
}

impl Default for FirDesignConfig {
    fn default() -> Self {
        Self {
            n_taps: 4096,
            sample_rate: 48000.0,
            phase: FirPhase::Linear,
            min_freq: 20.0,
            max_freq: 20000.0,
            window: WindowType::Blackman,
            correct_excess_phase: false, // Magnitude-only by default (more robust)
            phase_smoothing_octaves: 0.167, // 1/6 octave smoothing
            pre_ringing: None,
        }
    }
}
