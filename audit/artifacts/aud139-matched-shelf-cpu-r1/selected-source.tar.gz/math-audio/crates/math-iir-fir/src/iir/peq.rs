//! Parametric EQ (PEQ) operations: response computation, gain management,
//! format export (APO, RME, Apple AU, EasyEffects, PipeWire, CamillaDSP,
//! Wavelet, Roon), and Butterworth/Linkwitz-Riley filter construction.

use super::biquad::{Biquad, BiquadFilterType, Peq};
use crate::{DEFAULT_Q_HIGH_LOW_PASS, q2bw};
use base64::{Engine as _, engine::general_purpose};
use byteorder::{BigEndian, WriteBytesExt};
use ndarray::Array1;
use std::f64::consts::PI;
use std::sync::OnceLock;

mod biquad;
mod consts;
mod misc;
#[cfg(test)]
mod tests;
mod types;

pub use misc::*;
pub use types::*;

use biquad::biquad_to_apple_type;
use biquad::biquad_to_rme_type;
use consts::K_AUNBANDEQ_PARAM_BANDWIDTH;
use consts::K_AUNBANDEQ_PARAM_BYPASS_BAND;
use consts::K_AUNBANDEQ_PARAM_FILTER_TYPE;
use consts::K_AUNBANDEQ_PARAM_FREQUENCY;
use consts::K_AUNBANDEQ_PARAM_GAIN;
use misc::a_weighting_db;
use misc::enforce_rme_room_filter_constraints;
use misc::k_weighting_db;

/// Check if two PEQs are equal
///
/// Compares two PEQ vectors for equality, checking both weights and biquad parameters
pub fn peq_equal(left: &Peq, right: &Peq) -> bool {
    if left.len() != right.len() {
        return false;
    }

    left.iter().zip(right.iter()).all(|((w1, b1), (w2, b2))| {
        // Compare weights
        (w1 - w2).abs() < f64::EPSILON &&
        // Compare biquad parameters
        b1.filter_type == b2.filter_type &&
        (b1.freq - b2.freq).abs() < f64::EPSILON &&
        (b1.srate - b2.srate).abs() < f64::EPSILON &&
        (b1.q - b2.q).abs() < f64::EPSILON &&
        (b1.db_gain - b2.db_gain).abs() < f64::EPSILON
    })
}

/// Compute SPL for each frequency given a PEQ
///
/// # Arguments
/// * `freq` - Array of frequencies to compute response for
/// * `peq` - PEQ vector containing weighted biquad filters
///
/// # Returns
/// * Array of SPL values in dB for each frequency
pub fn peq_spl(freq: &Array1<f64>, peq: &Peq) -> Array1<f64> {
    let mut current_filter = Array1::zeros(freq.len());
    let mut scratch = Array1::zeros(freq.len());

    peq_spl_into(freq, peq, &mut current_filter, &mut scratch);
    current_filter
}

/// Compute a PEQ response into caller-owned buffers.
///
/// `response` and `filter_scratch` must both have the same length as `freq`.
/// Keeping both buffers outside this function lets optimization workers reuse
/// them across candidate evaluations without allocating in the hot path.
pub fn peq_spl_into(
    freq: &Array1<f64>,
    peq: &Peq,
    response: &mut Array1<f64>,
    filter_scratch: &mut Array1<f64>,
) {
    assert_eq!(
        response.len(),
        freq.len(),
        "response length must match frequency grid"
    );
    assert_eq!(
        filter_scratch.len(),
        freq.len(),
        "filter scratch length must match frequency grid"
    );

    response.fill(0.0);

    for (weight, iir) in peq {
        iir.np_log_result_into(freq, filter_scratch);
        for (sum, value) in response.iter_mut().zip(filter_scratch.iter()) {
            *sum += *value * *weight;
        }
    }
}

/// Compute loudness-weighted gain adjustment for PEQ to maintain spectral balance
///
/// This function estimates the perceived loudness change caused by a PEQ
/// by analyzing its frequency response with perceptual weighting.
/// Much faster than full Replay Gain analysis.
///
/// # Arguments
/// * `peq` - PEQ vector containing weighted biquad filters
/// * `weighting` - Weighting type: "a" for A-weighting, "k" for K-weighting (EBU R128-like)
///
/// # Returns
/// * Gain adjustment in dB to maintain similar loudness (0 dB = no change needed)
///
/// # Example
/// ```no_run
/// use math_audio_iir_fir::{Biquad, BiquadFilterType, peq_loudness_gain};
///
/// let bq = Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 6.0);
/// let peq = vec![(1.0, bq)];
/// let gain_adj = peq_loudness_gain(&peq, "k");
/// println!("Apply {} dB to maintain loudness balance", gain_adj);
/// ```
pub fn peq_loudness_gain(peq: &Peq, weighting: &str) -> f64 {
    if peq.is_empty() {
        return 0.0;
    }

    let freq = loudness_freq_grid();

    // Get PEQ frequency response in dB
    let peq_response_db = peq_spl(freq, peq);

    // Apply perceptual weighting
    let weighted_change: f64 = freq
        .iter()
        .zip(peq_response_db.iter())
        .map(|(f, peq_db)| {
            let weight_db = match weighting {
                "a" => a_weighting_db(*f),
                "k" => k_weighting_db(*f),
                _ => 0.0, // No weighting
            };

            // Convert to linear domain for integration
            // Original: 10^(weight/20)
            // After PEQ: 10^((weight + peq)/20)
            // Ratio: 10^(peq/20)

            let weight_linear = 10.0_f64.powf(weight_db / 20.0);
            let peq_ratio = 10.0_f64.powf(*peq_db / 20.0);

            // Weighted energy change
            weight_linear * weight_linear * (peq_ratio * peq_ratio - 1.0)
        })
        .sum();

    // Average weighted energy change across frequency
    let avg_energy_change = weighted_change / freq.len() as f64;

    // Convert back to dB (half because we squared for energy)
    // Negative because we want to compensate (reduce if PEQ increases loudness)
    // Guard: if total energy is zero or negative (extreme filter combinations),
    // clamp to a small positive value to avoid NaN from log10()
    let energy = (1.0 + avg_energy_change).max(f64::MIN_POSITIVE);
    let loudness_change_db = 10.0 * energy.log10();

    // Clamp to ±60dB — beyond this the filter config is pathological
    (-loudness_change_db).clamp(-60.0, 60.0)
}

/// Compute preamp gain for a PEQ: well adapted to computers
///
/// # Arguments
/// * `peq` - PEQ vector containing weighted biquad filters
///
/// # Returns
/// * Preamp gain in dB (negative value to prevent clipping)
fn preamp_freq_grid() -> &'static Array1<f64> {
    static GRID: OnceLock<Array1<f64>> = OnceLock::new();
    GRID.get_or_init(|| {
        Array1::logspace(
            10.0,
            (2.0f64 * 10.0).log10(),
            (2.0f64 * 10000.0).log10(),
            200,
        )
    })
}

fn loudness_freq_grid() -> &'static Array1<f64> {
    static GRID: OnceLock<Array1<f64>> = OnceLock::new();
    GRID.get_or_init(|| {
        Array1::logspace(
            10.0,
            (2.0f64 * 10.0).log10(),
            (2.0f64 * 10000.0).log10(),
            500,
        )
    })
}

/// Compute preamp gain for a PEQ: well adapted to computers
pub fn peq_preamp_gain(peq: &Peq) -> f64 {
    let freq = preamp_freq_grid();
    let spl = peq_spl(freq, peq);

    // Find maximum positive gain and return its negative
    let overall = spl
        .iter()
        .cloned()
        .fold(0.0f64, |acc, x| acc.max(x.max(0.0)));
    -overall
}

/// Compute preamp gain for a PEQ and look at the worst case
///
/// Note that we add 0.2 dB to have a margin for clipping
///
/// # Arguments
/// * `peq` - PEQ vector containing weighted biquad filters
///
/// # Returns
/// * Preamp gain in dB (negative value to prevent clipping)
pub fn peq_preamp_gain_max(peq: &Peq) -> f64 {
    if peq.is_empty() {
        return 0.0;
    }

    let freq = preamp_freq_grid();
    let spl = peq_spl(freq, peq);

    // Find maximum individual filter contribution
    let mut individual: f64 = 0.0;
    for (_, iir) in peq {
        let single_peq = vec![(1.0, iir.clone())];
        let single_spl = peq_spl(freq, &single_peq);
        let single_max = single_spl.iter().cloned().fold(0.0f64, |acc, x| acc.max(x));
        individual = individual.max(single_max);
    }

    // Find overall maximum positive gain
    let overall = spl
        .iter()
        .cloned()
        .fold(0.0f64, |acc, x| acc.max(x.max(0.0)));

    // Take worst case and add safety margin
    -(individual.max(overall) + 0.2)
}

/// Format PEQ as APO configuration string
///
/// # Arguments
/// * `comment` - Comment string to include at the top
/// * `peq` - PEQ vector containing weighted biquad filters
///
/// # Returns
/// * String formatted for EqualizerAPO
pub fn peq_format_apo(comment: &str, peq: &Peq) -> String {
    let mut res = Vec::new();
    res.push(comment.to_string());
    res.push(format!("Preamp: {:.1} dB", peq_preamp_gain(peq)));
    res.push(String::new());

    // Sort filters by frequency in ascending order
    let mut sorted_peq: Vec<(f64, &Biquad)> = peq.iter().map(|(_, iir)| (iir.freq, iir)).collect();
    sorted_peq.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));

    for (i, (_, iir)) in sorted_peq.iter().enumerate() {
        match iir.filter_type {
            BiquadFilterType::Peak | BiquadFilterType::Notch | BiquadFilterType::Bandpass => {
                res.push(format!(
                    "Filter {:2}: ON {:2} Fc {:5} Hz Gain {:+0.2} dB Q {:0.2}",
                    i + 1,
                    iir.filter_type.short_name(),
                    iir.freq as i32,
                    iir.db_gain,
                    iir.q
                ));
            }
            BiquadFilterType::Lowpass | BiquadFilterType::Highpass => {
                if (iir.q - DEFAULT_Q_HIGH_LOW_PASS).abs() < f64::EPSILON {
                    res.push(format!(
                        "Filter {:2}: ON {:2} Fc {:5} Hz",
                        i + 1,
                        iir.filter_type.short_name(),
                        iir.freq as i32
                    ));
                } else {
                    res.push(format!(
                        "Filter {:2}: ON {:2}Q Fc {:5} Hz Q {:0.2}",
                        i + 1,
                        iir.filter_type.short_name(),
                        iir.freq as i32,
                        iir.q
                    ));
                }
            }
            BiquadFilterType::Lowshelf
            | BiquadFilterType::Highshelf
            | BiquadFilterType::LowshelfOrf
            | BiquadFilterType::HighshelfOrf => {
                res.push(format!(
                    "Filter {:2}: ON {:2} Fc {:5} Hz Gain {:+0.2} dB Q {:.2}",
                    i + 1,
                    iir.filter_type.short_name(),
                    iir.freq as i32,
                    iir.db_gain,
                    iir.q
                ));
            }
            BiquadFilterType::PeakMatched => {
                res.push(format!(
                    "Filter {:2}: ON {:2} Fc {:5} Hz Gain {:+0.2} dB Q {:0.2}",
                    i + 1,
                    iir.filter_type.short_name(),
                    iir.freq as i32,
                    iir.db_gain,
                    iir.q
                ));
            }
            BiquadFilterType::HighpassVariableQ => {
                res.push(format!(
                    "Filter {:2}: ON HPQ Fc {:5} Hz Q {:0.2}",
                    i + 1,
                    iir.freq as i32,
                    iir.q
                ));
            }
            BiquadFilterType::AllPass => {
                res.push(format!(
                    "Filter {:2}: ON AP Fc {:5} Hz Q {:0.2}",
                    i + 1,
                    iir.freq as i32,
                    iir.q
                ));
            }
        }
    }

    res.push(String::new());
    res.join("\n")
}

/// Compute Q values for Butterworth filters
///
/// # Arguments
/// * `order` - Filter order
///
/// # Returns
/// * Vector of Q values for each biquad section
pub fn peq_butterworth_q(order: usize) -> Vec<f64> {
    let odd = !order.is_multiple_of(2);
    let mut q_values = Vec::new();

    for i in 0..order / 2 {
        let q = 2.0 * (PI / order as f64 * (i as f64 + 0.5)).sin();
        q_values.push(1.0 / q);
    }

    if odd {
        q_values.push(-1.0);
    }

    q_values
}

/// Create Butterworth lowpass filter
///
/// # Arguments
/// * `order` - Filter order
/// * `freq` - Cutoff frequency in Hz
/// * `srate` - Sample rate in Hz
///
/// # Returns
/// * PEQ containing the Butterworth lowpass filter sections
pub fn peq_butterworth_lowpass(order: usize, freq: f64, srate: f64) -> Peq {
    let q_values = peq_butterworth_q(order);
    q_values
        .into_iter()
        .map(|q| {
            (
                1.0,
                Biquad::new(BiquadFilterType::Lowpass, freq, srate, q, 0.0),
            )
        })
        .collect()
}

/// Create Butterworth highpass filter
///
/// # Arguments
/// * `order` - Filter order
/// * `freq` - Cutoff frequency in Hz
/// * `srate` - Sample rate in Hz
///
/// # Returns
/// * PEQ containing the Butterworth highpass filter sections
pub fn peq_butterworth_highpass(order: usize, freq: f64, srate: f64) -> Peq {
    let q_values = peq_butterworth_q(order);
    q_values
        .into_iter()
        .map(|q| {
            (
                1.0,
                Biquad::new(BiquadFilterType::Highpass, freq, srate, q, 0.0),
            )
        })
        .collect()
}

/// Compute Q values for Linkwitz-Riley filters
///
/// # Arguments
/// * `order` - Filter order
///
/// # Returns
/// * Vector of Q values for each biquad section
pub fn peq_linkwitzriley_q(order: usize) -> Vec<f64> {
    assert!(
        order >= 2 && order.is_multiple_of(2),
        "Linkwitz-Riley order must be even and >= 2, got {order}"
    );
    let q_bw = peq_butterworth_q(order / 2);
    let mut q_values = Vec::new();

    if !order.is_multiple_of(4) {
        // Odd number of pairs
        q_values.extend_from_slice(&q_bw[..q_bw.len() - 1]);
        q_values.extend_from_slice(&q_bw[..q_bw.len() - 1]);
        q_values.push(0.5);
    } else {
        // Even number of pairs
        q_values.extend_from_slice(&q_bw);
        q_values.extend_from_slice(&q_bw);
    }

    q_values
}

/// Create Linkwitz-Riley lowpass filter
///
/// # Arguments
/// * `order` - Filter order
/// * `freq` - Cutoff frequency in Hz
/// * `srate` - Sample rate in Hz
///
/// # Returns
/// * PEQ containing the Linkwitz-Riley lowpass filter sections
pub fn peq_linkwitzriley_lowpass(order: usize, freq: f64, srate: f64) -> Peq {
    let q_values = peq_linkwitzriley_q(order);
    q_values
        .into_iter()
        .map(|q| {
            (
                1.0,
                Biquad::new(BiquadFilterType::Lowpass, freq, srate, q, 0.0),
            )
        })
        .collect()
}

/// Create Linkwitz-Riley highpass filter
///
/// # Arguments
/// * `order` - Filter order
/// * `freq` - Cutoff frequency in Hz
/// * `srate` - Sample rate in Hz
///
/// # Returns
/// * PEQ containing the Linkwitz-Riley highpass filter sections
pub fn peq_linkwitzriley_highpass(order: usize, freq: f64, srate: f64) -> Peq {
    let q_values = peq_linkwitzriley_q(order);
    q_values
        .into_iter()
        .map(|q| {
            (
                1.0,
                Biquad::new(BiquadFilterType::Highpass, freq, srate, q, 0.0),
            )
        })
        .collect()
}

/// Create All-Pass filter
///
/// # Arguments
/// * `freq` - Center frequency in Hz
/// * `srate` - Sample rate in Hz
/// * `q` - Q factor
///
/// # Returns
/// * PEQ containing the All-Pass filter section
pub fn peq_allpass(freq: f64, srate: f64, q: f64) -> Peq {
    vec![(
        1.0,
        Biquad::new(BiquadFilterType::AllPass, freq, srate, q, 0.0),
    )]
}

/// Print a formatted table of the parametric EQ filters from a Peq.
pub fn peq_print(peq: &Peq) {
    // Build filter rows from Peq
    let mut rows: Vec<FilterRow> = Vec::new();
    for (_weight, filter) in peq {
        rows.push(FilterRow {
            freq: filter.freq,
            q: filter.q,
            gain: filter.db_gain,
            kind: filter.filter_type.short_name(),
        });
    }

    // Sort by frequency
    rows.sort_by(|a, b| {
        a.freq
            .partial_cmp(&b.freq)
            .unwrap_or(std::cmp::Ordering::Equal)
    });

    println!("+-# -|-Freq (Hz)--|-Q ---------|-Gain (dB)--|-Type-----+");
    for (i, r) in rows.iter().enumerate() {
        println!(
            "| {:<2} | {:<10.2} | {:<10.3} | {:<+10.3} | {:<8} |",
            i + 1,
            r.freq,
            r.q,
            r.gain,
            r.kind
        );
    }
    println!("+----|------------|------------|------------|----------+");
}

/// Format PEQ as RME TotalMix channel preset XML
///
/// # Arguments
/// * `peq` - PEQ vector containing weighted biquad filters
///
/// # Returns
/// * String formatted as RME TotalMix channel preset XML
///
/// # Notes
/// Generates XML in the format expected by RME TotalMix channel EQ (max 3 bands).
/// Includes LC Grade and LC Freq defaults, followed by Band parameters for
/// frequency, Q, and gain, then Band Type specifications.
pub fn peq_format_rme_channel(peq: &Peq) -> String {
    #[allow(clippy::vec_init_then_push)]
    let mut lines = vec![
        "<Preset>".to_string(),
        "  <Equalizer>".to_string(),
        "    <Params>".to_string(),
        "\t<val e=\"LC Grade\" v=\"1.00,\"/>".to_string(),
        "\t<val e=\"LC Freq\" v=\"20.00,\"/>".to_string(),
    ];

    // Add Band parameters (freq, Q, gain)
    for (i, (_, biquad)) in peq.iter().enumerate() {
        lines.push(format!(
            "      <val e=\"Band{} Freq\" v=\"{:7.2},\"/>",
            i + 1,
            biquad.freq
        ));
        lines.push(format!(
            "      <val e=\"Band{} Q\" v=\"{:4.2},\"/>",
            i + 1,
            biquad.q
        ));
        lines.push(format!(
            "        <val e=\"Band{} Gain\" v=\"{:4.2},\"/>",
            i + 1,
            biquad.db_gain
        ));
    }

    // Add Band types
    for (i, (_, biquad)) in peq.iter().enumerate() {
        let rme_type = biquad_to_rme_type(biquad.filter_type, i + 1);
        if rme_type >= 0.0 {
            lines.push(format!(
                "        <val e=\"Band{} Type\" v=\"{:4.2},\"/>",
                i + 1,
                rme_type
            ));
        }
    }

    lines.push("    </Params>".to_string());
    lines.push("  </Equalizer>".to_string());
    lines.push("</Preset>".to_string());

    lines.join("\n")
}

/// Format PEQ as RME TotalMix room EQ preset XML (dual channel)
///
/// # Arguments
/// * `left` - PEQ vector for left channel
/// * `right` - PEQ vector for right channel (if empty, left channel is used for both)
///
/// # Returns
/// * String formatted as RME TotalMix room EQ preset XML
///
/// # Notes
/// Generates XML in the format expected by RME TotalMix room EQ.
/// Always outputs exactly 9 bands per channel with RME constraints:
/// - Position 1 can be: PK, LS, HS, LP, or HP (lowest freq non-PK preferred)
/// - Positions 2-8 can only be PK
/// - Position 9 can be: PK, LS, HS, LP, or HP (highest freq non-PK preferred)
pub fn peq_format_rme_room(left: &Peq, right: &Peq) -> String {
    // Apply RME room EQ constraints - returns exactly 9 bands
    let left_constrained = enforce_rme_room_filter_constraints(left);
    let right_constrained = if !right.is_empty() {
        enforce_rme_room_filter_constraints(right)
    } else {
        left_constrained.clone()
    };

    let mut lines = Vec::new();

    // Helper closure to process a channel's PEQ items
    let process_channel = |peqs: &Peq, lines: &mut Vec<String>| {
        // Add frequency, Q, and gain parameters
        for (i, (_, biquad)) in peqs.iter().enumerate() {
            lines.push(format!(
                "        <val e=\"REQ Band{} Freq\" v=\"{:7.2},\"/>",
                i + 1,
                biquad.freq
            ));
            lines.push(format!(
                "        <val e=\"REQ Band{} Q\" v=\"{:4.2},\"/>",
                i + 1,
                biquad.q
            ));
            lines.push(format!(
                "        <val e=\"REQ Band{} Gain\" v=\"{:4.2},\"/>",
                i + 1,
                biquad.db_gain
            ));
        }

        // Add type parameters
        for (i, (_, biquad)) in peqs.iter().enumerate() {
            let rme_type = biquad_to_rme_type(biquad.filter_type, i + 1);
            if rme_type >= 0.0 {
                lines.push(format!(
                    "        <val e=\"REQ Band{} Type\" v=\"{:4.2},\"/>",
                    i + 1,
                    rme_type
                ));
            }
        }
    };

    lines.push("<Preset>".to_string());

    // Process left channel
    let preamp_gain = 0.0;
    lines.push("  <Room EQ L>".to_string());
    lines.push("    <Params>".to_string());
    lines.push("\t<val e=\"REQ Delay\" v=\"0.00,\"/>".to_string());
    process_channel(&left_constrained, &mut lines);
    lines.push(format!(
        "\t<val e=\"REQ Chan Gain\" v=\"{},\"/>",
        preamp_gain
    ));
    lines.push("    </Params>".to_string());
    lines.push("  </Room EQ L>".to_string());

    // Process right channel (use left if right is empty)
    lines.push("  <Room EQ R>".to_string());
    lines.push("    <Params>".to_string());
    lines.push("\t<val e=\"REQ Delay\" v=\"0.00,\"/>".to_string());
    if !right_constrained.is_empty() {
        process_channel(&right_constrained, &mut lines);
    } else {
        process_channel(&left_constrained, &mut lines);
    }
    lines.push(format!(
        "\t<val e=\"REQ Chan Gain\" v=\"{},\"/>",
        preamp_gain
    ));
    lines.push("    </Params>".to_string());
    lines.push("  </Room EQ R>".to_string());

    lines.push("</Preset>".to_string());

    lines.join("\n")
}

/// Format PEQ as Apple AUNBandEQ preset (aupreset) plist XML
///
/// # Arguments
/// * `peq` - PEQ vector containing weighted biquad filters
/// * `name` - Name for the preset
///
/// # Returns
/// * String formatted as Apple AUNBandEQ preset plist XML
///
/// # Notes
/// Generates a plist XML file containing base64-encoded binary data
/// in the format expected by Apple's AUNBandEQ audio unit.
/// Supports up to 16 bands with parameters for bypass, type, frequency,
/// gain, and bandwidth.
pub fn peq_format_aupreset(peq: &Peq, name: &str) -> String {
    let len_peq = peq.len().min(16); // Max 16 bands for Apple
    let preamp_gain = peq_preamp_gain(peq);

    // Build binary data structure
    let mut buffer = Vec::new();

    // Header: 5 values (4 integers + 1 float)
    // Structure: [0, 0, ndata (81), 0, preamp_gain]
    buffer.write_i32::<BigEndian>(0).unwrap();
    buffer.write_i32::<BigEndian>(0).unwrap();
    buffer.write_i32::<BigEndian>(81).unwrap(); // ndata is always 81
    buffer.write_i32::<BigEndian>(0).unwrap();
    buffer.write_f32::<BigEndian>(preamp_gain as f32).unwrap();

    // Create parameter map
    let mut params = std::collections::BTreeMap::new();

    // Add parameters for each band
    for (i, (_, biquad)) in peq.iter().take(16).enumerate() {
        let idx = i as i32;
        params.insert(K_AUNBANDEQ_PARAM_BYPASS_BAND + idx, 0.0f32); // 0.0 = enabled
        params.insert(
            K_AUNBANDEQ_PARAM_FILTER_TYPE + idx,
            biquad_to_apple_type(biquad.filter_type) as f32,
        );
        params.insert(K_AUNBANDEQ_PARAM_FREQUENCY + idx, biquad.freq as f32);
        params.insert(K_AUNBANDEQ_PARAM_GAIN + idx, biquad.db_gain as f32);
        params.insert(K_AUNBANDEQ_PARAM_BANDWIDTH + idx, q2bw(biquad.q) as f32);
    }

    // Fill remaining bands (up to 16) with disabled/zero values
    for i in len_peq..16 {
        let idx = i as i32;
        params.insert(K_AUNBANDEQ_PARAM_BYPASS_BAND + idx, 1.0f32); // 1.0 = disabled
        params.insert(K_AUNBANDEQ_PARAM_FILTER_TYPE + idx, 0.0f32);
        params.insert(K_AUNBANDEQ_PARAM_FREQUENCY + idx, 0.0f32);
        params.insert(K_AUNBANDEQ_PARAM_GAIN + idx, 0.0f32);
        params.insert(K_AUNBANDEQ_PARAM_BANDWIDTH + idx, 0.0f32);
    }

    // Write parameters in sorted order (param_id, value) pairs
    for (param_id, value) in params.iter() {
        buffer.write_i32::<BigEndian>(*param_id).unwrap();
        buffer.write_f32::<BigEndian>(*value).unwrap();
    }

    // Base64 encode the buffer
    let b64_text = general_purpose::STANDARD.encode(&buffer);

    // Format as chunks of 68 characters with tabs
    let chunk_size = 68;
    let mut data_lines = Vec::new();
    for chunk in b64_text.as_bytes().chunks(chunk_size) {
        data_lines.push(format!("\t{}", String::from_utf8_lossy(chunk)));
    }
    let data_section = data_lines.join("\n");

    // Build the plist XML
    format!(
        r#"<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>ParametricType</key>
	<integer>11</integer>
	<key>data</key>
	<data>
{}
	</data>
	<key>manufacturer</key>
	<integer>1634758764</integer>
	<key>name</key>
	<string>{}</string>
	<key>numberOfBands</key>
	<integer>{}</integer>
	<key>subtype</key>
	<integer>1851942257</integer>
	<key>type</key>
	<integer>1635083896</integer>
	<key>version</key>
	<integer>0</integer>
</dict>
</plist>
"#,
        data_section, name, len_peq
    )
}

/// Format a PEQ as an EasyEffects JSON preset.
///
/// Produces a valid EasyEffects PEQ input preset with up to 30 bands.
pub fn peq_format_easyeffects(comment: &str, peq: &Peq) -> String {
    use std::fmt::Write;

    fn ee_type(ft: BiquadFilterType) -> &'static str {
        match ft {
            BiquadFilterType::Peak | BiquadFilterType::PeakMatched => "Bell",
            BiquadFilterType::Lowshelf | BiquadFilterType::LowshelfOrf => "Lo Shelf",
            BiquadFilterType::Highshelf | BiquadFilterType::HighshelfOrf => "Hi Shelf",
            BiquadFilterType::Lowpass => "Lo-pass",
            BiquadFilterType::Highpass | BiquadFilterType::HighpassVariableQ => "Hi-pass",
            BiquadFilterType::Notch => "Notch",
            BiquadFilterType::Bandpass => "Bandpass",
            BiquadFilterType::AllPass => "Allpass",
        }
    }

    let preamp = peq_preamp_gain(peq);
    let num_bands = peq.len().min(30);
    let mut bands = String::new();

    for (i, (_, iir)) in peq.iter().enumerate().take(30) {
        if i > 0 {
            writeln!(bands, ",").unwrap();
        }
        write!(
            bands,
            r#"        "band{i}": {{
          "frequency": {freq},
          "gain": {gain},
          "q": {q},
          "type": "{ft}",
          "mode": "RLC (BT)",
          "slope": "x1",
          "solo": false,
          "mute": false
        }}"#,
            freq = iir.freq,
            gain = iir.db_gain,
            q = iir.q,
            ft = ee_type(iir.filter_type),
        )
        .unwrap();
    }

    format!(
        r#"// {comment}
{{
  "output": {{
    "equalizer#0": {{
      "input-gain": {preamp:.2},
      "output-gain": 0.0,
      "num-bands": {num_bands},
      "split-channels": false,
      "left": {{
{bands}
      }},
      "right": {{
{bands}
      }}
    }}
  }}
}}"#
    )
}

/// Format a PEQ as a PipeWire filter-chain SPA-JSON configuration.
///
/// Produces a stereo (L/R) PipeWire module configuration with biquad filter nodes.
pub fn peq_format_pipewire(comment: &str, peq: &Peq) -> String {
    use std::fmt::Write;

    fn pw_label(ft: BiquadFilterType) -> &'static str {
        match ft {
            BiquadFilterType::Peak | BiquadFilterType::PeakMatched => "bq_peaking",
            BiquadFilterType::Lowshelf | BiquadFilterType::LowshelfOrf => "bq_lowshelf",
            BiquadFilterType::Highshelf | BiquadFilterType::HighshelfOrf => "bq_highshelf",
            BiquadFilterType::Lowpass => "bq_lowpass",
            BiquadFilterType::Highpass | BiquadFilterType::HighpassVariableQ => "bq_highpass",
            BiquadFilterType::Notch => "bq_notch",
            BiquadFilterType::Bandpass => "bq_bandpass",
            BiquadFilterType::AllPass => "bq_allpass",
        }
    }

    let preamp = peq_preamp_gain(peq);
    let mut out = String::new();
    writeln!(out, "# {comment}").unwrap();
    writeln!(out, "# PipeWire filter-chain configuration").unwrap();
    writeln!(out).unwrap();
    writeln!(out, "context.modules = [").unwrap();
    writeln!(out, "  {{ name = libpipewire-module-filter-chain").unwrap();
    writeln!(out, "    args = {{").unwrap();
    writeln!(out, "      filter.graph = {{").unwrap();
    writeln!(out, "        nodes = [").unwrap();

    // Build nodes for both L and R channels
    let channels = ["L", "R"];
    let mut all_node_names: Vec<Vec<String>> = Vec::new();

    for ch in &channels {
        let mut node_names = Vec::new();

        // Preamp gain node
        if preamp.abs() > 0.01 {
            let name = format!("{ch}_preamp");
            writeln!(out, "          {{ type = builtin  name = \"{name}\"  label = bq_highshelf  control = {{ \"Freq\" = 0  \"Q\" = 1.0  \"Gain\" = {preamp:.2} }} }}").unwrap();
            node_names.push(name);
        }

        // EQ filter nodes
        for (i, (_, iir)) in peq.iter().enumerate() {
            let label = pw_label(iir.filter_type);
            let name = format!("{ch}_eq_{i}");
            match iir.filter_type {
                BiquadFilterType::Lowpass
                | BiquadFilterType::Highpass
                | BiquadFilterType::HighpassVariableQ => {
                    writeln!(out, "          {{ type = builtin  name = \"{name}\"  label = {label}  control = {{ \"Freq\" = {:.1}  \"Q\" = {:.4} }} }}", iir.freq, iir.q).unwrap();
                }
                _ => {
                    writeln!(out, "          {{ type = builtin  name = \"{name}\"  label = {label}  control = {{ \"Freq\" = {:.1}  \"Q\" = {:.4}  \"Gain\" = {:.2} }} }}", iir.freq, iir.q, iir.db_gain).unwrap();
                }
            }
            node_names.push(name);
        }

        all_node_names.push(node_names);
    }

    writeln!(out, "        ]").unwrap();

    // Links
    writeln!(out, "        links = [").unwrap();
    for nodes in &all_node_names {
        for pair in nodes.windows(2) {
            writeln!(
                out,
                "          {{ output = \"{}:Out\"  input = \"{}:In\" }}",
                pair[0], pair[1]
            )
            .unwrap();
        }
    }
    writeln!(out, "        ]").unwrap();

    // Inputs/outputs
    writeln!(out, "        inputs  = [").unwrap();
    for nodes in &all_node_names {
        if let Some(first) = nodes.first() {
            writeln!(out, "          {{ node = \"{first}\"  port = \"In\" }}").unwrap();
        }
    }
    writeln!(out, "        ]").unwrap();
    writeln!(out, "        outputs = [").unwrap();
    for nodes in &all_node_names {
        if let Some(last) = nodes.last() {
            writeln!(out, "          {{ node = \"{last}\"  port = \"Out\" }}").unwrap();
        }
    }
    writeln!(out, "        ]").unwrap();

    writeln!(out, "      }}").unwrap();
    writeln!(
        out,
        "      capture.props = {{ media.class = Audio/Sink  node.name = \"sotf_eq\" }}"
    )
    .unwrap();
    writeln!(
        out,
        "      playback.props = {{ node.name = \"sotf_eq_out\" }}"
    )
    .unwrap();
    writeln!(out, "      audio.channels = 2").unwrap();
    writeln!(out, "      audio.position = [ \"FL\", \"FR\" ]").unwrap();
    writeln!(out, "    }}").unwrap();
    writeln!(out, "  }}").unwrap();
    writeln!(out, "]").unwrap();

    out
}

/// Format a PEQ as a CamillaDSP YAML configuration.
///
/// Produces a stereo CamillaDSP config with Biquad filters in the pipeline.
pub fn peq_format_camilladsp(comment: &str, peq: &Peq, sample_rate: u32) -> String {
    use std::fmt::Write;

    fn cdsp_type(ft: BiquadFilterType) -> &'static str {
        match ft {
            BiquadFilterType::Peak | BiquadFilterType::PeakMatched => "Peaking",
            BiquadFilterType::Lowshelf | BiquadFilterType::LowshelfOrf => "Lowshelf",
            BiquadFilterType::Highshelf | BiquadFilterType::HighshelfOrf => "Highshelf",
            BiquadFilterType::Lowpass => "LowpassQ",
            BiquadFilterType::Highpass | BiquadFilterType::HighpassVariableQ => "HighpassQ",
            BiquadFilterType::Notch => "Notch",
            BiquadFilterType::Bandpass => "Bandpass",
            BiquadFilterType::AllPass => "Allpass",
        }
    }

    let preamp = peq_preamp_gain(peq);
    let mut out = String::new();
    writeln!(out, "# {comment}").unwrap();
    writeln!(out, "# CamillaDSP configuration").unwrap();
    writeln!(out).unwrap();

    // Devices
    writeln!(out, "devices:").unwrap();
    writeln!(out, "  samplerate: {sample_rate}").unwrap();
    writeln!(out, "  chunksize: 1024").unwrap();
    writeln!(out, "  capture:").unwrap();
    writeln!(out, "    type: Stdin").unwrap();
    writeln!(out, "    channels: 2").unwrap();
    writeln!(out, "    format: S32LE").unwrap();
    writeln!(out, "  playback:").unwrap();
    writeln!(out, "    type: Stdout").unwrap();
    writeln!(out, "    channels: 2").unwrap();
    writeln!(out, "    format: S32LE").unwrap();
    writeln!(out).unwrap();

    // Filters
    writeln!(out, "filters:").unwrap();
    if preamp.abs() > 0.01 {
        writeln!(out, "  preamp:").unwrap();
        writeln!(out, "    type: Gain").unwrap();
        writeln!(out, "    parameters:").unwrap();
        writeln!(out, "      gain: {preamp:.2}").unwrap();
    }
    for (i, (_, iir)) in peq.iter().enumerate() {
        let ft = cdsp_type(iir.filter_type);
        writeln!(out, "  eq_{i}:").unwrap();
        writeln!(out, "    type: Biquad").unwrap();
        writeln!(out, "    parameters:").unwrap();
        writeln!(out, "      type: {ft}").unwrap();
        writeln!(out, "      freq: {:.1}", iir.freq).unwrap();
        writeln!(out, "      q: {:.4}", iir.q).unwrap();
        if iir.db_gain.abs() > 0.001 {
            writeln!(out, "      gain: {:.2}", iir.db_gain).unwrap();
        }
    }
    writeln!(out).unwrap();

    // Pipeline
    writeln!(out, "pipeline:").unwrap();
    writeln!(out, "  - type: Filter").unwrap();
    writeln!(out, "    channels: [0, 1]").unwrap();
    writeln!(out, "    names:").unwrap();
    if preamp.abs() > 0.01 {
        writeln!(out, "      - preamp").unwrap();
    }
    for i in 0..peq.len() {
        writeln!(out, "      - eq_{i}").unwrap();
    }

    out
}

/// Format a PEQ as a Wavelet GraphicEQ string.
///
/// Evaluates the PEQ biquad chain at the 9 standard graphic EQ band frequencies
/// and formats the result as a Wavelet-compatible line.
pub fn peq_format_wavelet(comment: &str, peq: &Peq, sample_rate: f64) -> String {
    use std::fmt::Write;

    const BANDS: [f64; 9] = [
        32.0, 64.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0,
    ];

    let preamp = peq_preamp_gain(peq);
    let mut out = String::new();
    writeln!(out, "# {comment}").unwrap();
    writeln!(out, "# Wavelet GraphicEQ").unwrap();

    write!(out, "GraphicEQ:").unwrap();
    for (i, &freq) in BANDS.iter().enumerate() {
        let mut db = preamp;
        for (_, bq) in peq.iter() {
            db += bq.log_result(freq);
        }
        if i > 0 {
            write!(out, ";").unwrap();
        }
        write!(out, " {freq:.0} {db:.1}").unwrap();
    }
    writeln!(out).unwrap();

    // Suppress unused variable warning for sample_rate — kept for API consistency
    let _ = sample_rate;

    out
}

/// Format a PEQ as a Roon DSP parametric EQ preset (JSON).
///
/// Roon's parametric EQ uses a JSON object with a `bands` array. Each band has a
/// filter type, frequency, gain, Q factor, and enabled flag. Roon supports up to 20 bands.
///
/// The output can be used as reference for manual entry in Roon's DSP Engine UI.
pub fn peq_format_roon(comment: &str, peq: &Peq) -> String {
    use std::fmt::Write;

    fn roon_type(ft: BiquadFilterType) -> &'static str {
        match ft {
            BiquadFilterType::Peak | BiquadFilterType::PeakMatched => "Peak/Dip",
            BiquadFilterType::Lowshelf | BiquadFilterType::LowshelfOrf => "Low Shelf",
            BiquadFilterType::Highshelf | BiquadFilterType::HighshelfOrf => "High Shelf",
            BiquadFilterType::Lowpass => "Low Pass",
            BiquadFilterType::Highpass | BiquadFilterType::HighpassVariableQ => "High Pass",
            BiquadFilterType::Bandpass => "Band Pass",
            BiquadFilterType::Notch => "Band Stop",
            BiquadFilterType::AllPass => "Band Stop",
        }
    }

    let preamp = peq_preamp_gain(peq);
    let mut bands = String::new();

    for (i, (_, iir)) in peq.iter().enumerate().take(20) {
        if i > 0 {
            writeln!(bands, ",").unwrap();
        }
        write!(
            bands,
            r#"    {{
      "type": "{ft}",
      "frequency": {freq},
      "gain": {gain},
      "q": {q},
      "enabled": true
    }}"#,
            ft = roon_type(iir.filter_type),
            freq = iir.freq,
            gain = iir.db_gain,
            q = iir.q,
        )
        .unwrap();
    }

    format!(
        r#"// {comment}
// Roon DSP Parametric EQ preset (preamp: {preamp:.2} dB)
{{
  "bands": [
{bands}
  ],
  "is_enabled": true
}}"#
    )
}
