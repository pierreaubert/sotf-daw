use super::misc::bessel_i0;
use super::types::FirBank;
use super::window_type::generate_window;

#[cfg(test)]
mod fir_tests {
    use super::super::*;
    use super::*;
    use ndarray::array;
    use num_traits::Float;

    fn approx_eq(a: f64, b: f64, tol: f64) -> bool {
        (a - b).abs() <= tol
    }

    #[test]
    fn test_fir_lowpass_creation() {
        let fir = Fir::lowpass(51, 1000.0, 48000.0, WindowType::Hamming, 0.0);
        assert_eq!(fir.filter_type, FirFilterType::Lowpass);
        assert_eq!(fir.n_taps(), 51);
        assert_eq!(fir.freq, 1000.0);
        assert_eq!(fir.srate, 48000.0);
        assert_eq!(fir.window, WindowType::Hamming);
    }

    #[test]
    fn test_fir_highpass_creation() {
        let fir = Fir::highpass(51, 1000.0, 48000.0, WindowType::Hann, 0.0);
        assert_eq!(fir.filter_type, FirFilterType::Highpass);
        assert_eq!(fir.n_taps(), 51);
        assert_eq!(fir.freq, 1000.0);
    }

    #[test]
    fn test_fir_bandpass_creation() {
        let fir = Fir::bandpass(51, 500.0, 2000.0, 48000.0, WindowType::Blackman, 0.0);
        assert_eq!(fir.filter_type, FirFilterType::Bandpass);
        assert_eq!(fir.n_taps(), 51);
        assert_eq!(fir.freq, 500.0);
        assert_eq!(fir.freq_upper, Some(2000.0));
    }

    #[test]
    fn test_fir_bandstop_creation() {
        let fir = Fir::bandstop(51, 500.0, 2000.0, 48000.0, WindowType::Kaiser, 5.0);
        assert_eq!(fir.filter_type, FirFilterType::Bandstop);
        assert_eq!(fir.n_taps(), 51);
        assert_eq!(fir.kaiser_beta, 5.0);
    }

    #[test]
    fn test_fir_bandpass_has_unity_gain_at_band_center() {
        let low = 4000.0;
        let high = 8000.0;
        let fir = Fir::bandpass(51, low, high, 48_000.0, WindowType::Hann, 0.0);
        let center_gain = fir.result((low + high) * 0.5);
        assert!(
            (center_gain - 1.0).abs() < 1e-12,
            "bandpass center gain must be one, got {center_gain}"
        );
    }

    #[test]
    fn test_fir_bandstop_has_unity_dc_gain() {
        let fir = Fir::bandstop(51, 4000.0, 8000.0, 48_000.0, WindowType::Hann, 0.0);
        let dc_gain = fir.result(0.0);
        assert!(
            (dc_gain - 1.0).abs() < 1e-12,
            "bandstop DC gain must be one, got {dc_gain}"
        );
    }

    #[test]
    fn test_fir_custom_creation() {
        let coeffs = vec![0.1, 0.2, 0.4, 0.2, 0.1];
        let fir = Fir::new_custom(coeffs.clone(), 48000.0);
        assert_eq!(fir.filter_type, FirFilterType::Custom);
        assert_eq!(fir.n_taps(), 5);
        assert_eq!(fir.coeffs(), &coeffs);
    }

    #[test]
    fn test_fir_reset() {
        let mut fir = Fir::lowpass(51, 1000.0, 48000.0, WindowType::Hamming, 0.0);

        // Process some samples
        fir.process(1.0);
        fir.process(0.5);

        // Reset should clear state
        fir.reset();

        // State should be zeroed (can't directly check internal state, but we verify no crash)
        let _ = fir.process(0.0);
    }

    #[test]
    fn test_fir_lowpass_dc_response() {
        let fir = Fir::lowpass(51, 1000.0, 48000.0, WindowType::Hamming, 0.0);

        // DC (0 Hz) should have ~0 dB gain for lowpass
        let response = fir.log_result(0.0);
        assert!(
            response > -1.0 && response < 1.0,
            "DC response should be near 0 dB, got {:.2}",
            response
        );
    }

    #[test]
    fn test_fir_highpass_dc_response() {
        let fir = Fir::highpass(51, 1000.0, 48000.0, WindowType::Hamming, 0.0);

        // DC (0 Hz) should have strong attenuation for highpass
        let response = fir.log_result(0.0);
        assert!(
            response < -20.0,
            "DC response for highpass should be < -20 dB, got {:.2}",
            response
        );
    }

    #[test]
    fn test_fir_process_dc() {
        let mut fir = Fir::lowpass(51, 1000.0, 48000.0, WindowType::Hamming, 0.0);

        // Process DC signal (constant 1.0)
        let mut output = 0.0;
        for _ in 0..100 {
            output = fir.process(1.0);
        }

        // After settling, lowpass output should be close to input for DC
        assert!(
            approx_eq(output, 1.0, 0.1),
            "DC output should be ~1.0, got {:.4}",
            output
        );
    }

    #[test]
    fn test_fir_np_log_result_is_finite() {
        let fir = Fir::lowpass(51, 1000.0_f64, 48000.0, WindowType::Hamming, 0.0);
        let freqs = array![20.0_f64, 100.0, 1_000.0, 10_000.0, 20_000.0];
        let resp = fir.np_log_result(&freqs);

        for (i, v) in resp.iter().enumerate() {
            assert!(v.is_finite(), "response at idx {} not finite: {}", i, v);
        }
    }

    #[test]
    fn test_window_rectangular() {
        let window = generate_window(5, WindowType::Rectangular, 0.0_f64);
        assert_eq!(window.len(), 5);
        for &w in &window {
            assert_eq!(w, 1.0);
        }
    }

    #[test]
    fn test_window_hamming() {
        let window = generate_window(5, WindowType::Hamming, 0.0_f64);
        assert_eq!(window.len(), 5);

        // Hamming window should have maximum at center
        let max_val = window.iter().fold(f64::NEG_INFINITY, |a, &b| a.max(b));
        assert!(window[2] >= max_val - 1e-10);

        // Edges should be lower than center
        assert!(window[0] < window[2]);
        assert!(window[4] < window[2]);
    }

    #[test]
    fn test_window_hann() {
        let window = generate_window(5, WindowType::Hann, 0.0_f64);
        assert_eq!(window.len(), 5);

        // Hann window edges should be near zero
        assert!(window[0] < 0.1);
        assert!(window[4] < 0.1);

        // Center should be near 1.0
        assert!(window[2] > 0.9);
    }

    #[test]
    fn test_window_blackman() {
        let window = generate_window(5, WindowType::Blackman, 0.0_f64);
        assert_eq!(window.len(), 5);

        // Blackman window should have maximum at center
        let max_val = window.iter().fold(f64::NEG_INFINITY, |a, &b| a.max(b));
        assert!(window[2] >= max_val - 1e-10);
    }

    #[test]
    fn test_window_kaiser() {
        let window = generate_window(5, WindowType::Kaiser, 5.0_f64);
        assert_eq!(window.len(), 5);

        // All values should be positive
        for &w in &window {
            assert!(w > 0.0);
        }

        // Center should be maximum (1.0 for Kaiser)
        assert!(approx_eq(window[2], 1.0, 1e-10));
    }

    #[test]
    fn test_bessel_i0() {
        // Test modified Bessel function at known points
        assert!(approx_eq(bessel_i0(0.0_f64), 1.0, 1e-10));
        assert!(approx_eq(bessel_i0(1.0_f64), 1.266, 0.001));
        assert!(approx_eq(bessel_i0(5.0_f64), 27.24, 0.01));
    }

    #[test]
    fn test_fir_bank_empty() {
        let bank: FirBank<f64> = vec![];
        let freqs = array![100.0_f64, 1000.0, 10000.0];
        let response = fir_bank_spl(&freqs, &bank);

        // Empty bank should give zero response
        for &r in response.iter() {
            assert_eq!(r, 0.0);
        }
    }

    #[test]
    fn test_fir_bank_single_filter() {
        let fir = Fir::lowpass(51, 1000.0, 48000.0, WindowType::Hamming, 0.0);
        let bank = vec![(1.0, fir)];
        let freqs = array![100.0, 1000.0, 10000.0];
        let response = fir_bank_spl(&freqs, &bank);

        // Should have finite response at all frequencies
        for &r in response.iter() {
            assert!(r.is_finite());
        }
    }

    #[test]
    fn test_fir_bank_preamp_gain() {
        let fir = Fir::lowpass(51, 1000.0, 48000.0, WindowType::Hamming, 0.0);
        let bank = vec![(1.0, fir)];

        let gain = fir_bank_preamp_gain(&bank);

        // Preamp gain should be small and negative (or zero)
        assert!(
            gain <= 1.0,
            "Preamp gain should be <= 1.0 dB, got {:.2}",
            gain
        );
    }

    #[test]
    fn test_fir_display() {
        let fir = Fir::lowpass(51, 1000.0, 48000.0, WindowType::Hamming, 0.0);
        let display = format!("{}", fir);

        assert!(display.contains("LP"));
        assert!(display.contains("1000"));
        assert!(display.contains("48000"));
        assert!(display.contains("51"));
        assert!(display.contains("HAMM"));
    }

    #[test]
    fn test_fir_bandpass_display() {
        let fir = Fir::bandpass(51, 500.0, 2000.0, 48000.0, WindowType::Hann, 0.0);
        let display = format!("{}", fir);

        assert!(display.contains("BP"));
        assert!(display.contains("500"));
        assert!(display.contains("2000"));
    }

    #[test]
    fn test_fir_coeffs_symmetry() {
        // Linear phase FIR filters should have symmetric coefficients
        let fir = Fir::lowpass(51, 1000.0, 48000.0, WindowType::Hamming, 0.0);
        let coeffs = fir.coeffs();
        let n = coeffs.len();

        // Check symmetry
        for i in 0..n / 2 {
            assert!(
                approx_eq(coeffs[i], coeffs[n - 1 - i], 1e-10),
                "Coeffs should be symmetric: coeffs[{}]={:.6} != coeffs[{}]={:.6}",
                i,
                coeffs[i],
                n - 1 - i,
                coeffs[n - 1 - i]
            );
        }
    }

    #[test]
    fn test_fir_symmetry_flag_detected() {
        let fir = Fir::lowpass(101, 1000.0, 48000.0, WindowType::Hamming, 0.0);
        assert!(
            fir.symmetric,
            "Hamming lowpass should be detected as symmetric"
        );

        let asym = Fir::new_custom(vec![0.1, 0.2, 0.3, 0.4], 48000.0);
        assert!(
            !asym.symmetric,
            "Asymmetric coefficients should not be detected as symmetric"
        );
    }

    #[test]
    fn test_fir_lowpass_cutoff_attenuation() {
        let cutoff = 1000.0;
        let fir = Fir::lowpass(101, cutoff, 48000.0, WindowType::Blackman, 0.0);

        // At cutoff frequency, should have some attenuation (typically -6 dB for ideal)
        let response_at_cutoff = fir.log_result(cutoff);
        assert!(
            response_at_cutoff < -3.0 && response_at_cutoff > -10.0,
            "Response at cutoff should be between -3 and -10 dB, got {:.2}",
            response_at_cutoff
        );

        // Well below cutoff should have minimal attenuation
        let response_below = fir.log_result(cutoff / 4.0);
        assert!(
            response_below > -3.0,
            "Response well below cutoff should be > -3 dB, got {:.2}",
            response_below
        );

        // Well above cutoff should have strong attenuation
        let response_above = fir.log_result(cutoff * 4.0);
        assert!(
            response_above < -20.0,
            "Response well above cutoff should be < -20 dB, got {:.2}",
            response_above
        );
    }

    #[test]
    fn test_fir_highpass_cutoff_attenuation() {
        let cutoff = 1000.0;
        let fir = Fir::highpass(101, cutoff, 48000.0, WindowType::Blackman, 0.0);

        // Well below cutoff should have strong attenuation
        let response_below = fir.log_result(cutoff / 4.0);
        assert!(
            response_below < -20.0,
            "Response well below cutoff should be < -20 dB, got {:.2}",
            response_below
        );

        // Well above cutoff should have minimal attenuation
        let response_above = fir.log_result(cutoff * 4.0);
        assert!(
            response_above > -3.0,
            "Response well above cutoff should be > -3 dB, got {:.2}",
            response_above
        );
    }

    #[test]
    fn test_fir_f32() {
        let fir = Fir::<f32>::lowpass(63, 1000.0, 48000.0, WindowType::Hann, 0.0);
        assert_eq!(fir.coeffs().len(), 63);
    }

    #[test]
    fn test_generate_window_empty() {
        let w = generate_window::<f64>(0, WindowType::Hann, 0.0);
        assert!(w.is_empty());
    }

    #[test]
    fn test_generate_window_single_tap() {
        let w = generate_window::<f64>(1, WindowType::Hann, 0.0);
        assert_eq!(w.len(), 1);
        assert_eq!(w[0], 1.0);
    }

    #[test]
    fn test_generate_window_kaiser_beta_zero_is_rectangular() {
        let w = generate_window::<f64>(16, WindowType::Kaiser, 0.0);
        assert_eq!(w.len(), 16);
        for &v in &w {
            assert!(
                (v - 1.0).abs() < 1e-12,
                "Kaiser with beta=0 should equal rectangular window"
            );
        }
    }

    #[test]
    fn test_generate_window_hann_edges_zero() {
        let w = generate_window::<f64>(32, WindowType::Hann, 0.0);
        assert!(w[0].abs() < 1e-12);
        assert!(w[w.len() - 1].abs() < 1e-12);
    }

    #[test]
    fn test_generate_window_hamming_edges() {
        let w = generate_window::<f64>(32, WindowType::Hamming, 0.0);
        let expected_edge = 0.54 - 0.46 * (2.0 * std::f64::consts::PI).cos();
        assert!((w[0] - expected_edge).abs() < 1e-12);
        assert!((w[w.len() - 1] - expected_edge).abs() < 1e-12);
    }

    #[test]
    fn test_generate_window_values_bounded() {
        for &wt in &[
            WindowType::Rectangular,
            WindowType::Hamming,
            WindowType::Hann,
            WindowType::Blackman,
            WindowType::Kaiser,
        ] {
            let beta = if wt == WindowType::Kaiser { 5.0 } else { 0.0 };
            let w = generate_window::<f64>(33, wt, beta);
            for (i, &v) in w.iter().enumerate() {
                assert!(
                    (-1e-12..=1.0 + 1e-12).contains(&v),
                    "{:?} window value out of bounds at {}: {}",
                    wt,
                    i,
                    v
                );
            }
        }
    }

    #[test]
    fn test_generate_window_symmetry_even_length() {
        let w = generate_window::<f64>(16, WindowType::Blackman, 0.0);
        let n = w.len();
        for i in 0..n / 2 {
            assert!(
                (w[i] - w[n - 1 - i]).abs() < 1e-12,
                "Blackman window should be symmetric"
            );
        }
    }

    #[test]
    fn test_generate_window_f32() {
        let w = generate_window::<f32>(16, WindowType::Hamming, 0.0);
        assert_eq!(w.len(), 16);
        for &v in &w {
            assert!(v.is_finite());
            assert!(v >= 0.0);
        }
    }

    #[test]
    fn test_generate_window_kaiser_large_beta() {
        let w = generate_window::<f64>(32, WindowType::Kaiser, 10.0);
        assert_eq!(w.len(), 32);
        // Center should be maximum (close to 1.0)
        assert!(w[16] > 0.99);
        // Edges should be small but positive
        assert!(w[0] > 0.0);
        assert!(w[0] < 0.5);
    }

    #[test]
    fn test_generate_window_blackman_edges_near_zero() {
        let w = generate_window::<f64>(64, WindowType::Blackman, 0.0);
        assert!(w[0].abs() < 1e-12);
        assert!(w[w.len() - 1].abs() < 1e-12);
    }

    #[test]
    fn test_try_constructors_accept_valid_params() {
        assert!(Fir::try_new_custom(vec![0.5, 0.5], 48000.0_f64).is_ok());
        assert!(Fir::try_lowpass(51, 1000.0, 48000.0_f64, WindowType::Hamming, 0.0).is_ok());
        assert!(Fir::try_highpass(51, 1000.0, 48000.0_f64, WindowType::Hann, 0.0).is_ok());
        assert!(
            Fir::try_bandpass(51, 500.0, 2000.0, 48000.0_f64, WindowType::Blackman, 0.0).is_ok()
        );
        assert!(Fir::try_bandstop(51, 500.0, 2000.0, 48000.0_f64, WindowType::Kaiser, 5.0).is_ok());
    }

    #[test]
    fn test_try_new_custom_rejects_empty_coeffs() {
        let err = Fir::try_new_custom(Vec::<f64>::new(), 48000.0).unwrap_err();
        assert_eq!(err, crate::FirError::EmptyCoeffs);
    }

    #[test]
    fn test_try_constructors_reject_bad_sample_rate() {
        let err = Fir::try_new_custom(vec![1.0_f64], 0.0).unwrap_err();
        assert!(matches!(err, crate::FirError::InvalidSampleRate { .. }));
        let err = Fir::try_lowpass(51, 1000.0, -48000.0_f64, WindowType::Hamming, 0.0).unwrap_err();
        assert!(matches!(err, crate::FirError::InvalidSampleRate { .. }));
    }

    #[test]
    fn test_try_constructors_reject_zero_taps() {
        let err = Fir::try_lowpass(0, 1000.0, 48000.0_f64, WindowType::Hamming, 0.0).unwrap_err();
        assert_eq!(err, crate::FirError::InvalidTaps { n_taps: 0 });
    }

    #[test]
    fn test_try_constructors_reject_bad_cutoff() {
        // At Nyquist and above.
        let err = Fir::try_lowpass(51, 24000.0, 48000.0_f64, WindowType::Hamming, 0.0).unwrap_err();
        assert!(matches!(err, crate::FirError::InvalidFrequency { .. }));
        // Non-positive.
        let err = Fir::try_highpass(51, 0.0, 48000.0_f64, WindowType::Hann, 0.0).unwrap_err();
        assert!(matches!(err, crate::FirError::InvalidFrequency { .. }));
    }

    #[test]
    fn test_try_constructors_reject_bad_band() {
        // Inverted edges.
        let err =
            Fir::try_bandpass(51, 2000.0, 500.0, 48000.0_f64, WindowType::Hann, 0.0).unwrap_err();
        assert!(matches!(err, crate::FirError::InvalidBand { .. }));
        // Edge above Nyquist.
        let err =
            Fir::try_bandstop(51, 500.0, 30000.0, 48000.0_f64, WindowType::Hann, 0.0).unwrap_err();
        assert!(matches!(err, crate::FirError::InvalidBand { .. }));
        // NaN inputs are rejected, not silently accepted.
        let err =
            Fir::try_lowpass(51, f64::NAN, 48000.0_f64, WindowType::Hamming, 0.0).unwrap_err();
        assert!(matches!(err, crate::FirError::InvalidFrequency { .. }));
    }

    #[test]
    #[should_panic(expected = "Fir::new_custom")]
    fn test_new_custom_panics_on_empty_coeffs() {
        let _ = Fir::new_custom(Vec::<f64>::new(), 48000.0);
    }

    #[test]
    #[should_panic(expected = "Fir::lowpass")]
    fn test_lowpass_panics_on_zero_taps() {
        let _ = Fir::lowpass(0, 1000.0, 48000.0_f64, WindowType::Hamming, 0.0);
    }

    #[test]
    #[should_panic(expected = "Fir::lowpass")]
    fn test_lowpass_panics_above_nyquist() {
        let _ = Fir::lowpass(51, 48000.0, 48000.0_f64, WindowType::Hamming, 0.0);
    }

    #[test]
    #[should_panic(expected = "Fir::bandpass")]
    fn test_bandpass_panics_on_inverted_edges() {
        let _ = Fir::bandpass(51, 2000.0, 500.0, 48000.0_f64, WindowType::Hann, 0.0);
    }

    #[test]
    fn test_np_log_result_into_matches_allocating() {
        let fir = Fir::lowpass(51, 1000.0_f64, 48000.0, WindowType::Hamming, 0.0);
        let freqs = array![20.0_f64, 100.0, 1_000.0, 10_000.0, 20_000.0];
        let expected = fir.np_log_result(&freqs);
        let mut out = ndarray::Array1::zeros(freqs.len());
        fir.np_log_result_into(&freqs, &mut out);
        assert_eq!(out, expected);
    }

    #[test]
    fn test_fir_bank_into_matches_allocating() {
        let lp = Fir::lowpass(31, 1000.0, 48000.0, WindowType::Hamming, 0.0);
        let hp = Fir::highpass(31, 2000.0, 48000.0, WindowType::Hann, 0.0);
        let bank = vec![(1.0, lp), (0.5, hp)];
        let freqs = array![100.0, 1000.0, 5000.0, 10_000.0];
        let expected = fir_bank_spl(&freqs, &bank);
        let mut response = ndarray::Array1::zeros(freqs.len());
        let mut scratch = ndarray::Array1::zeros(freqs.len());
        fir_bank_spl_into(&freqs, &bank, &mut response, &mut scratch);
        assert_eq!(response, expected);

        // compute_fir_bank_response_into agrees too.
        let mut response2 = ndarray::Array1::zeros(freqs.len());
        let mut scratch2 = ndarray::Array1::zeros(freqs.len());
        crate::compute_fir_bank_response_into(&freqs, &bank, &mut response2, &mut scratch2);
        assert_eq!(response2, expected);
    }

    #[test]
    fn test_process_block_runs_under_ftz_guard() {
        use crate::denormals::ScopedFlushToZero;
        let mut fir = Fir::lowpass(31, 1000.0_f64, 48000.0, WindowType::Hamming, 0.0);
        let _guard = ScopedFlushToZero::new();
        let mut block = vec![1.0_f64; 64];
        fir.process_block(&mut block);
        assert!(block.iter().all(|v| v.is_finite()));
    }

    #[test]
    fn test_generate_window_all_types_non_empty() {
        for &wt in &[
            WindowType::Rectangular,
            WindowType::Hamming,
            WindowType::Hann,
            WindowType::Blackman,
            WindowType::Kaiser,
        ] {
            let beta = if wt == WindowType::Kaiser { 3.0 } else { 0.0 };
            let w = generate_window::<f64>(8, wt, beta);
            assert_eq!(w.len(), 8);
            for &v in &w {
                assert!(v.is_finite());
                assert!(
                    v >= -1e-12,
                    "window value should not be significantly negative: {v}"
                );
            }
        }
    }
}
