//! Forward-reverse (zero-phase) filtering for offline signal processing.
//!
//! Provides [`filtfilt`] — a forward-backward IIR filter that achieves zero phase
//! distortion, equivalent to MATLAB's `filtfilt` or `scipy.signal.sosfiltfilt`.
//!
//! This is ideal for pre-processing room impulse responses before analysis,
//! where preserving temporal features (phase) is critical.
//!
//! All functions are generic over [`FilterFloat`](crate::FilterFloat) — the signal
//! type and coefficient type must match (`f32` with `f32`, or `f64` with `f64`).
//!
//! # Example
//!
//! ```rust
//! use math_audio_iir_fir::{peq_butterworth_lowpass, BiquadCoefficients};
//! use math_audio_iir_fir::filtfilt::{filtfilt, peq_to_coefficients};
//!
//! // Design a 4th-order Butterworth lowpass at 4kHz (returns Peq<f64>)
//! let peq = peq_butterworth_lowpass(4, 4000.0, 48000.0);
//! let sections = peq_to_coefficients(&peq);
//!
//! // Signal type must match coefficient type
//! let signal: Vec<f64> = vec![0.0; 480];
//! let filtered = filtfilt(&signal, &sections);
//! ```

mod biquad;
mod misc;
#[cfg(test)]
mod tests;

pub use biquad::*;
pub use misc::*;
