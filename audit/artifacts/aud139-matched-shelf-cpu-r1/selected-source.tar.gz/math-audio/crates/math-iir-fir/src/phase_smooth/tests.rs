use super::misc::compute_group_delay;
use super::misc::find_interpolation_indices;
use super::misc::integrate_group_delay;
use super::misc::interpolate_phase_complex;
use super::misc::unwrap_phase;
use super::smooth::smooth_octave;
use super::smooth::smooth_phase_via_group_delay;
use std::f64::consts::PI;

fn approx_eq(a: f64, b: f64, tol: f64) -> bool {
    (a - b).abs() <= tol
}

#[test]
fn test_unwrap_phase_no_wrapping() {
    let phase = vec![0.0, 0.5, 1.0, 1.5, 2.0];
    let unwrapped = unwrap_phase(&phase);
    assert_eq!(unwrapped, phase);
}

#[test]
fn test_unwrap_phase_with_positive_wrap() {
    // Phase jumps from near π to near -π (should add 2π)
    let phase = vec![0.0, 1.0, 2.0, 3.0, -3.0, -2.0];
    let unwrapped = unwrap_phase(&phase);

    // After unwrapping, the sequence should be continuous
    assert!(approx_eq(unwrapped[0], 0.0, 1e-10));
    assert!(approx_eq(unwrapped[4], -3.0 + 2.0 * PI, 1e-10));
    assert!(approx_eq(unwrapped[5], -2.0 + 2.0 * PI, 1e-10));
}

#[test]
fn test_unwrap_phase_with_negative_wrap() {
    // Phase jumps from near -π to near π (should subtract 2π)
    let phase = vec![0.0, -1.0, -2.0, -3.0, 3.0, 2.0];
    let unwrapped = unwrap_phase(&phase);

    assert!(approx_eq(unwrapped[0], 0.0, 1e-10));
    assert!(approx_eq(unwrapped[4], 3.0 - 2.0 * PI, 1e-10));
    assert!(approx_eq(unwrapped[5], 2.0 - 2.0 * PI, 1e-10));
}

#[test]
fn test_unwrap_phase_empty() {
    let phase: Vec<f64> = vec![];
    let unwrapped = unwrap_phase(&phase);
    assert!(unwrapped.is_empty());
}

#[test]
fn test_compute_group_delay_constant_slope() {
    // Linear phase with constant slope should give constant group delay
    // φ(f) = -2π * τ * f => τ_g = τ
    let delay = 0.001; // 1ms delay
    let freqs: Vec<f64> = (1..=10).map(|i| i as f64 * 100.0).collect(); // 100-1000 Hz
    let phase: Vec<f64> = freqs.iter().map(|&f| -2.0 * PI * delay * f).collect();

    let gd = compute_group_delay(&freqs, &phase);

    // All group delay values should be approximately 1ms
    for &g in &gd {
        assert!(
            approx_eq(g, delay, 1e-6),
            "Group delay {} should be close to {}",
            g,
            delay
        );
    }
}

#[test]
fn test_smooth_octave_flat_data() {
    let freqs: Vec<f64> = (1..=10)
        .map(|i| 100.0 * 2.0_f64.powf(i as f64 / 3.0))
        .collect();
    let values = vec![1.0; freqs.len()];

    let smoothed = smooth_octave(&freqs, &values, 0.5);

    // Flat data should remain flat after smoothing
    for &v in &smoothed {
        assert!(approx_eq(v, 1.0, 1e-10));
    }
}

#[test]
fn test_smooth_octave_reduces_noise() {
    let freqs: Vec<f64> = (0..100)
        .map(|i| 20.0 * 2.0_f64.powf(i as f64 * 0.1))
        .collect();
    let values: Vec<f64> = freqs
        .iter()
        .enumerate()
        .map(|(i, _)| if i % 2 == 0 { 1.0 } else { -1.0 })
        .collect();

    let smoothed = smooth_octave(&freqs, &values, 0.5);

    // Smoothed values should have lower variance than original
    let orig_var: f64 = values.iter().map(|v| v * v).sum::<f64>() / values.len() as f64;
    let smooth_var: f64 = smoothed.iter().map(|v| v * v).sum::<f64>() / smoothed.len() as f64;

    assert!(
        smooth_var < orig_var,
        "Smoothed variance {} should be less than original {}",
        smooth_var,
        orig_var
    );
}

#[test]
fn test_integrate_group_delay_roundtrip() {
    // Create a phase curve, compute group delay, integrate back
    let delay = 0.002; // 2ms
    let freqs: Vec<f64> = (1..=20).map(|i| i as f64 * 50.0).collect(); // 50-1000 Hz
    let original_phase: Vec<f64> = freqs.iter().map(|&f| -2.0 * PI * delay * f).collect();

    let gd = compute_group_delay(&freqs, &original_phase);
    let reconstructed = integrate_group_delay(&freqs, &gd, original_phase[0]);

    // Reconstructed phase should match original (within numerical precision)
    for i in 0..freqs.len() {
        assert!(
            approx_eq(reconstructed[i], original_phase[i], 0.1),
            "At freq {}: reconstructed {} != original {}",
            freqs[i],
            reconstructed[i],
            original_phase[i]
        );
    }
}

#[test]
fn test_smooth_phase_via_group_delay_linear_phase() {
    // Linear phase (constant group delay) should be preserved after smoothing
    let delay = 0.001;
    let freqs: Vec<f64> = (1..=50)
        .map(|i| 20.0 * 2.0_f64.powf(i as f64 * 0.2))
        .collect();
    let phase: Vec<f64> = freqs.iter().map(|&f| -2.0 * PI * delay * f).collect();

    let smoothed = smooth_phase_via_group_delay(&freqs, &phase, 0.167);

    // For a constant delay system, the group delay should be constant
    // After smoothing and integration, the phase should still be approximately linear
    // We check that the phase values are correlated with frequency
    let n = freqs.len();

    // Calculate the average group delay from the smoothed phase
    // If phase is linear with frequency, group delay is constant
    let gd_samples: Vec<f64> = (1..n)
        .map(|i| {
            let dphi = smoothed[i] - smoothed[i - 1];
            let df = freqs[i] - freqs[i - 1];
            -dphi / (2.0 * PI * df)
        })
        .collect();

    let avg_gd: f64 = gd_samples.iter().sum::<f64>() / gd_samples.len() as f64;

    // The average group delay should be close to original delay
    assert!(
        approx_eq(avg_gd, delay, delay * 0.5),
        "Average group delay {} should be close to expected {}",
        avg_gd,
        delay
    );
}

#[test]
fn test_interpolate_phase_complex_basic() {
    let src_freqs = vec![100.0, 1000.0, 10000.0];
    let src_phase = vec![0.0, -PI / 2.0, -PI];

    let target_freqs = vec![100.0, 316.0, 1000.0, 3160.0, 10000.0];
    let result = interpolate_phase_complex(&src_freqs, &src_phase, &target_freqs);

    // Known points should match
    assert!(approx_eq(result[0], 0.0, 0.1));
    assert!(approx_eq(result[2], -PI / 2.0, 0.1));
    assert!(approx_eq(result[4], -PI, 0.1));
}

#[test]
fn test_interpolate_phase_complex_near_wrap() {
    // Test interpolation near the wrap point (±π)
    let src_freqs = vec![100.0, 200.0];
    let src_phase = vec![PI * 0.9, -PI * 0.9]; // Near wrap point

    let target_freqs = vec![150.0];
    let result = interpolate_phase_complex(&src_freqs, &src_phase, &target_freqs);

    // Should interpolate through the "short way" (near π)
    // not through 0
    assert!(
        result[0].abs() > PI / 2.0,
        "Interpolated phase {} should be near ±π",
        result[0]
    );
}

#[test]
fn test_smooth_phase_via_group_delay_empty() {
    let freqs: Vec<f64> = vec![];
    let phase: Vec<f64> = vec![];
    let result = smooth_phase_via_group_delay(&freqs, &phase, 0.167);
    assert!(result.is_empty());
}

#[test]
fn test_smooth_phase_via_group_delay_short() {
    // With < 3 points, should return unchanged
    let freqs = vec![100.0, 200.0];
    let phase = vec![0.0, -0.5];
    let result = smooth_phase_via_group_delay(&freqs, &phase, 0.167);
    assert_eq!(result, phase);
}

#[test]
fn test_find_interpolation_indices() {
    let freqs = vec![100.0, 200.0, 400.0, 800.0];

    // Below range
    let (l, u, _t) = find_interpolation_indices(&freqs, 50.0);
    assert_eq!(l, 0);
    assert_eq!(u, 0);

    // Above range
    let (l, u, _t) = find_interpolation_indices(&freqs, 1000.0);
    assert_eq!(l, 3);
    assert_eq!(u, 3);

    // At exact point
    let (l, u, _t) = find_interpolation_indices(&freqs, 200.0);
    assert_eq!(l, 1);
    assert_eq!(u, 2); // Due to binary search, upper will be next

    // Between points
    let (l, u, t) = find_interpolation_indices(&freqs, 300.0);
    assert_eq!(l, 1);
    assert_eq!(u, 2);
    assert!(t > 0.0 && t < 1.0);
}
