/// FIR filter types
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum FirFilterType {
    /// Low-pass filter
    Lowpass,
    /// High-pass filter
    Highpass,
    /// Band-pass filter
    Bandpass,
    /// Band-stop (notch) filter
    Bandstop,
    /// Custom filter (user-provided coefficients)
    Custom,
}

impl FirFilterType {
    /// Returns the short string representation of the filter type.
    pub fn short_name(&self) -> &'static str {
        match self {
            FirFilterType::Lowpass => "LP",
            FirFilterType::Highpass => "HP",
            FirFilterType::Bandpass => "BP",
            FirFilterType::Bandstop => "BS",
            FirFilterType::Custom => "CUSTOM",
        }
    }

    /// Returns the long string representation of the filter type.
    pub fn long_name(&self) -> &'static str {
        match self {
            FirFilterType::Lowpass => "Lowpass",
            FirFilterType::Highpass => "Highpass",
            FirFilterType::Bandpass => "Bandpass",
            FirFilterType::Bandstop => "Bandstop",
            FirFilterType::Custom => "Custom",
        }
    }
}
