use super::super::biquad::{Biquad, BiquadFilterType, Peq};
use super::peq_spl_into;
use ndarray::Array1;

/// Compute the combined PEQ response (in dB) on a given frequency grid for a Peq.
///
/// # Arguments
/// * `freqs` - Frequency points for evaluation (Hz)
/// * `peq` - Parametric equalizer containing weighted biquad filters
/// * `_sample_rate` - Sample rate in Hz (unused, kept for API compatibility)
///
/// # Returns
/// Frequency response in dB SPL at the specified frequency points
pub fn compute_peq_response(freqs: &Array1<f64>, peq: &Peq, _sample_rate: f64) -> Array1<f64> {
    let mut response = Array1::zeros(freqs.len());
    let mut filter_scratch = Array1::zeros(freqs.len());
    compute_peq_response_into(freqs, peq, _sample_rate, &mut response, &mut filter_scratch);
    response
}

/// Compute a combined PEQ response into caller-owned reusable buffers.
pub fn compute_peq_response_into(
    freqs: &Array1<f64>,
    peq: &Peq,
    _sample_rate: f64,
    response: &mut Array1<f64>,
    filter_scratch: &mut Array1<f64>,
) {
    peq_spl_into(freqs, peq, response, filter_scratch);
}

/// Compute A-weighting in dB for a given frequency
///
/// A-weighting approximates the frequency response of the human ear
/// and is used for loudness estimation.
///
/// # Arguments
/// * `f` - Frequency in Hz
///
/// # Returns
/// * A-weighting value in dB
pub(super) fn a_weighting_db(f: f64) -> f64 {
    // A-weighting formula (IEC 61672-1)
    let f2 = f * f;
    let f4 = f2 * f2;

    let numerator = 12194.0_f64.powi(2) * f4;
    let denominator = (f2 + 20.6_f64.powi(2))
        * ((f2 + 107.7_f64.powi(2)) * (f2 + 737.9_f64.powi(2))).sqrt()
        * (f2 + 12194.0_f64.powi(2));

    let ra = numerator / denominator;
    20.0 * ra.log10() + 2.0 // +2.0 is normalization constant
}

/// Compute K-weighting in dB for a given frequency
///
/// K-weighting is used by EBU R128 loudness measurement standard.
/// This helper is a rough analytic approximation of the pre-filter + RLB
/// cascade, not a bit-exact EBU R128 implementation.
///
/// # Arguments
/// * `f` - Frequency in Hz
///
/// # Returns
/// * K-weighting value in dB (approximate)
pub(super) fn k_weighting_db(f: f64) -> f64 {
    // Simplified K-weighting approximation
    // Based on high-shelf at ~1500Hz and high-pass around 40Hz

    // High-pass stage (4th order Butterworth at 38Hz)
    let f_hp = 38.0;
    let hp_response = if f > 1.0 {
        20.0 * 4.0 * (f / f_hp).log10() // 4th order = 80 dB/decade
    } else {
        -200.0
    };
    let hp_gain = hp_response.min(0.0);

    // High-shelf stage (+4 dB above 1500 Hz)
    let f_hs = 1500.0;
    let hs_gain = if f > f_hs {
        4.0 * (1.0 - (f_hs / f).powf(2.0).min(1.0))
    } else {
        0.0
    };

    hp_gain + hs_gain
}

/// Get priority for filter type (higher number = higher priority)
///
/// # Arguments
/// * `filter_type` - The type of filter
///
/// # Returns
/// * Priority value (higher = more important to keep)
///
/// # Notes
/// Priority levels:
/// - Lowshelf/Highshelf: 9 (important for overall curve)
/// - Lowpass/Highpass: 7 (medium priority)
/// - Bandpass: 5 (lower priority)
/// - Peak: 3 (lowest priority, most common)
/// - Default: 1
#[allow(dead_code)]
pub(super) fn get_filter_priority(filter_type: BiquadFilterType) -> u8 {
    match filter_type {
        BiquadFilterType::Lowshelf | BiquadFilterType::Highshelf => 9,
        BiquadFilterType::Lowpass => 7,
        BiquadFilterType::Highpass | BiquadFilterType::HighpassVariableQ => 7,
        BiquadFilterType::Bandpass => 5,
        BiquadFilterType::Peak => 3,
        _ => 1,
    }
}

/// Filter PEQs while preserving order and prioritizing important filter types
///
/// # Arguments
/// * `peqs` - List of PEQ items in original order
/// * `max_count` - Maximum number of PEQ items to keep
///
/// # Returns
/// * List of PEQ items in original order, limited to max_count, with low-priority/low-gain filters removed
///
/// # Notes
/// If the input has fewer than or equal to max_count items, returns a clone.
/// Otherwise, sorts by priority (descending) then by absolute gain (descending),
/// takes the top max_count items, and returns them in their original order.
#[allow(dead_code)]
pub(super) fn filter_peqs_by_gain(peqs: &Peq, max_count: usize) -> Peq {
    if peqs.len() <= max_count {
        return peqs.clone();
    }

    // Create list of (index, peq_item, priority, abs_gain) for sorting
    let mut indexed_peqs: Vec<(usize, &(f64, Biquad), u8, f64)> = peqs
        .iter()
        .enumerate()
        .map(|(i, item)| {
            let priority = get_filter_priority(item.1.filter_type);
            let abs_gain = item.1.db_gain.abs();
            (i, item, priority, abs_gain)
        })
        .collect();

    // Sort by priority (descending) then by absolute gain (descending)
    // This puts high-priority, high-gain filters first
    indexed_peqs.sort_by(|a, b| {
        b.2.cmp(&a.2) // Compare priority (descending)
            .then_with(|| b.3.partial_cmp(&a.3).unwrap_or(std::cmp::Ordering::Equal))
        // Then abs_gain (descending)
    });

    // Take the top max_count filters
    let mut selected: Vec<(usize, (f64, Biquad))> = indexed_peqs
        .into_iter()
        .take(max_count)
        .map(|(idx, item, _, _)| (idx, item.clone()))
        .collect();

    // Sort selected filters back to original order by index
    selected.sort_by_key(|(idx, _)| *idx);

    // Extract just the PEQ items
    selected.into_iter().map(|(_, item)| item).collect()
}

/// Enforce RME room EQ constraints
///
/// # Arguments
/// * `peqs` - List of PEQ items
///
/// # Returns
/// * List of exactly 9 PEQ items with RME room EQ constraints applied:
///   - Position 1 can be: PK, LS, HS, LP, or HP (lowest freq non-PK preferred)
///   - Positions 2-8 can only be PK
///   - Position 9 can be: PK, LS, HS, LP, or HP (highest freq non-PK preferred)
///   - Missing slots filled with zero-gain PK filters at 1kHz
///
/// # Notes
/// RME room EQ hardware constraints:
/// - Total of 9 bands maximum
/// - Only positions 1 and 9 support non-PK filter types
/// - If more than 2 non-PK filters exist, picks lowest and highest frequency
pub(super) fn enforce_rme_room_filter_constraints(peqs: &Peq) -> Peq {
    // Separate filters by category
    let mut pk_filters: Vec<(f64, Biquad)> = Vec::new();
    let mut non_pk_filters: Vec<(f64, Biquad)> = Vec::new();

    for item in peqs {
        match item.1.filter_type {
            BiquadFilterType::Peak => pk_filters.push(item.clone()),
            BiquadFilterType::Lowshelf
            | BiquadFilterType::Highshelf
            | BiquadFilterType::Lowpass
            | BiquadFilterType::Highpass
            | BiquadFilterType::HighpassVariableQ => non_pk_filters.push(item.clone()),
            _ => {
                // Convert unsupported types to PK
                eprintln!(
                    "Warning: Filter type {:?} not supported by RME room EQ, converting to PK",
                    item.1.filter_type
                );
                let mut converted = item.1.clone();
                converted.filter_type = BiquadFilterType::Peak;
                pk_filters.push((item.0, converted));
            }
        }
    }

    // Select non-PK filters for positions 1 and 9
    let mut selected_low: Option<(f64, Biquad)> = None;
    let mut selected_high: Option<(f64, Biquad)> = None;

    if non_pk_filters.len() > 2 {
        eprintln!(
            "Warning: RME room EQ supports at most 2 non-PK filters (positions 1 and 9). \
             Found {} non-PK filters. Selecting lowest and highest frequency filters.",
            non_pk_filters.len()
        );
    }

    if !non_pk_filters.is_empty() {
        // Sort non-PK filters by frequency
        let mut sorted_non_pk = non_pk_filters.clone();
        sorted_non_pk.sort_by(|a, b| {
            a.1.freq
                .partial_cmp(&b.1.freq)
                .unwrap_or(std::cmp::Ordering::Equal)
        });

        // Select lowest frequency for position 1
        selected_low = Some(sorted_non_pk[0].clone());

        // If we have more than one non-PK, select highest frequency for position 9
        if sorted_non_pk.len() > 1 {
            selected_high = Some(sorted_non_pk[sorted_non_pk.len() - 1].clone());
        }
    }

    // Build the result with exactly 9 bands
    let mut result: Vec<(f64, Biquad)> = Vec::new();

    // Position 1: non-PK (if available) or first PK
    if let Some(low) = selected_low {
        result.push(low);
    } else if !pk_filters.is_empty() {
        result.push(pk_filters.remove(0));
    } else {
        // Create dummy zero-gain PK filter
        result.push((
            1.0,
            Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 0.0),
        ));
    }

    // Positions 2-8: PK filters only (7 slots)
    let mut middle_count = 0;
    while middle_count < 7 {
        if !pk_filters.is_empty() {
            result.push(pk_filters.remove(0));
        } else {
            // Fill with zero-gain PK filters
            result.push((
                1.0,
                Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 0.0),
            ));
        }
        middle_count += 1;
    }

    // Position 9: non-PK (if available) or PK
    if let Some(high) = selected_high {
        result.push(high);
    } else if !pk_filters.is_empty() {
        result.push(pk_filters.remove(0));
    } else {
        // Create dummy zero-gain PK filter
        result.push((
            1.0,
            Biquad::new(BiquadFilterType::Peak, 1000.0, 48000.0, 1.0, 0.0),
        ));
    }

    // Warn if we had to drop PK filters
    if !pk_filters.is_empty() {
        eprintln!(
            "Warning: {} PK filters were dropped due to 9-band limit",
            pk_filters.len()
        );
    }

    result
}
