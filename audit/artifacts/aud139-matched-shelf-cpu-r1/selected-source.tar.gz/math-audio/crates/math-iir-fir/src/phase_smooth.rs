//! Phase smoothing via group delay
//!
//! This module provides functions for smoothing noisy phase measurements
//! by converting to group delay, applying octave smoothing, and integrating
//! back to phase.
//!
//! # Approach
//!
//! Group delay smoothing is preferred over direct phase smoothing because:
//! - Group delay (derivative of phase) has no wrapping discontinuities
//! - Preserves linear delay component naturally
//! - Consistent with how audio engineers think about phase
//! - Existing octave-smoothing pattern can be reused
//!
//! # Pipeline
//!
//! ```text
//! Measured Phase → Unwrap → Differentiate to Group Delay → Smooth (1/N octave) → Integrate → Smoothed Phase
//! ```

mod misc;
mod smooth;
#[cfg(test)]
mod tests;

pub use misc::*;
pub use smooth::*;
