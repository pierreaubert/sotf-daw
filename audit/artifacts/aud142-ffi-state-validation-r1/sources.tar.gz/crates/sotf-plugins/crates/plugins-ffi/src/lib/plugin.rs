//! C-callable plugin lifecycle and processing entry points.
//!
//! Every exported function follows the same ownership contract: pointers
//! received from C are borrowed for the duration of the call, pointers
//! returned as owned values must be freed with the matching `plugin_free_*`
//! function exactly once, and any pointer derived from a [`PluginHandle`] is
//! only valid while that handle remains alive and undestroyed.

use super::PluginError;
use super::PluginFfiCapabilities;
use super::PluginHandle;
use super::PluginMidiEvent;
use super::PluginNoteExpressionEvent;
use super::PluginPresetDocumentInfo;
use super::PluginSwiftPackageInfo;
use super::PluginVst3FfiDescriptor;
use super::consts::MAX_FFI_MIDI_EVENTS_PER_BLOCK;
use super::consts::MAX_FFI_OUTPUT_EVENTS_PER_BLOCK;
use super::consts::MAX_PRESET_JSON_IMPORT_BYTES;
use super::consts::MAX_PRESET_STATE_BYTES;
use super::consts::PRESET_FILE_EXTENSION;
use super::consts::PRESET_MIME_TYPE;
use super::consts::PRESET_UT_TYPE;
use super::consts::SOTF_PLUGIN_FFI_ABI_VERSION;
use super::consts::SWIFT_HEADER_NAME;
use super::consts::SWIFT_LIBRARY_NAME;
use super::consts::SWIFT_PACKAGE_NAME;
use super::consts::SWIFT_PRODUCT_NAME;
use super::consts::SWIFT_TARGET_NAME;
use super::consts::VST3_COMPONENT_NAME;
use super::consts::VST3_ENTRYPOINT;
use super::consts::VST3_SDK_VERSION;
use super::consts::VST3_VENDOR;
use super::copy::copy_bytes_to_ffi_buffer;
use super::copy::copy_midi_output_events;
use super::copy::copy_note_expression_output_events;
use super::host::host_kind_name;
use super::libc::libc_free;
use super::libc::libc_malloc;
use super::misc::sanitize_filename_component;
use super::misc::set_last_error;
use super::misc::set_last_error_static;
pub use super::parameter_map::{ParameterInfo, ParameterMap};
use super::process::process_impl;
use super::process::process_with_ffi_events_impl;
use super::process::process_with_full_events_impl;
use super::types::current_host_kind;
use super::{LAST_ERROR, LAST_STATIC_ERROR};
use sotf_host::plugin::ProcessContext;
use std::ffi::{CStr, CString};
use std::os::raw::{c_char, c_double, c_int};
use std::panic::{self, AssertUnwindSafe};
use std::ptr;
use std::slice;

const PRESET_UT_TYPE_JSON: &str = "org.spinorama.sotf.plugin-preset";

fn load_changed_state(
    plugin: &mut dyn sotf_host::plugin::Plugin,
    state: &[u8],
    plugin_type: &str,
) -> Result<(), String> {
    let mut incoming: serde_json::Map<String, serde_json::Value> = serde_json::from_slice(state)
        .map_err(|error| format!("Failed to parse plugin state: {error}"))?;

    // Crossfeed's preset selector is an action that changes several other
    // parameters. Apply it before their explicit saved values, so replaying a
    // saved custom mode cannot be overwritten by its preset selection.
    if matches!(plugin_type, "Crossfeed" | "crossfeed")
        && let Some(preset) = incoming.remove("preset")
    {
        let preset = serde_json::to_vec(&serde_json::json!({"preset": preset}))
            .map_err(|error| format!("Failed to serialize preset selection: {error}"))?;
        load_changed_state(plugin, &preset, "")?;
    }

    let current: serde_json::Map<String, serde_json::Value> =
        serde_json::from_slice(&plugins_bridge::state::save_state(plugin))
            .map_err(|error| format!("Failed to capture plugin state: {error}"))?;
    // Unchanged setters may run preset/momentary actions or reload resources.
    // Invalid values still differ and reach the normal typed loader below.
    incoming.retain(|key, value| current.get(key) != Some(value));
    let changes = serde_json::to_vec(&incoming)
        .map_err(|error| format!("Failed to serialize plugin state: {error}"))?;
    plugins_bridge::state::load_state(plugin, &changes)
}

fn is_dynamic_eq_shelf_structural_id(plugin_type: &str, param_id: &str) -> bool {
    if !matches!(plugin_type, "DynamicEQ" | "dynamic_eq" | "dynamic-eq") {
        return false;
    }
    let Some((band, field)) = param_id
        .strip_prefix("band_")
        .and_then(|suffix| suffix.split_once('_'))
    else {
        return false;
    };
    band.parse::<usize>().is_ok_and(|index| index < 8) && matches!(field, "shape" | "shelf_slope")
}

fn replace_plugin_from_state(handle: &mut PluginHandle, state: &[u8]) -> Result<(), String> {
    if matches!(
        handle.plugin_type.as_str(),
        "DynamicEQ" | "dynamic_eq" | "dynamic-eq"
    ) {
        return replace_dynamic_eq_from_state(handle, state);
    }
    if handle.plugin_type == "LinearPhaseEQ" {
        return replace_linear_phase_eq_from_state(handle, state);
    }
    if matches!(handle.plugin_type.as_str(), "Crossover" | "crossover") {
        return replace_crossover_from_state(handle, state);
    }
    if matches!(
        handle.plugin_type.as_str(),
        "BandSplit" | "band_split" | "bandsplit"
    ) {
        return replace_band_split_from_state(handle, state);
    }

    let current = plugins_bridge::state::save_state(&*handle.plugin);
    let mut replacement_config = handle.config_json.clone();
    let (current_state, incoming_state) =
        if matches!(handle.plugin_type.as_str(), "Convolution" | "convolution") {
            let mut current_values: serde_json::Map<String, serde_json::Value> =
                serde_json::from_slice(&current).map_err(|error| {
                    format!("Failed to capture current Convolution state: {error}")
                })?;
            let mut incoming_values: serde_json::Map<String, serde_json::Value> =
                serde_json::from_slice(state)
                    .map_err(|error| format!("Failed to parse Convolution state: {error}"))?;

            let mut config: serde_json::Value = match handle.config_json.trim() {
                "" | "null" | "{}" => serde_json::json!({}),
                config => serde_json::from_str(config)
                    .map_err(|error| format!("Failed to parse Convolution config: {error}"))?,
            };
            let config_object = config
                .as_object_mut()
                .ok_or_else(|| "Convolution config must be a JSON object".to_string())?;
            let configured_mode = config_object
                .get("true_stereo")
                .and_then(serde_json::Value::as_bool)
                .unwrap_or(false);
            let current_mode = match current_values.get("true_stereo") {
                Some(serde_json::Value::Bool(enabled)) => *enabled,
                Some(_) => {
                    return Err("Current Convolution true_stereo state is not a boolean".into());
                }
                None => configured_mode,
            };
            let next_mode = match incoming_values.get("true_stereo") {
                None => current_mode,
                Some(serde_json::Value::Bool(enabled)) => *enabled,
                Some(_) => return Err("Convolution true_stereo state must be a boolean".into()),
            };

            // Structural routing is constructor state: instantiate the replacement
            // in the requested mode before replaying ordinary partial parameters.
            // If the mode changes, apply an incoming IR path to construction too;
            // otherwise a legacy two-channel IR in the old config can reject a
            // valid four-channel preset before its saved IR path is restored.
            // Leave the original config bytes alone when routing is unchanged.
            if next_mode != current_mode {
                let incoming_ir_file = incoming_values
                    .get("ir_file")
                    .filter(|value| value.is_string())
                    .cloned();
                let current_ir_file = current_values
                    .get("ir_file")
                    .filter(|value| value.is_string())
                    .cloned();
                config_object.insert("true_stereo".into(), serde_json::Value::Bool(next_mode));
                if let Some(ir_file) = incoming_ir_file.clone().or(current_ir_file) {
                    config_object.insert("ir_file".into(), ir_file);
                    current_values.remove("ir_file");
                    if incoming_ir_file.is_some() {
                        incoming_values.remove("ir_file");
                    }
                }
                replacement_config = serde_json::to_string(&config)
                    .map_err(|error| format!("Failed to serialize Convolution config: {error}"))?;
            }
            current_values.remove("true_stereo");
            incoming_values.remove("true_stereo");
            (
                serde_json::to_vec(&current_values).map_err(|error| {
                    format!("Failed to serialize current Convolution state: {error}")
                })?,
                serde_json::to_vec(&incoming_values).map_err(|error| {
                    format!("Failed to serialize incoming Convolution state: {error}")
                })?,
            )
        } else {
            (current, state.to_vec())
        };

    // Construct from the original configuration: the flat parameter snapshot
    // does not contain every resource, routing matrix, or setup option.
    // All fallible work runs on a separate instance on the control thread.
    let mut replacement = super::plugin_factory::create_unprepared_plugin(
        &handle.plugin_type,
        &replacement_config,
        handle.input_channels,
        handle.output_channels,
        handle.sample_rate,
    )?;
    // Preserve live automation when a partial preset omits a parameter. Only
    // replay values that differ from the constructor, avoiding unnecessary
    // writes to setup parameters already represented by the original config.
    load_changed_state(&mut *replacement, &current_state, &handle.plugin_type)?;
    load_changed_state(&mut *replacement, &incoming_state, &handle.plugin_type)?;

    replacement =
        plugins_bridge::prepare_standalone_plugin(replacement, handle.max_callback_frames)?;
    replacement.initialize(handle.sample_rate)?;

    // A setup setter may change its bus widths. The host's buffers and stored
    // layout remain fixed for the lifetime of the handle.
    if replacement.input_channels() != handle.input_channels
        || replacement.output_channels() != handle.output_channels
    {
        return Err("Restored plugin channel layout differs from the handle layout".into());
    }

    // Keep ParameterMap storage alive: foreign ParameterInfo pointers remain
    // valid until plugin_destroy. A rejected preset never touches live DSP.
    handle.plugin = replacement;
    handle.config_json = replacement_config;
    Ok(())
}

fn is_crossover_runtime_id(id: &str) -> bool {
    matches!(id, "type" | "frequency" | "mode" | "fir_taps")
        || id
            .strip_prefix("frequency_")
            .is_some_and(|suffix| suffix.parse::<usize>().is_ok())
        || id
            .strip_prefix("channel_frequency_")
            .is_some_and(|suffix| suffix.parse::<usize>().is_ok())
        || id
            .strip_prefix("channel_mode_")
            .is_some_and(|suffix| suffix.parse::<usize>().is_ok())
}

fn replace_crossover_from_state(handle: &mut PluginHandle, state: &[u8]) -> Result<(), String> {
    let current_state: serde_json::Map<String, serde_json::Value> =
        serde_json::from_slice(&plugins_bridge::state::save_state(&*handle.plugin))
            .map_err(|error| format!("Failed to capture current Crossover state: {error}"))?;
    let incoming_state: serde_json::Map<String, serde_json::Value> = serde_json::from_slice(state)
        .map_err(|error| format!("Failed to parse Crossover state: {error}"))?;
    let current_type = current_state
        .get("type")
        .and_then(serde_json::Value::as_str)
        .ok_or_else(|| "Current Crossover type state must be a string".to_string())?
        .to_owned();
    let current_type = sotf_plugins::plugin_crossover::canonical_crossover_type(&current_type)?;
    let requested_type = match incoming_state.get("type") {
        Some(serde_json::Value::String(value)) => {
            sotf_plugins::plugin_crossover::canonical_crossover_type(value)?
        }
        Some(_) => return Err("Crossover type state must be a string".into()),
        None => current_type,
    };
    let requested_fir = requested_type == "LinearPhase";

    // State import is a partial merge, matching the public FFI contract.
    // Known Crossover IDs absent from this instance identify a topology change;
    // inactive FIR taps and unknown keys retain the generic loader's ignore
    // behavior unless the requested family activates that FIR control.
    for key in incoming_state.keys() {
        if is_crossover_runtime_id(key) && !current_state.contains_key(key) && key != "fir_taps" {
            return Err(format!(
                "Crossover state parameter '{key}' changes the active topology; create a new handle"
            ));
        }
    }
    let mut merged_state = current_state;
    for (key, value) in incoming_state {
        if is_crossover_runtime_id(&key)
            && (key != "fir_taps" || requested_fir || current_type == "LinearPhase")
        {
            merged_state.insert(key, value);
        }
    }
    merged_state.insert(
        "type".into(),
        serde_json::Value::String(requested_type.to_owned()),
    );

    let is_per_channel = merged_state
        .keys()
        .any(|key| key.starts_with("channel_frequency_"));
    let crossover_type = merged_state
        .get("type")
        .and_then(serde_json::Value::as_str)
        .ok_or_else(|| "Crossover type state must be a string".to_string())?;

    let mut config: serde_json::Value = match handle.config_json.trim() {
        "" | "null" | "{}" => serde_json::json!({}),
        config => serde_json::from_str(config)
            .map_err(|error| format!("Failed to parse Crossover config: {error}"))?,
    };
    let config_object = config
        .as_object_mut()
        .ok_or_else(|| "Crossover config must be a JSON object".to_string())?;
    config_object.insert(
        "type".into(),
        serde_json::Value::String(crossover_type.to_owned()),
    );

    if is_per_channel {
        let mut frequencies = Vec::new();
        let mut modes = Vec::new();
        loop {
            let channel = frequencies.len();
            let frequency_id = format!("channel_frequency_{channel}");
            let Some(frequency) = merged_state.get(&frequency_id) else {
                break;
            };
            let frequency = frequency
                .as_f64()
                .ok_or_else(|| format!("Crossover {frequency_id} must be numeric"))?;
            if !frequency.is_finite() {
                return Err(format!("Crossover {frequency_id} must be finite"));
            }
            let mode_id = format!("channel_mode_{channel}");
            let mode = merged_state
                .get(&mode_id)
                .and_then(serde_json::Value::as_str)
                .ok_or_else(|| format!("Crossover {mode_id} must be a string"))?;
            frequencies.push(serde_json::Value::from(frequency));
            modes.push(serde_json::Value::String(mode.to_owned()));
        }
        if frequencies.len() != handle.input_channels {
            return Err(format!(
                "Crossover per-channel state has {} cutoffs for {} input channels",
                frequencies.len(),
                handle.input_channels
            ));
        }
        // Keep dormant global frequency/mode and multiway values from the
        // constructor config. Complete explicit channel modes select the live
        // route, so dormant `output=both` remains valid.
        config_object.insert(
            "channel_frequencies_hz".into(),
            serde_json::Value::Array(frequencies),
        );
        config_object.insert("channel_modes".into(), serde_json::Value::Array(modes));
    } else {
        let frequency = merged_state
            .get("frequency")
            .and_then(serde_json::Value::as_f64)
            .ok_or_else(|| "Crossover frequency state must be numeric".to_string())?;
        if !frequency.is_finite() {
            return Err("Crossover frequency state must be finite".into());
        }
        let mode = merged_state
            .get("mode")
            .and_then(serde_json::Value::as_str)
            .ok_or_else(|| "Crossover mode state must be a string".to_string())?;
        let mut extra_frequencies = Vec::new();
        let mut ordered_frequencies = vec![frequency];
        for index in 2..=3 {
            let id = format!("frequency_{index}");
            let Some(value) = merged_state.get(&id) else {
                break;
            };
            let value = value
                .as_f64()
                .ok_or_else(|| format!("Crossover {id} state must be numeric"))?;
            if !value.is_finite() {
                return Err(format!("Crossover {id} state must be finite"));
            }
            ordered_frequencies.push(value);
            extra_frequencies.push(serde_json::Value::from(value));
        }
        if ordered_frequencies
            .windows(2)
            .any(|pair| pair[0] >= pair[1])
        {
            return Err("Crossover cutoff frequencies must be strictly increasing".into());
        }
        config_object.insert("frequency".into(), serde_json::Value::from(frequency));
        config_object.insert("output".into(), serde_json::Value::String(mode.to_owned()));
        config_object.insert(
            "extra_frequencies".into(),
            serde_json::Value::Array(extra_frequencies),
        );
        if crossover_type == "LinearPhase"
            && let Some(fir_taps) = merged_state.get("fir_taps")
        {
            let fir_taps = fir_taps
                .as_i64()
                .ok_or_else(|| "Crossover fir_taps state must be an integer".to_string())?;
            config_object.insert("fir_taps".into(), serde_json::Value::from(fir_taps));
        }
    }

    let replacement_config = serde_json::to_string(&config)
        .map_err(|error| format!("Failed to serialize Crossover config: {error}"))?;
    let mut replacement = super::plugin_factory::create_unprepared_plugin(
        &handle.plugin_type,
        &replacement_config,
        handle.input_channels,
        handle.output_channels,
        handle.sample_rate,
    )?;
    replacement =
        plugins_bridge::prepare_standalone_plugin(replacement, handle.max_callback_frames)?;
    replacement.initialize(handle.sample_rate)?;
    if replacement.input_channels() != handle.input_channels
        || replacement.output_channels() != handle.output_channels
    {
        return Err("Restored Crossover channel layout differs from the handle layout".into());
    }

    // The runtime map changes when a restore enters or leaves FIR mode, and
    // its default values track the committed state. Keep every old map alive
    // because C callers may retain any previously returned info pointer.
    let next_parameter_map = ParameterMap::from_plugin(&*replacement, &handle.plugin_type);
    handle.retired_parameter_maps.push(std::mem::replace(
        &mut handle.parameter_map,
        next_parameter_map,
    ));
    handle.plugin = replacement;
    handle.config_json = replacement_config;
    Ok(())
}

fn replace_dynamic_eq_from_state(handle: &mut PluginHandle, state: &[u8]) -> Result<(), String> {
    // Partial presets merge into the full live snapshot, which includes all
    // eight slots even when fewer bands currently process audio.
    let mut merged_state: serde_json::Map<String, serde_json::Value> =
        serde_json::from_slice(&plugins_bridge::state::save_state(&*handle.plugin))
            .map_err(|error| format!("Failed to capture current DynamicEQ state: {error}"))?;
    let incoming_state: serde_json::Map<String, serde_json::Value> = serde_json::from_slice(state)
        .map_err(|error| format!("Failed to parse DynamicEQ state: {error}"))?;
    merged_state.extend(incoming_state);
    let merged_state = serde_json::to_vec(&merged_state)
        .map_err(|error| format!("Failed to merge DynamicEQ state: {error}"))?;
    let replacement_config = super::plugin_factory::merge_dynamic_eq_state_into_config(
        &handle.config_json,
        &merged_state,
    )?;

    // Construct, prepare, and initialize a separate instance. The live
    // plugin, constructor config, and parameter-map pointers remain untouched
    // until every fallible operation and layout check has succeeded.
    let mut replacement = super::plugin_factory::create_unprepared_plugin(
        &handle.plugin_type,
        &replacement_config,
        handle.input_channels,
        handle.output_channels,
        handle.sample_rate,
    )?;
    replacement =
        plugins_bridge::prepare_standalone_plugin(replacement, handle.max_callback_frames)?;
    replacement.initialize(handle.sample_rate)?;
    if replacement.input_channels() != handle.input_channels
        || replacement.output_channels() != handle.output_channels
    {
        return Err("Restored DynamicEQ channel layout differs from the handle layout".into());
    }

    handle.plugin = replacement;
    handle.config_json = replacement_config;
    Ok(())
}

fn replace_band_split_from_state(handle: &mut PluginHandle, state: &[u8]) -> Result<(), String> {
    let mut merged_state: serde_json::Map<String, serde_json::Value> =
        serde_json::from_slice(&plugins_bridge::state::save_state(&*handle.plugin))
            .map_err(|error| format!("Failed to capture current BandSplit state: {error}"))?;
    let incoming_state: serde_json::Map<String, serde_json::Value> = serde_json::from_slice(state)
        .map_err(|error| format!("Failed to parse BandSplit state: {error}"))?;
    merged_state.extend(incoming_state);

    let choice = |key: &str| -> Result<usize, String> {
        let value = merged_state
            .get(key)
            .and_then(serde_json::Value::as_i64)
            .ok_or_else(|| format!("BandSplit {key} must be a choice index"))?;
        usize::try_from(value).map_err(|_| format!("BandSplit {key} choice is out of range"))
    };
    let cutoff = |key: &str| -> Result<f64, String> {
        let value = merged_state
            .get(key)
            .and_then(serde_json::Value::as_f64)
            .ok_or_else(|| format!("BandSplit {key} must be numeric"))?;
        if !value.is_finite() {
            return Err(format!("BandSplit {key} must be finite"));
        }
        Ok(value)
    };

    // These values are choice indices in the public parameter state and
    // constructor values in plugin configuration. Build the full active
    // cutoff vector before applying any setters, so a coordinated shift such
    // as [1000, 2000, 3000] -> [2000, 3000, 4000] never passes through an
    // invalid intermediate ordering.
    let band_count = choice("num_bands")?
        .checked_add(2)
        .filter(|count| (2..=4).contains(count))
        .ok_or_else(|| "BandSplit num_bands choice is out of range".to_string())?;
    let expected_outputs = handle
        .input_channels
        .checked_mul(band_count)
        .ok_or_else(|| "BandSplit output channel count overflow".to_string())?;
    if expected_outputs != handle.output_channels {
        return Err(format!(
            "BandSplit restore changes output geometry from {} to {}; create a new handle",
            handle.output_channels, expected_outputs
        ));
    }

    let crossover_type = match choice("type")? {
        0 => "LR24",
        1 => "LR48",
        _ => return Err("BandSplit type choice is out of range".into()),
    };
    let recombination_mode = match choice("recombination_mode")? {
        0 => "legacy_cascade",
        1 => "phase_compensated",
        _ => return Err("BandSplit recombination_mode choice is out of range".into()),
    };
    let mut frequencies = Vec::with_capacity(band_count - 1);
    for key in ["frequency", "frequency_2", "frequency_3"]
        .into_iter()
        .take(band_count - 1)
    {
        frequencies.push(cutoff(key)?);
    }

    let mut config: serde_json::Value = match handle.config_json.trim() {
        "" | "null" | "{}" => serde_json::json!({}),
        config => serde_json::from_str(config)
            .map_err(|error| format!("Failed to parse BandSplit config: {error}"))?,
    };
    let config_object = config
        .as_object_mut()
        .ok_or_else(|| "BandSplit config must be a JSON object".to_string())?;
    // `crossover_type` is a supported legacy alias for the canonical `type`
    // constructor field. Remove it before inserting the new canonical value,
    // otherwise serde sees both names for one field and rejects the rebuild.
    config_object.remove("crossover_type");
    config_object.insert(
        "frequencies".into(),
        serde_json::to_value(&frequencies)
            .map_err(|error| format!("Failed to serialize BandSplit cutoffs: {error}"))?,
    );
    config_object.insert(
        "explicit_frequencies".into(),
        serde_json::to_value(&frequencies)
            .map_err(|error| format!("Failed to serialize BandSplit explicit cutoffs: {error}"))?,
    );
    config_object.insert("num_bands".into(), serde_json::json!(band_count));
    config_object.insert("type".into(), serde_json::json!(crossover_type));
    config_object.insert(
        "recombination_mode".into(),
        serde_json::json!(recombination_mode),
    );
    // Inactive cutoffs remain visible and serializable when this same-width
    // handle later reopens a wider band configuration.
    for key in ["frequency", "frequency_2", "frequency_3"] {
        config_object.insert(key.into(), serde_json::json!(cutoff(key)?));
    }
    let replacement_config = serde_json::to_string(&config)
        .map_err(|error| format!("Failed to serialize BandSplit config: {error}"))?;

    let mut replacement = super::plugin_factory::create_unprepared_plugin(
        &handle.plugin_type,
        &replacement_config,
        handle.input_channels,
        handle.output_channels,
        handle.sample_rate,
    )?;
    // Reapply non-constructor controls such as band gains. Structural and
    // cutoff values already match the replacement constructor, so the
    // changed-only loader will not replay them in an unsafe order.
    let merged_state = serde_json::to_vec(&merged_state)
        .map_err(|error| format!("Failed to serialize merged BandSplit state: {error}"))?;
    load_changed_state(&mut *replacement, &merged_state, &handle.plugin_type)?;
    replacement =
        plugins_bridge::prepare_standalone_plugin(replacement, handle.max_callback_frames)?;
    replacement.initialize(handle.sample_rate)?;

    if replacement.input_channels() != handle.input_channels
        || replacement.output_channels() != handle.output_channels
    {
        return Err("Restored plugin channel layout differs from the handle layout".into());
    }

    handle.plugin = replacement;
    handle.config_json = replacement_config;
    Ok(())
}

#[cfg(test)]
#[path = "state_tests.rs"]
mod state_tests;

fn replace_linear_phase_eq_from_state(
    handle: &mut PluginHandle,
    state: &[u8],
) -> Result<(), String> {
    // Match the generic state loader's partial-update contract: values omitted
    // from the incoming object retain their current live values, including
    // automation applied after the last structural reconstruction.
    let mut merged_state: serde_json::Map<String, serde_json::Value> =
        serde_json::from_slice(&plugins_bridge::state::save_state(&*handle.plugin))
            .map_err(|error| format!("Failed to capture current LinearPhaseEQ state: {error}"))?;
    let incoming_state: serde_json::Map<String, serde_json::Value> = serde_json::from_slice(state)
        .map_err(|error| format!("Failed to parse LinearPhaseEQ state: {error}"))?;
    if let Some(num_filters) = incoming_state
        .get("num_filters")
        .and_then(serde_json::Value::as_u64)
    {
        // A smaller incoming structure replaces, rather than preserves, the
        // now-out-of-range live bands. Explicit incoming out-of-range band
        // fields remain in the overlay and are rejected by constructor merge.
        merged_state.retain(|key, _| {
            key.strip_prefix("band_")
                .and_then(|rest| rest.split_once('_'))
                .and_then(|(index, _)| index.parse::<u64>().ok())
                .is_none_or(|index| index < num_filters)
        });
    }
    merged_state.extend(incoming_state);
    let merged_state = serde_json::to_vec(&merged_state)
        .map_err(|error| format!("Failed to merge LinearPhaseEQ state: {error}"))?;
    let rebuilt_config = super::plugin_factory::merge_linear_phase_eq_state_into_config(
        &handle.config_json,
        &merged_state,
    )?;
    let mut replacement = super::plugin_factory::create_plugin_with_max_callback(
        &handle.plugin_type,
        &rebuilt_config,
        handle.input_channels,
        handle.output_channels,
        handle.sample_rate,
        handle.max_callback_frames,
    )?;
    replacement.initialize(handle.sample_rate)?;

    // LinearPhaseEQ's FFI parameter map is built from static specs and the
    // maximum band template, so structural changes do not alter it. Retaining
    // the original allocation also preserves the documented lifetime of
    // ParameterInfo pointers returned to foreign callers.
    //
    // Commit only after parsing, construction, and initialization succeeded.
    // Any earlier error leaves the live plugin and constructor config intact.
    handle.plugin = replacement;
    handle.config_json = rebuilt_config;
    Ok(())
}

/// Get the last error message.
///
/// # Returns
/// * Pointer to a null-terminated C string, or `NULL` if no error has been set.
/// * The pointer points to thread-local storage that remains valid until the
///   next FFI call on the same thread that may set an error. Copy the contents
///   if you need it to outlive the next call.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_get_last_error() -> *const c_char {
    let static_error = LAST_STATIC_ERROR.with(std::cell::Cell::get);
    if !static_error.is_null() {
        return static_error;
    }
    LAST_ERROR.with(|e| {
        e.borrow()
            .as_ref()
            .map(|s| s.as_ptr())
            .unwrap_or(ptr::null())
    })
}

/// Get the stable ABI version for this FFI surface.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_ffi_abi_version() -> u32 {
    SOTF_PLUGIN_FFI_ABI_VERSION
}

/// Get runtime capabilities for the current target.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_ffi_capabilities() -> PluginFfiCapabilities {
    PluginFfiCapabilities {
        abi_version: SOTF_PLUGIN_FFI_ABI_VERSION,
        host_kind: current_host_kind(),
        supports_audio: true,
        supports_parameters: true,
        supports_state: true,
        supports_midi_input: true,
        supports_midi_output: true,
        supports_note_expression: true,
        supports_apple_au_v3: cfg!(any(target_os = "macos", target_os = "ios")),
        supports_ios_au_v3: cfg!(target_os = "ios"),
        supports_windows_vst3: cfg!(target_os = "windows"),
        supports_swift_package: cfg!(any(target_os = "macos", target_os = "ios")),
        supports_preset_documents: true,
    }
}

/// Get machine-readable platform and capability metadata as JSON.
///
/// # Returns
/// * JSON string owned by the caller. It must be released with
///   [`plugin_free_string`] when no longer needed.
/// * `NULL` on error.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_ffi_platform_info_json() -> *mut c_char {
    let caps = plugin_ffi_capabilities();
    let json = serde_json::json!({
        "abi_version": caps.abi_version,
        "target_os": std::env::consts::OS,
        "target_arch": std::env::consts::ARCH,
        "host_kind": host_kind_name(caps.host_kind),
        "supports_audio": caps.supports_audio,
        "supports_parameters": caps.supports_parameters,
        "supports_state": caps.supports_state,
        "supports_midi_input": caps.supports_midi_input,
        "supports_midi_output": caps.supports_midi_output,
        "supports_note_expression": caps.supports_note_expression,
        "supports_apple_au_v3": caps.supports_apple_au_v3,
        "supports_ios_au_v3": caps.supports_ios_au_v3,
        "supports_windows_vst3": caps.supports_windows_vst3,
        "supports_swift_package": caps.supports_swift_package,
        "supports_preset_documents": caps.supports_preset_documents,
    });

    match CString::new(json.to_string()) {
        Ok(s) => s.into_raw(),
        Err(_) => ptr::null_mut(),
    }
}

/// Get preset document metadata for host file dialogs and AUv3 document state.
///
/// The returned string pointers reference static, null-terminated C strings
/// with program lifetime. They must not be freed.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_preset_document_info() -> PluginPresetDocumentInfo {
    PluginPresetDocumentInfo {
        schema_version: 1,
        ut_type: PRESET_UT_TYPE.as_ptr().cast(),
        file_extension: PRESET_FILE_EXTENSION.as_ptr().cast(),
        mime_type: PRESET_MIME_TYPE.as_ptr().cast(),
        supports_full_state_for_document: cfg!(any(target_os = "macos", target_os = "ios")),
        supports_security_scoped_bookmarks: cfg!(target_os = "macos"),
    }
}

/// Get Windows/VST3 FFI metadata for native language bindings.
///
/// The returned string pointers reference static, null-terminated C strings
/// with program lifetime. They must not be freed.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_vst3_ffi_descriptor() -> PluginVst3FfiDescriptor {
    PluginVst3FfiDescriptor {
        abi_version: SOTF_PLUGIN_FFI_ABI_VERSION,
        // Stable namespace UUID: "SOTF-FFI-VST3-01" bytes.
        class_id: *b"SOTF-FFI-VST3-01",
        component_name: VST3_COMPONENT_NAME.as_ptr().cast(),
        vendor: VST3_VENDOR.as_ptr().cast(),
        sdk_version: VST3_SDK_VERSION.as_ptr().cast(),
        entrypoint: VST3_ENTRYPOINT.as_ptr().cast(),
        supports_com_factory: false,
        supports_audio_effects: true,
        supports_instruments: true,
        supports_midi_output: true,
        supports_note_expression: true,
    }
}

/// Get Swift Package metadata for Xcode/SwiftPM integrations.
///
/// The returned string pointers reference static, null-terminated C strings
/// with program lifetime. They must not be freed.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_swift_package_info() -> PluginSwiftPackageInfo {
    PluginSwiftPackageInfo {
        package_name: SWIFT_PACKAGE_NAME.as_ptr().cast(),
        product_name: SWIFT_PRODUCT_NAME.as_ptr().cast(),
        target_name: SWIFT_TARGET_NAME.as_ptr().cast(),
        library_name: SWIFT_LIBRARY_NAME.as_ptr().cast(),
        umbrella_header: SWIFT_HEADER_NAME.as_ptr().cast(),
        supports_staticlib: true,
        supports_xcframework: true,
    }
}

/// Create a new plugin instance
///
/// # Arguments
/// * `plugin_type` - Plugin type name (e.g., "EQ", "Compressor")
/// * `config_json` - JSON configuration string
/// * `sample_rate` - Sample rate in Hz
/// * `input_channels` - Number of input channels
/// * `output_channels` - Number of output channels
///
/// # Returns
/// * Opaque plugin handle on success
/// * NULL on failure (check plugin_get_last_error())
///
/// # Safety
/// * `plugin_type` and `config_json` must be valid, null-terminated UTF-8 C strings
///   that remain readable for the duration of this call.
/// * The returned handle is owned by the caller and must be released with
///   [`plugin_destroy`] exactly once. The pointer is invalid after that call.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_create(
    plugin_type: *const c_char,
    config_json: *const c_char,
    sample_rate: u32,
    input_channels: usize,
    output_channels: usize,
) -> *mut PluginHandle {
    // Catch panics and return NULL
    let result = panic::catch_unwind(AssertUnwindSafe(|| {
        // Validate pointers
        if plugin_type.is_null() || config_json.is_null() {
            set_last_error("NULL pointer passed to plugin_create");
            return ptr::null_mut();
        }

        // Convert C strings to Rust
        let plugin_type_str = unsafe {
            match CStr::from_ptr(plugin_type).to_str() {
                Ok(s) => s,
                Err(_) => {
                    set_last_error("Invalid UTF-8 in plugin_type");
                    return ptr::null_mut();
                }
            }
        };

        let config_str = unsafe {
            match CStr::from_ptr(config_json).to_str() {
                Ok(s) => s,
                Err(_) => {
                    set_last_error("Invalid UTF-8 in config_json");
                    return ptr::null_mut();
                }
            }
        };

        // Canonicalize direct-format aliases once so factory policy,
        // parameter metadata, serialized identity, and adapter selection
        // cannot disagree.
        let plugin_type_str = super::plugin_factory::canonical_direct_plugin_type(plugin_type_str);

        let max_callback_frames =
            match super::plugin_factory::max_callback_frames_from_config(config_str) {
                Ok(value) => value,
                Err(error) => {
                    set_last_error(&error);
                    return ptr::null_mut();
                }
            };

        // Create plugin
        let mut plugin = match super::plugin_factory::create_plugin_with_max_callback(
            plugin_type_str,
            config_str,
            input_channels,
            output_channels,
            sample_rate,
            max_callback_frames,
        ) {
            Ok(p) => p,
            Err(e) => {
                set_last_error(&format!("Failed to create plugin: {}", e));
                return ptr::null_mut();
            }
        };

        // Initialize plugin
        if let Err(e) = plugin.initialize(sample_rate) {
            set_last_error(&format!("Failed to initialize plugin: {}", e));
            return ptr::null_mut();
        }

        // Build parameter map
        let parameter_map = ParameterMap::from_plugin(&*plugin, plugin_type_str);

        // Create handle
        let handle = Box::new(PluginHandle {
            plugin,
            plugin_type: plugin_type_str.to_string(),
            config_json: config_str.to_string(),
            parameter_map,
            retired_parameter_maps: Vec::new(),
            sample_rate,
            max_callback_frames,
            input_channels,
            output_channels,
            midi_output_events: Vec::with_capacity(MAX_FFI_OUTPUT_EVENTS_PER_BLOCK),
            note_expression_output_events: Vec::with_capacity(MAX_FFI_OUTPUT_EVENTS_PER_BLOCK),
        });

        Box::into_raw(handle)
    }));

    result.unwrap_or_else(|_| {
        set_last_error("Panic occurred in plugin_create");
        ptr::null_mut()
    })
}

/// Destroy a plugin instance
///
/// # Safety
/// * handle must be a valid pointer returned by plugin_create()
/// * handle must not be used after this call
#[unsafe(no_mangle)]
pub extern "C" fn plugin_destroy(handle: *mut PluginHandle) {
    if !handle.is_null() {
        let _ = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
            drop(Box::from_raw(handle));
        }));
    }
}

/// Reset plugin state (clear buffers, reset filters)
///
/// # Safety
/// * handle must be a valid pointer returned by plugin_create()
#[unsafe(no_mangle)]
pub extern "C" fn plugin_reset(handle: *mut PluginHandle) -> c_int {
    if handle.is_null() {
        set_last_error("NULL handle in plugin_reset");
        return PluginError::InvalidHandle.into();
    }

    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &mut *handle;
        handle_ref.plugin.reset();
        PluginError::Success
    }));

    result
        .unwrap_or_else(|_| {
            set_last_error("Panic in plugin_reset");
            PluginError::UnknownError
        })
        .into()
}

/// Process audio samples
///
/// # Arguments
/// * `handle` - Plugin handle
/// * `input` - Interleaved input samples [C0_F0, C1_F0, ..., C0_F1, C1_F1, ...]
/// * `output` - Interleaved output buffer (will be filled)
/// * `num_frames` - Number of frames to process
///
/// # Returns
/// * 0 on success
/// * Error code on failure
///
/// # Safety
/// * `handle` must be a valid plugin handle returned by [`plugin_create`] that
///   has not been destroyed.
/// * `input` and `output` must be valid, properly aligned, non-overlapping
///   buffers that remain valid for the duration of this call.
/// * `input` must contain at least `num_frames * input_channels` samples and
///   `output` must have space for at least `num_frames * output_channels`
///   samples, where `input_channels` and `output_channels` are the values
///   passed to [`plugin_create`].
/// * This function is designed to be real-time safe (no allocations).
#[unsafe(no_mangle)]
pub extern "C" fn plugin_process(
    handle: *mut PluginHandle,
    input: *const f32,
    output: *mut f32,
    num_frames: usize,
) -> c_int {
    if handle.is_null() || input.is_null() || output.is_null() {
        return PluginError::NullPointer.into();
    }

    // Real-time processing: avoid panic catching overhead in release builds
    #[cfg(debug_assertions)]
    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let context = ProcessContext::new((*handle).sample_rate, num_frames);
        process_impl(handle, input, output, num_frames, &context)
    }));

    #[cfg(not(debug_assertions))]
    let result: Result<PluginError, ()> = Ok(unsafe {
        let context = ProcessContext::new((*handle).sample_rate, num_frames);
        process_impl(handle, input, output, num_frames, &context)
    });

    result
        .unwrap_or_else(|_| {
            set_last_error("Panic in plugin_process");
            PluginError::ProcessingFailed
        })
        .into()
}

/// Process audio samples with incoming MIDI events.
///
/// MIDI events are copied into a fixed stack buffer, then borrowed by
/// ProcessContext. No heap allocation occurs on the render path.
///
/// # Safety
/// * `handle`, `input`, and `output` must satisfy the same contract as
///   [`plugin_process`].
/// * `midi_events` must point to `midi_event_count` valid [`PluginMidiEvent`]
///   structs and remain readable for the duration of this call. It may be
///   `NULL` only when `midi_event_count` is `0`.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_process_with_midi(
    handle: *mut PluginHandle,
    input: *const f32,
    output: *mut f32,
    num_frames: usize,
    midi_events: *const PluginMidiEvent,
    midi_event_count: usize,
) -> c_int {
    if handle.is_null()
        || input.is_null()
        || output.is_null()
        || (midi_events.is_null() && midi_event_count > 0)
    {
        return PluginError::NullPointer.into();
    }

    #[cfg(debug_assertions)]
    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        process_with_ffi_events_impl(
            handle,
            input,
            output,
            num_frames,
            midi_events,
            midi_event_count,
        )
    }));

    #[cfg(not(debug_assertions))]
    let result: Result<PluginError, ()> = Ok(unsafe {
        process_with_ffi_events_impl(
            handle,
            input,
            output,
            num_frames,
            midi_events,
            midi_event_count,
        )
    });

    result
        .unwrap_or_else(|_| {
            set_last_error("Panic in plugin_process_with_midi");
            PluginError::ProcessingFailed
        })
        .into()
}

/// Process audio with MIDI/note-expression input and output ABI slots.
///
/// Incoming MIDI is bridged into ProcessContext. Queued MIDI output and Note
/// Expression events are copied into host-provided buffers without allocating
/// on the render path.
///
/// # Safety
/// * `handle`, `input`, and `output` must satisfy the same contract as
///   [`plugin_process`].
/// * `midi_input` must point to `midi_input_count` valid [`PluginMidiEvent`]
///   structs and remain readable for the duration of this call. It may be
///   `NULL` only when `midi_input_count` is `0`.
/// * `note_expression_input` must point to `note_expression_input_count` valid
///   [`PluginNoteExpressionEvent`] structs and remain readable for the duration
///   of this call. It may be `NULL` only when `note_expression_input_count` is `0`.
/// * If queued output events exist, `midi_output` and `note_expression_output`
///   must be valid writable buffers with capacities matching the supplied
///   `_capacity` values and remain writable for the duration of this call.
/// * `midi_output_count` and `note_expression_output_count` must be valid
///   pointers to `usize` values that this call may write.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_process_with_events(
    handle: *mut PluginHandle,
    input: *const f32,
    output: *mut f32,
    num_frames: usize,
    midi_input: *const PluginMidiEvent,
    midi_input_count: usize,
    note_expression_input: *const PluginNoteExpressionEvent,
    note_expression_input_count: usize,
    _midi_output: *mut PluginMidiEvent,
    _midi_output_capacity: usize,
    midi_output_count: *mut usize,
    _note_expression_output: *mut PluginNoteExpressionEvent,
    _note_expression_output_capacity: usize,
    note_expression_output_count: *mut usize,
) -> c_int {
    if !midi_output_count.is_null() {
        unsafe {
            *midi_output_count = 0;
        }
    }
    if !note_expression_output_count.is_null() {
        unsafe {
            *note_expression_output_count = 0;
        }
    }

    if note_expression_input.is_null() && note_expression_input_count > 0 {
        return PluginError::NullPointer.into();
    }
    if note_expression_input_count > MAX_FFI_MIDI_EVENTS_PER_BLOCK {
        set_last_error("Too many Note Expression events for one FFI processing block");
        return PluginError::BufferTooSmall.into();
    }

    if handle.is_null()
        || input.is_null()
        || output.is_null()
        || (midi_input.is_null() && midi_input_count > 0)
    {
        return PluginError::NullPointer.into();
    }

    #[cfg(debug_assertions)]
    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        process_with_full_events_impl(
            handle,
            input,
            output,
            num_frames,
            midi_input,
            midi_input_count,
            note_expression_input,
            note_expression_input_count,
            _midi_output,
            _midi_output_capacity,
            midi_output_count,
            _note_expression_output,
            _note_expression_output_capacity,
            note_expression_output_count,
        )
    }));

    #[cfg(not(debug_assertions))]
    let result: Result<PluginError, ()> = Ok(unsafe {
        process_with_full_events_impl(
            handle,
            input,
            output,
            num_frames,
            midi_input,
            midi_input_count,
            note_expression_input,
            note_expression_input_count,
            _midi_output,
            _midi_output_capacity,
            midi_output_count,
            _note_expression_output,
            _note_expression_output_capacity,
            note_expression_output_count,
        )
    });

    result
        .unwrap_or_else(|_| {
            set_last_error("Panic in plugin_process_with_events");
            PluginError::ProcessingFailed
        })
        .into()
}

/// Clear queued MIDI and Note Expression output events.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_clear_output_events(handle: *mut PluginHandle) -> c_int {
    if handle.is_null() {
        return PluginError::InvalidHandle.into();
    }
    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &mut *handle;
        handle_ref.midi_output_events.clear();
        handle_ref.note_expression_output_events.clear();
        PluginError::Success
    }));
    result.unwrap_or(PluginError::UnknownError).into()
}

/// Queue one outgoing MIDI event for the next event-aware process call.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_enqueue_midi_output_event(
    handle: *mut PluginHandle,
    event: PluginMidiEvent,
) -> c_int {
    if handle.is_null() {
        return PluginError::InvalidHandle.into();
    }
    if event.len > 3 {
        set_last_error("Invalid outgoing MIDI event length");
        return PluginError::InvalidConfig.into();
    }
    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &mut *handle;
        if handle_ref.midi_output_events.len() >= MAX_FFI_OUTPUT_EVENTS_PER_BLOCK {
            set_last_error("MIDI output queue is full");
            return PluginError::BufferTooSmall;
        }
        handle_ref.midi_output_events.push(event);
        PluginError::Success
    }));
    result.unwrap_or(PluginError::UnknownError).into()
}

/// Queue one outgoing Note Expression event for the next event-aware process call.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_enqueue_note_expression_output_event(
    handle: *mut PluginHandle,
    event: PluginNoteExpressionEvent,
) -> c_int {
    if handle.is_null() {
        return PluginError::InvalidHandle.into();
    }
    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &mut *handle;
        if handle_ref.note_expression_output_events.len() >= MAX_FFI_OUTPUT_EVENTS_PER_BLOCK {
            set_last_error("Note Expression output queue is full");
            return PluginError::BufferTooSmall;
        }
        handle_ref.note_expression_output_events.push(event);
        PluginError::Success
    }));
    result.unwrap_or(PluginError::UnknownError).into()
}

/// Copy queued outgoing MIDI events without processing audio.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_get_midi_output_events(
    handle: *mut PluginHandle,
    out: *mut PluginMidiEvent,
    capacity: usize,
    out_count: *mut usize,
) -> c_int {
    if handle.is_null() {
        return PluginError::InvalidHandle.into();
    }
    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &mut *handle;
        copy_midi_output_events(&mut handle_ref.midi_output_events, out, capacity, out_count)
    }));
    result.unwrap_or(PluginError::UnknownError).into()
}

/// Copy queued outgoing Note Expression events without processing audio.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_get_note_expression_output_events(
    handle: *mut PluginHandle,
    out: *mut PluginNoteExpressionEvent,
    capacity: usize,
    out_count: *mut usize,
) -> c_int {
    if handle.is_null() {
        return PluginError::InvalidHandle.into();
    }
    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &mut *handle;
        copy_note_expression_output_events(
            &mut handle_ref.note_expression_output_events,
            out,
            capacity,
            out_count,
        )
    }));
    result.unwrap_or(PluginError::UnknownError).into()
}

/// Get the number of parameters
#[unsafe(no_mangle)]
pub extern "C" fn plugin_get_parameter_count(handle: *const PluginHandle) -> c_int {
    if handle.is_null() {
        return 0;
    }

    unsafe {
        let handle_ref = &*handle;
        handle_ref.parameter_map.count() as c_int
    }
}

/// Get parameter info by index.
///
/// # Returns
/// * Pointer to parameter info. The pointer is valid only while the
///   `PluginHandle` used to obtain it remains alive and has not been destroyed.
/// * `NULL` if the handle is invalid or the index is out of bounds.
///
/// # Safety
/// * `handle` must be a valid plugin handle that has not been destroyed.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_get_parameter_info(
    handle: *const PluginHandle,
    index: usize,
) -> *const ParameterInfo {
    if handle.is_null() {
        return ptr::null();
    }

    unsafe {
        let handle_ref = &*handle;
        handle_ref
            .parameter_map
            .get_info(index)
            .map(|info| info as *const ParameterInfo)
            .unwrap_or(ptr::null())
    }
}

/// Get one choice label for a parameter in its enumerated ABI position.
///
/// The returned pointer references a static NUL-terminated string and is
/// valid for the process lifetime. It is `NULL` when the index does not
/// identify a supported choice parameter or when `choice_index` is invalid.
///
/// # Safety
/// * `handle` must be `NULL` or a live plugin handle.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_get_parameter_choice_label(
    handle: *const PluginHandle,
    parameter_index: usize,
    choice_index: usize,
) -> *const c_char {
    if handle.is_null() {
        return ptr::null();
    }

    // SAFETY: the caller promises a live handle; the method only reads its
    // immutable parameter map and returns a process-static string pointer.
    unsafe {
        (&*handle)
            .parameter_map
            .choice_label_at(parameter_index, choice_index)
            .unwrap_or(ptr::null())
    }
}

/// Set a parameter value (normalized 0.0-1.0).
///
/// # Arguments
/// * `handle` - Plugin handle
/// * `param_id` - Parameter ID string
/// * `normalized_value` - Normalized value (0.0 = min, 1.0 = max)
///
/// # Returns
/// * 0 on success
/// * Error code on failure
///
/// # Safety
/// * `handle` must be a valid plugin handle that has not been destroyed.
/// * `param_id` must be a valid, null-terminated UTF-8 C string that remains
///   readable for the duration of this call.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_set_parameter(
    handle: *mut PluginHandle,
    param_id: *const c_char,
    normalized_value: c_double,
) -> c_int {
    if handle.is_null() || param_id.is_null() {
        set_last_error("NULL pointer in plugin_set_parameter");
        return PluginError::NullPointer.into();
    }

    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &mut *handle;

        let param_id_str = match CStr::from_ptr(param_id).to_str() {
            Ok(s) => s,
            Err(_) => {
                set_last_error("Invalid UTF-8 in param_id");
                return PluginError::InvalidUtf8;
            }
        };

        if is_dynamic_eq_shelf_structural_id(&handle_ref.plugin_type, param_id_str) {
            set_last_error_static(c"Dynamic EQ shelf shape and slope require state restoration");
            return PluginError::InvalidParameter;
        }

        match handle_ref.parameter_map.set_normalized(
            &mut *handle_ref.plugin,
            param_id_str,
            normalized_value,
        ) {
            Ok(_) => PluginError::Success,
            Err(e) => {
                set_last_error(&format!("Failed to set parameter: {}", e));
                PluginError::InvalidParameter
            }
        }
    }));

    result
        .unwrap_or_else(|_| {
            set_last_error("Panic in plugin_set_parameter");
            PluginError::UnknownError
        })
        .into()
}

/// Get a parameter value (normalized 0.0-1.0).
///
/// # Returns
/// * Normalized value on success
/// * -1.0 on error
///
/// # Safety
/// * `handle` must be a valid plugin handle that has not been destroyed.
/// * `param_id` must be a valid, null-terminated UTF-8 C string that remains
///   readable for the duration of this call.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_get_parameter(
    handle: *const PluginHandle,
    param_id: *const c_char,
) -> c_double {
    if handle.is_null() || param_id.is_null() {
        return -1.0;
    }

    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &*handle;

        let param_id_str = match CStr::from_ptr(param_id).to_str() {
            Ok(s) => s,
            Err(_) => return -1.0,
        };

        handle_ref
            .parameter_map
            .get_normalized(&*handle_ref.plugin, param_id_str)
            .unwrap_or(-1.0)
    }));

    result.unwrap_or(-1.0)
}

/// Get plugin information as a JSON string.
///
/// # Returns
/// * JSON string owned by the caller. It must be released with
///   [`plugin_free_string`] when no longer needed.
/// * `NULL` on error.
///
/// # Safety
/// * `handle` must be a valid plugin handle that has not been destroyed.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_get_info_json(handle: *const PluginHandle) -> *mut c_char {
    if handle.is_null() {
        return ptr::null_mut();
    }

    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &*handle;
        let info = handle_ref.plugin.info();

        let json = serde_json::json!({
            "name": info.name,
            "version": info.version,
            "author": info.author,
            "description": info.description,
            "input_channels": handle_ref.input_channels,
            "output_channels": handle_ref.output_channels,
            "latency_samples": handle_ref.plugin.latency_samples(),
        });

        match CString::new(json.to_string()) {
            Ok(s) => s.into_raw(),
            Err(_) => ptr::null_mut(),
        }
    }));

    result.unwrap_or(ptr::null_mut())
}

/// Free a string returned by the plugin.
///
/// # Safety
/// * `s` must be either `NULL` or a pointer previously returned by a function
///   documented as returning an owned string (for example [`plugin_get_info_json`],
///   [`plugin_ffi_platform_info_json`], or [`plugin_suggest_preset_filename`]).
/// * The pointer must not be freed more than once.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_free_string(s: *mut c_char) {
    if !s.is_null() {
        unsafe {
            let _ = CString::from_raw(s);
        }
    }
}

/// Save plugin state to a JSON byte buffer.
///
/// # Returns
/// * Pointer to an allocated buffer owned by the caller on success. It must be
///   released with [`plugin_free_state`] when no longer needed.
/// * `NULL` on error.
///
/// # Safety
/// * `handle` must be a valid plugin handle that has not been destroyed.
/// * `out_len` must be a valid pointer to `usize` that this call may write.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_save_state(handle: *const PluginHandle, out_len: *mut usize) -> *mut u8 {
    if handle.is_null() || out_len.is_null() {
        return ptr::null_mut();
    }

    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &*handle;
        let state = plugins_bridge::state::save_state(&*handle_ref.plugin);
        let len = state.len();
        let ptr = state.as_ptr();

        // Allocate and copy to a buffer the caller can free
        let buf = libc_malloc(len);
        if buf.is_null() {
            return ptr::null_mut();
        }
        std::ptr::copy_nonoverlapping(ptr, buf, len);
        *out_len = len;
        buf
    }));

    result.unwrap_or(ptr::null_mut())
}

/// Load plugin state from a JSON byte buffer.
///
/// Restoration is transactional: failure leaves the live instance unchanged.
/// Success replaces the DSP instance, restarting its processing history while
/// retaining constructor configuration and parameter values omitted by `data`.
/// This operation may allocate, load resources, and stop worker threads.
///
/// # Returns
/// * 0 on success
/// * Error code on failure
///
/// # Safety
/// * `handle` must be a valid plugin handle that has not been destroyed.
/// * `data` must point to `len` bytes of valid JSON that remain readable for
///   the duration of this call.
/// * Call on a control thread with no concurrent access to `handle`, including
///   audio processing or parameter access.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_load_state(
    handle: *mut PluginHandle,
    data: *const u8,
    len: usize,
) -> c_int {
    if handle.is_null() || data.is_null() {
        set_last_error("NULL pointer in plugin_load_state");
        return PluginError::NullPointer.into();
    }

    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &mut *handle;
        let slice = slice::from_raw_parts(data, len);

        let load_result = replace_plugin_from_state(handle_ref, slice);
        match load_result {
            Ok(_) => PluginError::Success,
            Err(e) => {
                set_last_error(&format!("Failed to load state: {e}"));
                PluginError::InvalidConfig
            }
        }
    }));

    result
        .unwrap_or_else(|_| {
            set_last_error("Panic in plugin_load_state");
            PluginError::UnknownError
        })
        .into()
}

/// Free a state buffer returned by [`plugin_save_state`] or
/// [`plugin_export_preset_json`].
///
/// # Safety
/// * `data` must be either `NULL` or a pointer previously returned by a
///   function documented as returning an owned byte buffer, with the same
///   `len` value that was written to the associated `out_len` pointer.
/// * The pointer must not be freed more than once.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_free_state(data: *mut u8, len: usize) {
    if !data.is_null() && len > 0 {
        libc_free(data, len);
    }
}

/// Export a named preset document as JSON bytes.
///
/// The returned buffer uses the preset document schema advertised by
/// [`plugin_preset_document_info`] and must be freed with [`plugin_free_state`].
///
/// # Safety
/// * `handle` must be a valid plugin handle that has not been destroyed.
/// * `preset_name` may be `NULL` or must be a valid, null-terminated UTF-8 C
///   string that remains readable for the duration of this call.
/// * `out_len` must be a valid pointer to `usize` that this call may write.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_export_preset_json(
    handle: *const PluginHandle,
    preset_name: *const c_char,
    out_len: *mut usize,
) -> *mut u8 {
    if handle.is_null() || out_len.is_null() {
        return ptr::null_mut();
    }

    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &*handle;
        let name = if preset_name.is_null() {
            "Untitled"
        } else {
            CStr::from_ptr(preset_name).to_str().unwrap_or("Untitled")
        };
        let state = plugins_bridge::state::save_state(&*handle_ref.plugin);
        let info = handle_ref.plugin.info();
        let document = serde_json::json!({
            "schema_version": 1,
            "ut_type": PRESET_UT_TYPE_JSON,
            "file_extension": "sotfpreset",
            "preset_name": name,
            "plugin_type": handle_ref.plugin_type,
            "plugin_name": info.name,
            "plugin_version": info.version,
            "state": state,
        });
        let bytes = match serde_json::to_vec(&document) {
            Ok(bytes) => bytes,
            Err(err) => {
                set_last_error(&format!("Failed to serialize preset document: {err}"));
                return ptr::null_mut();
            }
        };
        copy_bytes_to_ffi_buffer(&bytes, out_len)
    }));

    result.unwrap_or_else(|_| {
        set_last_error("Panic in plugin_export_preset_json");
        ptr::null_mut()
    })
}

/// Import a JSON preset document created by [`plugin_export_preset_json`].
///
/// Uses the transactional, control-thread restoration behavior documented by
/// [`plugin_load_state`].
///
/// # Safety
/// * `handle` must be a valid plugin handle that has not been destroyed.
/// * `data` must point to `len` bytes of valid preset JSON that remain readable
///   for the duration of this call.
/// * Call on a control thread with no concurrent access to `handle`.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_import_preset_json(
    handle: *mut PluginHandle,
    data: *const u8,
    len: usize,
) -> c_int {
    if handle.is_null() || data.is_null() {
        set_last_error("NULL pointer in plugin_import_preset_json");
        return PluginError::NullPointer.into();
    }
    if len > MAX_PRESET_JSON_IMPORT_BYTES {
        set_last_error(&format!(
            "Preset JSON exceeds {} byte import limit",
            MAX_PRESET_JSON_IMPORT_BYTES
        ));
        return PluginError::InvalidConfig.into();
    }

    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &mut *handle;
        let slice = slice::from_raw_parts(data, len);
        let document: serde_json::Value = match serde_json::from_slice(slice) {
            Ok(document) => document,
            Err(err) => {
                set_last_error(&format!("Invalid preset JSON: {err}"));
                return PluginError::InvalidConfig;
            }
        };

        if document
            .get("schema_version")
            .and_then(serde_json::Value::as_u64)
            != Some(1)
        {
            set_last_error("Preset JSON schema_version must be integer 1");
            return PluginError::InvalidConfig;
        }
        if document.get("ut_type").and_then(serde_json::Value::as_str) != Some(PRESET_UT_TYPE_JSON)
        {
            set_last_error("Preset JSON has an unsupported ut_type");
            return PluginError::InvalidConfig;
        }
        let Some(preset_plugin_type) = document
            .get("plugin_type")
            .and_then(serde_json::Value::as_str)
        else {
            set_last_error("Preset JSON is missing a string plugin_type");
            return PluginError::InvalidConfig;
        };
        if !super::plugin_factory::preset_import_type_matches_target(
            &handle_ref.plugin_type,
            preset_plugin_type,
        ) {
            set_last_error("Preset plugin_type does not match the current plugin family");
            return PluginError::InvalidConfig;
        }

        let Some(state_values) = document.get("state").and_then(|state| state.as_array()) else {
            set_last_error("Preset JSON is missing a state byte array");
            return PluginError::InvalidConfig;
        };
        if state_values.len() > MAX_PRESET_STATE_BYTES {
            set_last_error(&format!(
                "Preset state exceeds {} byte limit",
                MAX_PRESET_STATE_BYTES
            ));
            return PluginError::InvalidConfig;
        }

        let mut state = Vec::with_capacity(state_values.len());
        for value in state_values {
            let Some(byte) = value.as_u64().and_then(|v| u8::try_from(v).ok()) else {
                set_last_error("Preset state contains a non-byte value");
                return PluginError::InvalidConfig;
            };
            state.push(byte);
        }

        let state = if matches!(
            handle_ref.plugin_type.as_str(),
            "DynamicEQ" | "dynamic_eq" | "dynamic-eq"
        ) {
            match super::plugin_factory::add_dynamic_eq_preset_shelf_defaults(&state) {
                Ok(state) => state,
                Err(error) => {
                    set_last_error(&format!("Invalid DynamicEQ preset state: {error}"));
                    return PluginError::InvalidConfig;
                }
            }
        } else {
            state
        };

        let load_result = replace_plugin_from_state(handle_ref, &state);
        match load_result {
            Ok(_) => PluginError::Success,
            Err(e) => {
                set_last_error(&format!("Failed to import preset state: {e}"));
                PluginError::InvalidConfig
            }
        }
    }));

    result
        .unwrap_or_else(|_| {
            set_last_error("Panic in plugin_import_preset_json");
            PluginError::UnknownError
        })
        .into()
}

/// Suggest a filesystem-safe preset filename.
///
/// # Returns
/// * Owned string that the caller must release with [`plugin_free_string`].
/// * `NULL` on error.
///
/// # Safety
/// * `handle` must be a valid plugin handle that has not been destroyed.
/// * `preset_name` may be `NULL` or must be a valid, null-terminated UTF-8 C
///   string that remains readable for the duration of this call.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_suggest_preset_filename(
    handle: *const PluginHandle,
    preset_name: *const c_char,
) -> *mut c_char {
    if handle.is_null() {
        return ptr::null_mut();
    }

    let result = panic::catch_unwind(AssertUnwindSafe(|| unsafe {
        let handle_ref = &*handle;
        let name = if preset_name.is_null() {
            "Untitled"
        } else {
            CStr::from_ptr(preset_name).to_str().unwrap_or("Untitled")
        };
        let plugin = sanitize_filename_component(&handle_ref.plugin_type);
        let preset = sanitize_filename_component(name);
        CString::new(format!("{plugin}-{preset}.sotfpreset"))
            .map(CString::into_raw)
            .unwrap_or(ptr::null_mut())
    }));

    result.unwrap_or(ptr::null_mut())
}

/// Get the list of available plugin types as a JSON array string.
///
/// # Returns
/// * JSON array string owned by the caller. It must be released with
///   [`plugin_free_string`] when no longer needed.
/// * `NULL` on error.
#[unsafe(no_mangle)]
pub extern "C" fn plugin_available_types() -> *mut c_char {
    let types = plugins_bridge::factory::available_plugin_types();
    let json = serde_json::json!(types);
    match CString::new(json.to_string()) {
        Ok(s) => s.into_raw(),
        Err(_) => ptr::null_mut(),
    }
}
