# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Faithful Kautz room correction (`req-math-audio-kautz.md`):
  `KautzCorrection` dry-plus-bank model (`H = 1 + Σ g·B`, signed linear
  gains, strength scaling, bypass, allocation-free sample/block
  processing, validated rate rebuild) with the legacy bank-only API
  untouched; checked Gauss-Newton fitting (`fit_correction`) against the
  realized complex magnitude with log-equal weighting, normalization
  policy, composite boost/cut/neutrality/band guards, before/after
  objective and absolute-error diagnostics with honest termination
  statuses; versioned plugin-bank
  spec (`kautz-correction-v1`) with legacy field aliases and structured
  refusal. Limits documented by test: magnitude-only fitting can settle
  in phase-flipped local minima; sampled guards do not certify the
  continuum.
- `peq_spl_into` and `compute_peq_response_into`: PEQ response evaluation
  into caller-owned buffers so optimisation workers can reuse scratch
  space without allocating in the hot path.

### Fixed
- `suppress_pre_ringing` now applies a smooth time-varying cap (audible
  threshold near the main impulse fading cosinusoidally to zero at the
  time limit) instead of blending toward a clamped value; pre-ring energy
  beyond the threshold decays monotonically with distance from the main tap.

### Performance
- x86_64 AVX2/FMA fast paths for biquad DF1 `process_block` and FIR
  general/symmetric convolution (~87 → ~150 Msamples/s on the filter
  bench); aarch64 NEON 8-output symmetric-FIR block path and unrolled DF1
  scalar path (+12% aggregate throughput, bit-identical checksums).

## [0.5.23] - 2026-09-09

### Fixed

- Kirkeby correction now uses the original frequency coordinates for correction-band
  transitions instead of scratch-buffer values overwritten during minimum-phase extraction.
- Minimum-phase extraction now mirrors the DC-to-Nyquist log-magnitude spectrum
  into an even periodic spectrum and uses its exact transform length. A common
  measurement/target SPL calibration offset no longer introduces spurious phase.
- Added regressions for common SPL calibration invariance and all-pass excess-phase
  correction. These fixes do not establish end-to-end hybrid correction quality.

## [0.5.22] - 2026-09-08

### Added
- Shared `Crossover` API with selectable Butterworth, Linkwitz–Riley, and
  cascaded Bessel families at orders 2 and 4, plus fourth-order Neville–Thiele
  with notch parameter 0.5. Supports `f32` and `f64`, independent channel state,
  allocation-free sample/frame processing, frequency updates, and state reset.
- Documented crossover normalization and summing polarity, including the
  approximately 1.37 dB summation dip of fourth-order cascaded Bessel and the
  stopband notches of Neville–Thiele. Existing crossover APIs remain available.
- `FirError` and fallible `Fir::try_*` constructors; the infallible
  constructors now panic via `expect` in all build profiles instead of
  `debug_assert`-only validation.

### Changed
- Filter-bank evaluation uses the buffer-reusing `np_log_result_into` path.
- `Biquad::process_block` now enables FTZ/DAZ for the block duration;
  per-sample `process` documents caller-owned denormal handling
  (see the FTZ policy in `denormals`).

## [0.5.16] - 2026-07-10

### Fixed
- `Biquad::new` and `Biquad::update_params` now sanitize invalid sample rates,
  gains, and out-of-band frequencies, keeping fallback coefficients finite and
  non-degenerate inside the open Nyquist interval.
- Windowed-sinc bandpass filters are normalized at band center and bandstop
  filters at DC, giving exact unity gain at their reference passband points.
- Kirkeby correction transition widths now track FFT-bin resolution and are
  capped by configured correction-band edges instead of using a fixed 10 Hz.

### Changed
- Clarified that coefficient interpolation between stable real biquads remains
  stable for interpolation factors in `[0, 1]`.
- Corrected Kautz documentation to describe the implemented fixed-pole resonant
  basis rather than an unimplemented complete orthonormal pair.
- Corrected `filtfilt` documentation to describe its odd-padding and cumulative
  per-section steady-state initialization instead of a Gustafsson global solve.
- Clarified that response-based FIR design accepts negative dB cuts while phase
  is intentionally selected separately by `FirPhase`.

## [0.5.14] - 2026-05-30

### Changed
- `generate_fir_from_response` now validates that frequency points are finite,
  positive, non-empty, and strictly increasing, and that target magnitudes are
  finite before log-frequency interpolation.
- Updated Kautz documentation to describe the QR-based regularized
  least-squares solve.
- Documented the rare symmetric-numerator fallback used by Orfanidis shelves
  and PeakMatched filters when their quadratic split is near-degenerate.
- Clarified that K-weighting is an approximation and documented
  `ScopedFlushToZero` FTZ/DAZ behavior across architectures.

## [0.5.13] - 2025-05-13

### Changed
- Optimised initialization of parameters.

## [0.5.12] - 2025-05-13

### Added
- Added support for linear phase crossover.
- Exposed `DEFAULT_FIR_CROSSOVER_TAPS` plus lowpass/highpass coefficient
  accessors on `FirCrossover`.
- Added Warped Linear Predictive Coding (LPC).
- Added Kautz filters.

### Fixed
- `warped_biquad`: `compute_implicit_consts` now uses a type-aware threshold
  (`T::epsilon() * 1000 * coeff_scale`) instead of a hard-coded `1e-15`,
  preventing huge `inv_denom` values for small denominators in `f32` (#3).
- `kautz`: `optimize_gains` now solves the regularized least-squares problem
  via QR on the augmented system instead of normal equations + Cholesky.
  Regularization strength increased from `1e-6` to `1e-4` (#4).
- `filtfilt`: default padding multiplier increased from `3` to `6`. Added
  `filtfilt_with_padlen` for explicit padding control (#8).

## [0.5.10] - 2025-05-13

### Added
- Added missing LR8 crossovers.
- Added ZDF (Zero-Delay Feedback) state variable filter.

## [0.5.9] - 2025-05-13

### Added
- Added `BiquadBank` (can pack 2 or 4 operations in 1 clock depending on hardware).
- Added PeakMatched filters (Vicanek matched analog response).
